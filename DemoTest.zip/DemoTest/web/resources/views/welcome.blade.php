<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/3/2016
 * Time: 10:21 AM
 */
?>

@extends('layout.master')

@section('head')
    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }

        .error {
            color: #FB0007;
        }

        .shop-pic, #signUp {
            display: none;
            text-align: center;
        }
    </style>
@endsection

@section('content')
    <div id="loading">
        <div class="svg-icon-loader">
            <img src="assets/admin/images/bars.svg" width="40" alt="loader">
        </div>
    </div>
    <div class="center-vertical login-bg">
        <div class="center-content">
            <form action="/login" class="col-md-4 col-sm-5 col-xs-11 col-lg-3 center-margin"
                  method="post">
                {{ csrf_field() }}
                <div id="header-logo" class="logo-bg"
                     style="background-color: white; border-radius: 8px 8px 0px 0px; margin: 0px 0px -2px; height: 62px;">
                    {{--<a href="/" title="{{Config::get('app.APPLICATION_NAME')}}">--}}
                        {{--<img src="assets/admin/images/logo.png"--}}
                             {{--style="float: left; width: 45px; margin: 14px 0px 0px 17px;"/>--}}
                        {{--<img src="assets/admin/images/logo_text.png" style="width: 250px; margin: 17px 0px 0px;"/>--}}
                    {{--</a>--}}
                </div>
                <div id="login-form" class="content-box bg-default">
                    <div class="content-box-wrapper pad20A">
                        <center>
                            <img class="mrg25B center-margin radius-all-100 login-user-pic admin-pic"
                                 src="assets/admin/images/default_admin.png" alt="Admin"/>
                            <img class="mrg25B center-margin radius-all-100 login-user-pic shop-pic"
                                 src="assets/admin/images/default_shopper.png" alt="shopkeeper"/>
                        </center>
                        <span class="error">{{ $errors->authError->first() }}</span>
                        <span class="error"> {{ $errors->login->first('role') }}</span>
                        <div class="form-group" style="display: inline-flex;">
                            <div class="radio-danger">
                                <label>
                                    <input type="radio" name="role" class="custom-radio" id="role_admin"
                                           value="3" checked @if(old('role')==3) checked @endif/> Admin
                                </label>
                            </div>
                            <div class="radio-danger">
                                <label>
                                    <input type="radio" name="role" class="custom-radio" id="role_shopkeeper"
                                           value="2" @if(old('role')==2) checked @endif/>
                                    ShopKeeper
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-envelope-o"></i></span>
                                <input type="text" name="email" class="form-control"
                                       placeholder="Enter email" value="{{ old('email') }}"/>
                                <span class="error"> {{ $errors->login->first('email') }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                                <input type="password" name="password" class="form-control"
                                       placeholder="Password"/>
                                <span class="error"> {{ $errors->login->first('password') }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary">Login</button>
                        </div>
                        <div class="form-group" id="signUp">
                            Don't have an Account ? <a href="/signUP" class="text-theme"><b>SIGNUP</b></a> here
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')

    <script>
        $(document).ready(function () {

            if ($("#role_admin:checked").val()) {
                $('.admin-pic').show();
                $('.shop-pic').hide();
                $('#signUp').hide();
            }
            else {
                if ($("#role_shopkeeper:checked").val()) {
                    $('.admin-pic').hide();
                    $('.shop-pic').show();
                    $('#signUp').show();
                }
            }
        });

        $("#role_admin").change(function () {
            if (this.checked) {
                $('.admin-pic').show();
                $('.shop-pic').hide();
                $('#signUp').hide();
            }
        });
        $("#role_shopkeeper").change(function () {
            if (this.checked) {
                $('.admin-pic').hide();
                $('.shop-pic').show();
                $('#signUp').show();
            }
        });

    </script>

@endsection