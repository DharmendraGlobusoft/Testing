<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/14/2016
 * Time: 1:07 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th {
            width: auto !important;
        }

        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5),
        th:nth-child(6), th:nth-child(7), th:nth-child(8), th:nth-child(9), th:nth-child(10) {
            text-align: center !important;
            vertical-align: top !important;
        }

        td:nth-child(1), td:nth-child(2), td:nth-child(6), td:nth-child(7), td:nth-child(8),
        td:nth-child(9),  td:nth-child(10) {
            text-align: center !important;
        }

    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">Product details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Add Product in Your shop</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <span style="color:#FB0007;" id="errorMsg">Sorry ! this product has not added in this shop.</span>
                                <span style="color:green;" id="successMsg">This product has been successfully added in this shop.</span>
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Product</label>
                                        <div class="col-sm-9">
                                            <select id="selectProduct" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Product</option>
                                                @if($unAssignProductList != null)
                                                    @foreach($unAssignProductList as $value)
                                                        <option value="{{$value->product_id}}">{{$value->product_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                            <span style="color:#FB0007;" id="productError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Enter the Quantity</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="addQuantity" class="form-control"
                                                   id="addQuantity"
                                                   placeholder="Enter the Quantity"/>
                                            <span style="color:#FB0007;" id="quantityError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>ADD</span> <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Product List of Your Shop</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Assigned Date</th>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Sub Product Name</th>
                                <th>Main Product Name</th>
                                <th>Stock Quantity</th>
                                <th>Activation Status</th>
                                <th>Edit Stock Quantity</th>
                                <th>Remove Product</th>
                                <th>View Details</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')
    <div class="modal fade" id="updateStockQuantityModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Stock Quantity</h4>
                </div>
                <form class="form-horizontal bordered-row" action="" method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Product Name</label>
                            <div class="col-sm-8" id="productNameContent" style="cursor: not-allowed">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Stock Quantity</label>
                            <div class="col-sm-8">
                                <input type="text" name="stockQuantity"
                                       id="stockQuantity" class="form-control" data-oldStockQuantity="" value=""/>
                                <span style="color:#FB0007;" id="stock_quantityError"></span>
                            </div>
                        </div>
                    </div>
                    <br>
                    <span id="updateError" style="color: #FB0007; margin-left: 153px;"></span>
                    <span id="updateSuccess" style="color: green;"></span>
                    <div class="modal-footer" id="setUpdateButton">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="removeProductModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Remove this product from the shop</h4>
                </div>
                <form class="form-horizontal bordered-row" action="" method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-sm-9 control-label" style="color:red;">Are you really want to remove this
                                product from your shop ?</label>
                        </div>
                    </div>
                    <br>
                    <div class="modal-footer" id="setRemoveButton">
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {

            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $("#successMsg, #errorMsg").hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "destroy": true,
                "ajax": {
                    "url": "/viewProductList",
                    "type": "POST",
                    "async": "True",
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [5, 6, 7, 8, 9]}]
            });

            // This function use for add new product to a shop with stock quantity.
            $(document.body).on('click', '#addButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewProductListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'assignProductToShop',
                        productId: $('#selectProduct').val(),
                        quantity: $('#addQuantity').val()
                    },
                    success: function (response) {

                        $('#shopError, #productError, #quantityError').html('');
                        $('#successMsg , #errorMsg').hide();

                        if (response == 'success') {

                            $('#successMsg').show();
                            $('#successMsg').delay(3000).fadeOut();
                            $('#addQuantity').val('');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            $.ajax({
                                url: "/viewProductListAjax",
                                type: "POST",
                                dataType: 'JSON',
                                data: {
                                    action: 'getUnassignedProductList',
                                },
                                success: function (response) {
                                    if (response != 'fail') {
                                        var option = '';
                                        $.each(response, function (key, value) {
                                            option = option + '<option value="' + value.product_id + '">' + value.product_name + '</option>';
                                        });

                                        $('#selectProduct').html('');
                                        $('#selectProduct').html('<option disabled selected>Select Product</option>' + option);
                                        $('#selectProduct').select2();
                                    }
                                    else {
                                        $('#selectProduct').html('');
                                        $('#selectProduct').html('<option disabled selected>Select Product</option>');
                                        $('#selectProduct').select2();
                                    }
                                }
                            });

                        }
                        else if (response == 'fail')
                            $('#errorMsg').show();
                        else {
                            $.each(response, function (key, value) {
                                $('#' + key + 'Error').html(value[0]);
                            });
                        }
                    },
                    error: function (req, status, err) {
                        $('#shopError, #productError, #quantityError').html('');
                        $('#successMsg , #errorMsg').hide();
                    }
                });
            });

            // This function use for only show update modal with Product information.
            $(document.body).on('click', '#updateStockQuantity', function (event) {
                event.preventDefault();
                $('#updateSuccess').html('');
                $("#updateError").html('');
                $("#stock_quantityError").html('');

                $('#productNameContent').html('<label dataModal-productId="' + $(this).attr("data-productId") + '" id="productName" class="form-control" style="cursor: not-allowed"> ' +
                        $(this).attr("data-productName") +
                        '</label>');
                $('#stockQuantity').val($(this).attr("data-stockQuantity"));
                $('#stockQuantity').attr("data-oldStockQuantity", $(this).attr("data-stockQuantity"));

                $('#setUpdateButton').html('<button id="updateStockQuantityButton" class="btn btn-alt btn-hover btn-primary">' +
                        ' <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>' +
                        ' <button id="cancelStockQuantityButton" class="btn btn-alt btn-hover btn-info" data-dismiss="modal">' +
                        ' <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>');

            });

            // This function use for update particular Product Stock Quantity.
            $(document.body).on('click', '#updateStockQuantityButton', function (event) {
                event.preventDefault();
                $('#updateSuccess').html('');
                $("#updateError").html('');
                $("#stock_quantityError").html('');

                $.ajax({
                    url: '/viewProductListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'updateStockQuantity',
                        productId: $('#productName').attr("dataModal-productId"),
                        oldStockQuantity: $('#stockQuantity').attr("data-oldStockQuantity"),
                        newStockQuantity: $('#stockQuantity').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $("#stock_quantityError").html('');
                            $('#updateSuccess').html('Product quantity has been successfully updated.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function () {
                                $("#updateStockQuantityModal").fadeOut();
                                setTimeout(function () {
                                    $("#cancelStockQuantityButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else
                            if (response == 'fail')
                                $("#updateError").html('Sorry ! Product quantity has not updated.');
                            else {
                                $.each(response, function (key, value) {
                                    $('#' + key + 'Error').html(value[0]);
                                });
                            }
                    },
                    error: function (req, status, err) {
                        $("#updateError").html('Sorry ! Product quantity has not updated.');
                    }
                }); //End of  ajax
            });

            // This function use for only show remove modal.
            $(document.body).on('click', '#removeProduct', function (event) {
                event.preventDefault();

                $('#setRemoveButton').html('<button data-shopId="' + $(this).attr("data-shopId") + '" data-productId="' + $(this).attr("data-productId") + '" ' +
                        'data-stockQuantity ="' + $(this).attr("data-stockQuantity") + '" id="removeButton" class="btn btn-alt btn-hover btn-primary">' +
                        ' <span>Yes</span> <i class="glyph-icon icon-arrow-right"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>' +
                        ' <button id="cancelRemoveButton" class="btn btn-alt btn-hover btn-info" data-dismiss="modal">' +
                        ' <span>No</span> <i class="glyph-icon icon-remove"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>');

            });

            // This function use for remove particular Product from shop.
            $(document.body).on('click', '#removeButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewProductListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'removeProduct',
                        shopId: $(this).attr("data-shopId"),
                        productId: $(this).attr("data-productId"),
                        stockQuantity: $(this).attr("data-stockQuantity"),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function () {
                                $("#removeProductModal").fadeOut();
                                setTimeout(function () {
                                    $("#cancelRemoveButton").trigger("click");
                                }, 400);
                            }, 100);


                            $.ajax({
                                url: "/viewProductListAjax",
                                type: "POST",
                                dataType: 'JSON',
                                data: {
                                    action: 'getUnassignedProductList',
                                },
                                success: function (response) {
                                    if (response != 'fail') {
                                        var option = '';
                                        $.each(response, function (key, value) {
                                            option = option + '<option value="' + value.product_id + '">' + value.product_name + '</option>';
                                        });

                                        $('#selectProduct').html('');
                                        $('#selectProduct').html('<option disabled selected>Select Product</option>' + option);
                                        $('#selectProduct').select2();
                                    }
                                    else {
                                        $('#selectProduct').html('');
                                        $('#selectProduct').html('<option disabled selected>Select Product</option>');
                                        $('#selectProduct').select2();
                                    }
                                }
                            });

                        }
                        else {
                            console.log('Sorry ! Product has not removed.');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Sorry ! Product has not removed.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection
