<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 5:07 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('content')

    <div id="page-title">
        <h2 id="viewShop"><i class="glyph-icon icon-linecons-eye"></i> View shop Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newShopForm" class="form-horizontal bordered-row" action="" method="post">
            {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label"> Location </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Country</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['country_name']!= null)
                                                        {{$shopData['country_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">State</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['state_name']!= null)
                                                        {{$shopData['state_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">City</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['city_name']!= null)
                                                        {{$shopData['city_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Street</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['street_name']!= null)
                                                        {{$shopData['street_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:188px;">
                                                <label id="viewShop" class="control-label">Shop Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Name</label>
                                            </td>
                                            <td>
                                                <label id="viewShop" class="form-control" style="width:100%;">
                                                    @if($shopData['shop_name']!= NULL)
                                                        {{$shopData['shop_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        @if($shopData['shop_image']!= null)
                                                            <img src="{{$shopData['shop_image']}}">
                                                            <input type="hidden" value="{{$shopData['shop_image']}}" name="shopImagePath">
                                                        @else
                                                            <img src="http://placehold.it/200x150">
                                                        @endif
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:188px;">
                                                <label id="viewShop" class="control-label">Shopkeeper
                                                    Detail</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label id="viewShop" class="control-label">
                                                    Shopkeeper Id & Name
                                                </label>
                                            </td>
                                            <td>
                                                <label id="viewShop" class="form-control" style="width:100%;">
                                                    @if($shopData['shopkeeper_meta_id']!= null && $shopData['first_name']!= null)
                                                        {{$shopData['id']}}. {{$shopData['first_name']}}
                                                    @else
                                                        Not Assigned
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shopkeeper Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: auto; height: 150px;">
                                                        @if($shopData['shopkeeper_image']!= null)
                                                            <img src="{{$shopData['shopkeeper_image']}}">
                                                        @else
                                                            <img src="{{Config::get('app.WEB_HOST')}}assets/shopkeeper/ProfilePic.jpg">
                                                        @endif
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="buttonBar" class="col-md-11" style="text-align: center; width: 100%;">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <div class="form-group">
                                        <button id="viewShop"
                                                class="btn btn-alt btn-hover btn-info viewListButton">
                                            <span>View Shop List</span>
                                            <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('script')
    <script>
        $(document).ready(function () {
            $(document.body).on("click", '.viewListButton', function (event) {
                event.preventDefault();
                window.location.replace('/viewShopList');
            });
        });
    </script>
@endsection
