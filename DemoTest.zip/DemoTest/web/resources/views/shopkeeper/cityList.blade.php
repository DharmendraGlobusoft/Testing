<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 8:41 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3){
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">City Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Select State</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Country</label>
                                        <div class="col-sm-9">
                                            <select id="selectCountry" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Country</option>
                                                @if($country != null)
                                                    @foreach($country as $value)
                                                        <option value="{{$value->country_id}}">{{$value->country_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the State</label>
                                        <div class="col-sm-9">
                                            <select id="selectState" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select State</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">City List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>City Id</th>
                                <th>City Name</th>
                                <th>Activation Status</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {

            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for fetch State list according to Country id.
            // And display it in drop down select tag.
            $(document.body).on("change", '#selectCountry', function () {
                $('#datatable').DataTable({ "destroy": true}).destroy();
                $('tbody').empty();

                var countryId = $(this).val();
                $.ajax({
                    url: "/viewCityListAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getStateList',
                        countryId: countryId
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            var option = '';
                            $.each(response, function (key, value) {
                                option = option + '<option value="' + value.state_id + '">' + value.state_name + '</option>';
                            });

                            $('#selectState').html('');
                            $('#selectState').html('<option disabled selected>Select State</option>' + option);
                            $('#selectState').select2();
                        }
                        else {
                            $('#selectState').html('');
                            $('#selectState').html('<option disabled selected>Select State</option>');
                            $('#selectState').select2();
                        }
                    }
                });
            });

            //This function use for fetch City list according to state id.
            // And display it in dataTable.
            $(document.body).on('change', '#selectState', function (event) {
                event.preventDefault();

                $('#addCityName').attr('data-stateId', $(this).val());

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                    "ajax": {
                        "url": "/viewCityList",
                        "type": "POST",
                        "async": "True",
                        data: {
                            stateId: $(this).val()
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [2]}]
                });

            });
        });
    </script>
@endsection
