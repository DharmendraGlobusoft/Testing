<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 7:11 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <style>
        th {
            width: auto !important;
        }

        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7) {
            text-align: center !important;
        }

        td:nth-child(4), td:nth-child(5), td:nth-child(6), td:nth-child(7) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">User details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">User List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>User Id</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Activation Status</th>
                                <th>View Details</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')

    <div class="modal fade" id="userDetailModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                    <h4 class="modal-title">User Details</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">First Name</span>
                                <br/>
                                <strong id="first_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Age</span>
                                <br/>
                                <strong id="age"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Address</span>
                                <br/>
                                <strong id="address"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Picture</span>
                                <br/>
                                <img id="image" src="" class="img-thumbnail" style="width:35%;"/>
                                <img id="default_image"
                                     src="{{ Config::get('app.API_HOST') }}profilePicture/ProfilePic.jpg"
                                     class="img-thumbnail" style="width:35%;"/>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">Last Name</span>
                                <br/>
                                <strong id="last_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Gender</span>
                                <br/>
                                <strong id="gender"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Mobile Number</span>
                                <br/>
                                <strong id="contact_number"></strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "/viewUserList",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [3, 4]}]
            });

            // This function use for view all details of a particular user.
            $(document.body).on('click', '#viewUserDetail', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewUserListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'viewUserDetail',
                        userId: $(this).attr("value"),
                    },
                    success: function (response) {
                        if (response != 'fail') {

                            if (response.first_name == null || response.first_name == '')
                                response.first_name = 'Not Available';

                            if (response.last_name == null || response.last_name == '')
                                response.last_name = 'Not Available';

                            if (response.age == null || response.age == '')
                                response.age = 'Not Available';
                            else
                                response.age = response.age + ' yrs';

                            if (response.gender == 1)
                                response.gender = 'Male';
                            else
                                if (response.gender == 2)
                                    response.gender = 'Female';

                            if (response.address == null || response.address == '')
                                response.address = 'Not Available';

                            if (response.contact_number == null || response.contact_number == '')
                                response.contact_number = 'Not Available';

                            if (response.image == null || response.image == '')
                            {
                                $('#image').hide();
                                $('#default_image').show();
                            }
                            else
                            {
                                $('#default_image').hide();
                                $('#image').attr('src', response.image);
                                $('#image').show();
                            }

                            $('#first_name').html(response.first_name);
                            $('#last_name').html(response.last_name);
                            $('#age').html(response.age);
                            $('#gender').html(response.gender);
                            $('#address').html(response.address);
                            $('#contact_number').html(response.contact_number);

                        }
                        else {
                            $('#first_name').html('Not Available');
                            $('#last_name').html('Not Available');
                            $('#age').html('Not Available');
                            $('#gender').html('Not Available');
                            $('#address').html('Not Available');
                            $('#contact_number').html('Not Available');
                            $('#image').hide();
                            $('#default_image').show();
                        }
                    },
                    error: function (req, status, err) {
                        $('#first_name').html('Not Available');
                        $('#last_name').html('Not Available');
                        $('#age').html('Not Available');
                        $('#gender').html('Not Available');
                        $('#address').html('Not Available');
                        $('#contact_number').html('Not Available');
                        $('#image').hide();
                        $('#default_image').show();
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection
