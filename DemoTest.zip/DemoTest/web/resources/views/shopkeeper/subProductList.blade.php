<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/14/2016
 * Time: 3:23 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3){
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3){
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Sub Product Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Select Main Product</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Main Product</label>
                                        <div class="col-sm-9">
                                            <select id="selectMainProduct" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Main Product</option>
                                                @if($mainProduct != null)
                                                    @foreach($mainProduct as $value)
                                                        <option value="{{$value->main_product_id}}">{{$value->product_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Sub Product List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Sub Product Id</th>
                                <th>Sub Product Name</th>
                                <th>Activation Status</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {
            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for fetch Sub Product list according to Main Product id.
            // And display it in dataTable.
            $(document.body).on('change', '#selectMainProduct', function (event) {
                event.preventDefault();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                    "ajax": {
                        "url": "/viewSubProduct",
                        "type": "POST",
                        "async": "True",
                        data: {
                            mainProductId: $(this).val()
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [2]}]
                });
            });
        });
    </script>
@endsection


