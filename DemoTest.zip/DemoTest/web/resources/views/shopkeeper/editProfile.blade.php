<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 3:58 PM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <link rel="stylesheet" href="assets/contactNumber/css/intlTelInput.css">
    <style>
        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2>Profile Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="example-box-wrapper">
                <ul class="list-group row list-group-icons">
                    <li class="col-md-3 active">
                        <a href="javascript:;" data-toggle="tab" class="list-group-item"><i
                                    class="glyph-icon font-red icon-user"></i> Personal Information</a>
                    </li>
                    <li style="text-align: center">
                        <span class="error">@if(isset($dataFetchFail)){{ $dataFetchFail}}@endif</span>
                        <span class="error">{{ $errors->fail->first()}}</span>
                        <span class="success">@if(isset($userData['success'])){{$userData['success']}}@endif</span>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane pad0A fade active in">
                        <div class="content-box">
                            <form class="form-horizontal pad15L pad15R bordered-row"
                                  action="/editShopkeeperProfile"
                                  method="post">
                                {{ csrf_field() }}
                                <div class="form-group remove-border">
                                    <label class="col-sm-3 control-label">First Name</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" name="firstName"
                                               placeholder="Enter First Name" maxlength="50"
                                               @if(!empty(Session::get('_old_input')))value="{{ old('firstName') }}"
                                               @else @if($userData['first_name'])
                                               value="{{ $userData['first_name'] }}"
                                               @else value="{{ $userData['name'] }}"
                                                @endif
                                                @endif >
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('first_name') }}</span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Last Name</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" name="lastName"
                                               placeholder="Enter Last Name" maxlength="50"
                                               @if(!empty(Session::get('_old_input')))value="{{ old('lastName') }}"
                                               @else @if($userData['last_name'])
                                               value="{{ $userData['last_name'] }}"
                                                @endif
                                                @endif >
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('last_name') }}</span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Email:</label>
                                    <div class="col-sm-6">
                                        <input type="email" class="form-control" name="email" readonly=""
                                               @if($userData['email']) value="{{ $userData['email'] }}" @endif >
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('email') }}</span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Contact Number</label>
                                    <div class="col-sm-6">
                                        <input id="phone" type="tel" name="phone" class="form-control"
                                               style="width:191% !important;"
                                               placeholder="Enter your contact number" value="{{old('phone-full')}}">
                                        <input id="hidden" type="hidden" name="phone-full"
                                               value="{{old('phone-full')}}">
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('contact_number') }}</span>
                                    <span class="error" id="contactError"></span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Age</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" name="age"
                                               placeholder="Enter your age" maxlength="3"
                                               @if(!empty(Session::get('_old_input')))value="{{ old('age') }}"
                                               @else
                                               @if($userData['age'])
                                               value="{{ $userData['age'] }}"
                                                @endif
                                                @endif >
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('age') }}</span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Gender</label>
                                    <div class="col-sm-6">
                                        <label>
                                            <input type="radio" name="gender" class="custom-radio" id="male"
                                                   value="1" checked
                                                   @if(old('gender')==1 || $userData['gender'] == 1) checked @endif/>
                                            Male
                                        </label>
                                        <label>
                                            <input type="radio" name="gender" class="custom-radio" id="female"
                                                   value="2"
                                                   @if(old('gender')==2 || $userData['gender'] == 2) checked @endif/>
                                            Female
                                        </label>
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('gender') }}</span>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Address</label>
                                    <div class="col-sm-6">
                                        <textarea name="address" rows="3" class="form-control textarea-autosize"
                                                  placeholder="Enter your address"
                                                  maxlength="450">@if(!empty(Session::get('_old_input'))){{old('address')}}@else @if($userData['address']){{$userData['address']}}@endif @endif</textarea>
                                    </div>
                                    <span class="error"> {{ $errors->editProfile->first('address') }}</span>
                                </div>
                                <div class="button-pane mrg20T text-right">
                                    <button class="btn btn-alt btn-hover btn-primary" type="submit">
                                        <span>SAVE</span> <i class="glyph-icon icon-arrow-right"></i>
                                        <div class="ripple-wrapper"></div>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="assets/contactNumber/js/intlTelInput.min.js"></script>
    <script src="assets/contactNumber/js/utils.js"></script>

    <script type="text/javascript">

        $("#phone").intlTelInput({
            autoHideDialCode: true,
            autoPlaceholder: true,
            geoIpLookup: function (callback) {
                $.get("http://ipinfo.io", function () {
                }, "jsonp").always(function (resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            initialCountry: "auto",
            nationalMode: true,
            separateDialCode: true
        });
        $("#phone").intlTelInput("setNumber", "<?php
                if (!empty(Session::get('_old_input')))
                    echo old('phone-full');
                else
                    echo $userData['contact_number'];
                ?>");

        $("form").submit(function () {
            if ($("#phone").intlTelInput("isValidNumber")) {
                $("#hidden").val($("#phone").intlTelInput("getNumber"));
                $('#contactError').html('');
                return true;
            }
            else {
                $('.error').html('');
                $('#contactError').html('Please enter a valid contact number.');

                return false;
            }
        });

    </script>
@endsection