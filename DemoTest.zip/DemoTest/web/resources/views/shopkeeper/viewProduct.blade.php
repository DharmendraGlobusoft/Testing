<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/14/2016
 * Time: 5:49 PM
 */
?>
@extends('shopkeeper.layout.master')

@section('content')

    <div id="page-title">
        <h2 id="viewProduct"><i class="glyph-icon icon-linecons-eye"></i> View Product Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newProductForm" class="form-horizontal bordered-row"
                  action="/viewProductDetail/@if($productData['product_id']!= null){{$productData['product_id']}}@endif"
                  method="post" enctype="multipart/form-data" files="true">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label"> Category </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width:35%;">
                                                <label class="control-label">Main Product</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($productData['main_product_name']!= null)
                                                        {{$productData['main_product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Sub Product</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($productData['sub_product_name']!= null)
                                                        {{$productData['sub_product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:210px;">
                                                <label id="viewProduct" class="control-label">Product Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Name</label>
                                            </td>
                                            <td>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['product_name']!= NULL)
                                                        {{$productData['product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        @if($productData['image']!= null)
                                                            <img src="{{$productData['image']}}">
                                                            <input type="hidden" value="{{$productData['image']}}"
                                                                   name="productImagePath">
                                                        @else
                                                            <img src="http://placehold.it/200x150">
                                                        @endif
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Weight</label>
                                            </td>
                                            <td style="width:278px;">
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['product_weight']!= NULL)
                                                        {{$productData['product_weight']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Cost</label>
                                            </td>
                                            <td>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['cost']!= NULL)
                                                        <i class="glyph-icon icon-rupee"></i>
                                                        {{$productData['cost']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Service Tax</label>
                                            </td>
                                            <td>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['service_tax']!= NULL)
                                                        {{$productData['service_tax']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Description</label>
                                            </td>
                                            <td>
                                                @if(Session::has('error'))
                                                    <?php  $textAreaContent = old('productDescription'); ?>
                                                @else
                                                    @if(old('productDescription'))
                                                        <?php  $textAreaContent = old('productDescription'); ?>
                                                    @else
                                                        @if($productData['product_detail'] != NULL)
                                                            <?php  $textAreaContent = $productData['product_detail']; ?>
                                                        @endif
                                                    @endif
                                                @endif
                                                <label id="viewProduct" class="form-control"
                                                       style="width:100%; height: 100px; scroll-behavior: auto;">
                                                    @if($productData['product_detail']!= NULL)
                                                        {{$productData['product_detail']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if(!empty($otherImages))
                        <div class="col-md-11" style="text-align:center; width:100%">
                            <div class="panel">
                                <div class="panel-body">
                                    <div class="example-box-wrapper">
                                        <table class="table table-responsive">
                                            <tbody>
                                            <tr>
                                                <td>
                                                    <label class="control-label">Product Others Image</label>
                                                </td>
                                                <td>
                                                    <div class="fileinput fileinput-new" data-provides="fileinput">
                                                        @foreach($otherImages as $eachimage)
                                                            <div class="thumbnail"
                                                                 style="width: 200px; height: 150px; float: left; margin-right: 10px;">
                                                                <img src="{{$eachimage->image_url}}"
                                                                     style="width: 150px; height: 185px;">
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    <div id="buttonBar" class="col-md-11" style="text-align: center; width: 100%;">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <div class="form-group">
                                        <button id="viewProduct"
                                                class="btn btn-alt btn-hover btn-info viewListButton">
                                            <span>View Product List</span>
                                            <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('script')

    <script>
        $(document).ready(function () {

            $(document.body).on("click", '.viewListButton', function (event) {
                event.preventDefault();
                window.location.replace('/viewProductList');
            });

        });
    </script>

@endsection

