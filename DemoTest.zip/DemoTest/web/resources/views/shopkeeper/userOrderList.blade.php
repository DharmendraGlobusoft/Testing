<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 11:01 AM
 */
?>

@extends('shopkeeper.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th {
            width: auto !important;
        }

        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7)
        , th:nth-child(8), th:nth-child(9), th:nth-child(10), th:nth-child(11) {
            text-align: center !important;
            vertical-align: top !important;
        }

        td:nth-child(1), td:nth-child(2), td:nth-child(5), td:nth-child(6), td:nth-child(7),
        td:nth-child(8), td:nth-child(9), td:nth-child(10), td:nth-child(11) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">User Order details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">User Order List of Your Shop Only</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Sl.No.</th>
                                <th>Order Id</th>
                                <th>User Name</th>
                                <th>Shop Name</th>
                                <th>Order Date</th>
                                <th>Total Payable Amount (Rs.)</th>
                                <th>Pay Type</th>
                                <th>Payment Status</th>
                                <th>Order Status</th>
                                <th>Action</th>
                                <th>View</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')
    <div class="modal fade" id="viewOrderDetailModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-hidden="true" data-dismiss="modal" class="close" type="button">&times;</button>
                    <h4 class="modal-title">User Order Details</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <fieldset class="fsStyle">
                                <legend class="legendStyle">Primary Details:</legend>
                                <div class="row" id="primary_detail" style="margin-top: 2%;  margin-left: 4%;">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="control-label">Order Id</span>
                                            <br/>
                                            <strong id="order_id"></strong>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <span class="control-label">User Id</span>
                                            <br/>
                                            <strong id="user_id"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Shop Id</span>
                                            <br/>
                                            <strong id="shop_id"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Total Quantity</span>
                                            <br/>
                                            <strong id="total_quantity"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Pay Type</span>
                                            <br/>
                                            <strong id="pay_type"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Order Date</span>
                                            <br/>
                                            <strong id="order_date"></strong>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group" style="height: 42px;">
                                            <span class="control-label"></span>
                                            <br/>
                                            <strong></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">User Name</span>
                                            <br/>
                                            <strong id="user_name"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Shop Name</span>
                                            <br/>
                                            <strong id="shop_name"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Order Status</span>
                                            <br/>
                                            <strong id="order_status"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Payment Status</span>
                                            <br/>
                                            <strong id="payment_status"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Delivery Date</span>
                                            <br/>
                                            <strong id="delivery_date"></strong>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="fsStyle">
                                <legend class="legendStyle">Amount Details:</legend>
                                <div class="row" id="amount_detail" style="margin-top: 2%;  margin-left: 4%;">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="control-label">Total Cost</span>
                                            <br/>
                                            <strong id="total_cost"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Total Discount Amount</span>
                                            <br/>
                                            <strong id="total_discount_amount"></strong>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="control-label">Total Service Tax</span>
                                            <br/>
                                            <strong id="total_service_tax"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Total Payable Cost</span>
                                            <br/>
                                            <strong id="total_payable_cost"></strong>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="fsStyle">
                                <legend class="legendStyle">Delivery Address:</legend>
                                <div class="row" id="delivery_address" style="margin-top: 2%;  margin-left: 4%;">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="control-label">First Name</span>
                                            <br/>
                                            <strong id="first_name"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Contact</span>
                                            <br/>
                                            <strong id="contact"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Address Line 1</span>
                                            <br/>
                                            <strong id="address1"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">District</span>
                                            <br/>
                                            <strong id="district"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Country</span>
                                            <br/>
                                            <strong id="country"></strong>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="control-label">Last Name</span>
                                            <br/>
                                            <strong id="last_name"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Email</span>
                                            <br/>
                                            <strong id="email"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Address Line 2</span>
                                            <br/>
                                            <strong id="address2"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">State</span>
                                            <br/>
                                            <strong id="state"></strong>
                                        </div>
                                        <div class="form-group">
                                            <span class="control-label">Pin</span>
                                            <br/>
                                            <strong id="pin"></strong>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="fsStyle">
                                <legend class="legendStyle">Product Details:</legend>
                                    <div class="row" id="product_detail" style="margin-top: 2%;  margin-left: 4%;">
                                    </div>
                            </fieldset>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-danger" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "destroy": true,
                "ajax": {
                    "url": "/viewOrderList",
                    "type": "POST",
                    "async": "True",
                },
                "order": [[4, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [0, 5, 6, 7, 8, 9, 10]}]
            });

            //This function use for change status of user order
            $(document.body).on('change', '#orderStatus', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewOrderListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'changeOrderStatus',
                        orderId: $(this).attr("data-orderId"),
                        orderStatus: $(this).val()
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            // This function use for view particular user order all details.
            $(document.body).on('click', '#viewOrderDetail', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewOrderListAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'viewOrder',
                        orderId: $(this).attr("value"),
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            //Primary Detail
                            $('#order_id').html(response.order_detail_id);
                            $('#user_id').html(response.id);
                            $('#user_name').html(response.name);
                            $('#shop_id').html(response.shop_id);
                            $('#shop_name').html(response.shop_name);
                            $('#total_quantity').html(response.total_quantity);
                            $('#order_status').html(response.order_status);
                            $('#pay_type').html(response.pay_type);
                            $('#payment_status').html(response.payment_status);
                            $('#order_date').html(response.order_date);
                            $('#delivery_date').html(response.delivery_date);
                            //Amount Detail
                            $('#total_cost').html('Rs. '+response.total_cost);
                            $('#total_service_tax').html('Rs. '+response.total_service_tax);
                            $('#total_discount_amount').html('Rs. '+response.total_discount_amount);
                            $('#total_payable_cost').html('Rs. '+response.total_pay_cost);
                            //Delivery Address
                            $('#first_name').html(response.first_name);
                            $('#last_name').html(response.last_name);
                            $('#contact').html(response.contact_country_code+' - '+response.contact_number);
                            $('#email').html(response.email);
                            $('#address1').html(response.address_line1);
                            $('#address2').html(response.address_line2);
                            $('#district').html(response.district);
                            $('#state').html(response.state);
                            $('#country').html(response.country);
                            $('#pin').html(response.pin);
                            //Product Detail
                            var html = '';

                            if(response.product_detail == null || response.product_detail == '')
                                $('#product_detail').html('Not Available');
                            else {
                                var i = 1;
                                $.each(response.product_detail, function (key, value) {
                                    html = html + '<div class = "col-md-6">';

                                    if(i!=1) { html = html + '<hr>'; }

                                    html = html + '<div class="form-group">' +
                                            ' <span class="control-label">Product Id</span>' +
                                            ' <br/>' +
                                            ' <strong>' + value.product_id + '</strong>' +
                                            ' </div>' +
                                            ' <div class="form-group">' +
                                            ' <span class="control-label">Quantity</span>' +
                                            ' <br/>' +
                                            ' <strong>' + value.quantity + '</strong>' +
                                            ' </div>' +
                                            ' <div class="form-group">' +
                                            ' <span class="control-label">Service Tax</span>' +
                                            ' <br/>' +
                                            ' <strong>' + value.service_tax + ' %</strong>' +
                                            ' </div>' +
                                            ' </div>' +
                                            ' <div class="col-md-6">';

                                    if(i!=1) { html = html + '<hr>'; }

                                    html = html + ' <div class="form-group">' +
                                            ' <span class="control-label">Product Name</span>' +
                                            ' <br/>' +
                                            ' <strong>' + value.product_name + '</strong>' +
                                            ' </div>' +
                                            ' <div class="form-group">' +
                                            ' <span class="control-label">Product Cost</span>' +
                                            ' <br/>' +
                                            ' <strong>Rs. ' + value.product_cost + '</strong>' +
                                            ' </div>' +
                                            ' <div class="form-group">' +
                                            ' <span class="control-label">Discount Amount</span>' +
                                            ' <br/>' +
                                            ' <strong>Rs. ' + value.discount_amount + '</strong>' +
                                            ' </div>' +
                                            ' </div>';
                                    i++;
                                });

                                $('#product_detail').html(html);
                            }
                        }
                        else {
                            //Primary Detail
                            $('#order_id , #user_id, #user_name, #shop_id, #shop_name, ' +
                                    '#total_quantity, #order_status, #pay_type, ' +
                                    '#payment_status, #order_date, #delivery_date').html('Not Available');
                            //Amount Detail
                            $('#total_cost, #total_service_tax, #total_discount_amount, ' +
                                    '#total_payable_cost').html('Not Available');
                            //Delivery Address
                            $('#first_name, #last_name, #contact, #email,' +
                                    '#address1, #address2, #district, #state, ' +
                                    '#country, #pin').html('Not Available');
                            //Product Detail
                            $('#product_detail').html('Not Available');
                        }
                    },
                    error: function (req, status, err) {
                        //Primary Detail
                        $('#order_id , #user_id, #user_name, #shop_id, #shop_name, ' +
                                '#total_quantity, #order_status, #pay_type, ' +
                                '#payment_status, #order_date, #delivery_date').html('Not Available');
                        //Amount Detail
                        $('#total_cost, #total_service_tax, #total_discount_amount, ' +
                                '#total_payable_cost').html('Not Available');
                        //Delivery Address
                        $('#first_name, #last_name, #contact, #email,' +
                                '#address1, #address2, #district, #state, ' +
                                '#country, #pin').html('Not Available');
                        //Product Detail
                        $('#product_detail').html('Not Available');                    }
                }); //End of  ajax
            });
        });
    </script>
@endsection


