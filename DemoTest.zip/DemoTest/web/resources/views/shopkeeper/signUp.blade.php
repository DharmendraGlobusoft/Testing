<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/5/2016
 * Time: 12:10 PM
 */
?>
@extends('layout.master')

@section('head')
    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }
        .error{
            color: #FB0007;
        }
        .success{
            color: green;
        }
    </style>
@endsection

@section('content')
    <div id="loading">
        <div class="svg-icon-loader">
            <img src="assets/admin/images/bars.svg" width="40" alt="">
        </div>
    </div>
    <div class="center-vertical login-bg">
        <div class="center-content">
            <form action="/signUP"  class="col-md-4 col-sm-5 col-xs-11 col-lg-3 center-margin"
                  method="post">
                {{ csrf_field() }}
                <input name="timezone" type="hidden" value="" id="timezone">
                <div id="header-logo" class="logo-bg">
                    <a href="/" class="logo-content-big logo-left" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}}</a>
                    <a href="/" class="logo-content-small" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}}</a>
                </div>
                <div id="login-form" class="content-box bg-default">
                    <div class="content-box-wrapper pad20A">
                        <img class="mrg25B center-margin radius-all-100 display-block login-user-pic"
                             src="assets/admin/images/default_shopper.png" alt=""/>
                        <span class="success">{{ $errors->success->first()}}</span>
                        <span class="error">{{ $errors->fail->first()}}</span>
                        <br><br>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-user"></i></span>
                                <input type="text" name="name" class="form-control"
                                       placeholder="Enter Name" value="{{ old('name') }}"/>
                                <span class="error"> {{ $errors->signUP->first('name') }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-envelope"></i></span>
                                <input type="email" name="email" class="form-control"
                                       placeholder="Enter Email" value="{{ old('email') }}"/>
                                <span class="error"> {{ $errors->signUP->first('email') }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                                <input type="password" name="password" class="form-control"
                                       placeholder="Password" />
                                <span class="error"> {{ $errors->signUP->first('password') }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                                <input type="password" name="password_confirmation" class="form-control"
                                       placeholder="Confirm Password" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="checkbox-primary">
                                <input type="checkbox" name="termCondition"  class="custom-checkbox" @if(old('termCondition')== true) checked @endif/> I Agree with Terms
                                &amp; Conditions
                            </div>
                            <span class="error"> {{ $errors->signUP->first('termCondition') }}</span>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary">Signup</button>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-right">
                                Already a member ? <a href="/" class="text-theme"><b> LOGIN </b></a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

@section('script')
    <script type="text/javascript" src="/assets/js/jstz.min.js"></script>

    <script>
        $(document).ready(function () {
            var timezone = jstz.determine();
            var timezoneName = timezone.name();
            $('#timezone').val(timezoneName);
        });
    </script>
@endsection