<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 6:40 PM
 */
?>

<div id="page-header">
    <div id="header-nav-left">
        <a class="header-btn" id="logout-btn" href="/lockScreen" title="Lock your screen">
            <i class="glyph-icon icon-linecons-lock"></i>
        </a>
        <div class="user-account-btn dropdown">
            <a href="#" title="{{Session::get('fullName')}}" class="user-profile clearfix" data-toggle="dropdown">
                <img width="28" src="{{Session::get('imageUrl')}}" alt="">
                <span>{{Session::get('fullName')}}</span>
                <i class="glyph-icon icon-angle-down"></i>
            </a>
            <div class="dropdown-menu float-right">
                <div class="box-sm">
                    <div class="login-box clearfix" title="{{Session::get('fullName')}}">
                        <div class="user-img">
                            <a href="" title="change photo" class="change-img" data-toggle="modal" data-target="#changephoto">Change photo</a>
                            <img src="{{Session::get('imageUrl')}}" alt="Profile image">
                        </div>
                        <div class="user-info">
                            <span>{{Session::get('fullName')}}<i>Shopkeeper Person</i></span>
                            <a href="/editShopkeeperProfile" title="Edit profile">Edit profile</a>
                            <a href="" class="change-pass" title="Change Password" data-toggle="modal" data-target="#changepass">Change Password</a>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="button-pane button-pane-alt pad5L pad5R text-center">
                        <a href="/logout" class="btn btn-flat display-block font-normal btn-danger">
                            <i class="glyph-icon icon-power-off"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="header-nav-right">
        <div class="dropdown" id="notifications-btn">
       <h2 style="color:#918D99; display: block; font-size: 20px; font-weight: 700; margin-top: 18px;">
           Shopkeeper Panel</h2>
        </div>
    </div>
</div>
