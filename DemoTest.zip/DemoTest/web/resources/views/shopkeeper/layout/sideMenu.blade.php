<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 6:41 PM
 */
?>

<div id="page-sidebar">
    <div id="header-logo" class="logo-bg">
{{--        <a href="/shopkeeperDashboard" class="logo-content-big" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}} </a>--}}
        <a href="/shopkeeperDashboard" class="logo-content-small" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}} </a>
        <a id="close-sidebar" href="#" title="Close sidebar"><i class="glyph-icon icon-outdent"></i></a>
    </div>
    <div class="scroll-sidebar">
        <ul id="sidebar-menu">
            <li class="header"><span>Menu List</span></li>
            <li>
                <a href="/shopkeeperDashboard" title="Dashboard">
                    <i class="glyph-icon icon-linecons-tv"></i> <span>Dashboard</span>
                </a>
            </li>
            @if(Session::get('shopId')=='Available')
            <li>
                <a href="javascript:void(0);" title="Users">
                    <i class="glyph-icon icon-linecons-user"></i> <span>Users</span>
                </a>
                <div class="sidebar-submenu">
                    <ul>
                        <li><a  href="/viewUserList" title=" View user list"><span>User List</span></a></li>
                        <li><a  href="/viewShopkeeperList" title="View shopkeeper list"><span>Shopkeeper List</span></a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="javascript:void(0);" title="Shops">
                    <i class="glyph-icon icon-linecons-shop"></i> <span>Shops</span>
                </a>
                <div class="sidebar-submenu">
                    <ul>
                        <li><a  href="/viewShopList" title="View shop List"><span>Shop List</span></a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="javascript:void(0);" title="Product">
                    <i class="glyph-icon icon-linecons-cup"></i> <span>Product</span>
                </a>
                <div class="sidebar-submenu">
                    <ul>
                        <li><a  href="/viewMainProduct" title="View main product"><span>View Main Product</span></a></li>
                        <li><a  href="/viewSubProduct" title="View sub product"><span>View Sub Product</span></a></li>
                        <li><a  href="/addNewProduct" title="Add new product"><span>Add New Product</span></a></li>
                        <li><a  href="/viewProductList" title="View product List"><span>View Product List</span></a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a  href="/viewOrderList" title="Order Details">
                    <i class="glyph-icon icon-linecons-note"></i> <span>Order Details</span>
                </a>
            </li>
            <li>
                <a  href="/viewTransactionList" title="Transaction Details">
                    <i class="glyph-icon icon-linecons-money"></i> <span>Transaction Details</span>
                </a>
            </li>
            <li>
                <a href="javascript:void(0);" title="Location">
                    <i class="glyph-icon icon-linecons-location"></i> <span>Location</span>
                </a>
                <div class="sidebar-submenu location">
                    <ul>
                        <li><a  href="/viewCountryList" title="View Country"><span>Country List</span></a></li>
                        <li><a  href="/viewStateList" title="View State"><span>State List</span></a></li>
                        <li><a  href="/viewCityList" title="View City"><span>City List</span></a></li>
                    </ul>
                </div>
            </li>
            @endif
        </ul>
    </div>
</div>
