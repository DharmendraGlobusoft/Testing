<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/13/2016
 * Time: 10:22 AM
 */
?>

<head>
    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <title>{{Config::get('app.APPLICATION_NAME')}}  || Shopkeeper</title>
    <meta name="description" content="Grocery - online Grocery">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="author" content="AllThatIsRam">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="stylesheet" href="/assets/admin/css/animate.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/plugin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/widget.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/admin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/custom.css" />
    <link rel="stylesheet" href="/assets/admin/css/jasny-bootstrap.min.css" />

    <!-- BEGIN OPTIONAL HEAD -->
    @yield('head')
    <!-- END OPTIONAL HEAD -->
</head>
