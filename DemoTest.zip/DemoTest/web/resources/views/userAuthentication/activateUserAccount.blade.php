<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 7/2/2016
 * Time: 1:35 PM
 */
?>

@extends('layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/animate.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/materialize.min.css" media="screen,projection" />
    <link rel="stylesheet" href="/assets/admin/css/ziingo-style.css" />

    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }
        .error{
            color: #FB0007;
        }
        .shop-pic, #signUp {
            display: none;
            text-align: center;
        }
    </style>


    <!--[if IE]>
    <style>
        .login-user-pic {
            width: 150px !important;
        }
        .col-lg-3.center-margin {
            width: 335px !important;
        }
        .form-control {
            width: 78% !important;
        }
    </style>
    <![endif]-->
@endsection

@section('content')
    <div id="loading">
        <div class="svg-icon-loader">
            <img src="/assets/admin/images/bars.svg" width="40" alt="loader">
        </div>
    </div>
    <div class="center-vertical login-bg">
        <div class="center-content">
            <main class="page-content">
                <section class="">
                    <div class="parallax-container" style="height:477px;">
                        <div class="parallax-content p-top-64">
                            <div class="container">
                                <div class="bg-pixel-black center paddingTB-lg">
                                    <h3 class="font-SquadaOne animated zoomIn delay-p2s">{{Config::get('app.APPLICATION_NAME')}}</h3>
                                    <hr><br><br>
                                    <h5 class="font-SquadaOne animated zoomIn delay-p2s">{{$message}}</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>

        </div>
    </div>
@endsection

@section('script')

    <script>
        $(document).ready(function () {
            Ziingo.initComponents();
        });
    </script>

@endsection
