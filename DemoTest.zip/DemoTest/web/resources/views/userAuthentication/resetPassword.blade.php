<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 7/7/2016
 * Time: 3:35 PM
 */
?>

@extends('layout.master')

@section('head')
    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }
        .error{
            color: #FB0007;
        }
        .shop-pic, #signUp {
            display: none;
            text-align: center;
        }
    </style>


    <!--[if IE]>
    <style>
        .login-user-pic {
            width: 150px !important;
        }
        .col-lg-3.center-margin {
            width: 335px !important;
        }
        .form-control {
            width: 78% !important;
        }
    </style>
    <![endif]-->
@endsection

@section('content')
    <div id="loading">
        <div class="svg-icon-loader">
            <img src="/assets/admin/images/bars.svg" width="40" alt="loader">
        </div>
    </div>
    <div class="center-vertical login-bg">
        <div class="center-content">
            <form action="/password/forgotPassword" method="post" name="passwordResetForm" class="col-md-4 col-sm-5 col-xs-11 col-lg-3 center-margin">
                {{ csrf_field() }}
                <input type="hidden" name="token" value="{{ $token }}">
                <div id="header-logo" class="logo-bg" style="background-color: white; border-radius: 8px 8px 0px 0px; margin: 0px 0px -2px; height: 62px;">
                    <a href="/" title="{{Config::get('app.APPLICATION_NAME')}}"><img src="{{Config::get('app.WEB_HOST')}}assets/admin/images/logo.png" style="float: left; width: 45px; margin: 14px 0px 0px 17px;"/>
                        <img src="{{Config::get('app.WEB_HOST')}}assets/admin/images/logo_text.png" style="width: 250px; margin: 17px 0px 0px;"/></a>
                </div>
                <div id="login-form" class="content-box bg-default">
                    <div class="content-box-wrapper pad20A text-center">
                        <h4 style="margin-bottom:8%;">Reset Password</h4>
                        <span id="validatedMessage" ></span>

                        @if ( isset($messageSuccess))
                            <span style="margin-left: 5px; color: green;"> {{ $messageSuccess }}</span>
                        @endif

                        @if ( isset($messageError))
                            <span style="margin-left: 20px; color: red;"> {{ $messageError }}</span>
                        @endif

                        @if (isset($messageErrorArray[0]) )
                            <span style="margin-left: 20px; color: red;"> {{ $messageErrorArray[0] }}</span>
                        @else
                            @if (isset($messageErrorArray[1]) )
                                <span style="margin-left: 20px; color: red;"> {{ $messageErrorArray[1] }}</span>
                            @else
                                @if (isset($messageErrorArray[2]) )
                                    <span style="margin-left: 20px; color: red;"> {{ $messageErrorArray[2] }}</span>
                                @endif
                            @endif
                        @endif

                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i class="glyph-icon icon-unlock-alt"></i></span>
                                <input value="{{ $email }}" name="email" type="email" id='email' class="form-control" placeholder="your registered email id"  />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i class="glyph-icon icon-unlock-alt"></i></span>
                                <input name="password" type="password" class="psw form-control" placeholder="New Password" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i class="glyph-icon icon-unlock-alt"></i></span>
                                <input name="password_confirmation" type="password" class="psw form-control" placeholder="Confirm Password"  />
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submitButton" class="btn btn-block btn-primary" id="resetPassword">Reset Password</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

