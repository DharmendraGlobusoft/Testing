<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/4/2016
 * Time: 4:41 PM
 */
?>

@extends('layout.master')

@section('head')
    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }
        body {
            overflow: hidden;
            background: #fafafa
        }
        .error{
            color: #FB0007;
        }
    </style>
@endsection

@section('content')
    <div id="loading">
        <div class="svg-icon-loader"><img src="assets/admin/images/bars.svg" width="40" alt=""></div>
    </div>
    <div class="center-vertical login-bg">
        <div class="center-content">
            <div class="col-md-4 col-sm-5 col-xs-11 col-lg-3 center-margin">
                <div class="panel-layout wow bounceInDown">
                    <div class="panel-content pad0A bg-white">
                        <div class="meta-box meta-box-offset">
                            @if(Session::get('imageUrl'))
                            <img src="{{Session::get('imageUrl')}}" alt="Profile image" class="meta-image img-bordered login-user-pic img-circle" />
                            @else
                                <h3 class="meta-heading font-size-28" style="color:#FB0007"> Sorry !!</h3>
                                <h4 class="meta-subheading font-size-13 font-gray">Your are already logged out</h4>
                            @endif
                            <h3 class="meta-heading font-size-16">{{Session::get('fullName')}}</h3>
                            <h4 class="meta-subheading font-size-13 font-gray">{{Session::get('type')}}</h4>
                            <span class="error">{{ $errors->authError->first() }}</span>
                        </div>
                        <form action="/unlock" class="form-inline" method="post">
                            {{ csrf_field() }}
                            <div class="content-box-wrapper pad20A">
                                <div class="form-group">
                                    <div class="input-group">
                                        <input type="password" placeholder="Password" class="form-control" name="password" />
    										<span class="input-group-btn">
    											<button class="btn btn-primary" type="submit"><i class="glyph-icon icon-unlock-alt"></i></button>
    										</span>
                                    </div>
                                    <span class="error"> {{ $errors->login->first('password') }}</span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')

    <script src="assets/admin/js/wow.js"></script>
    <script>
        $(window).load(function () {
            setTimeout(function () {
                $('#loading').fadeOut(400, "linear");
            }, 300);

            wow = new WOW({
                animateClass: 'animated',
                offset: 100
            });
            wow.init();
        });
    </script>

@endsection