<?php
/**
 * Created by PhpStorm.
 * User: GLB-280
 * Date: 9/12/2018
 * Time: 1:08 PM
 */
?>
<!DOCTYPE html>

<html>
<head>
    <title>Payment Checkout</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .errorMsg{
            color: #FF0000;
        }
    </style>
</head>

<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-5 col-sm-6 col-xs-12 col-md-push-4 col-sm-push-6" style="margin-top: 5%;">
                <div class="panel panel-default">
                    <div class="panel-heading text-center" style="background-color: #337ab7;color:#fff;">
                        <h4>Order Checkout Page</h4>
                    </div>
                    <div class="panel-body" style="border: 1px solid #337ab7;padding:25px;">
                        <form method="post" action="/hdfcPayment"><br>
                            {{csrf_field()}}
                            <div class="form-group">
                                {{--Enter Order Id:<input class="form-control" id="orderId" name="orderId" value="{{old('orderId')}}" required type="text">--}}
                                Order Id:<input class="form-control" id="orderId" name="orderId" value="@if($errors->has('amount')){{old('orderId')}}@else<?php echo rand(1,100);?>@endif" required type="text" readonly>
                                @if($errors->has('orderId'))
                                    <span class="errorMsg">{{$errors->first('orderId')}}</span>
                                @endif
                            </div>
                            <div class="form-group">
                                Enter Amount:<input class="form-control" id="amount" name="amount" value="{{old('amount')}}" required type="text">
                                @if($errors->has('amount'))
                                    <span class="errorMsg">{{$errors->first('amount')}}</span>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg btn-block">Pay with HDFC Payment Gateway</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#orderId').on('keypress',function (e) {
            if(e.which===46){
                alert('Order Id must be integer');
                return false;
            }
        }) ;
    });
</script>
</body>

</html>