<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>HDFC Payment</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    {{--<h2>Payment Checkout Express</h2>--}}
    <?php
        $_SESSION['p_amt']= $price;
        $_SESSION['orderId'] = $orderId;
    ?>
    <form method="post" name="redirect" action="/payment/ccavRequestHandler.php">
        <div class="form-group">
            <input type="hidden" class="form-control" id="amount" name="amount" value="{{$price}}" readonly>
        </div>

        <input type="hidden" name="tid" id="tid" value="{{time()}}" readonly />

        <input type="hidden" name="merchant_id" value="182682"/>

        {{--<input type="hidden" name="order_id" value="{{time()}}"/>--}}
        <input type="hidden" name="order_id" value="{{$orderId}}"/>

        <input type="hidden" name="currency" value="INR"/>
        <input type="hidden" name="redirect_url" value="https://citytreq.com/payment/ccavResponseHandler.php"/>
        <input type="hidden" name="cancel_url" value="https://citytreq.com/payment/ccavResponseHandler.php"/>
        <input type="hidden" name="language" value="EN"/>
        {{--<button type="submit" class="btn btn-default">Pay Now</button>--}}
    </form>
    <script language='javascript'>document.redirect.submit();</script>

</div>
</body>
</html>