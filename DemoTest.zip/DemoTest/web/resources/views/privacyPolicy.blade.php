<!DOCTYPE html>
<html>

<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Jagpreet Kaur">
    <title>City Walk Privacy & Refund Policy</title>
    <link type="text/css" rel="stylesheet" href="assets/admin/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="assets/admin/css/font-awesome.min.css"/>
    <style>
        .head-bg {
        }

        .logo {
            position: absolute;
            left: 65px;
            top: 70px;
            width: 75px;
        }

        .sign-up {
            position: absolute;
            right: 105px;
            top: 100px;
            color: #fff;
            font-weight: 700;
        }

        .sign-up:hover {
            position: absolute;
            right: 105px;
            top: 100px;
            color: #f95c5c;
            font-weight: 700;
        }

        .log-in {
            position: absolute;
            right: 45px;
            top: 100px;
            color: #fff;
            font-weight: 700;
        }

        .log-in:hover {
            position: absolute;
            right: 45px;
            top: 100px;
            color: #f95c5c;
            font-weight: 700;
        }

        .heading-text {
            color: #00A650;
            position: absolute;
            left: 155px;
            top: 75px;
        }

        .support {
            color: #fff;
            position: absolute;
            top: 89px;
            left: 564px;
            background-color: #000;
            font-size: 25px;
            padding: 10px 50px;
            opacity: 0.7;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12 head-bg" style="padding:0px !important;">
            <img src="/assets/admin/images/bg.jpg" class="img-responsive"/>
            {{--<a href="#"><img src="/assets/admin/images/logo.png" class="img-responsive logo"/></a>--}}
            <span class="support"><b>Privacy & Refund Policy</b></span>
        </div>
    </div>
</div>

<div class="container" style="margin:50px;">

            <h3 style="text-align: center">Privacy policy</h3>
    <p>
        This privacy policy has been compiled to better serve those who are concerned with how their 'Personally Identifiable Information' (PII) is being used online. PII, as described in US privacy law and information security, is information that can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context. Please read our privacy policy carefully to get a clear understanding of how we collect, use, protect or otherwise handle your Personally Identifiable Information in accordance with our website.

    </p>
    <p>
        What personal information do we collect from the people that visit our blog, website or app?

    </p>

    <p>
        When ordering or registering on our site, as appropriate, you may be asked to enter your name, phone number or other details to help you with your experience.

    </p>

    <p>
        When do we collect information?

    </p>

    <p>
        We collect information from you when you register on our site, place an order, fill out a form or enter information on our site.

    </p>

    <p>
        Provide us with feedback on our products or services 

    </p>

    <p>
        How do we use your information?

    </p>

    <p>
        We may use the information we collect from you when you register, make a purchase, sign up for our newsletter, respond to a survey or marketing communication, surf the website, or use certain other site features in the following ways:

    </p>

    <ul>

        <li>To personalize your experience and to allow us to deliver the type of content and product offerings in which you are most interested.</li>

        <li>To improve our website in order to better serve you.</li>
        <li>
            To allow us to better service you in responding to your customer service requests.
        </li>

        <li>
            To quickly process your transactions.
        </li>

        <li>
            To ask for ratings and reviews of services or products
        </li>
    </ul>

    <p>
        How do we protect your information?
    </p>

    <p>
        Our website is scanned on a regular basis for security holes and known vulnerabilities in order to make your visit to our site as safe as possible.

    </p>

    <p>
        We use regular Malware Scanning.

    </p>

    <p>
        We do not use an SSL certificate

    </p>

    <ul>
        <li>We only provide articles and information. We never ask for personal or private information like names, email addresses, or credit card numbers.</li>
    </ul>

    <p>
        Do we use 'cookies'?
    </p>

    <p>
        Yes. Cookies are small files that a site or its service provider transfers to your computer's hard drive through your Web browser (if you allow) that enables the site's or service provider's systems to recognize your browser and capture and remember certain information. For instance, we use cookies to help us remember and process the items in your shopping cart. They are also used to help us understand your preferences based on previous or current site activity, which enables us to provide you with improved services. We also use cookies to help us compile aggregate data about site traffic and site interaction so that we can offer better site experiences and tools in the future.

    </p>

    <p>
        We use cookies to:
    </p>

    <ul>
        <li>
            Help remember and process the items in the shopping cart.
        </li>
    </ul>

    <p>
        You can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies. You do this through your browser settings. Since browser is a little different, look at your browser's Help Menu to learn the correct way to modify your cookies.

    </p>

    <p>
        If you turn cookies off, Some of the features that make your site experience more efficient may not function properly.It won't affect the user's experience that make your site experience more efficient and may not function properly.

    </p>

    <p>
        Third-party disclosure

    </p>

    <p>
        We do not sell, trade, or otherwise transfer to outside parties your Personally Identifiable Information.

    </p>

    <p>
        Third-party links

    </p>

    <p>
        We do not include or offer third-party products or services on our website.

    </p>

    <p>
        COPPA (Children Online Privacy Protection Act)
    </p>

    <p>
        When it comes to the collection of personal information from children under the age of 13 years old, the Children's Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, United States' consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect children's privacy and safety online.

    </p>

    <p>
        We do not specifically market to children under the age of 13 years old.

    </p>

    <p>
        Do we let third-parties, including ad networks or plug-ins collect PII from children under 13?

    </p>

    <p>
        Fair Information Practices

    </p>

    <p>
        The Fair Information Practices Principles form the backbone of privacy law in the United States and the concepts they include have played a significant role in the development of data protection laws around the globe. Understanding the Fair Information Practice Principles and how they should be implemented is critical to comply with the various privacy laws that protect personal information.

    </p>

    <p>
        In order to be in line with Fair Information Practices we will take the following responsive action, should a data breach occur:

    </p>

    <p>
        We will notify you via phone call

    </p>
    <ul>
        <li>
             Within 7 business days
        </li>
    </ul>
    <p>
        We also agree to the Individual Redress Principle which requires that individuals have the right to legally pursue enforceable rights against data collectors and processors who fail to adhere to the law. This principle requires not only that individuals have enforceable rights against data users, but also that individuals have recourse to courts or government agencies to investigate and/or prosecute non-compliance by data processors.

    </p>

    <p>
        CAN SPAM Act

    </p>
    <p>
        The CAN-SPAM Act is a law that sets the rules for commercial email, establishes requirements for commercial messages, gives recipients the right to have emails stopped from being sent to them, and spells out tough penalties for violations.

    </p>

    <p>
        We collect your email address in order to:

    </p>
    <ul>
        <li>
            Send information, respond to inquiries, and/or other requests or questions
        </li>
    </ul>

    <p>
        To be in accordance with CANSPAM, we agree to the following:

    </p>

    <p>Not use false or misleading subjects or email addresses.</p>
    <p>If at any time you would like to unsubscribe from receiving future emails, you can email us at and we will promptly remove you from ALLcorrespondence.</p>


    <br>
    <br>
    <h3 style="text-align: center">Return and refunds policy</h3>

        <p>Thanks for the shopping if you are not entirely satisfied with your purches we're  here to help</p>
        <p><b>Refunds</b></p>
        <p>Once we receive your item, we will inspect it and notify you that we have received your returned item. We will immediately notify you on the status of your refund after inspecting the item. If your return is approved, we will initiate a refund to your credit card (or original method of payment).You will receive the credit within a certain amount of days, depending on your card issuer's policies.</p>
            <p><b>Returns</b></p>
    <p>You have 30 calendar days to return an item from the date you received it.To be eligible for a return, your item must be unused and in the same condition that you received it.Your item must be in the original packaging.Your item needs to have the receipt or proof of purchase.
    </p>
    <p><b>Shipping</b></p>
    <p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are nonrefundable.If you receive a refund, the cost of return shipping will be deducted from your refund.</p>

</div>


<script src="assets/admin/js/jquery.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
</body>
</html>