<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/18/2016
 * Time: 11:13 AM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7) {
            text-align: center !important;
        }

        td:nth-child(4), td:nth-child(5), td:nth-child(6), td:nth-child(7) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">Shop details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Shop List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Shop Id</th>
                                <th>Shop Name</th>
                                <th>Assigned Shopkeeper</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>View/Edit Details</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')
    <div class="modal fade" id="deleteShopModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Shop Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-3 control-label">Shop Id:</label>
                                    <div>
                                        <label id="shopId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-3 control-label">Shop Name:</label>
                                    <div>
                                        <label id="shopName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this shop then all detail related to
                                            this shop will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "/viewShop",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [3, 4, 5, 6]}]
            });

            //This function use for activate shop status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewShopAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        shopId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate shop by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewShopAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        shopId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });


            // This function use for only show delete modal with shop information.
            $(document.body).on('click', '#deleteShop', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewShopAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'shopDetail',
                        shopId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#shopId').html(response['shop_id']);
                            $('#shopName').html(response['shop_name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["shop_id"] + '" class="btn btn-primary" id="shopDeleteButton">Yes</button>');
                        }
                        else {
                            $('#shopId').html('Not available');
                            $('#shopName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#shopId').html('Not available');
                        $('#shopName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular shop.
            $(document.body).on('click', '#shopDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewShopAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        shopId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#deleteSuccess').html('Shop has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function() {
                                $("#deleteShopModal").fadeOut();
                                setTimeout(function() {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! Shop has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! Shop has not deleted.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection
