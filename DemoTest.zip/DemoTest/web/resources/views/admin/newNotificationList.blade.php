<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/17/2016
 * Time: 8:31 PM
 */
?>

@extends('admin.layout.master')

@section('head')

@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">New Notification List</h2>
    </div>


    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="row">
                <div class="col-md-10 col-sm-offset-1">
                    <div class="portlet light bordered">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h2 class="no-margin">My Notifications</h2>
                                <h5><span class="notification-suc-err"></span><br></h5>
                            </div>
                            <div class="panel-body" id="notificationSection">

                            </div>
                            <button id='loadmore' class='btn btn-primary col-md-4 col-sm-offset-4 hide'>Load more
                            </button>
                            <br><br>
                        </div>
                    </div>
                    <div class="modal fade" id="viewnotimessage">
                        <div class="modal-dialog">
                            <div class="modal-content text-center">
                                <div class="modal-header">

                                    <button class="close" data-dismiss="modal"><span>&times;</span></button>
                                    <h3 class="Descriptions" data-dismiss="modal"><span>Description</span></h3>

                                    <h4 class="message"></h4>

                                </div>
                                <div class="modal-body">
                                    <textarea class="form-control" id="description" disabled
                                              style="cursor: default"></textarea>
                                    <br><br>
                                    <div align="right">
                                        <a href="" type="button" class="btn btn-success hidden" id="notificationlink">View
                                            Details</a>
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')

    <script type="text/javascript">
        $(window).load(function () {
            jQuery("#loadmore").trigger("click");
            $("#loadmore").removeClass('hide');
        });

        $(document).ready(function () {
            var count = 0;

            $(document.body).on('click', '#loadmore', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/notificationAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'notificationListWithLimit',
                        offset: count
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            if (response.length != 0) {
                                $.each(response, function (key, value) {
                                    var diff = Math.abs(new Date() - new Date(value['created_at']));
                                    var seconds = Math.floor(diff / 1000); //ignore any left over units smaller than a second
                                    var minutes = Math.floor(seconds / 60);
                                    seconds = seconds % 60;
                                    var hours = Math.floor(minutes / 60);
                                    minutes = minutes % 60;
                                    var day = null;
                                    if (hours > 24) {
                                        day = Math.floor(hours / 24);
                                        hours = Math.floor(hours - (24 * day));
                                    }
                                    var finalTime = '';

                                    if (minutes == 0)
                                        finalTime = seconds + ' seconds ago';
                                    else if (hours == 0)
                                        finalTime = minutes + ' minutes ago';
                                    else
                                        if(day == null)
                                            finalTime = hours + ' hours ago';
                                        else
                                            finalTime = day + ' day ago';

                                    $("#notificationSection").append('' +
                                            '<ul class="list-unstyled notification-list">' +
                                            '<li class="row"> ' +
                                            '<div class="col-sm-8 col-xs-10"> ' +
                                            '<p>' + value['message'] + '</p> ' +
                                            '<i style="color:#03A9F4">'+ finalTime +'</i>' +
                                            '</div> ' +
                                            '<div class="col-sm-3 text-center">' +
                                            '<button id="viewNotifications" data-notificationId="' + value['notification_id'] + '" class="btn btn-primary">' +
                                            'View</button>' +
                                            '</div> ' +
                                            '</li> ' +
                                            '<div style="color: black; background: lightgrey; width: 100%; height: 2px;">' +
                                            '<hr>' +
                                            '</div> ' +
                                            '</ul>');
                                });
                            }
                            else {
                                $("#loadmore").hide();
                                $('#notificationSection').append('<span style="float:left;position:relative;left:30%;color:red;padding:10% 0; font-size: 20px;">There are no more new notification</span>');
                            }
                        } else {
                            $("#loadmore").hide();
                            $('#notificationSection').append('<span style="float:left;position:relative;left:30%;color:red;padding:10% 0; font-size: 20px;">There are no more new notification</span>');
                        }
                        count = count + 10;
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            $(document.body).on("click", '#viewNotifications', function (event) {
                event.preventDefault();
                $.ajax({
                    url: "/notificationAjax",
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'changeNotificationStatus',
                        notificationId: $(this).attr('data-notificationId'),
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            window.location.replace("/viewOrder");
                        }
                        else
                            console.log(response);
                    }
                });
            });

        });
    </script>
@endsection



