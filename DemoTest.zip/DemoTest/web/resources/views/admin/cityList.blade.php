<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/21/2016
 * Time: 8:41 PM
 */
?>

@extends('admin.layout.master')


@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(5) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">City Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Select State</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Country</label>
                                        <div class="col-sm-9">
                                            <select id="selectCountry" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Country</option>
                                                @if($country != null)
                                                    @foreach($country as $value)
                                                        <option value="{{$value->country_id}}">{{$value->country_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the State</label>
                                        <div class="col-sm-9">
                                            <select id="selectState" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select State</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <h3 class="title-hero">Add City</h3>
                    <span style="color: green;" id="addSuccess">Successfully, New city name has been added.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Enter the City</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="addCityName" data-stateId="" class="form-control"
                                                   id="addCityName"
                                                   placeholder="Enter the City Name"/>
                                            <span style="color:#FB0007;" id="addError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addCityButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>SAVE</span> <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel editContent">
                <div class="panel-body">
                    <h3 class="title-hero">Edit City</h3>
                    <span style="color: green;" id="editSuccess">Successfully, City name has been updated.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">City Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" data-cityId="" name="editCityName"
                                                   id="editCityName" class="form-control" value=""/>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="editCityButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                        <button id="cancelCityButton" class="btn btn-alt btn-hover btn-info">
                                            <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">City List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>City Id</th>
                                <th>City Name</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>Edit</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {

            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $('.editContent').hide();
            $('.addContent').hide();
            $('#addSuccess').hide();
            $('#editSuccess').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for fetch State list according to Country id.
            // And display it in drop down select tag.
            $(document.body).on("change", '#selectCountry', function () {
                $('#datatable').DataTable({ "destroy": true}).destroy();
                $('tbody').empty();

                var countryId = $(this).val();
                $.ajax({
                    url: "/viewCityAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getStateList',
                        countryId: countryId
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            var option = '';
                            $.each(response, function (key, value) {
                                option = option + '<option value="' + value.state_id + '">' + value.state_name + '</option>';
                            });

                            $('#selectState').html('');
                            $('#selectState').html('<option disabled selected>Select State</option>' + option);
                            $('#selectState').select2();
                            $('.editContent').hide();
                            $('.addContent').hide();
                            $('#addSuccess').hide();
                            $('#editSuccess').hide();
                        }
                        else {
                            $('#selectState').html('');
                            $('#selectState').html('<option disabled selected>Select State</option>');
                            $('#selectState').select2();
                        }
                    }
                });
            });

            //This function use for fetch City list according to state id.
            // And display it in dataTable.
            $(document.body).on('change', '#selectState', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('#addCityName').val('');
                $('#addCityName').attr('data-stateId', $(this).val());
                $('.addContent').show();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                    "ajax": {
                        "url": "/viewCity",
                        "type": "POST",
                        "async": "True",
                        data: {
                            stateId: $(this).val()
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [2, 3, 4]}]
                });

            });

            //This function use for activate City status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCityAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        cityId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate City by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCityAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        cityId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for display edit City name section to user
            $(document.body).on('click', '#editButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewCityAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'cityNameAndId',
                        cityId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('.addContent').hide();
                            $('.editContent').show();
                            $('#editCityName').val(response.city_name);
                            $('#editCityName').attr('value', response.city_name);
                            $('#editCityName').attr('data-cityId', response.city_id);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for add new City name by click on save button by admin
            $(document.body).on('click', '#addCityButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCityAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'create',
                        stateId: $('#addCityName').attr('data-stateId'),
                        cityName: $('#addCityName').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#addError').html('');
                            $('#addCityName').val('');
                            $('#addSuccess').show();
                            $('#addSuccess').delay(3000).fadeOut(600);
                        }
                        else {
                            $('#addError').html(response);
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for update City name by click on update button by admin
            $(document.body).on('click', '#editCityButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCityAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update',
                        cityId: $('#editCityName').attr('data-cityId'),
                        cityName: $('#editCityName').val(),
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#editSuccess').show();
                            $('#editSuccess').delay(1000).fadeOut(600);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for hide edit City division and show add City division.
            $(document.body).on('click', '#cancelCityButton', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('.addContent').show();
            });

        });
    </script>
@endsection
