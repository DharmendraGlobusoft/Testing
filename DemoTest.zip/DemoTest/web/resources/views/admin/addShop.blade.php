<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/16/2016
 * Time: 12:41 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 >Add new shop</h2>
        <span class="success" style="margin-left:40px;">@if(Session::has('success')){{Session::get('success')}}@endif</span>
        <span class="error" style="margin-left:50px;">@if(Session::has('fail')){{Session::get('fail')}}@endif</span>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newShopForm" class="form-horizontal bordered-row" action="/addShop" method="post"
                  enctype="multipart/form-data" files="true">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label">Choose Location </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Choose Country</label>
                                            </td>
                                            <td>
                                                <select name="country" id="country"
                                                        class="js-example-responsive form-control" style="width:100%;">
                                                    <option disabled selected value="null">Select Country</option>
                                                    @if($initialShopData['countryList']!= null)
                                                        @foreach($initialShopData['countryList'] as $value)
                                                            <option value="{{$value->country_id}}"
                                                                    @if(old('country') == $value->country_id) selected @endif>
                                                                {{$value->country_name}}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                                <span class="error"> {{ $errors->createShopError->first('country') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Choose State</label>
                                            </td>
                                            <td>
                                                <select name="state" id="state"
                                                        class="js-example-responsive form-control" style="width:100%;">
                                                    <option disabled selected>Select State</option>

                                                </select>
                                                <span class="error"> {{ $errors->createShopError->first('state') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Choose City</label>
                                            </td>
                                            <td>
                                                <select name="city" id="city" class="js-example-responsive form-control"
                                                        style="width:100%;">
                                                    <option disabled selected>Select City</option>

                                                </select>
                                                <span class="error"> {{ $errors->createShopError->first('city') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Enter the Location</label>
                                            </td>
                                            <td>
                                                <input type="text" name="location" class="form-control" value="{{old('location')}}"
                                                       placeholder="Enter the Location"/>
                                                <span class="error"> {{ $errors->createShopError->first('location') }}</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label">Add Shop Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Name</label>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="shopName" value="{{old('shopName')}}"
                                                       placeholder="Enter the shop name"/>
                                                <span class="error"> {{ $errors->createShopError->first('shop_name') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        <img src="http://placehold.it/200x150" alt="">
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                    <div>
														<span class="btn btn-default btn-file">
															<span class="fileinput-new">Select Image</span>
															<span class="fileinput-exists">Replace</span>
															<input type="file" name="shopImage">
														</span>
                                                        <a href="#" class="btn btn-danger fileinput-exists"
                                                           data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                    <span class="error"> {{ $errors->createShopError->first('shop_image') }}</span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label">Assign a Shopkeeper</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Choose Shopkeeper</label>
                                                <br>
                                                <span class="error"> {{ $errors->createShopError->first('shopkeeper') }}</span>
                                            </td>
                                            <td>
                                                <select name="shopkeeperId" class="js-example-responsive form-control" style="width:100%;">
                                                    <option disabled selected>Select Shopkeeper</option>
                                                    <option value="0" @if(old('shopkeeperId')== '0') selected @endif >Not need now</option>
                                                    @if($initialShopData['shopkeepers']!= null)
                                                        @foreach($initialShopData['shopkeepers'] as $value)
                                                            <option  value="{{$value->shopkeeper_meta_id}}" @if(old('shopkeeperId')== $value->shopkeeper_meta_id ) selected @endif>
                                                                {{$value->id}} . {{$value->first_name}}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6" style="text-align: center;">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-alt btn-hover btn-primary">
                                            <span>Create</span>
                                            <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('script')
    <script src="/assets/admin/js/select2.full.min.js"></script>

    <script>
        //This statement include the search functionality inside the select tag of html.
        $(".js-example-responsive").select2();

        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //Below function fetched the state and city and put it in required field as their old input.
            var countryId = $('#country').val();
            if(countryId != null) {
                $.ajax({
                    url: "/addShopAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getStateList',
                        countryId: countryId
                    },
                    success: function (response) {

                        if (response != 'fail') {
                            var option = '';
                            var oldStateId = <?php echo json_encode(old('state')); ?>;
                            $.each(response, function (key, value) {
                                if( oldStateId == value.state_id )
                                    option = option + '<option value="' + value.state_id + '" selected >' + value.state_name + '</option>';
                                else
                                    option = option + '<option value="' + value.state_id + '">' + value.state_name + '</option>';
                            });

                            $('#state').html('');
                            $('#state').html('<option disabled selected>Select State</option>' + option);
                            $('#state').select2();
                        }
                        else {
                            $('#state').html('');
                            $('#state').html('<option disabled selected>Select State</option>');
                            $('#state').select2();
                        }
                    }
                });
             var   StateId = <?php echo json_encode(old('state')); ?>;
                if(StateId != null) {
                    $.ajax({
                        url: "/addShopAjax",
                        type: "POST",
                        dataType: 'JSON',
                        data: {
                            action: 'getCityList',
                            stateId: StateId
                        },
                        success: function (response) {
                            if (response != 'fail') {
                                var option = '';
                                var oldCityId = <?php echo json_encode(old('city')); ?>;
                                $.each(response, function (key, value) {
                                    if( oldCityId == value.city_id )
                                        option = option + '<option value="' + value.city_id + '" selected >' + value.city_name + '</option>';
                                    else
                                        option = option + '<option value="' + value.city_id + '">' + value.city_name + '</option>';
                                });
                                $('#city').html('');
                                $('#city').html('<option disabled selected>Select City</option>' + option);
                                $('#city').select2();
                            }
                            else {
                                $('#city').html('');
                                $('#city').html('<option disabled selected>Select City</option>');
                                $('#city').select2();
                            }
                        }
                    });
                }

            }

            //This function fetch state list.
            $(document.body).on("change", '#country', function () {
                var countryId = $('#country').val();
                $.ajax({
                    url: "/addShopAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getStateList',
                        countryId: countryId
                    },
                    success: function (response) {

                        if (response != 'fail') {
                            var option = '';
                            $.each(response, function (key, value) {
                                option = option + '<option value="' + value.state_id + '">' + value.state_name + '</option>';
                            });

                            $('#state').html('');
                            $('#state').html('<option disabled selected>Select State</option>' + option);
                            $('#state').select2();
                            $('#city').html('');
                            $('#city').html('<option disabled selected>Select City</option>');
                            $('#city').select2();
                        }
                        else {
                            $('#state').html('');
                            $('#state').html('<option disabled selected>Select State</option>');
                            $('#state').select2();
                            $('#city').html('');
                            $('#city').html('<option disabled selected>Select City</option>');
                            $('#city').select2();
                        }
                    }
                });
            });

            //This function fetch city list.
            $(document.body).on("change", '#state', function () {
                var stateId = $('#state').val();
                $.ajax({
                    url: "/addShopAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getCityList',
                        stateId: stateId
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            var option = '';
                            $.each(response, function (key, value) {
                                option = option + '<option value="' + value.city_id + '">' + value.city_name + '</option>';
                            });
                            $('#city').html('');
                            $('#city').html('<option disabled selected>Select City</option>' + option);
                            $('#city').select2();
                        }
                        else {
                            $('#city').html('');
                            $('#city').html('<option disabled selected>Select City</option>');
                            $('#city').select2();
                        }
                    }
                });
            });

        });
    </script>

@endsection

