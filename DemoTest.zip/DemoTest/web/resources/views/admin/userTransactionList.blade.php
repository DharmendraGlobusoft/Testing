<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/3/2016
 * Time: 3:46 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7), th:nth-child(8), th:nth-child(9), th:nth-child(10)  {
            text-align: center !important;
            vertical-align: top !important;
        }

        td:nth-child(1), td:nth-child(2), td:nth-child(5), td:nth-child(6), td:nth-child(7), td:nth-child(8), td:nth-child(9), td:nth-child(10) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Transaction Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">User Transaction List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Sl.No.</th>
                                <th>User Id</th>
                                <th>User Name</th>
                                <th>Transaction Id</th>
                                <th>Transaction Date</th>
                                <th>Order Id</th>
                                <th>Transaction Amount</th>
                                <th>Transaction Status</th>
                                <th>Pay Type</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modal')
    <div class="modal fade" id="deleteTransactionModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Delete this user Transaction</h4>
                </div>
                <form class="form-horizontal bordered-row" action="" method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="col-sm-9 control-label" style="color:red;">Are you really want to Delete this
                                User Transaction ?</label>
                        </div>
                    </div>
                    <br>
                    <div class="modal-footer" id="setDeleteButton">
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                "ajax": {
                    "url": "/viewTransaction",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[4, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [0, 6, 7, 8, 9]}]
            });

            // This function use for only show delete modal.
            $(document.body).on('click', '#deleteTransaction', function (event) {
                event.preventDefault();

                $('#setDeleteButton').html('<button data-orderId="' + $(this).attr("data-orderId") + '" data-userPaymentId="' + $(this).attr("value") + '" ' +
                        'id="deleteButton" class="btn btn-alt btn-hover btn-primary">' +
                        ' <span>Yes</span> <i class="glyph-icon icon-arrow-right"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>' +
                        ' <button id="cancelDeleteButton" class="btn btn-alt btn-hover btn-info" data-dismiss="modal">' +
                        ' <span>No</span> <i class="glyph-icon icon-remove"></i>' +
                        ' <div class="ripple-wrapper"></div>' +
                        ' </button>');

            });

            // This function use for delete particular user transaction detail.
            $(document.body).on('click', '#deleteButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewTransactionAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deleteTransaction',
                        userPaymentId: $(this).attr("data-userPaymentId"),
                        orderId: $(this).attr("data-orderId"),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function () {
                                $("#deleteTransactionModal").fadeOut();
                                setTimeout(function () {
                                    $("#cancelDeleteButton").trigger("click");
                                }, 400);
                            }, 100);
                        }
                        else {
                            console.log('Sorry ! Transaction has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Sorry ! Transaction has not deleted.');
                    }
                }); //End of  ajax
            });
        });
    </script>
@endsection


