<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/11/2016
 * Time: 7:11 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th {
            width: auto !important;
        }

        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7) {
            text-align: center !important;
        }

        td:nth-child(4), td:nth-child(5), td:nth-child(6), td:nth-child(7) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">User details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">User List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>User Id</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>View Details</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')

    <div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">User Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-3 control-label">User Id:</label>
                                    <div>
                                        <label id="userId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-3 control-label">User Name:</label>
                                    <div>
                                        <label id="userName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this user then all detail related to
                                            this user will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="userDetailModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                    <h4 class="modal-title">User Details</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">First Name</span>
                                <br/>
                                <strong id="first_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Age</span>
                                <br/>
                                <strong id="age"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Address</span>
                                <br/>
                                <strong id="address"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Picture</span>
                                <br/>
                                <img id="image" src="" class="img-thumbnail" style="width:35%;"/>
                                <img id="default_image"
                                     src="{{ Config::get('app.API_HOST') }}profilePicture/ProfilePic.jpg"
                                     class="img-thumbnail" style="width:35%;"/>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">Last Name</span>
                                <br/>
                                <strong id="last_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Gender</span>
                                <br/>
                                <strong id="gender"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Mobile Number</span>
                                <br/>
                                <strong id="contact_number"></strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "/viewUser",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [3, 4, 5, 6]}]
            });

            //This function use for activate user status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewUserAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        userId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate user by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewUserAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        userId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            // This function use for view all details of a particular user.
            $(document.body).on('click', '#viewUserDetail', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewUserAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'viewUserDetail',
                        userId: $(this).attr("value"),
                    },
                    success: function (response) {
                        if (response != 'fail') {

                            if (response.first_name == null || response.first_name == '')
                                response.first_name = 'Not Available';

                            if (response.last_name == null || response.last_name == '')
                                response.last_name = 'Not Available';

                            if (response.age == null || response.age == '')
                                response.age = 'Not Available';
                            else
                                response.age = response.age + ' yrs';

                            if (response.gender == 1)
                                response.gender = 'Male';
                            else
                                if (response.gender == 2)
                                    response.gender = 'Female';

                            if (response.address == null || response.address == '')
                                response.address = 'Not Available';

                            if (response.contact_number == null || response.contact_number == '')
                                response.contact_number = 'Not Available';

                            if (response.image == null || response.image == '')
                            {
                                $('#image').hide();
                                $('#default_image').show();
                            }
                            else
                            {
                                $('#default_image').hide();
                                $('#image').attr('src', response.image);
                                $('#image').show();
                            }

                            $('#first_name').html(response.first_name);
                            $('#last_name').html(response.last_name);
                            $('#age').html(response.age);
                            $('#gender').html(response.gender);
                            $('#address').html(response.address);
                            $('#contact_number').html(response.contact_number);

                        }
                        else {
                            $('#first_name').html('Not Available');
                            $('#last_name').html('Not Available');
                            $('#age').html('Not Available');
                            $('#gender').html('Not Available');
                            $('#address').html('Not Available');
                            $('#contact_number').html('Not Available');
                            $('#image').hide();
                            $('#default_image').show();
                        }
                    },
                    error: function (req, status, err) {
                        $('#first_name').html('Not Available');
                        $('#last_name').html('Not Available');
                        $('#age').html('Not Available');
                        $('#gender').html('Not Available');
                        $('#address').html('Not Available');
                        $('#contact_number').html('Not Available');
                        $('#image').hide();
                        $('#default_image').show();
                    }
                }); //End of  ajax
            });

            // This function use for only show delete modal with user information.
            $(document.body).on('click', '#deleteUser', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewUserAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'userDetail',
                        userId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#userId').html(response['id']);
                            $('#userName').html(response['name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["id"] + '" class="btn btn-primary" id="userDeleteButton">Yes</button>');
                        }
                        else {
                            $('#userId').html('Not available');
                            $('#userName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#userId').html('Not available');
                        $('#userName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular user.
            $(document.body).on('click', '#userDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewUserAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        userId: $(this).attr("value")
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == 'success') {
                            $('#deleteSuccess').html('User has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);
                            setTimeout(function () {
                                $("#deleteUserModal").fadeOut();
                                setTimeout(function () {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! User has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! User has not deleted.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection
