<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/13/2016
 * Time: 5:22 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7) {
            text-align: center !important;
        }

        td:nth-child(4), td:nth-child(5), td:nth-child(6), td:nth-child(7) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">ShopKeeper details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">ShopKeeper List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Shopkeeper Id</th>
                                <th>Shopkeeper Name</th>
                                <th>Email</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>View Details</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')

    <div class="modal fade" id="deleteShopkeeperModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Shopkeeper Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-3 control-label">Shopkeeper Id:</label>
                                    <div>
                                        <label id="shopkeeperId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-3 control-label">Shopkeeper Name:</label>
                                    <div>
                                        <label id="shopkeeperName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this shopkeeper then all detail related to
                                            this shopkeeper will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="shopkeeperDetailModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                    <h4 class="modal-title">User Details</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">First Name</span>
                                <br/>
                                <strong id="first_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Age</span>
                                <br/>
                                <strong id="age"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Address</span>
                                <br/>
                                <strong id="address"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Picture</span>
                                <br/>
                                <img id="image" src="" class="img-thumbnail" style="width:35%;"/>
                                <img id="default_image"
                                     src="{{ Config::get('app.API_HOST') }}profilePicture/ProfilePic.jpg"
                                     class="img-thumbnail" style="width:35%;"/>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="m-bottom-md">
                                <span class="control-label">Last Name</span>
                                <br/>
                                <strong id="last_name"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Gender</span>
                                <br/>
                                <strong id="gender"></strong>
                            </div>
                            <div class="m-top-md m-bottom-md">
                                <span class="control-label">Mobile Number</span>
                                <br/>
                                <strong id="contact_number"></strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
                </div>
            </div>
        </div>
    </div>

@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "/viewShopkeeper",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [3, 4, 5, 6]}]
            });

            //This function use for activate shopkeeper status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewShopkeeperAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        shopkeeperId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate shopkeeper by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewShopkeeperAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        shopkeeperId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            // This function use for view all details of a particular shopkeeper.
            $(document.body).on('click', '#viewShopkeeperDetail', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewShopkeeperAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'viewShopkeeperDetail',
                        shopkeeperId: $(this).attr("value"),
                    },
                    success: function (response) {
                        if (response != 'fail') {

                            if (response.first_name == null || response.first_name == '')
                                response.first_name = 'Not Available';

                            if (response.last_name == null || response.last_name == '')
                                response.last_name = 'Not Available';

                            if (response.age == null || response.age == '')
                                response.age = 'Not Available';
                            else
                                response.age = response.age + ' yrs';

                            if (response.gender == 1)
                                response.gender = 'Male';
                            else
                            if (response.gender == 2)
                                response.gender = 'Female';
                            else
                                response.gender = 'Not Available';

                            if (response.address == null || response.address == '')
                                response.address = 'Not Available';

                            if (response.contact_number == null || response.contact_number == '')
                                response.contact_number = 'Not Available';

                            if (response.image == null || response.image == '')
                            {
                                $('#image').hide();
                                $('#default_image').show();
                            }
                            else
                            {
                                $('#default_image').hide();
                                $('#image').attr('src', response.image);
                                $('#image').show();
                            }

                            $('#first_name').html(response.first_name);
                            $('#last_name').html(response.last_name);
                            $('#age').html(response.age);
                            $('#gender').html(response.gender);
                            $('#address').html(response.address);
                            $('#contact_number').html(response.contact_number);

                        }
                        else {
                            $('#first_name').html('Not Available');
                            $('#last_name').html('Not Available');
                            $('#age').html('Not Available');
                            $('#gender').html('Not Available');
                            $('#address').html('Not Available');
                            $('#contact_number').html('Not Available');
                            $('#image').hide();
                            $('#default_image').show();
                        }
                    },
                    error: function (req, status, err) {
                        $('#first_name').html('Not Available');
                        $('#last_name').html('Not Available');
                        $('#age').html('Not Available');
                        $('#gender').html('Not Available');
                        $('#address').html('Not Available');
                        $('#contact_number').html('Not Available');
                        $('#image').hide();
                        $('#default_image').show();
                    }
                }); //End of  ajax
            });

            // This function use for only show delete modal with shopkeeper information.
            $(document.body).on('click', '#deleteShopkeeper', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewShopkeeperAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'shopkeeperDetail',
                        shopkeeperId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#shopkeeperId').html(response['id']);
                            $('#shopkeeperName').html(response['name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["id"] + '" class="btn btn-primary" id="shopkeeperDeleteButton">Yes</button>');
                        }
                        else {
                            $('#shopkeeperId').html('Not available');
                            $('#shopkeeperName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#shopkeeperId').html('Not available');
                        $('#shopkeeperName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular shopkeeper.
            $(document.body).on('click', '#shopkeeperDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewShopkeeperAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        shopkeeperId: $(this).attr("value")
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == 'success') {
                            $('#deleteSuccess').html('Shopkeeper has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function() {
                                $("#deleteShopkeeperModal").fadeOut();
                                setTimeout(function() {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! Shopkeeper has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! Shopkeeper has not deleted.');
                    }
                }); //End of  ajax
            });
        });
    </script>
@endsection

