<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/25/2016
 * Time: 3:23 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(5), td:nth-child(6) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Main Product Detail</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <h3 class="title-hero">Add New Main Product</h3>
                    <span style="color: green;" id="addSuccess">Successfully, New Main Product name has been added.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Enter the Main Product</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="addMainProductName" class="form-control" id="addMainProductName"
                                                   placeholder="Enter the main product name"/>
                                            <span style="color:#FB0007;" id="addError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addMainProductButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>SAVE</span> <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel editContent">
                <div class="panel-body">
                    <h3 class="title-hero">Edit Main Product</h3>
                    <span style="color: green;" id="editSuccess">Successfully, Main Product name has been updated.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Main Product Name</label>
                                        <div class="col-sm-9">
                                            <input type="text" data-mainProductId="" name="editMainProductName"
                                                   id="editMainProductName" class="form-control" value=""/>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="editMainProductButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                        <button id="cancelMainProductButton" class="btn btn-alt btn-hover btn-info">
                                            <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Main Product List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>MainProduct Id</th>
                                <th>MainProduct Name</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modal')
    <div class="modal fade" id="deleteMainProductModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Main Product Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-4 control-label">Main Product Id:</label>
                                    <div>
                                        <label id="mainProductId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-4 control-label">Main Product Name:</label>
                                    <div>
                                        <label id="mainProductName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this Main Product then all detail of Sub Product and Product related to
                                            this Main Product will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $('.editContent').hide();
            $('#addSuccess').hide();
            $('#editSuccess').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                "ajax": {
                    "url": "/addMainProduct",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [2, 3, 4, 5]}]
            });

            //This function use for activate Main Product status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        mainProductId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate Main Product by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        mainProductId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for display edit Main Product name section to user
            $(document.body).on('click', '#editButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'mainProductNameAndId',
                        mainProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('.addContent').hide();
                            $('.editContent').show();
                            $('#editMainProductName').val(response.product_name);
                            $('#editMainProductName').attr('value', response.product_name);
                            $('#editMainProductName').attr('data-mainProductId', response.main_product_id);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for add new Main Product name by click on save button by admin
            $(document.body).on('click', '#addMainProductButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'create',
                        mainProductName: $('#addMainProductName').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#addError').html('');
                            $('#addMainProductName').val('');
                            $('#addSuccess').show();
                            $('#addSuccess').delay( 3000).fadeOut(600);
                        }
                        else {
                            $('#addError').html(response);
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for update Main Product name by click on update button by admin
            $(document.body).on('click', '#editMainProductButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update',
                        mainProductId: $('#editMainProductName').attr('data-mainProductId'),
                        mainProductName: $('#editMainProductName').val(),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#editSuccess').show();
                            $('#editSuccess').delay( 1000).fadeOut(600);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for hide edit Main Product division and show add Main Product division.
            $(document.body).on('click', '#cancelMainProductButton', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('.addContent').show();
            });

            // This function use for only show delete modal with Main Product information.
            $(document.body).on('click', '#deleteMainProduct', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'mainProductNameAndId',
                        mainProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#mainProductId').html(response['main_product_id']);
                            $('#mainProductName').html(response['product_name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["main_product_id"] + '" class="btn btn-primary" id="mainProductDeleteButton">Yes</button>');
                        }
                        else {
                            $('#mainProductId').html('Not available');
                            $('#mainProductName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#mainProductId').html('Not available');
                        $('#mainProductName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular Main Product.
            $(document.body).on('click', '#mainProductDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/addMainProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        mainProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == 'success') {
                            $('#deleteSuccess').html('Main Product has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function() {
                                $("#deleteMainProductModal").fadeOut();
                                setTimeout(function() {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! Main Product has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! Main Product has not deleted.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection


