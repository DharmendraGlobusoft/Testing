<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/21/2016
 * Time: 8:41 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(5) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">State Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Select Country</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Country</label>
                                        <div class="col-sm-9">
                                            <select id="selectCountry" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Country</option>
                                                @if($country != null)
                                                    @foreach($country as $value)
                                                        <option value="{{$value->country_id}}">{{$value->country_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <h3 class="title-hero">Add State</h3>
                    <span style="color: green;" id="addSuccess">Successfully, New state name has been added.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Enter the State</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="addStateName" data-countryId="" class="form-control"
                                                   id="addStateName"
                                                   placeholder="Enter the State Name"/>
                                            <span style="color:#FB0007;" id="addError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addStateButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>SAVE</span> <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel editContent">
                <div class="panel-body">
                    <h3 class="title-hero">Edit State</h3>
                    <span style="color: green;" id="editSuccess">Successfully, State name has been updated.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">State Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" data-stateId="" name="editStateName"
                                                   id="editStateName" class="form-control" value=""/>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="editStateButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                        <button id="cancelStateButton" class="btn btn-alt btn-hover btn-info">
                                            <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">State List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>State Id</th>
                                <th>State Name</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>Edit</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {
            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $('.editContent').hide();
            $('.addContent').hide();
            $('#addSuccess').hide();
            $('#editSuccess').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for fetch state list according to country id.
            // And display it in dataTable.
            $(document.body).on('change', '#selectCountry', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('#addStateName').val('');
                $('#addStateName').attr('data-countryId',$(this).val());
                $('.addContent').show();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                    "ajax": {
                        "url": "/viewState",
                        "type": "POST",
                        "async": "True",
                        data: {
                            countryId: $(this).val()
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [2, 3, 4]}]
                });
            });

            //This function use for activate State status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewStateAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        stateId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate State by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewStateAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        stateId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for display edit State name section to user
            $(document.body).on('click', '#editButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewStateAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'stateNameAndId',
                        stateId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('.addContent').hide();
                            $('.editContent').show();
                            $('#editStateName').val(response.state_name);
                            $('#editStateName').attr('value', response.state_name);
                            $('#editStateName').attr('data-stateId', response.state_id);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for add new State name by click on save button by admin
            $(document.body).on('click', '#addStateButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewStateAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'create',
                        countryId:  $('#addStateName').attr('data-countryId'),
                        stateName: $('#addStateName').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#addError').html('');
                            $('#addStateName').val('');
                            $('#addSuccess').show();
                            $('#addSuccess').delay(3000).fadeOut(600);
                        }
                        else {
                            $('#addError').html(response);
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for update State name by click on update button by admin
            $(document.body).on('click', '#editStateButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewStateAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update',
                        stateId: $('#editStateName').attr('data-stateId'),
                        stateName: $('#editStateName').val(),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#editSuccess').show();
                            $('#editSuccess').delay(1000).fadeOut(600);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for hide edit State division and show add State division.
            $(document.body).on('click', '#cancelStateButton', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('.addContent').show();
            });

        });
    </script>
@endsection

