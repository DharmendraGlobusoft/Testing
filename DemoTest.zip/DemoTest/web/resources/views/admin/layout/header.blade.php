<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/3/2016
 * Time: 6:40 PM
 */
?>

<div id="page-header">
    <div id="header-nav-left">
        <a class="header-btn" id="logout-btn" href="/lockScreen" title="Lock your screen">
            <i class="glyph-icon icon-linecons-lock"></i>
        </a>
        <div class="user-account-btn dropdown">
            <a href="#" title="{{Session::get('fullName')}}" class="user-profile clearfix" data-toggle="dropdown">
                <img width="28" src="{{Session::get('imageUrl')}}" alt="">
                <span>{{Session::get('fullName')}}</span>
                <i class="glyph-icon icon-angle-down"></i>
            </a>
            <div class="dropdown-menu float-right">
                <div class="box-sm">
                    <div class="login-box clearfix" title="{{Session::get('fullName')}}">
                        <div class="user-img">
                            <a href="" title="change photo" class="change-img" data-toggle="modal" data-target="#changephoto">Change photo</a>
                            <img src="{{Session::get('imageUrl')}}" alt="Profile image">
                        </div>
                        <div class="user-info">
                            <span>{{Session::get('fullName')}}<i>Administrative Person</i></span>
                            <a href="/editProfile" title="Edit profile">Edit profile</a>
                            <a href="" class="change-pass" title="Change Password" data-toggle="modal" data-target="#changepass">Change Password</a>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="button-pane button-pane-alt pad5L pad5R text-center">
                        <a href="/logout" class="btn btn-flat display-block font-normal btn-danger">
                            <i class="glyph-icon icon-power-off"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="header-nav-right">
        <div class="dropdown" id="notifications-btn">
            <a data-toggle="dropdown" href="#" title="">
                <span class="small-badge bg-yellow notifications-count" style="color:#FB0007; width: 30px;height: 45px;"></span>
                <i class="glyph-icon icon-linecons-megaphone"></i>

            </a>
            <div class="dropdown-menu box-md float-left">
                <div class="popover-title display-block clearfix pad10A">
                    Notifications
                </div>
                <div class="scrollable-content scrollable-slim-box">
                    <ul class="no-border notifications-box">

                    </ul>
                </div>
                <div class="button-pane button-pane-alt pad5T pad5L pad5R text-center">
                    <a href="/newNotification" class="btn btn-flat btn-primary" title="View all notifications">
                        View all notifications
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
