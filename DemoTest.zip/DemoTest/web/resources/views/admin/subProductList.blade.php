<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/25/2016
 * Time: 3:23 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(5), td:nth-child(6) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Sub Product Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Select Main Product</h3>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Choose the Main Product</label>
                                        <div class="col-sm-9">
                                            <select id="selectMainProduct" class="js-example-responsive form-control"
                                                    style="width:100%;">
                                                <option disabled selected>Select Main Product</option>
                                                @if($mainProduct != null)
                                                    @foreach($mainProduct as $value)
                                                        <option value="{{$value->main_product_id}}">{{$value->product_name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <h3 class="title-hero">Add Sub Product</h3>
                    <span style="color: green;" id="addSuccess">Successfully, New SubProduct name has been added.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Enter the Sub Product</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="addSubProductName" data-mainProductId="" class="form-control"
                                                   id="addSubProductName"
                                                   placeholder="Enter the sub product name"/>
                                            <span style="color:#FB0007;" id="addError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addSubProductButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>SAVE</span> <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel editContent">
                <div class="panel-body">
                    <h3 class="title-hero">Edit Sub Product</h3>
                    <span style="color: green;" id="editSuccess">Successfully, Sub Product name has been updated.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Sub Product Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" data-subProductId="" name="editSubProductName"
                                                   id="editSubProductName" class="form-control" value=""/>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="editSubProductButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                        <button id="cancelSubProductButton" class="btn btn-alt btn-hover btn-info">
                                            <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Sub Product List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Sub Product Id</th>
                                <th>Sub Product Name</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modal')
    <div class="modal fade" id="deleteSubProductModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Sub Product Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-4 control-label">Sub Product Id:</label>
                                    <div>
                                        <label id="subProductId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-4 control-label">Sub Product Name:</label>
                                    <div>
                                        <label id="subProductName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this Sub Product then all detail of Product related to
                                            this Sub Product will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {
            //This statement include the search functionality inside the select tag of html.
            $(".js-example-responsive").select2();

            $('.editContent').hide();
            $('.addContent').hide();
            $('#addSuccess').hide();
            $('#editSuccess').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for fetch Sub Product list according to Main Product id.
            // And display it in dataTable.
            $(document.body).on('change', '#selectMainProduct', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('#addSubProductName').val('');
                $('#addSubProductName').attr('data-mainProductId',$(this).val());
                $('.addContent').show();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                    "ajax": {
                        "url": "/addSubProduct",
                        "type": "POST",
                        "async": "True",
                        data: {
                            mainProductId: $(this).val()
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [2, 3, 4, 5]}]
                });
            });

            //This function use for activate Sub Product status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        subProductId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate Sub Product by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        subProductId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for display edit Sub Product name section to user
            $(document.body).on('click', '#editButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'subProductNameAndId',
                        subProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('.addContent').hide();
                            $('.editContent').show();
                            $('#editSubProductName').val(response.product_name);
                            $('#editSubProductName').attr('value', response.product_name);
                            $('#editSubProductName').attr('data-subProductId', response.sub_product_id);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for add new Sub Product name by click on save button by admin
            $(document.body).on('click', '#addSubProductButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'create',
                        mainProductId:  $('#addSubProductName').attr('data-mainProductId'),
                        subProductName: $('#addSubProductName').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#addError').html('');
                            $('#addSubProductName').val('');
                            $('#addSuccess').show();
                            $('#addSuccess').delay(3000).fadeOut(600);
                        }
                        else {
                            $('#addError').html(response);
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for update Sub Product name by click on update button by admin
            $(document.body).on('click', '#editSubProductButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update',
                        subProductId: $('#editSubProductName').attr('data-subProductId'),
                        subProductName: $('#editSubProductName').val(),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#editSuccess').show();
                            $('#editSuccess').delay(1000).fadeOut(600);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for hide edit Sub Product division and show add Sub Product division.
            $(document.body).on('click', '#cancelSubProductButton', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('.addContent').show();
            });

            // This function use for only show delete modal with Sub Product information.
            $(document.body).on('click', '#deleteSubProduct', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'subProductNameAndId',
                        subProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#subProductId').html(response['sub_product_id']);
                            $('#subProductName').html(response['product_name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["sub_product_id"] + '" class="btn btn-primary" id="subProductDeleteButton">Yes</button>');
                        }
                        else {
                            $('#subProductId').html('Not available');
                            $('#subProductName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#subProductId').html('Not available');
                        $('#subProductName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular Sub Product.
            $(document.body).on('click', '#subProductDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/addSubProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        subProductId: $(this).attr("value")
                    },
                    success: function (response) {
                        console.log(response);
                        if (response == 'success') {
                            $('#deleteSuccess').html('Sub Product has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function() {
                                $("#deleteSubProductModal").fadeOut();
                                setTimeout(function() {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! Sub Product has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! Sub Product has not deleted.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection


