<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/30/2016
 * Time: 5:49 PM
 */
?>
@extends('admin.layout.master')

@section('head')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        #otherimagesdiv .fileinput-exists {
            display: initial !important;
        }

        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
        .text-center-td {
            text-align: center !important;
        }
        #todolist {
            width: 100%;
        }

        #todolist1 {
            width: 100%;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 id="viewProduct"><i class="glyph-icon icon-linecons-eye"></i> View Product Details</h2>
        <h2 id="editProduct"><i class="glyph-icon icon-linecons-pencil"></i> Edit Product Details</h2>
        <span class="success"
              style="margin-left:40px;">@if(Session::has('success')){{Session::get('success')}}@endif</span>
        <span class="error" style="margin-left:50px;">@if(Session::has('fail')){{Session::get('fail')}}@endif</span>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newProductForm" class="form-horizontal bordered-row"
                  action="/viewProductDetail/@if($productData['product_id']!= null){{$productData['product_id']}}@endif"
                  method="post" enctype="multipart/form-data" files="true">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label"> Category </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width:35%;">
                                                <label class="control-label">Main Product</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($productData['main_product_name']!= null)
                                                        {{$productData['main_product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Sub Product</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($productData['sub_product_name']!= null)
                                                        {{$productData['sub_product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body" style="min-height: 360px;height: 100%;">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:210px;">
                                                <label id="viewProduct" class="control-label">Product Details</label>
                                                <label id="editProduct" class="control-label">Change Product
                                                    Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Name</label>
                                            </td>
                                            <td>
                                                <input id="editProduct" type="text" class="form-control"
                                                       name="productName"

                                                       @if(Session::has('error'))
                                                       value="{{old('productName')}}"
                                                       @else
                                                       @if(old('productName'))
                                                       value="{{old('productName')}}"
                                                       @else
                                                       @if($productData['product_name'] != NULL)
                                                       value="{{$productData['product_name']}}"
                                                       @endif
                                                       @endif
                                                       @endif
                                                       placeholder="Enter the shop name"/>
                                                <span class="error"> {{ $errors->productError->first('product_name') }}</span>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['product_name']!= NULL)
                                                        {{$productData['product_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        @if($productData['image']!= null)
                                                            <img src="{{$productData['image']}}">
                                                            <input type="hidden" value="{{$productData['image']}}"
                                                                   name="productImagePath">
                                                        @else
                                                            <img src="http://placehold.it/200x150">
                                                        @endif
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                    <div id="editProduct">
														<span class="btn btn-default btn-file">
															<span class="fileinput-new">Select Image</span>
															<span class="fileinput-exists">Replace</span>
															<input type="file" name="productImage">
														</span>
                                                        <a href="#" class="btn btn-danger fileinput-exists"
                                                           data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                    <span class="error"> {{ $errors->productError->first('product_image') }}</span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Weight</label>
                                            </td>
                                            <td style="width:278px;">
                                                <input id="editProduct" type="text" class="form-control"
                                                       name="productWeight"

                                                       @if(Session::has('error'))
                                                       value="{{old('productWeight')}}"
                                                       @else
                                                       @if(old('productWeight'))
                                                       value="{{old('productWeight')}}"
                                                       @else
                                                       @if($productData['product_weight'] != NULL)
                                                       value="{{$productData['product_weight']}}"
                                                       @endif
                                                       @endif
                                                       @endif
                                                       placeholder="Enter the product weight"/>
                                                <span class="error"> {{ $errors->productError->first('product_weight') }}</span>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['product_weight']!= NULL)
                                                        {{$productData['product_weight']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Cost</label>
                                            </td>
                                            <td>
                                                <div class="input-group" id="editProduct">
                                                <span class="input-group-addon addon-inside bg-black">
                                                        <i class="glyph-icon icon-rupee"></i>
                                                </span>
                                                    <input type="text" class="form-control"
                                                           name="productCost"

                                                           @if(Session::has('error'))
                                                           value="{{old('productCost')}}"
                                                           @else
                                                           @if(old('productCost'))
                                                           value="{{old('productCost')}}"
                                                           @else
                                                           @if($productData['cost'] != NULL)
                                                           value="{{$productData['cost']}}"
                                                           @endif
                                                           @endif
                                                           @endif
                                                           placeholder="Enter the product cost"/>
                                                </div>
                                                <span class="error"> {{ $errors->productError->first('product_cost') }}</span>

                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['cost']!= NULL)
                                                        <i class="glyph-icon icon-rupee"></i>
                                                        {{$productData['cost']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Service Tax</label>
                                            </td>
                                            <td>
                                                <input id="editProduct" type="text" class="form-control"
                                                       name="productServiceTax"
                                                       @if(Session::has('error'))
                                                       value="{{old('productServiceTax')}}"
                                                       @else
                                                       @if(old('productServiceTax'))
                                                       value="{{old('productServiceTax')}}"
                                                       @else
                                                       @if($productData['service_tax'] != NULL)
                                                       value="{{$productData['service_tax']}}"
                                                       @endif
                                                       @endif
                                                       @endif
                                                       placeholder="Enter the product service tax"/>
                                                <span class="error"> {{ $errors->productError->first('product_service_tax') }}</span>
                                                <label id="viewProduct" class="form-control" style="width:100%;">
                                                    @if($productData['service_tax']!= NULL)
                                                        {{$productData['service_tax']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Description</label>
                                            </td>
                                            <td>
                                                @if(Session::has('error'))
                                                    <?php  $textAreaContent = old('productDescription'); ?>
                                                @else
                                                    @if(old('productDescription'))
                                                        <?php  $textAreaContent = old('productDescription'); ?>
                                                    @else
                                                        @if($productData['product_detail'] != NULL)
                                                            <?php  $textAreaContent = $productData['product_detail']; ?>
                                                        @endif
                                                    @endif
                                                @endif
                                                <textarea id="todolist" class="form-control"
                                                          name="productDescription"
                                                          placeholder="Enter the product description"
                                                          style="height: 60px;">{{$textAreaContent}}</textarea>
                                                <span class="error"> {{ $errors->productError->first('product_description') }}</span>
                                                {{--<label id="viewProduct" class="form-control"--}}
                                                {{--style="width:100%; height: 60px; scroll-behavior: auto;">--}}
                                                {{--@if($productData['product_detail']!= NULL)--}}
                                                {{--{{$productData['product_detail']}}--}}
                                                {{--@endif--}}
                                                {{--</label>--}}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Features</label>
                                            </td>
                                            <td>

                                                @if(Session::has('error'))
                                                    <?php  $textAreaContent = old('productFeatures'); ?>
                                                @else
                                                    @if(old('productFeatures'))
                                                        <?php  $textAreaContent = old('productFeatures'); ?>
                                                    @else
                                                        @if($productData['product_detail'] != NULL)
                                                            <?php  $textAreaContent = $productData['product_features']; ?>
                                                        @endif
                                                    @endif
                                                @endif
                                                <textarea id="todolist1" class="todolist1" class="form-control"
                                                          name="productFeatures"
                                                          placeholder="Enter the product Features"
                                                          style="height: 60px;">{{$textAreaContent}}</textarea>
                                                <span class="error"> {{ $errors->productError->first('product_features') }}</span>
                                                {{--<label id="viewProduct" class="form-control"--}}
                                                {{--style="width:100%; height: 60px; scroll-behavior: auto;">--}}
                                                {{--@if($productData['product_features']!= NULL)--}}
                                                {{--{{$productData['product_features']}}--}}
                                                {{--@endif--}}
                                                {{--</label>--}}
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{--======================Added by Dharmendra=======================================--}}


                    @if($productData['sub_product_id'] == 44)

                        {{--cloth size--}}
                        <div class="col-md-11 cloth" style="text-align:center; width:100%">
                            <div class="panel">
                                <div class="panel-body">
                                    <div class="example-box-wrapper">
                                        <table class="table table-responsive">
                                            <tbody>
                                            <tr style="display: flex;align-content: center;">
                                                <td class="text-center-td">
                                                    <label class="control-label"
                                                           style="font-size: 16px;color: #fb004c;margin-bottom: 5px">Size</label>
                                                    <label class="control-label"
                                                           style="font-size: 16px;color: #fb004c;">Quantity</label>
                                                </td>
                                                <td class="text-center-td">
                                                    <label class="control-label size-head">S</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['sizeS']}}"
                                                           class="numeric" name="sizeS" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">M</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['sizeM']}}"
                                                           class="numeric" name="sizeM" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">L</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['sizeL']}}"
                                                           class="numeric" name="sizeL" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">XL</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['sizeXL']}}"
                                                           class="numeric" name="sizeXL" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">XXL</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['sizeXXL']}}"
                                                           class="numeric" name="sizeXXL" class="form-control">
                                                </td>
                                                <td>

                                                </td>
                                            </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    @else

                        {{--shoes size--}}
                        <div class="col-md-11 shoe" style="text-align:center; width:100%">
                            <div class="panel">
                                <div class="panel-body">
                                    <div class="example-box-wrapper">
                                        <table class="table table-responsive">
                                            <tbody>
                                            <tr style="display: flex;align-content: center;">
                                                <td class="text-center-td">
                                                    <label class="control-label"
                                                           style="font-size: 16px;color: #fb004c;margin-bottom: 5px">Size
                                                        No.</label>
                                                    <label class="control-label"
                                                           style="font-size: 16px;color: #fb004c;">Quantity</label>
                                                </td>
                                                <td class="text-center-td">
                                                    <label class="control-label size-head">6</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['size6']}}"
                                                           class="numeric" name="size6" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">7</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['size7']}}"
                                                           class="numeric" name="size7" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">8</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['size8']}}"
                                                           class="numeric" name="size8" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">9</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['size9']}}"
                                                           class="numeric" name="size9" class="form-control">
                                                </td>
                                                <td class="text-center-td">

                                                    <label class="control-label size-head">10</label>
                                                    <input type="number"
                                                           value="{{$productData['stockdetails']['size10']}}"
                                                           class="numeric" name="size10" class="form-control">
                                                </td>
                                                <td>

                                                </td>
                                            </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                    @endif
                    {{--===================================================================================================--}}
                    @if(empty($otherImages))
                        <div class="col-md-11" style="text-align:center; width:100%" id="editProduct">
                            @else
                                <div class="col-md-11" style="text-align:center; width:100%">
                                    @endif
                                    <div class="panel">
                                        <div class="panel-body">
                                            <div class="example-box-wrapper">
                                                <table class="table table-responsive">
                                                    <tbody>
                                                    <tr>
                                                        <td>
                                                            <label class="control-label">Product Others Image</label>
                                                        </td>
                                                        <td>
                                                            <div class="fileinput fileinput-new"
                                                                 data-provides="fileinput"
                                                                 id="otherimagesdiv">
                                                                <?php $temp = 0;?>
                                                                @foreach($otherImages as $eachimage)
                                                                    <div id="otherimagepreviewdiv{{$temp}}"
                                                                         class="fileinput-preview fileinput-exists thumbnail otherimagesdivs"
                                                                         style="width: 200px; height: 150px; float: left; margin-right: 10px;">
                                                                        <img src="{{$eachimage->image_url}}"
                                                                             style="width: 150px; height: 185px;">
                                                                    </div>
                                                                    <?php $temp++; ?>
                                                                @endforeach

                                                                @if($temp==0)
                                                                    <div class="fileinput-new thumbnail"
                                                                         style="width: 200px; height: 150px;">
                                                                        <img src="http://placehold.it/200x150"
                                                                             alt=""/>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                            <div id="editProduct">
                                                    <span class="btn default btn-file btn-default">
                                                        <span class="fileinput-new"
                                                              id="otherimageselect"> Select Image</span>
                                                        <span class="fileinput-exists hidden" id="otherimagechange"> Replace </span>
                                                        <input type="hidden" name="exist_other_image" value="noChange"
                                                               id="noChangeField">
                                                        <input type="file" name="product_other_image[]" multiple=""
                                                               accept="image/*" id="otherimages">
                                                    </span>
                                                                <a class="btn default fileinput-exists btn-danger hidden"
                                                                   data-dismiss="fileinput" id="otherimagesremove">
                                                                    Remove All</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="buttonBar" class="col-md-11" style="text-align: center; width: 100%;">
                                    <div class="panel">
                                        <div class="panel-body">
                                            <div class="example-box-wrapper">
                                                <div class="form-group">
                                                    <button id="editProduct" type="submit"
                                                            class="btn btn-alt btn-hover btn-success saveButton">
                                                        <span>Save</span>
                                                        <i class="glyph-icon icon-save"></i>
                                                        <div class="ripple-wrapper"></div>
                                                    </button>

                                                    <button id="editProduct"
                                                            class="btn btn-alt btn-hover btn-secondary cancelButton">
                                                        <span>Cancel</span>
                                                        <i class="glyph-icon icon-remove"></i>
                                                        <div class="ripple-wrapper"></div>
                                                    </button>

                                                    <button id="viewProduct"
                                                            class="btn btn-alt btn-hover btn-primary editButton">
                                                        <span>Edit</span>
                                                        <i class="glyph-icon icon-linecons-pencil"></i>
                                                        <div class="ripple-wrapper"></div>
                                                    </button>

                                                    <button id="viewProduct"
                                                            class="btn btn-alt btn-hover btn-info viewListButton">
                                                        <span>View Product List</span>
                                                        <i class="glyph-icon icon-arrow-right"></i>
                                                        <div class="ripple-wrapper"></div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                </div>
                <input type="text" name="subProduct" value="{{$productData["sub_product_id"]}}" hidden>
            </form>
        </div>
    </div>

@endsection

@section('script')
    <script src="/assets/admin/js/select2.full.min.js"></script>

    <script>
        $(document).ready(function () {
            <?php
            if(Session::has('error')){
            ?>
            $('[id*="viewProduct"]').hide();
            $(".js-example-responsive").select2();
            <?php
            }
            else{
            ?>
            $('[id*="editProduct"]').hide();
            <?php
            }
            ?>

            $(document.body).on("click", '.viewListButton', function (event) {
                event.preventDefault();
                window.location.replace('/viewProduct');
            });

            $(document.body).on("click", '.editButton', function (event) {
                event.preventDefault();
                $('[id*="viewProduct"]').hide();
                $('[id*="editProduct"]').show();
                $('[class*="error"]').show();
            });

            $(document.body).on("click", '.cancelButton', function (event) {
                event.preventDefault();
                $('[id*="viewProduct"]').show();
                $('[id*="editProduct"]').hide();
                $('[class*="error"]').hide();

            });

            //It is ajax function which added a csrf token in meta tag of view page
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $(document.body).on('change', '#otherimages', function (e) {
                e.preventDefault();
                var obj = $(this);
                var imagecount = 0;
                var files1 = e.target.files === undefined ? (e.target && e.target.value ? [{name: e.target.value.replace(/^.+\\/, '')}] : []) : e.target.files;
                if (files1.length > 0) {
                    if (files1.length <= 3) {
                        var el = '';
                        var flag = false;
                        $('#otherimagesdiv').html('');
                        $.each(files1, function (i, a) {
                            var file = a;
                            el = '<div class="fileinput-preview fileinput-exists thumbnail otherimagesdivs" style="width: 200px; height: 150px; float: left; margin-right: 10px;" id="otherimagepreviewdiv' + imagecount + '">';
                            el += '</div>';
                            var img = document.createElement("img");
                            if ((typeof file.type !== "undefined" ? file.type.match(/^image\/(gif|png|jpeg)$/) : file.name.match(/\.(gif|png|jpeg)$/i)) && typeof FileReader !== "undefined") {
                                if (i == 0) {
                                    flag = true;
                                }
                                var reader = new FileReader();
                                $('#otherimagesdiv').append(el);
                                reader.onload = function (re) {
                                    img.src = re.target.result;
                                }
                                reader.readAsDataURL(file);
                                $('#otherimagepreviewdiv' + imagecount).html(img);
                                flag = flag && true;
                            }
                            imagecount++;
                        });
                        if (flag) {
                            $('#otherimagesdiv').removeClass('fileinput-new');
                            $('#otherimagesdiv').addClass('fileinput-exists');
                            $('#otherimagesremove').removeClass('hidden');
                            $('#otherimagechange').removeClass('hidden');
                            $('#otherimageselect').addClass('hidden');

                        } else {
                            alert("Image should be gif or png or jpeg format.");
                        }
                    } else {
                        alert("You can't upload more than 3 images.");
                    }

                } else {
                    var toAppend = '<div class="fileinput-new thumbnail" style="width: 200px; height: 150px; float: left; margin-right: 10px;">';
                    toAppend += '<img src="http://placehold.it/200x150" alt=""/>';
                    toAppend += '</div>';
                    $('#otherimagesdiv').html(toAppend);
                    $('#otherimagechange').addClass('hidden');
                    $('#otherimageselect').removeClass('hidden');
                    $('#otherimagesdiv').removeClass('fileinput-exists');
                    $('#otherimagesdiv').addClass('fileinput-new');
                    $('#otherimages').val('');
                }
            });

            $(document.body).on('change', '#otherimages', function (e) {
                $('#noChangeField').val('change');
            });

            $(document.body).on('click', '#otherimagesremove', function (e) {
                $('#noChangeField').val('change');
                var toAppend = '<div class="fileinput-new thumbnail" style="width: 200px; height: 150px; float: left; margin-right: 10px;">';
                toAppend += '<img src="http://placehold.it/200x150" alt=""/>';
                toAppend += '</div>';
                $('#otherimagesdiv').html(toAppend);
                $('#otherimagesdiv').removeClass('fileinput-exists');
                $('#otherimagesdiv').addClass('fileinput-new');
                $('#otherimagechange').addClass('hidden');
                $('#otherimageselect').removeClass('hidden');
                $('#otherimagesremove').addClass('hidden');
                $('#otherimages').val('');
            });
        });
    </script>

    <script>
        $(document).ready(function () {
            var id = '{{$productData["sub_product_id"]}}';
            if (id == 44) {  //for server 47
                $('.shoe ').hide();
                $('.cloth').show();
            } else if (id == 43) {  //for server 48
                $('.cloth').hide();
                $('.shoe ').show();
            }

        });

        $('.numeric').on('input', function (event) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>


    <script>
        $(".todolist1").focus(function () {
            if (document.getElementById('todolist1').value === '') {
                document.getElementById('todolist1').value += '• ';
            }
        });
        $(".todolist1").keyup(function (event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                document.getElementById('todolist1').value += '• ';
            }
            var txtval = document.getElementById('todolist1').value;
            if (txtval.substr(txtval.length - 1) == '\n') {
                document.getElementById('todolist1').value = txtval.substring(0, txtval.length - 1);
            }
        });
    </script>

@endsection

