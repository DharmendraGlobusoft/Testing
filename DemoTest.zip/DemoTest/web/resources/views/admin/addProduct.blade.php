<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/26/2016
 * Time: 12:58 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
        .control-label.size-head {
            font-size: 16px;
            margin-bottom: 10px;
            color: #918d99;
        }
        .text-center-td {
            text-align: center !important;
        }
        #todolist {width:100%;}
        #todolist1 {width:100%;}
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2>Add new Product</h2>
        <span class="success"
              style="margin-left:40px;">@if(Session::has('success')){{Session::get('success')}}@endif</span>
        <span class="error" style="margin-left:50px;">@if(Session::has('fail')){{Session::get('fail')}}@endif</span>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newProductForm" class="form-horizontal bordered-row" action="/addProduct" method="post"
                  enctype="multipart/form-data" files="true">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label">Choose Category </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width:35%;">
                                                <label class="control-label">Choose Main Product</label>
                                            </td>
                                            <td>
                                                <select name="mainProduct" id="mainProduct"
                                                        class="js-example-responsive form-control" style="width:100%;">
                                                    <option disabled selected value="null">Select Main Product</option>
                                                    @if($mainProductData != null)
                                                        @foreach($mainProductData as $value)
                                                            <option value="{{$value->main_product_id}}"
                                                                    @if(old('mainProduct') == $value->main_product_id) selected @endif>
                                                                {{$value->product_name}}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                                <span class="error"> {{ $errors->createProductError->first('main_product') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Choose Sub Product</label>
                                            </td>
                                            <td>
                                                <select name="subProduct" id="subProduct"
                                                        class="js-example-responsive form-control" style="width:100%;">
                                                    <option disabled selected>Select Sub Product</option>
                                                </select>
                                                <span class="error"> {{ $errors->createProductError->first('sub_product') }}</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label">Add Product Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Name</label>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="productName"
                                                       value="{{old('productName')}}"
                                                       placeholder="Enter the product name"/>
                                                <span class="error"> {{ $errors->createProductError->first('product_name') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        {{--<img src="http://placehold.it/200x150" alt="">--}}
                                                        <img src="/assets/admin/images/default-product-image.png" alt="">
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                    <div>
														<span class="btn btn-default btn-file">
															<span class="fileinput-new">Select Image</span>
															<span class="fileinput-exists">Replace</span>
															<input type="file" name="productImage">
														</span>
                                                        <a href="#" class="btn btn-danger fileinput-exists"
                                                           data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                    <span class="error"> {{ $errors->createProductError->first('product_image') }}</span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Weight</label>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="productWeight"
                                                       value="{{old('productWeight')}}"
                                                       placeholder="Enter the product weight"/>
                                                <span class="error"> {{ $errors->createProductError->first('product_weight') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Cost</label>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                     <span class="input-group-addon addon-inside bg-black">
                                                        <i class="glyph-icon icon-rupee"></i>
												    </span>
                                                    <input type="text" class="form-control" name="productCost"
                                                           value="{{old('productCost')}}"
                                                           placeholder="Enter the product cost"/>
                                                </div>
                                                <span class="error"> {{ $errors->createProductError->first('product_cost') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Service Tax (in %)</label>
                                            </td>
                                            <td>
                                                <input type="text" class="form-control" name="productServiceTax"
                                                       value="{{old('productServiceTax')}}"
                                                       placeholder="Enter the product service tax"/>
                                                <span class="error"> {{ $errors->createProductError->first('product_service_tax') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Description</label>
                                            </td>
                                            <td>
                                                <textarea id="todolist" class="todolist" class="form-control" name="productDescription"
                                                          placeholder="Enter the product description"
                                                          style="height:60px;">{{old('productDescription')}}</textarea>
                                                <span class="error"> {{ $errors->createProductError->first('product_description') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Features</label>
                                            </td>
                                            <td>
                                                <textarea id="todolist1" class="todolist1" class="form-control" name="productFeatures"
                                                          placeholder="Enter the product features"
                                                          style="height:60px;">{{old('productFeatures')}}</textarea>
                                                <span class="error"> {{ $errors->createProductError->first('product_features') }}</span>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{--======================Added by Dharmendra=======================================--}}
                    <div class="col-md-11 shoe" style="text-align:center; width:100%">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr style="display: flex;align-content: center;">
                                            <td class="text-center-td">
                                                <label class="control-label" style="font-size: 16px;color: #fb004c;margin-bottom: 5px" >Size No.</label>
                                                <label class="control-label"  style="font-size: 16px;color: #fb004c;">Quantity</label>
                                            </td>
                                            <td class="text-center-td">
                                                <label class="control-label size-head">6</label>
                                                <input type="number" class="numeric" name="size6" class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">7</label>
                                                <input type="number" class="numeric" name="size7"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">8</label>
                                                <input type="number" class="numeric" name="size8"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">9</label>
                                                <input type="number" class="numeric" name="size9"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">10</label>
                                                <input type="number" class="numeric" name="size10"  class="form-control">
                                            </td>
                                            <td>

                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-11 cloth" style="text-align:center; width:100%">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr style="display: flex;align-content: center;">
                                            <td class="text-center-td">
                                                <label class="control-label" style="font-size: 16px;color: #fb004c;margin-bottom: 5px" >Size</label>
                                                <label class="control-label"  style="font-size: 16px;color: #fb004c;">Quantity</label>
                                            </td>
                                            <td class="text-center-td">
                                                <label class="control-label size-head">S</label>
                                                <input type="number" class="numeric" name="sizeS"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">M</label>
                                                <input type="number" class="numeric" name="sizeM"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">L</label>
                                                <input type="number" class="numeric" name="sizeL"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">XL</label>
                                                <input type="number" class="numeric" name="sizeXL"  class="form-control">
                                            </td>
                                            <td class="text-center-td">

                                                <label class="control-label size-head">XXL</label>
                                                <input type="number" class="numeric" name="sizeXXL"  class="form-control">
                                            </td>
                                            <td>

                                            </td>
                                        </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{--===================================================================================================--}}


                    <div class="col-md-11" style="text-align:center; width:100%">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <label class="control-label">Product Others Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput" id="otherimagesdiv">
                                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                                                        {{--<img src="http://placehold.it/200x150" alt=""/>--}}
                                                        <img src="/assets/admin/images/default-product-image.png" alt=""/>
                                                    </div>
                                                </div>
                                                <div>
                                                    <span class="btn btn-default btn-file">
                                                        <span class="fileinput-new" id="otherimageselect">Select Image</span>
                                                        <span class="fileinput-exists hidden" id="otherimagechange"> Replace </span>
                                                        <input type="file" name="product_other_image[]" multiple="" accept="image/*" id="otherimages">
                                                    </span>
                                                    <a class="btn default fileinput-exists btn-danger hidden"
                                                       data-dismiss="fileinput" id="otherimagesremove"> Remove All</a>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-11" style="text-align:center; width:100%">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-alt btn-hover btn-primary">
                                            <span>Create</span>
                                            <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('script')
    {{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>--}}
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script type="text/javascript">
        //This statement include the search functionality inside the select tag of html.
        $(".js-example-responsive").select2();

        $(document).ready(function () {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $(document.body).on('change', '#otherimages', function (e) {
                e.preventDefault();
                var obj = $(this);
                var imagecount = 0;
                var files1 = e.target.files === undefined ? (e.target && e.target.value ? [{name: e.target.value.replace(/^.+\\/, '')}] : []) : e.target.files;
                if (files1.length > 0) {
                    if (files1.length <= 7) {
                        var el = '';
                        var flag = false;
                        $('#otherimagesdiv').html('');
                        $.each(files1, function (i, a) {
                            var file = a;
                            el = '<div class="fileinput-preview fileinput-exists thumbnail otherimagesdivs" style="width: 200px; height: 150px;" id="otherimagepreviewdiv' + imagecount + '">';
                            el += '</div>';
                            var img = document.createElement("img");
                            if ((typeof file.type !== "undefined" ? file.type.match(/^image\/(gif|png|jpeg)$/) : file.name.match(/\.(gif|png|jpeg)$/i)) && typeof FileReader !== "undefined") {
                                if (i == 0) {
                                    flag = true;
                                }
                                var reader = new FileReader();
                                $('#otherimagesdiv').append(el);
                                reader.onload = function (re) {
                                    img.src = re.target.result;
                                }
                                reader.readAsDataURL(file);
                                $('#otherimagepreviewdiv' + imagecount).html(img);
                                flag = flag && true;
                            }
                            imagecount++;
                        });
                        if (flag) {
                            $('#otherimagesdiv').removeClass('fileinput-new');
                            $('#otherimagesdiv').addClass('fileinput-exists');
                            $('#otherimagesremove').removeClass('hidden');
                            $('#otherimagechange').removeClass('hidden');
                            $('#otherimageselect').addClass('hidden');
                        } else {
                            alert("Image should be gif or png or jpeg format.");
                        }
                    } else {
                        alert("You can't upload more than 7 images.");
                    }

                } else {
                    var toAppend = '<div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">';
//                    toAppend += '<img src="http://placehold.it/200x150" alt=""/>';
                    toAppend += '<img src="/assets/admin/images/default-product-image.png" alt=""/>';
                    toAppend += '</div>';
                    $('#otherimagesdiv').html(toAppend);
                    $('#otherimagechange').addClass('hidden');
                    $('#otherimageselect').removeClass('hidden');
                    $('#otherimagesdiv').removeClass('fileinput-exists');
                    $('#otherimagesdiv').addClass('fileinput-new');
                    $('#otherimages').val('');
                }
            });

            $(document.body).on('click', '#otherimagesremove', function (e) {
                var toAppend = '<div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">';
//                toAppend += '<img src="http://placehold.it/200x150" alt=""/>';
                toAppend += '<img src="/assets/admin/images/default-product-image.png" alt=""/>';
                toAppend += '</div>';
                $('#otherimagesdiv').html(toAppend);
                $('#otherimagesdiv').removeClass('fileinput-exists');
                $('#otherimagesdiv').addClass('fileinput-new');
                $('#otherimagechange').addClass('hidden');
                $('#otherimageselect').removeClass('hidden');
                $('#otherimagesremove').addClass('hidden');
                $('#otherimages').val('');
            });

            //Below function fetched the sub product and put it in required field as their old input.
            var mainProductId = $('#mainProduct').val();
            if (mainProductId != null) {
                $.ajax({
                    url: "/addProductAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getSubProductList',
                        mainProductId: mainProductId
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            var option = '';
                            var oldValue = '<?php echo json_encode(old('subProduct')); ?>';
                            $.each(response, function (key, value) {
                                if (oldValue == value.sub_product_id)
                                    option = option + '<option value="' + value.sub_product_id + '" selected >' + value.product_name + '</option>';
                                else
                                    option = option + '<option value="' + value.sub_product_id + '">' + value.product_name + '</option>';
                            });

                            $('#subProduct').html('');
                            $('#subProduct').html('<option disabled selected>Select Sub Product</option>' + option);
                            $('#subProduct').select2();
                        }
                        else {
                            $('#subProduct').html('');
                            $('#subProduct').html('<option disabled selected>Select Sub Product</option>');
                            $('#subProduct').select2();
                        }
                    }
                });
            }

            //This function fetch sub product list.
            $(document.body).on("change", '#mainProduct', function () {
                var mainProductId = $('#mainProduct').val();
                $.ajax({
                    url: "/addProductAjax",
                    type: "POST",
                    dataType: 'JSON',
                    data: {
                        action: 'getSubProductList',
                        mainProductId: mainProductId
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            var option = '';
                            $.each(response, function (key, value) {
                                option = option + '<option value="' + value.sub_product_id + '">' + value.product_name + '</option>';
                            });

                            $('#subProduct').html('');
                            $('#subProduct').html('<option disabled selected>Select Sub Product</option>' + option);
                            $('#subProduct').select2();
                        }
                        else {
                            $('#subProduct').html('');
                            $('#subProduct').html('<option disabled selected>Select Sub Product</option>');
                            $('#subProduct').select2();
                        }
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.shoe ').hide();
            $('.cloth').hide();

        });
        $("#subProduct").change(function () {
            if ($(this).val()== 44) {
                $('.shoe ').hide();
                $('.cloth').show();
            }else if($(this).val()== 43){
                $('.cloth').hide();
                $('.shoe ').show();
            }
        });

        $('.numeric').on('input', function (event) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>

    {{--<script>--}}
        {{--$(".todolist").focus(function() {--}}
            {{--if(document.getElementById('todolist').value === ''){--}}
                {{--document.getElementById('todolist').value +='• ';--}}
            {{--}--}}
        {{--});--}}
        {{--$(".todolist").keyup(function(event){--}}
            {{--var keycode = (event.keyCode ? event.keyCode : event.which);--}}
            {{--if(keycode == '13'){--}}
                {{--document.getElementById('todolist').value +='• ';--}}
            {{--}--}}
            {{--var txtval = document.getElementById('todolist').value;--}}
            {{--if(txtval.substr(txtval.length - 1) == '\n'){--}}
                {{--document.getElementById('todolist').value = txtval.substring(0,txtval.length - 1);--}}
            {{--}--}}
        {{--});--}}
    {{--</script>--}}

    <script>
        $(".todolist1").focus(function() {
            if(document.getElementById('todolist1').value === ''){
                document.getElementById('todolist1').value +='• ';
            }
        });
        $(".todolist1").keyup(function(event){
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if(keycode == '13'){
                document.getElementById('todolist1').value +='• ';
            }
            var txtval = document.getElementById('todolist1').value;
            if(txtval.substr(txtval.length - 1) == '\n'){
                document.getElementById('todolist1').value = txtval.substring(0,txtval.length - 1);
            }
        });
    </script>

@endsection
