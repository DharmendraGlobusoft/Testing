<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 6/8/2016
 * Time: 2:01 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Add new shopkeeper</h2>
        <span class="success" id="successMsg" style="margin-left:40px;">you have successfully created shopkeeper.</span>
        <span class="error" id="errorMsg" style="margin-left:50px;">Sorry ! shopkeeper has not created.</span>
    </div>
    <div class="center-content">
        <form action="" id="createShopkeeperForm" class="col-md-4 col-sm-5 col-xs-11 col-lg-10 center-margin"
              method="post">
            {{ csrf_field() }}
            <input name="timezone" type="hidden" value="" id="timezone">
            <div id="login-form" class="content-box bg-default">
                <div class="content-box-wrapper pad20A">
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-user"></i></span>
                            <input type="text" name="name" class="form-control"
                                   placeholder="Enter Name"/>
                            <span class="error" id="nameError"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-envelope"></i></span>
                            <input type="email" name="email" class="form-control"
                                   placeholder="Enter Email"/>
                            <span class="error" id="emailError"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                            <input type="password" name="password" class="form-control"
                                   placeholder="Password"/>
                            <span class="error" id="passwordError"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                            <input type="password" name="password_confirmation" class="form-control"
                                   placeholder="Confirm Password"/>
                        </div>
                    </div>
                    <div class="form-group" style="text-align: center;" id="createShopkeeperSection" >
                        <button id="createShopkeeper" type="submit" class="btn btn-alt btn-hover btn-primary">
                            <span>Create</span>
                            <i class="glyph-icon icon-arrow-right"></i>
                            <div class="ripple-wrapper"></div>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

@endsection

@section('script')

    <script type="text/javascript" src="/assets/js/jstz.min.js"></script>

    <script>
        $(document).ready(function () {

            var timezone = jstz.determine();
            var timezoneName = timezone.name();
            $('#timezone').val(timezoneName);
            $('#successMsg , #errorMsg').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //This function use for add new Shopkeeper
            $(document.body).on('submit', 'form', function (event) {
                event.preventDefault();
                $('#createShopkeeperSection').attr('style','cursor:not-allowed; text-align: center;');
                $('#createShopkeeper').attr('disabled',true);
                $('#nameError, #emailError, #passwordError').html('');
                $('#successMsg , #errorMsg').hide();
                $.ajax({
                    url: '/addShopkeeper',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        timezone: this.timezone.value,
                        name: this.name.value,
                        email: this.email.value,
                        password: this.password.value,
                        password_confirmation: this.password_confirmation.value
                    },
                    success: function (response) {
                        $('#createShopkeeperSection').attr('style','cursor:pointer; text-align: center;');
                        $('#createShopkeeper').attr('disabled',false);

                        $('input:password').val('');

                        if (response == 'success') {
                            $(':input').val('');
                            $('#successMsg').show();
                        }
                        else if (response == 'fail') {
                            $(':input').val('');
                            $('#errorMsg').show();
                        }
                        else {
                            $.each(response, function (key, value) {
                                console.log(key + ": " + value);
                                $('#' + key + 'Error').html(value[0]);
                            });
                        }
                    },
                    error: function (req, status, err) {
                        $('#createShopkeeperSection').attr('style','cursor:pointer; text-align: center;');
                        $('#createShopkeeper').attr('disabled',false);
                        $(':input').val('');
                        $('#errorMsg').show();
                    }
                });
            });

        });
    </script>

@endsection


