<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/19/2016
 * Time: 5:07 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        .error {
            color: #FB0007;
        }

        .success {
            color: green;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 id="viewShop"><i class="glyph-icon icon-linecons-eye"></i> View shop Details</h2>
        <h2 id="editShop"><i class="glyph-icon icon-linecons-pencil"></i> Edit shop Details</h2>
        <span class="success" style="margin-left:40px;">@if(Session::has('success')){{Session::get('success')}}@endif</span>
        <span class="error" style="margin-left:50px;">@if(Session::has('fail')){{Session::get('fail')}}@endif</span>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form name="newShopForm" class="form-horizontal bordered-row"
                  action="/viewShopDetail/@if($shopData['shop_id']!= null){{$shopData['shop_id']}}@endif"
                  method="post" enctype="multipart/form-data" files="true">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px;">
                                                <label class="control-label"> Location </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Country</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['country_name']!= null)
                                                        {{$shopData['country_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">State</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['state_name']!= null)
                                                        {{$shopData['state_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">City</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['city_name']!= null)
                                                        {{$shopData['city_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Street</label>
                                            </td>
                                            <td>
                                                <label class="form-control" style="width:100%;">
                                                    @if($shopData['street_name']!= null)
                                                        {{$shopData['street_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:188px;">
                                                <label id="viewShop" class="control-label">Shop Details</label>
                                                <label id="editShop" class="control-label">Change Shop
                                                    Details</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Name</label>
                                            </td>
                                            <td>
                                                <input id="editShop" type="text" class="form-control"
                                                       name="shopName"

                                                       @if(Session::has('error'))
                                                            value="{{old('shopName')}}"
                                                       @else
                                                            @if(old('shopName'))
                                                                value="{{old('shopName')}}"
                                                            @else
                                                                @if($shopData['shop_name'] != NULL)
                                                                    value="{{$shopData['shop_name']}}"
                                                                @endif
                                                            @endif
                                                       @endif
                                                       placeholder="Enter the shop name"/>
                                                <span class="error"> {{ $errors->shopError->first('shop_name') }}</span>
                                                <label id="viewShop" class="form-control" style="width:100%;">
                                                    @if($shopData['shop_name']!= NULL)
                                                        {{$shopData['shop_name']}}
                                                    @endif
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shop Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: 200px; height: 150px;">
                                                        @if($shopData['shop_image']!= null)
                                                            <img src="{{$shopData['shop_image']}}">
                                                            <input type="hidden" value="{{$shopData['shop_image']}}" name="shopImagePath">
                                                        @else
                                                            <img src="http://placehold.it/200x150">
                                                        @endif
                                                    </div>
                                                    <div class="fileinput-preview fileinput-exists thumbnail"
                                                         style="max-width: 200px; max-height: 150px;">
                                                    </div>
                                                    <div id="editShop">
														<span class="btn btn-default btn-file">
															<span class="fileinput-new">Select Image</span>
															<span class="fileinput-exists">Replace</span>
															<input type="file" name="shopImage">
														</span>
                                                        <a href="#" class="btn btn-danger fileinput-exists"
                                                           data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                    <span class="error"> {{ $errors->shopError->first('shop_image') }}</span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <table class="table table-responsive">
                                        <tbody>
                                        <tr>
                                            <td style="border-top: medium none; color: rgb(251, 0, 7); font-size: 17px; width:188px;">
                                                <label id="editShop" class="control-label">Assign a
                                                    Shopkeeper</label>
                                                <label id="viewShop" class="control-label">Shopkeeper
                                                    Detail</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label id="editShop" class="control-label">
                                                    Choose Shopkeeper
                                                </label>
                                                <label id="viewShop" class="control-label">
                                                    Shopkeeper Id & Name
                                                </label>
                                            </td>
                                            <td>
                                                <select id="editShop" name="shopkeeperId"
                                                        class="js-example-responsive form-control"
                                                        style="width:100%;">
                                                    <option disabled selected>Select Shopkeeper</option>
                                                    <option value="0"
                                                            @if(old('shopkeeperId')!= NULL)
                                                                @if(old('shopkeeperId')== '0')
                                                                    selected
                                                                @endif
                                                            @else
                                                                @if($shopData['shopkeeper_meta_id'] == NULL)
                                                                    selected
                                                                @endif
                                                            @endif >
                                                        Not Assigned
                                                    </option>
                                                    @if($shopData['shopkeepers'] != NULL)
                                                        @foreach($shopData['shopkeepers'] as $value)
                                                            <option value="{{$value['shopkeeper_meta_id']}}"
                                                                    @if(old('shopkeeperId'))
                                                                        @if(old('shopkeeperId')== $value['shopkeeper_meta_id'])
                                                                            selected
                                                                        @endif
                                                                    @else
                                                                        @if($shopData['shopkeeper_meta_id']!= NULL)
                                                                            @if($shopData['shopkeeper_meta_id']== $value['shopkeeper_meta_id'])
                                                                                selected
                                                                            @endif
                                                                        @endif
                                                                    @endif
                                                            >
                                                                {{$value['id']}} . {{$value['first_name']}}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                                <label id="viewShop" class="form-control" style="width:100%;">
                                                    @if($shopData['shopkeeper_meta_id']!= null && $shopData['first_name']!= null)
                                                        {{$shopData['id']}}. {{$shopData['first_name']}}
                                                    @else
                                                        Not Assigned
                                                    @endif
                                                </label>
                                                <br>
                                                <span class="error"> {{ $errors->shopError->first('shopkeeper') }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="control-label">Shopkeeper Image</label>
                                            </td>
                                            <td>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-new thumbnail"
                                                         style="width: auto; height: 150px;">
                                                        @if($shopData['shopkeeper_image']!= null)
                                                            <img src="{{$shopData['shopkeeper_image']}}">
                                                        @else
                                                            <img src="{{Config::get('app.WEB_HOST')}}assets/shopkeeper/ProfilePic.jpg">
                                                        @endif
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="buttonBar" class="col-md-11" style="text-align: center; width: 100%;">
                        <div class="panel">
                            <div class="panel-body">
                                <div class="example-box-wrapper">
                                    <div class="form-group">
                                        <button id="editShop" type="submit"
                                                class="btn btn-alt btn-hover btn-success saveButton">
                                            <span>Save</span>
                                            <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>

                                        <button id="editShop"
                                                class="btn btn-alt btn-hover btn-secondary cancelButton">
                                            <span>Cancel</span>
                                            <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>

                                        <button id="viewShop"
                                                class="btn btn-alt btn-hover btn-primary editButton">
                                            <span>Edit</span>
                                            <i class="glyph-icon icon-linecons-pencil"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>

                                        <button id="viewShop"
                                                class="btn btn-alt btn-hover btn-info viewListButton">
                                            <span>View Shop List</span>
                                            <i class="glyph-icon icon-arrow-right"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

@endsection

@section('script')
    <script src="/assets/admin/js/select2.full.min.js"></script>

    <script>
        $(document).ready(function () {
            <?php
            if(Session::has('error')){
            ?>
            $('[id*="viewShop"]').hide();
            $(".js-example-responsive").select2();
            <?php
            }
            else{
            ?>
            $('[id*="editShop"]').hide();
            <?php
            }
            ?>

            $(document.body).on("click", '.viewListButton', function (event) {
                event.preventDefault();
                window.location.replace('/viewShop');
            });

            $(document.body).on("click", '.editButton', function (event) {
                event.preventDefault();
                $(".js-example-responsive").select2();
                $('[id*="viewShop"]').hide();
                $('[id*="editShop"]').show();
                $('[class*="error"]').show();
            });

            $(document.body).on("click", '.cancelButton', function (event) {
                event.preventDefault();
                $(".js-example-responsive").select2('destroy');
                $('[id*="viewShop"]').show();
                $('[id*="editShop"]').hide();
                $('[class*="error"]').hide();


            });
        });
    </script>

@endsection
