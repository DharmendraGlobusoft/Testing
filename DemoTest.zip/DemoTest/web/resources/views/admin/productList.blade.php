<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/28/2016
 * Time: 4:28 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <link rel="stylesheet" href="/assets/admin/css/select2.min.css"/>
    <style>
        th {
            width: auto !important;
        }

        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6), th:nth-child(7) , th:nth-child(8), th:nth-child(9) {
            text-align: center !important;
            vertical-align: top !important;
        }

        td:nth-child(1), td:nth-child(5), td:nth-child(6), td:nth-child(7), td:nth-child(8), td:nth-child(9) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">Product details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"></label>
                                        <div class="col-sm-9">
                                            <div class="radio-danger col-md-6">
                                                <label>
                                                    <input type="radio" id="allProductList" name="example-radio" checked
                                                           class="custom-radio" style="outline: medium none ! important;"/>
                                                    View all Product List
                                                </label>
                                            </div>
                                            <div class="radio-danger col-md-6">
                                                <label>
                                                    <input type="radio" id="shopWiseProductList" name="example-radio"
                                                           class="custom-radio" style="outline: medium none ! important;"/>
                                                    View Product List by Shop wise
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group" id="shopSection">
                                        <label class="col-sm-3 control-label">Select the Shop</label>
                                        <div class="col-sm-9" id="selectShopOption">

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Product List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Sub Product Name</th>
                                <th>Main Product Name</th>
                                <th>Stock Quantity</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>View/Edit Details</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('modal')
    <div class="modal fade" id="deleteProductModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Product Deletion</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-horizontal pad15L pad15R bordered-row" style="margin-bottom: -30px">
                                <div class="form-group remove-border">
                                    <label class="col-sm-3 control-label">Product Id:</label>
                                    <div>
                                        <label id="productId" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br>
                                    <label class="col-sm-3 control-label">Product Name:</label>
                                    <div>
                                        <label id="productName" class="col-sm-3 control-label"></label>
                                    </div>
                                    <br><br><br>
                                    <div style="text-align:center; font-weight:normal !important;">
                                        <label style="color: #6E8CD7">If you delete this Product then all detail related to
                                            this Product will be delete.</label>
                                        <br><br>
                                        <label style="color: #FB0007">Are you confirm ?</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <span id="deleteError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="deleteSuccess" style="color: green;"></span>
                <div class="modal-footer" id="setDeleteButton">
                </div>
            </div>
        </div>
    </div>
@endsection


@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/admin/js/select2.full.min.js"></script>
    <script>
        $(document).ready(function () {

            $('#shopSection').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
                "destroy": true,
                "ajax": {
                    "url": "/viewProduct",
                    "type": "POST",
                    "async": "True",
                    data: {
                        category: '1',
                    },
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [4, 5, 6, 7, 8]}]
            });

            //This function use for fetch all Product list with detail
            $(document.body).on('click', '#allProductList', function (event) {
                $('#shopSection').hide();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
                    "ajax": {
                        "url": "/viewProduct",
                        "type": "POST",
                        "async": "True",
                        data: {
                            category: '1',
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [4, 5, 6, 7, 8]}]
                });
            });

            //This function use for display all Shop name for selecting it.
            $(document.body).on("click", '#shopWiseProductList', function () {
                $('#datatable').DataTable({"destroy": true}).destroy();
                $('tbody').empty();
                $('#selectShopOption').html('');
                $('#selectShopOption').html(
                        '<select id="selectShop" class="js-example-responsive form-control"' +
                        ' style="width:100%;">' +
                        ' <option disabled selected>Select Shop</option>' +
                        ' @if($shopList != null)' +
                        ' @foreach($shopList as $value)' +
                        ' <option value="{{$value->shop_id}}">{{$value->shop_name}}</option>' +
                        '@endforeach' +
                        '@endif' +
                        '</select>');
                $(".js-example-responsive").select2();
                $('#shopSection').show();
            });

            //This function use for fetch all Product list according to shop Id
            $(document.body).on("change", '#selectShop', function (event) {

                var shopId = $(this).val();

                $('#datatable').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
                    "ajax": {
                        "url": "/viewProduct",
                        "type": "POST",
                        "async": "True",
                        data: {
                            category: '2',
                            shopId: shopId,
                        },
                    },
                    "order": [[0, "desc"]],
                    "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                    "columnDefs": [{'orderable': false, 'targets': [4, 5, 6, 7, 8]}]
                });
            });

            //This function use for activate Product status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        productId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate Product by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        productId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });


            // This function use for only show delete modal with Product information.
            $(document.body).on('click', '#deleteProduct', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'productDetail',
                        productId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('#productId').html(response['product_id']);
                            $('#productName').html(response['product_name']);
                            $('#setDeleteButton').html('<button id="noButton" type="button" class="btn btn-default" data-dismiss="modal">No</button> ' +
                                    '<button type="button" value="' + response["product_id"] + '" class="btn btn-primary" id="productDeleteButton">Yes</button>');
                        }
                        else {
                            $('#productId').html('Not available');
                            $('#productName').html('Not available');
                            $('#setDeleteButton').html('');
                        }
                    },
                    error: function (req, status, err) {
                        $('#productId').html('Not available');
                        $('#productName').html('Not available');
                        $('#setDeleteButton').html('');
                    }
                });
            });

            // This function use for delete particular Product.
            $(document.body).on('click', '#productDeleteButton', function (event) {
                event.preventDefault();
                $('#deleteSuccess').html('');
                $("#deleteError").html('');
                $.ajax({
                    url: '/viewProductAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete',
                        productId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#deleteSuccess').html('Product has been successfully deleted.');
                            $('#datatable').DataTable().ajax.reload(null, false);

                            setTimeout(function () {
                                $("#deleteProductModal").fadeOut();
                                setTimeout(function () {
                                    $("#noButton").trigger("click");
                                }, 400);
                            }, 700);
                        }
                        else {
                            $("#deleteError").html('Sorry ! Product has not deleted.');
                        }
                    },
                    error: function (req, status, err) {
                        $("#deleteError").html('Sorry ! Product has not deleted.');
                    }
                }); //End of  ajax
            });

        });
    </script>
@endsection

