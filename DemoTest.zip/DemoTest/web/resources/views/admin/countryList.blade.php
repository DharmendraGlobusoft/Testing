<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/21/2016
 * Time: 8:40 PM
 */
?>

@extends('admin.layout.master')

@section('head')
    <style>
        th{
            width:auto !important;
        }
        th:nth-child(1), th:nth-child(2), th:nth-child(3), th:nth-child(4), th:nth-child(5) {
            text-align: center !important;
        }

        td:nth-child(1), td:nth-child(3), td:nth-child(4), td:nth-child(5) {
            text-align: center !important;
        }
    </style>
@endsection

@section('content')

    <div id="page-title">
        <h2 style="color:#FB0007;">Country Details</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel addContent">
                <div class="panel-body">
                    <h3 class="title-hero">Add New Country</h3>
                    <span style="color: green;" id="addSuccess">Successfully, New country name has been added.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Enter the Country</label>
                                        <div class="col-sm-10">
                                            <input type="text" name="addCountryName" class="form-control" id="addCountryName"
                                                   placeholder="Enter the Country Name"/>
                                            <span style="color:#FB0007;" id="addError"></span>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="addCountryButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>SAVE</span> <i class="glyph-icon icon-save"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel editContent">
                <div class="panel-body">
                    <h3 class="title-hero">Edit Country</h3>
                    <span style="color: green;" id="editSuccess">Successfully, Country name has been updated.</span>
                    <div class="example-box-wrapper">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <form class="form-horizontal bordered-row" action="" method="post">
                                    {{ csrf_field() }}
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label">Country Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" data-countryId="" name="editCountryName"
                                                   id="editCountryName" class="form-control" value=""/>
                                        </div>
                                    </div>
                                    <div class="form-group pull-right">
                                        <button id="editCountryButton" class="btn btn-alt btn-hover btn-primary">
                                            <span>UPDATE</span> <i class="glyph-icon icon-refresh"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                        <button id="cancelCountryButton" class="btn btn-alt btn-hover btn-info">
                                            <span>CANCEL</span> <i class="glyph-icon icon-remove"></i>
                                            <div class="ripple-wrapper"></div>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="title-hero">Country List</h3>
                    <div class="example-box-wrapper">
                        <table id="datatable" class="table table-striped table-bordered" style="width:100%;">
                            <thead>
                            <tr>
                                <th>Country Id</th>
                                <th>Country Name</th>
                                <th>Activation Status</th>
                                <th>Action</th>
                                <th>Edit</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="/assets/dataTables/jquery.dataTables.min.js"></script>
    <script src="/assets/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {

            $('.editContent').hide();
            $('#addSuccess').hide();
            $('#editSuccess').hide();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('#datatable').DataTable({
                "processing": true,
                "serverSide": true,
//                "stateSave": true,  //If you want to save current table state in local then uncomment it.
                "ajax": {
                    "url": "/viewCountry",
                    "type": "POST",
                    "async": "True"
                },
                "order": [[0, "desc"]],
                "lengthMenu": [[5, 10, 15], [5, 10, 15]],       //you can set any time no. of row display
                "columnDefs": [{'orderable': false, 'targets': [2, 3, 4]}]
            });

            //This function use for activate Country status by click on activate button by admin
            $(document.body).on('click', '#activate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCountryAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'activate',
                        countryId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for deactivate Country by click on deactivate button by admin
            $(document.body).on('click', '#deActivate', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCountryAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'deactivate',
                        countryId: $(this).attr("value")
                    },
                    success: function (response) {

                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for display edit Country name section to user
            $(document.body).on('click', '#editButton', function (event) {
                event.preventDefault();

                $.ajax({
                    url: '/viewCountryAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'countryNameAndId',
                        countryId: $(this).attr("value")
                    },
                    success: function (response) {
                        if (response != 'fail') {
                            $('.addContent').hide();
                            $('.editContent').show();
                            $('#editCountryName').val(response.country_name);
                            $('#editCountryName').attr('value', response.country_name);
                            $('#editCountryName').attr('data-countryId', response.country_id);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for add new Country name by click on save button by admin
            $(document.body).on('click', '#addCountryButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCountryAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'create',
                        countryName: $('#addCountryName').val()
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#addError').html('');
                            $('#addCountryName').val('');
                            $('#addSuccess').show();
                            $('#addSuccess').delay( 3000).fadeOut(600);
                        }
                        else {
                            $('#addError').html(response);
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for update Country name by click on update button by admin
            $(document.body).on('click', '#editCountryButton', function (event) {
                event.preventDefault();
                $.ajax({
                    url: '/viewCountryAjax',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'update',
                        countryId: $('#editCountryName').attr('data-countryId'),
                        countryName: $('#editCountryName').val(),
                    },
                    success: function (response) {
                        if (response == 'success') {
                            $('#datatable').DataTable().ajax.reload(null, false);
                            $('#editSuccess').show();
                            $('#editSuccess').delay( 1000).fadeOut(600);
                        }
                        else {
                            console.log('Something went wrong');
                        }
                    },
                    error: function (req, status, err) {
                        console.log('Something went wrong');
                    }
                });
            });

            //This function use for hide edit Country division and show add Country division.
            $(document.body).on('click', '#cancelCountryButton', function (event) {
                event.preventDefault();
                $('#addError').html('');
                $('.editContent').hide();
                $('.addContent').show();
            });

        });
    </script>
@endsection

