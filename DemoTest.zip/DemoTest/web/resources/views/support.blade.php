<!DOCTYPE html>
<html>

<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Jagpreet Kaur">
    <title>Ali-Club Support</title>
    <link type="text/css" rel="stylesheet" href="assets/admin/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="assets/admin/css/font-awesome.min.css"/>
    <style>
        .head-bg {
        }

        .logo {
            position: absolute;
            left: 65px;
            top: 70px;
            width: 75px;
        }

        .sign-up {
            position: absolute;
            right: 105px;
            top: 100px;
            color: #fff;
            font-weight: 700;
        }

        .sign-up:hover {
            position: absolute;
            right: 105px;
            top: 100px;
            color: #f95c5c;
            font-weight: 700;
        }

        .log-in {
            position: absolute;
            right: 45px;
            top: 100px;
            color: #fff;
            font-weight: 700;
        }

        .log-in:hover {
            position: absolute;
            right: 45px;
            top: 100px;
            color: #f95c5c;
            font-weight: 700;
        }

        .heading-text {
            color: #00A650;
            position: absolute;
            left: 155px;
            top: 75px;
        }

        .support {
            color: #fff;
            position: absolute;
            top: 89px;
            left: 564px;
            background-color: #000;
            font-size: 25px;
            padding: 10px 50px;
            opacity: 0.7;
        }
    </style>
</head>

<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12 head-bg" style="padding:0px !important;">
            <img src="/assets/admin/images/bg.jpg" class="img-responsive"/>
            <a href="#"><img src="/assets/admin/images/logo.png" class="img-responsive logo"/></a>
            <span class="support"><b>SUPPORT</b></span>
        </div>
    </div>
</div>
<div class="container">
    <div class="row" style="margin-top:10px;">
        <div class="col-md-12">
            <center>
                <h3 style="color:#c50c0c;"><b>We are here to help you!</b></h3></center>
            <br/>
            <p class="text-center col-md-offset-1 col-md-10" style="font-size:17px;">
                Ali_club is your free and we glad to speak to you anytime any day to help you with your grocery need.
            </p>
        </div>
    </div>
    <div class="row" style="margin-top:30px;">
        <div class="col-md-12">
            <div class="col-md-4 text-center">
                <div class="panel panel-default col-md-9 col-md-offset-2"
                     style="background-color: #f3f3f3; padding: 26px 0px 9px;min-height:197px;">
                    <h4 style="color:#c50c0c;"><b>CONTACT DETAILS</b></h4>
                    <br>
                    <p><b>Phone No.:</b> <span style="font-weight:normal;">91-9179902999</span></p>
                    <br/>
                    <br/>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="panel panel-default col-md-9 col-md-offset-1"
                     style="background-color: #f3f3f3; padding: 26px 0px 9px;min-height:197px;">
                    <h4 style="color:#c50c0c;"><b>EMAIL DETAILS</b></h4>
                    <br/>
                    <p><b>Email Support:</b> <span style="font-weight:normal;">Imam5300ali@gmail.com</span></p>
                    <br/>
                    <br/>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="panel panel-default col-md-9"
                     style="background-color: #f3f3f3; padding: 26px 0px 9px;min-height:197px;">
                    <h4 style="color:#c50c0c;"><b>FOLLOW US:</b></h4>
                    <br/>
                    <ul class="list-unstyled list-inline" style="margin-left:5px;margin-top:20px;">
                        <li><img src="/assets/admin/images/facebook(2).png" class="img-responsive"
                                 style="width:30px;float:left;"/></li>
                        <li><img src="/assets/admin/images/instagram(1).png" class="img-responsive"
                                 style="width:30px;float:left;"/></li>
                        <li><img src="/assets/admin/images/twitter.png" class="img-responsive"
                                 style="width:30px;float:left;"/>
                        </li>
                        <li><img src="/assets/admin/images/rss.png" class="img-responsive"
                                 style="width:30px;float:left;"/>
                        </li>
                        <li><img src="/assets/admin/images/tumblr.png" class="img-responsive"
                                 style="width:30px;float:left;"/>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/admin/js/jquery.min.js"></script>
<script src="assets/admin/js/bootstrap.min.js"></script>
</body>
</html>