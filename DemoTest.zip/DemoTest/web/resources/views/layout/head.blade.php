<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/5/2016
 * Time: 04:02 PM
 */
?>

<head>
    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <!--<title>{{env('APPLICATION_NAME')}}</title>-->
    <title>Ali-Club</title>
    <meta name="description" content="Grocery - online Grocery">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="author" content="AllThatIsRam">

    <link rel="stylesheet" href="/assets/admin/css/animate.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/plugin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/widget.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/admin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/custom.css" />

    <!-- BEGIN OPTIONAL HEAD -->
    @yield('head')
    <!-- END OPTIONAL HEAD -->
</head>
