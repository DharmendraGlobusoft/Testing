<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/5/2016
 * Time: 4:05 PM
 */
?>

<!DOCTYPE html>
<html lang="en">
    <!-- BEGIN HEAD -->
    @include("layout.head")
    <!-- END HEAD -->
    <body>

    <!-- BEGIN MAIN CONTENT -->
    @yield('content')
    <!-- END MAIN CONTENT -->

    <!-- BEGIN COMMON JAVASCRIPT -->
    <script src="/assets/admin/js/jquery-core.js"></script>
    <script src="/assets/admin/js/jquery-ui-core.js"></script>
    <script src="/assets/admin/js/slimscroll.js"></script>
    <script src="/assets/admin/js/material.js"></script>
    <script src="/assets/admin/js/ripples.js"></script>
    <script src="/assets/admin/js/custom.js"></script>
    <script src="/assets/admin/js/layout.js"></script>

    <script>
        $(window).load(function () {
            setTimeout(function () {
                $('#loading').fadeOut(400, "linear");
            }, 300);
        });
    </script>
    <!-- END COMMON JAVASCRIPT -->

    <!-- BEGIN OPTIONAL JAVASCRIPT -->
    @yield('script')
    <!-- END OPTIONAL JAVASCRIPT -->
    </body>
</html>