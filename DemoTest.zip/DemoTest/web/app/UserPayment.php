<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Class UserPayment
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd JUNE, 2016
 */
class UserPayment extends Model
{

    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $table = 'user_payment';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $primaryKey = 'user_payment_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd JUNE, 2016
     */
    protected $fillable = [
        'transaction_id', 'transaction_amount', 'transaction_date', 'transaction_status',
        'refund_trans_id', 'refund_trans_amount', 'refund_trans_date', 'refund_trans_status',
        'timezone', 'id', 'order_detail_id',
    ];


    /**
     * It returns the list of Transaction with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchTransactionListByLimit($offset, $limit, $column, $direction, $searchValue)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('user_payment')
                    ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                    ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                    ->skip($offset)->take($limit)
                    ->select('user_payment.user_payment_id', 'user_payment.transaction_id', 'user_payment.transaction_amount',
                        'user_payment.transaction_date', 'users.id', 'users.name', 'user_payment.transaction_status',
                        'order_detail.order_detail_id', 'order_detail.pay_type')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('user_payment')
                    ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                    ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                    ->skip($offset)->take($limit)
                    ->where('users.id', 'like', '%' . $searchValue . '%')
                    ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                    ->orWhere('user_payment.transaction_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('user_payment.transaction_date', 'like', '%' . $searchValue . '%')
                    ->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                    ->select('user_payment.user_payment_id', 'user_payment.transaction_id', 'user_payment.transaction_amount',
                        'user_payment.transaction_date', 'users.id', 'users.name', 'user_payment.transaction_status',
                        'order_detail.order_detail_id', 'order_detail.pay_type')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of Transaction present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return int
     * @since 3rd JUNE, 2016
     */
    public function fetchNumberOfTransaction($searchValue)
    {
        try {
            if ($searchValue != '') {
                $select = DB::table('user_payment')
                    ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                    ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                    ->where('users.id', 'like', '%' . $searchValue . '%')
                    ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                    ->orWhere('user_payment.transaction_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('user_payment.transaction_date', 'like', '%' . $searchValue . '%')
                    ->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                    ->select('user_payment.user_payment_id')
                    ->count();

                return $select;
            } else {
                $select = DB::table('user_payment')
                    ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                    ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                    ->select('user_payment.user_payment_id')
                    ->count();

                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It delete a particular User Transaction and their related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userPaymentId
     * @param $orderId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function deleteUserTransaction($userPaymentId, $orderId)
    {
        try {
            DB::beginTransaction();

            $orderDetail = (array)DB::table('order_detail')->where('order_detail_id', '=', $orderId)
                ->select('payment_status', 'shop_id')
                ->first();

            $finalDeletion = false;

            if ($orderDetail['payment_status'] == 0 || $orderDetail['payment_status'] == 1 || $orderDetail['payment_status'] == 2) {

                $productDetail = (array)DB::table('order_product_detail')
                    ->where('order_detail_id', '=', $orderId)
                    ->where('restore_token', '=', 0)
                    ->select('product_id', 'quantity')
                    ->get();

                OrderDetail::where('order_detail_id', '=', $orderId)
                    ->update(['payment_status' => 3]);

                DB::table('order_cancel_detail')->where('user_payment_id', '=', $userPaymentId)
                    ->delete();

                if (!empty($productDetail)) {
                    $case = '';
                    foreach ($productDetail as $key => $value) {
                        $case = $case . 'WHEN (product_id = ' . $value->product_id . ') THEN stock_quantity + ' . $value->quantity . ' ';
                    }

                    DB::update('UPDATE product SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END )');

                    if (!($orderDetail['shop_id'] == null || $orderDetail['shop_id'] == '')) {
                        DB::update('UPDATE product_list SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END ) WHERE   shop_id = ' . $orderDetail['shop_id'] . '');
                    }

                    DB::table('order_product_detail')->where('order_detail_id', '=', $orderId)
                        ->update(['restore_token' => 1]);
                }

                $finalDeletion = DB::table('user_payment')->where('user_payment_id', '=', $userPaymentId)
                    ->delete();
            }

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


//================================================Shopkeeper====================================


    /**
     * It returns the list of Transaction [shop wise] with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 13th JUNE, 2016
     */
    public function fetchTransactionListByLimitAndShopId($offset, $limit, $column, $direction, $searchValue)
    {
        try {

            $orderDetailIds = (array)DB::table('shopkeeper_meta')
                ->join('order_detail', 'shopkeeper_meta.shop_id', '=', 'order_detail.shop_id')
                ->where('shopkeeper_meta.id', '=', Auth::user()->id)
                ->select('order_detail.order_detail_id')
                ->get();

            if (!empty($orderDetailIds)) {

                foreach ($orderDetailIds as $key => $value)
                    $orderDetailIds[$key] = $value->order_detail_id;

                if ($searchValue == '') {
                    $select = (array)DB::table('user_payment')
                        ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                        ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                        ->skip($offset)->take($limit)
                        ->whereIn('user_payment.order_detail_id', $orderDetailIds)
                        ->select('user_payment.user_payment_id', 'user_payment.transaction_id', 'user_payment.transaction_amount',
                            'user_payment.transaction_date', 'users.id', 'users.name', 'user_payment.transaction_status',
                            'order_detail.order_detail_id', 'order_detail.pay_type')
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('user_payment')
                        ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                        ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                        ->skip($offset)->take($limit)
                        ->whereIn('user_payment.order_detail_id', $orderDetailIds)
                        ->where(function ($query) use($searchValue) {
                            $query->where('users.id', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('user_payment.transaction_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('user_payment.transaction_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%');
                        })
                        ->select('user_payment.user_payment_id', 'user_payment.transaction_id', 'user_payment.transaction_amount',
                            'user_payment.transaction_date', 'users.id', 'users.name', 'user_payment.transaction_status',
                            'order_detail.order_detail_id', 'order_detail.pay_type')
                        ->orderBy($column, $direction)
                        ->get();
                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            } else
                return 0;
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of Transaction [shop wise] present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return int
     * @since 13th JUNE, 2016
     */
    public function fetchNumberOfTransactionByShopId($searchValue)
    {
        try {
            $orderDetailIds = (array)DB::table('shopkeeper_meta')
                ->join('order_detail', 'shopkeeper_meta.shop_id', '=', 'order_detail.shop_id')
                ->where('shopkeeper_meta.id', '=', Auth::user()->id)
                ->select('order_detail.order_detail_id')
                ->get();

            if (!empty($orderDetailIds)) {

                foreach ($orderDetailIds as $key => $value)
                    $orderDetailIds[$key] = $value->order_detail_id;

                if ($searchValue != '') {
                    $select = DB::table('user_payment')
                        ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                        ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                        ->whereIn('user_payment.order_detail_id', $orderDetailIds)
                        ->where(function ($query) use($searchValue) {
                            $query->where('users.id', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('user_payment.transaction_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('user_payment.transaction_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%');
                        })
                        ->select('user_payment.user_payment_id')
                        ->count();

                    return $select;
                } else {
                    $select = DB::table('user_payment')
                        ->leftJoin('order_detail', 'user_payment.order_detail_id', '=', 'order_detail.order_detail_id')
                        ->leftJoin('users', 'user_payment.id', '=', 'users.id')
                        ->whereIn('user_payment.order_detail_id', $orderDetailIds)
                        ->select('user_payment.user_payment_id')
                        ->count();

                    return $select;
                }
            } else
                return 0;
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }


} //End of class