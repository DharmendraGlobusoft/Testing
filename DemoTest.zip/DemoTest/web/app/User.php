<?php

namespace App;

use Illuminate\Database\QueryException;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

/**
 * Class User
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd MAY, 2016
 */
class User extends Authenticatable
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd MAY, 2016
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd MAY, 2016
     */
    protected $fillable = [
        'name', 'email', 'password', 'status', 'role', 'signup_type', 'timezone', 'facebook_id', 'google_id', 'twitter_id', 'avatar', 'token', 'device_token_id_android', 'device_token_id_ios',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd MAY, 2016
     */
    protected $hidden = [
        'password', 'remember_token',
    ];


    /**
     * It saves the shopkeeper sign up detail in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $signUpDetail
     * @return string
     * @since 6th MAY, 2016
     */
    public function createShopkeeper($signUpDetail)
    {
        try {
            User::create($signUpDetail);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It fetch and return admin profile data from DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 9th MAY, 2016
     */
    public function getAdminProfileData($userId)
    {
        $userData = User::leftJoin('users_meta', 'users.id', '=', 'users_meta.id')
            ->where('users.id', '=', $userId)
            ->select('users.email', 'users.name', 'users_meta.first_name', 'users_meta.last_name',
                'users_meta.contact_number', 'users_meta.age', 'users_meta.gender',
                'users_meta.address')
            ->first();
        if ($userData) {
            $userData = $userData->toArray();
            return $userData;
        } else
            return 'fail';
    }

    /**
     * It create or update admin profile data in DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $profileDetail
     * @return string
     * @since 9th MAY, 2016
     */
    public function editOrUpdateAdminProfile($profileDetail)
    {
        DB::beginTransaction();

        $usersDataUpdate = User::where('id', '=', $profileDetail['id'])
            ->update(['name' => $profileDetail['first_name'] . ' ' . $profileDetail['last_name']]);

        $usersMetaData = UsersMeta::where('id', '=', $profileDetail['id'])
            ->select('users_meta_id')
            ->first();
        if ($usersMetaData) {
            $usersMetaDataUpdate = UsersMeta::where('id', '=', $profileDetail['id'])
                ->update($profileDetail);
            $usersMetaDataCreate = 1;
        } else {
            $usersMetaDataCreate = UsersMeta::create($profileDetail);
            $usersMetaDataUpdate = 1;
        }

        if ($usersDataUpdate && $usersMetaDataUpdate && $usersMetaDataCreate) {
            $profileDetail = $this->getAdminProfileData($profileDetail['id']);
            DB::commit();
            return $profileDetail;
        } else {
            DB::rollBack();
            return 'fail';
        }
    }


    /**
     * It save the image path in DB and move to image in their directory.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $imageData
     * @return string
     * @since 10th MAY, 2016
     */
    public function uploadProfilePicture($imageData)
    {
        DB::beginTransaction();

        $usersMetaData = UsersMeta::where('id', '=', Auth::user()->id)
            ->select('users_meta_id', 'image')
            ->first();
        $imagePath = $imageData['profile_picture_fetchedPath'] . '/' . $imageData['profile_picture_name'];

        if ($usersMetaData) {
            $usersMetaDataUpdate = UsersMeta::where('id', '=', Auth::user()->id)
                ->update(['image' => $imagePath]);

            if ($usersMetaData->image != null) {
                $imagePathArray = explode("/", $usersMetaData->image);
                $unlinkImagePath = public_path() . '/' . $imagePathArray[3] . '/' . $imagePathArray[4] . '/' . $imagePathArray[5] . '/' . $imagePathArray[6];
                unlink($unlinkImagePath);
            }

            $usersMetaDataCreate = 1;
        } else {
            $usersMetaDataCreate = UsersMeta::create(['first_name' => '', 'contact_number' => '', 'gender' => 0,
                'image' => $imagePath, 'id' => Auth::user()->id]);
            $usersMetaDataUpdate = 1;
        }

        if ($usersMetaDataUpdate && $usersMetaDataCreate) {
            $imageData['profile_picture']->move($imageData['profile_picture_movedPath'], $imageData['profile_picture_name']);
            Session::put('imageUrl', $imagePath);
            DB::commit();
            return 'success';
        } else {
            DB::rollBack();
            return 'fail';
        }
    }

    /**
     * It matches user/shopkeeper old password and update the new password.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $passwordData
     * @return string
     * @since 11th MAY, 2016
     */
    public function updatePassword($passwordData)
    {
        $userOldPassword = User::where('id', '=', $passwordData['userId'])
            ->select('password')
            ->first();
        if (Hash::check($passwordData['oldPassword'], $userOldPassword->password)) {

            $updatePassword = DB::table('users')
                ->where('id', '=', $passwordData['userId'])
                ->update(['password' => Hash::make($passwordData['password'])]);

            if ($updatePassword)
                return 'success';
            else
                return 'Sorry ! your password has not updated.';
        } else
            return 'Your old password was wrong.';
    }


    /**
     * It return users/shopkeeper data according to given filter values.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 12th MAY, 2016
     */
    public function fetchUserListByLimit($offset, $limit, $column, $direction, $searchValue, $userRole)
    {
        if ($searchValue == '') {
            $select = (array)DB::table('users')
                ->skip($offset)->take($limit)
                ->where('role', '=', $userRole)
                ->select('id', 'name', 'email', 'status')
                ->orderBy($column, $direction)
                ->get();
            return $select;
        } else {
            $select = (array)DB::table('users')
                ->skip($offset)->take($limit)
                ->where('role', '=', $userRole)
                ->where(function ($query) use ($searchValue) {
                    $query->orWhere('id', 'like', '%' . $searchValue . '%')
                        ->orWhere('name', 'like', '%' . $searchValue . '%')
                        ->orWhere('email', 'like', '%' . $searchValue . '%');
                })
                ->select('id', 'name', 'email', 'status')
                ->orderBy($column, $direction)
                ->get();
            if (empty($select))
                return 0;
            else
                return $select;
        }
    }

    /**
     * It return total number of users/shopkeeper according to given filter values.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return array
     * @since 12th MAY, 2016
     */
    public function fetchNumberOfUsers($searchValue, $userRole)
    {
        if ($searchValue != '') {
            $select = (array)DB::table('users')
                ->where('role', '=', $userRole)
                ->where(function ($query) use ($searchValue) {
                    $query->orWhere('id', 'like', '%' . $searchValue . '%')
                        ->orWhere('name', 'like', '%' . $searchValue . '%')
                        ->orWhere('email', 'like', '%' . $searchValue . '%');
                })
                ->select('id')
                ->count();
            return $select;
        } else {
            $select = (array)DB::table('users')
                ->where('role', '=', $userRole)
                ->select('id')
                ->count();
            return $select;
        }
    }


    /**
     * It activate or deactivate user/shopkeeper status.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @param $status
     * @return string
     * @since 13th MAY, 2016
     */
    public function activateOrDeactivateUser($userId, $status)
    {
        $result = User::where('id', '=', $userId)
            ->update(['status' => $status]);

        if ($status == 2) {
            $sessionId = UserSession::where('id', '=', $userId)
                ->select('session_id')
                ->get();

            if (!$sessionId->isEmpty()) {
                foreach ($sessionId->toArray() as $key => $value) {
                    Session::getHandler()->destroy($value['session_id']);
                }
                UserSession::where('id', '=', $userId)
                    ->delete();
            }
        }
        if ($result)
            return 'success';
        else
            return 'fail';
    }

    /**
     * It return id and name of called user/shopkeeper.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 13th MAY, 2016
     */
    public function fetchOneUserOrShopkeeperDetail($userId)
    {
        $result = User::where('id', '=', $userId)
            ->select('id', 'name')
            ->first();
        if ($result)
            return $result->toArray();
        else
            return 'fail';
    }

    /**
     * It delete a user and their detail form all tables of Database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 13th MAY, 2016
     */
    public function deleteUser($userId)
    {
        try {
            DB::beginTransaction();

            $userEmail = DB::table('users')->where('id', '=', $userId)
                ->select('email')
                ->first();
            DB::table('feedback')->where('id', '=', $userId)
                ->delete();
            DB::table('review')->where('id', '=', $userId)
                ->delete();
            DB::table('password_resets')->where('email', '=', $userEmail->email)
                ->delete();
            DB::table('user_delivery_address')->where('id', '=', $userId)
                ->delete();
            DB::table('cart')->where('id', '=', $userId)
                ->delete();
            DB::table('users_meta')->where('id', '=', $userId)
                ->delete();
            DB::table('users')->where('id', '=', $userId)
                ->delete();

            if ($userEmail) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It delete a shopkeeper and their detail form all tables of Database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopkeeperId
     * @return string
     * @since 16th MAY, 2016
     */
    public function deleteShopkeeper($shopkeeperId)
    {
        try {
            DB::beginTransaction();

            $shopkeeperEmail = DB::table('users')->where('id', '=', $shopkeeperId)
                ->select('email')
                ->first();
            DB::table('admin_payment')->where('id', '=', $shopkeeperId)
                ->delete();
            DB::table('feedback')->where('id', '=', $shopkeeperId)
                ->delete();
            DB::table('password_resets')->where('email', '=', $shopkeeperEmail->email)
                ->delete();

            $shopkeeper_meta_data = DB::table('shopkeeper_meta')->where('id', '=', $shopkeeperId)
                ->select('shopkeeper_meta_id', 'shop_id')
                ->first();

            if (!empty($shopkeeper_meta_data)) {
                if ($shopkeeper_meta_data->shop_id != null) {

                    DB::table('shop')->where('shop_id', '=', $shopkeeper_meta_data->shop_id)
                        ->update(['assign_to_shopkeeper' => 0]);
                    DB::table('shopkeeper_meta')->where('id', '=', $shopkeeperId)
                        ->delete();
                } else {
                    DB::table('shopkeeper_meta')->where('id', '=', $shopkeeperId)
                        ->delete();
                }
            }
            DB::table('users')->where('id', '=', $shopkeeperId)
                ->delete();

            if ($shopkeeperEmail) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns all details of a particular user form user_meta table.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 8th JUNE, 2016
     */
    public function fetchAllDetailOfUser($userId)
    {
        try {
            $result = UsersMeta::where('id', '=', $userId)
                ->select('first_name', 'last_name', 'contact_number', 'age', 'gender', 'address', 'image')
                ->first();

            if ($result)
                return $result->toArray();
            else
                return 'fail';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns all details of a particular shopkeeper form shopkeeper_meta table.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 8th JUNE, 2016
     */
    public function fetchAllDetailOfShopkeeper($shopkeeperId)
    {
        try {
            $result = ShopKeeperMeta::where('id', '=', $shopkeeperId)
                ->select('first_name', 'last_name', 'contact_number', 'age', 'gender', 'address', 'image')
                ->first();

            if ($result)
                return $result->toArray();
            else {
                $userData = User::where('id', '=', $shopkeeperId)
                    ->select('name')
                    ->first();

                if ($userData) {
                    return array(
                        'first_name' => $userData->name,
                        'last_name' => '',
                        'contact_number' => '',
                        'age' => '',
                        'gender' => '',
                        'address' => '',
                        'image' => ''
                    );
                } else
                    return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

//=====================================================Shopkeeper====================================

    /**
     * It create or update Shopkeeper profile data in DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $profileDetail
     * @return string
     * @since 13th JUNE, 2016
     */
    public function editOrUpdateShopkeeperProfile($profileDetail)
    {
        DB::beginTransaction();

        $userDataUpdate = User::where('id', '=', $profileDetail['id'])
            ->update(['name' => $profileDetail['first_name'] . ' ' . $profileDetail['last_name']]);

        $shopkeeperMetaData = ShopKeeperMeta::where('id', '=', $profileDetail['id'])
            ->select('shopkeeper_meta_id')
            ->first();
        if ($shopkeeperMetaData) {
            $shopkeeperMetaDataUpdate = ShopKeeperMeta::where('id', '=', $profileDetail['id'])
                ->update($profileDetail);
            $shopkeeperMetaDataCreate = 1;
        } else {
            $shopkeeperMetaDataCreate = ShopKeeperMeta::create($profileDetail);
            $shopkeeperMetaDataUpdate = 1;
        }

        if ($userDataUpdate && $shopkeeperMetaDataUpdate && $shopkeeperMetaDataCreate) {
            $profileDetail = $this->getShopkeeperProfileData($profileDetail['id']);
            DB::commit();
            return $profileDetail;
        } else {
            DB::rollBack();
            return 'fail';
        }
    }

    /**
     * It fetch and return Shopkeeper profile data from DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userId
     * @return string
     * @since 13th JUNE, 2016
     */
    public function getShopkeeperProfileData($userId)
    {
        $userData = User::leftJoin('shopkeeper_meta', 'users.id', '=', 'shopkeeper_meta.id')
            ->where('users.id', '=', $userId)
            ->select('users.email', 'users.name', 'shopkeeper_meta.first_name', 'shopkeeper_meta.last_name',
                'shopkeeper_meta.contact_number', 'shopkeeper_meta.age', 'shopkeeper_meta.gender',
                'shopkeeper_meta.address')
            ->first();
        if ($userData) {
            $userData = $userData->toArray();
            return $userData;
        } else
            return 'fail';
    }

    /**
     * It save the image path in DB and move to image in their directory.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $imageData
     * @return string
     * @since 13th JUNE, 2016
     */
    public function uploadShopkeeperProfilePicture($imageData)
    {
        DB::beginTransaction();

        $shopKeeperMetaData = ShopKeeperMeta::where('id', '=', Auth::user()->id)
            ->select('shopkeeper_meta_id', 'image')
            ->first();
        $imagePath = $imageData['profile_picture_fetchedPath'] . '/' . $imageData['profile_picture_name'];
        if ($shopKeeperMetaData) {
            $shopKeeperMetaDataUpdate = ShopKeeperMeta::where('id', '=', Auth::user()->id)
                ->update(['image' => $imagePath]);

            if ($shopKeeperMetaData->image != null) {
                $imagePathArray = explode("/", $shopKeeperMetaData->image);
                $unlinkImagePath = public_path() . '/' . $imagePathArray[3] . '/' . $imagePathArray[4] . '/' . $imagePathArray[5] . '/' . $imagePathArray[6];
                unlink($unlinkImagePath);
            }

            $shopKeeperMetaDataCreate = 1;
        } else {
            $shopKeeperMetaDataCreate = ShopKeeperMeta::create(['first_name' => '', 'contact_number' => '', 'gender' => 0,
                'image' => $imagePath, 'id' => Auth::user()->id]);
            $shopKeeperMetaDataUpdate = 1;
        }

        if ($shopKeeperMetaDataUpdate && $shopKeeperMetaDataCreate) {
            $imageData['profile_picture']->move($imageData['profile_picture_movedPath'], $imageData['profile_picture_name']);
            Session::put('imageUrl', $imagePath);
            DB::commit();
            return 'success';
        } else {
            DB::rollBack();
            return 'fail';
        }
    }

}//End of class
