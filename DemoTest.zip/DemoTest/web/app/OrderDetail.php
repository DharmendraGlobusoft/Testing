<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Class OrderDetail
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd JUNE, 2016
 */
class OrderDetail extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $table = 'order_detail';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $primaryKey = 'order_detail_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd JUNE, 2016
     */
    protected $fillable = [
        'total_quantity', 'order_status', 'pay_type', 'payment_status', 'order_date', 'delivery_date', 'timezone', 'mobile_code', 'id', 'shop_id', 'shopkeeper_meta_id',
    ];


    /**
     * It returns the list of user order with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 8th JUNE, 2016
     */
    public function fetchOrderListByLimit($offset, $limit, $column, $direction, $searchValue, $shopId)
    {
        try {
            if ($shopId == null) {
                if ($searchValue == '') {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
//                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                            DB::raw('ROUND(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')//ADDED BY SHANKAR ON 25/10/2018
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->where('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                        ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                        ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                        ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%')
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
//                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                            DB::raw('ROUND(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')//added by shankar on 25/10/2018
                        ->orderBy($column, $direction)
                        ->get();
                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            } else {
                if ($searchValue == '') {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->where('order_detail.shop_id', '=', $shopId)
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
//                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                            DB::raw('ROUND(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')//added by shankar on 25/10/2018
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->where('order_detail.shop_id', '=', $shopId)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                        ->orderBy($column, $direction)
                        ->get();
                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of user order present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $shopId
     * @return int
     * @since 8th JUNE, 2016
     */
    public function fetchNumberOfOrder($searchValue, $shopId)
    {
        try {
            if ($shopId == null) {
                if ($searchValue != '') {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->where('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                        ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                        ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                        ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%')
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                } else {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                }
            } else {
                if ($searchValue != '') {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->where('order_detail.shop_id', '=', $shopId)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                } else {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->where('order_detail.shop_id', '=', $shopId)
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                }
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It returns all active shop list for viewing user order, shop wise.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return array|string
     * @since 8th JUNE, 2016
     */
    public function getAllShopList()
    {
        try {
            return (array)DB::table('shop')
                ->where('status', '=', 1)
                ->select('shop_id', 'shop_name')
                ->orderBy('shop_name', 'asc')
                ->get();

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It change the user order status.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @param $orderStatus
     * @return string
     * @since 8th JUNE, 2016
     */
    public function changeOrderStatus($orderId, $orderStatus)
    {
        try {
            OrderDetail::where('order_detail_id', '=', $orderId)
                ->update(['order_status' => $orderStatus]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It delete a particular user order and their related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @return string
     * @since 8th JUNE, 2016
     */
    public function deleteUserOrder($orderId)
    {
        try {
            DB::beginTransaction();

            $orderDetail = (array)DB::table('order_detail')->where('order_detail_id', '=', $orderId)
                ->select('payment_status', 'shop_id')
                ->first();

            DB::table('order_amount_detail')->where('order_detail_id', '=', $orderId)
                ->delete();
            DB::table('order_cancel_detail')->where('order_detail_id', '=', $orderId)
                ->delete();
            DB::table('order_delivery_address')->where('order_detail_id', '=', $orderId)
                ->delete();
            DB::table('user_payment')->where('order_detail_id', '=', $orderId)
                ->delete();

            if ($orderDetail['payment_status'] == 0 || $orderDetail['payment_status'] == 1) {

                $productDetail = (array)DB::table('order_product_detail')->where('order_detail_id', '=', $orderId)
                    ->select('product_id', 'quantity')
                    ->get();
                DB::table('order_product_detail')->where('order_detail_id', '=', $orderId)
                    ->delete();

                $case = '';
                foreach ($productDetail as $key => $value) {
                    $case = $case . 'WHEN (product_id = ' . $value->product_id . ') THEN stock_quantity + ' . $value->quantity . ' ';
                }

                DB::update('UPDATE product SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END )');

                if (!($orderDetail['shop_id'] == null || $orderDetail['shop_id'] == '')) {
                    DB::update('UPDATE product_list SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END ) WHERE   shop_id = ' . $orderDetail['shop_id'] . '');
                }

                $finalDeletion = DB::table('order_detail')->where('order_detail_id', '=', $orderId)
                    ->delete();

            } else
                if ($orderDetail['payment_status'] == 2) {

                    $productDetail = (array)DB::table('order_product_detail')
                        ->where('order_detail_id', '=', $orderId)
                        ->where('restore_token', '=', 0)
                        ->select('product_id', 'quantity')
                        ->get();

                    DB::table('order_product_detail')->where('order_detail_id', '=', $orderId)
                        ->delete();

                    if (!empty($productDetail)) {
                        $case = '';
                        foreach ($productDetail as $key => $value) {
                            $case = $case . 'WHEN (product_id = ' . $value->product_id . ') THEN stock_quantity + ' . $value->quantity . ' ';
                        }

                        DB::update('UPDATE product SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END )');

                        if (!($orderDetail['shop_id'] == null || $orderDetail['shop_id'] == '')) {
                            DB::update('UPDATE product_list SET stock_quantity = ( CASE ' . $case . ' ELSE (stock_quantity) END ) WHERE   shop_id = ' . $orderDetail['shop_id'] . '');
                        }
                    }
                    $finalDeletion = DB::table('order_detail')->where('order_detail_id', '=', $orderId)
                        ->delete();
                } else
                    if ($orderDetail['payment_status'] == 3) {

                        DB::table('order_product_detail')->where('order_detail_id', '=', $orderId)
                            ->delete();

                        $finalDeletion = DB::table('order_detail')->where('order_detail_id', '=', $orderId)
                            ->delete();
                    }

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns all details of a particular user order.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @return array|int|string
     * @since 8th JUNE, 2016
     */
    public function fetchAllDetailOfUserOrder($orderId)
    {
        try {
            DB::beginTransaction();

            $orderDetail = (array)DB::table('order_detail')
                ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                ->join('order_delivery_address', 'order_detail.order_detail_id', '=', 'order_delivery_address.order_detail_id')
                ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                ->where('order_detail.order_detail_id', '=', $orderId)
                ->select('order_detail.order_detail_id', 'users.id', 'users.name', 'shop.shop_id'
                    , 'shop.shop_name', 'order_detail.total_quantity', 'order_detail.order_status', 'order_detail.pay_type', 'order_detail.payment_status'
                    , 'order_detail.order_date', 'order_detail.delivery_date',
                    DB::raw('TRUNCATE(order_amount_detail.total_cost,2) as total_cost, TRUNCATE(order_amount_detail.total_service_tax,2) as total_service_tax,
                     TRUNCATE(order_amount_detail.total_discount_amount,2) as total_discount_amount, TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost')
                    , 'order_delivery_address.first_name', 'order_delivery_address.last_name', 'order_delivery_address.contact_country_code'
                    , 'order_delivery_address.contact_number', 'order_delivery_address.email'
                    , 'order_delivery_address.address_line1', 'order_delivery_address.address_line2', 'order_delivery_address.district'
                    , 'order_delivery_address.state', 'order_delivery_address.country'
                    , 'order_delivery_address.pin')
                ->first();

            $orderedProductDetail = (array)DB::table('order_product_detail')
                ->leftJoin('product', 'order_product_detail.product_id', '=', 'product.product_id')
                ->where('order_product_detail.order_detail_id', '=', $orderId)
                ->select('order_product_detail.quantity',
                    DB::raw('TRUNCATE(order_product_detail.product_cost,2) as product_cost, TRUNCATE(order_product_detail.service_tax,2) as service_tax,
                     TRUNCATE(order_product_detail.discount_amount,2) as discount_amount'),
                    'product.product_id', 'product.product_name')
                ->get();

            if (!empty($orderedProductDetail))
                $orderDetail['product_detail'] = $orderedProductDetail;
            else
                $orderDetail['product_detail'] = null;

            if (!empty($orderDetail)) {
                DB::commit();
                return $orderDetail;
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It return the order id and user device id from db for sending
     * notification to android users
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @param $orderStatus
     * @return string
     * @since 24th JUNE, 2016
     */
    public function getNotificationDataForAndroid($orderId)
    {
        try {
            $notificationDetail = OrderDetail::join('users', 'order_detail.id', '=', 'users.id')
                ->where('order_detail.order_detail_id', '=', $orderId)
                ->whereNotNull('users.device_token_id_android')
                ->select('order_detail.order_detail_id','order_detail.order_status','users.device_token_id_android')
                ->first();
            if ($notificationDetail)
                return $notificationDetail->toArray();
            else
                return 'fail';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return the order id and user device id from db for sending
     * notification to IOS users
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @param $orderStatus
     * @return string
     * @since 25th JUNE, 2016
     */
    public function getNotificationDataForIOS($orderId)
    {
        try {
            $notificationDetail = OrderDetail::join('users', 'order_detail.id', '=', 'users.id')
                ->where('order_detail.order_detail_id', '=', $orderId)
                ->whereNotNull('users.device_token_id_ios')
                ->select('order_detail.order_detail_id','order_detail.order_status','users.device_token_id_ios')
                ->first();
            if ($notificationDetail)
                return $notificationDetail->toArray();
            else
                return 'fail';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


//=====================================================Shopkeeper====================================


    /**
     * It returns the list of user order [shop wise] with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 13th JUNE, 2016
     */
    public function fetchOrderListByLimitAndShop($offset, $limit, $column, $direction, $searchValue)
    {
        try {
            $orderDetailIds = (array)DB::table('shopkeeper_meta')
                ->join('order_detail', 'shopkeeper_meta.shop_id', '=', 'order_detail.shop_id')
                ->where('shopkeeper_meta.id', '=', Auth::user()->id)
                ->select('order_detail.order_detail_id')
                ->get();

            if (!empty($orderDetailIds)) {

                foreach ($orderDetailIds as $key => $value)
                    $orderDetailIds[$key] = $value->order_detail_id;

                if ($searchValue == '') {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->whereIn('order_detail.order_detail_id', $orderDetailIds)
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->skip($offset)->take($limit)
                        ->whereIn('order_detail.order_detail_id', $orderDetailIds)
                        ->where(function ($query) use ($searchValue) {
                            $query->where('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('order_detail.order_detail_id', 'order_detail.order_status',
                            'order_detail.pay_type', 'order_detail.payment_status', 'order_detail.order_date',
                            DB::raw('TRUNCATE(order_amount_detail.total_pay_cost,2) as total_pay_cost'), 'users.name', 'shop.shop_name')
                        ->orderBy($column, $direction)
                        ->get();
                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            } else
                return 0;
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of user order [shop wise] present in DB
     * according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $shopId
     * @return int
     * @since 13th JUNE, 2016
     */
    public function fetchNumberOfOrderByShop($searchValue)
    {
        try {

            $orderDetailIds = (array)DB::table('shopkeeper_meta')
                ->join('order_detail', 'shopkeeper_meta.shop_id', '=', 'order_detail.shop_id')
                ->where('shopkeeper_meta.id', '=', Auth::user()->id)
                ->select('order_detail.order_detail_id')
                ->get();

            if (!empty($orderDetailIds)) {

                foreach ($orderDetailIds as $key => $value)
                    $orderDetailIds[$key] = $value->order_detail_id;

                if ($searchValue != '') {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->whereIn('order_detail.order_detail_id', $orderDetailIds)
                        ->where(function ($query) use ($searchValue) {
                            $query->where('order_detail.order_detail_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('order_detail.order_date', 'like', '%' . $searchValue . '%')
                                ->orWhere('users.name', 'like', '%' . $searchValue . '%')
                                ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                } else {
                    $select = DB::table('order_detail')
                        ->join('order_amount_detail', 'order_detail.order_detail_id', '=', 'order_amount_detail.order_detail_id')
                        ->leftJoin('users', 'order_detail.id', '=', 'users.id')
                        ->leftJoin('shop', 'order_detail.shop_id', '=', 'shop.shop_id')
                        ->whereIn('order_detail.order_detail_id', $orderDetailIds)
                        ->select('order_detail.order_detail_id')
                        ->count();
                    return $select;
                }
            } else
                return 0;
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }


} //End of class