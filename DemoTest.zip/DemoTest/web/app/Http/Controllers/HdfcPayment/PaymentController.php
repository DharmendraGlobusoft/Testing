<?php
/**
 * Created by PhpStorm.
 * User: GLB-280
 * Date: 7/16/2018
 * Time: 11:23 AM
 */

namespace App\Http\Controllers\HdfcPayment;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class PaymentController extends Controller
{
    //This fun only for testiong
    public function paymentCheckout(Request $request)
    {
        if ($request->isMethod('POST')) {

            $validator = Validator::make($request->all(), [
                'orderId' => 'required|numeric|min:1',
                'amount' => 'required|numeric|min:1'
            ]);
            if (!$validator->fails()) {
                $orderId = $request->input('orderId');
                $amount = $request->input('amount');
                return view('hdfcPayment.payment', ['orderId' => $orderId, 'price' => $amount]);
            } else {
                return redirect('/hdfcPayment')->withErrors($validator)->withInput();
            }
        }
        return view('hdfcPayment.paymentCheckout');
    }

    //==========

    public function hdfcPayment(Request $request, $orderId = null, $amount = null)
    {
        if ($request->isMethod('POST')) {
            $data = $request->all();
            dd($data);
        } else {
            //Get Method using for Testing
//            dd('Shankar Kumar', $orderId,$amount);
            return view('hdfcPayment.payment', ['orderId' => $orderId, 'price' => $amount]);
        }
    }

    /**
     * This function will be call, when payment done successfully
     * @author Shankar Mandal <shankarmandal@globussoft.in>
     * @Desc: Update pay_type,payment_status and traking_id and Payment Response data also stored in hdfc table
     * @since 13 July 2018
     */
    public function responseData_Old(Request $request)
    {
        $responseData = $request->input('data');
//        dd('here Shankar',$responseData);
//        $responseData = "order_id=1531756139&tracking_id=307003988628&bank_ref_no=201819727968410&order_status=Success&failure_message=&payment_mode=Debit Card&card_name=Visa Debit Card&status_code=null&status_message=CAPTURED&currency=INR&amount=10.0&billing_name=&billing_address=&billing_city=&billing_state=&billing_zip=&billing_country=&billing_tel=&billing_email=&delivery_name=Shankar Mandal&delivery_address=Junwani&delivery_city=Bhilai&delivery_state=Chhattisgarh&delivery_zip=490020&delivery_country=India&delivery_tel=7909006164&merchant_param1=&merchant_param2=&merchant_param3=&merchant_param4=&merchant_param5=&vault=N&offer_type=null&offer_code=null&discount_value=0.0&mer_amount=10.0&eci_value=null&retry=N&response_code=0&billing_notes=&trans_date=16/07/2018 21:20:11&bin_country=RUSSIAN FEDERATION\n";
//        $responseData = "order_id=1531806260&tracking_id=307003989129&bank_ref_no=201819803143475&order_status=Success&failure_message=&payment_mode=Debit Card&card_name=Visa Debit Card&status_code=null&status_message=CAPTURED&currency=INR&amount=10.0&billing_name=&billing_address=&billing_city=&billing_state=&billing_zip=&billing_country=&billing_tel=&billing_email=&delivery_name=Shankar Mandal&delivery_address=ertert&delivery_city=Bhilai&delivery_state=Chhattisgarh&delivery_zip=490020&delivery_country=India&delivery_tel=7909006164&merchant_param1=&merchant_param2=&merchant_param3=&merchant_param4=&merchant_param5=&vault=N&offer_type=null&offer_code=null&discount_value=0.0&mer_amount=10.0&eci_value=null&retry=N&response_code=0&billing_notes=&trans_date=17/07/2018 11:19:11&bin_country=RUSSIAN FEDERATION\x05\x05\x05\x05\x05";
        if (isset($responseData)) {

            //-----------------------------------------------
            $secret_key = 'shankarmandal@globussoft.in';
            $secret_iv = '456';//my_simple_secret_iv

            $encrypt_method = "AES-256-CBC";
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            $responseData = openssl_decrypt(base64_decode($responseData), $encrypt_method, $key, 0, $iv);
            //-------------------------------------------------

            $data = explode('&', $responseData);

            $value = '';
            $key = '';
            for ($i = 0; $i < count($data); $i++) {
                $val = explode('=', $data[$i]);
                for ($j = 0; $j < count($val); $j++) {
                    if ($j == 0) {
                        $key = $val[$j];
                    } else {
                        $value = $val[$j];
                    }
                    $allData[$key] = $value;  //Set Key value
                }
            }

            //Remove empty value fields from array
            foreach ($allData as $key => $val) {
                if (isset($allData[$key]) && !empty($allData[$key])) {
                    $resData[$key] = $val;
                }
            }

            // Assign required value to insert into DB
            $details = [];
            if (isset($resData['order_id']) && !empty($resData['order_id'])) {
                $details['order_id'] = $resData['order_id'];
            }
            if (isset($resData['tracking_id']) && !empty($resData['tracking_id'])) {
                $details['tracking_id'] = $resData['tracking_id'];
            }
            if (isset($resData['bank_ref_no']) && !empty($resData['bank_ref_no'])) {
                $details['bank_ref_no'] = $resData['bank_ref_no'];
            }
            if (isset($resData['order_status']) && !empty($resData['order_status'])) {
                $details['order_status'] = $resData['order_status'];
            }
            if (isset($resData['failure_message']) && !empty($resData['failure_message'])) {
                $details['failure_message'] = $resData['failure_message'];
            }
            if (isset($resData['payment_mode']) && !empty($resData['payment_mode'])) {
                $details['payment_mode'] = $resData['payment_mode'];
            }
            if (isset($resData['card_name']) && !empty($resData['card_name'])) {
                $details['card_name'] = $resData['card_name'];
            }
            if (isset($resData['status_code']) && !empty($resData['status_code'])) {
                $details['status_code'] = $resData['status_code'];
            }
            if (isset($resData['status_message']) && !empty($resData['status_message'])) {
                $details['status_message'] = $resData['status_message'];
            }
            if (isset($resData['currency']) && !empty($resData['currency'])) {
                $details['currency'] = $resData['currency'];
            }
            if (isset($resData['amount']) && !empty($resData['amount'])) {
                $details['amount'] = $resData['amount'];
            }
            if (isset($resData['delivery_name']) && !empty($resData['delivery_name'])) {
                $details['delivery_name'] = $resData['delivery_name'];
            }
            if (isset($resData['delivery_address']) && !empty($resData['delivery_address'])) {
                $details['delivery_address'] = 'Address:' . $resData['delivery_address'] . ',City:' . $resData['delivery_city'] . ',State:' . $resData['delivery_state'] . ',Zip Code:' . $resData['delivery_zip'];
            }
            if (isset($resData['delivery_country']) && !empty($resData['delivery_country'])) {
                $details['delivery_country'] = $resData['delivery_country'];
            }
            if (isset($resData['delivery_tel']) && !empty($resData['delivery_tel'])) {
                $details['delivery_tel'] = $resData['delivery_tel'];
            }
            if (isset($resData['vault']) && !empty($resData['vault'])) {
                $details['vault'] = $resData['vault'];
            }
            if (isset($resData['discount_value']) && !empty($resData['discount_value'])) {
                $details['discount_value'] = $resData['discount_value'];
            }
            if (isset($resData['mer_amount']) && !empty($resData['mer_amount'])) {
                $details['mer_amount'] = $resData['mer_amount'];
            }
            if (isset($resData['retry']) && !empty($resData['retry'])) {
                $details['retry'] = $resData['retry'];
            }
            if (isset($resData['trans_date']) && !empty($resData['trans_date'])) {
                $date = $resData['trans_date'];
                $date = str_replace('/', '-', $date);
                $details['trans_date'] = date('Y-m-d H:i:s', strtotime($date));
            }
            if (isset($resData['bin_country']) && !empty($resData['bin_country'])) {
                $details['bin_country'] = $resData['bin_country'];
            }

//        dd($details,$resData);

            try {
                DB::table('hdfcpayment')->insert($details);

//            //=====================================
                $orderDetails['payment_status'] = 1;
                if ($details['payment_mode'] == "Credit Card") {
                    $orderDetails['pay_type'] = 1;
                } elseif ($details['payment_mode'] == "Debit Card") {
                    $orderDetails['pay_type'] = 2;
                } elseif ($details['payment_mode'] == "Net Banking") {
                    $orderDetails['pay_type'] = 3;
                }

                if (isset($details['tracking_id']) && !empty($details['tracking_id'])) {
                    $orderDetails['tracking_id'] = $details['tracking_id'];
                } else {
                    $orderDetails['tracking_id'] = null;
                }

                //Commented this query just for testing purpose after completing test have to uncomment this DB query
                DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                    ->update(['pay_type' => $orderDetails['pay_type'], 'payment_status' => $orderDetails['payment_status'], 'tracking_id' => $orderDetails['tracking_id']]);

                //=====================================

                return view('hdfcPayment.transMessage', ['data' => $details]);
            } catch (\Exception $e) {
                return $e->getMessage();
            }
        } else {
            return view('hdfcPayment.transMessage');
        }

    }


    public function responseData(Request $request)
    {

        $responseData = $request->input('data');
        $res = $responseData;
        if (isset($responseData)) {

            //-----------------------------------------------
            $secret_key = 'shankarmandal@globussoft.in';
            $secret_iv = '456';//my_simple_secret_iv

            $encrypt_method = "AES-256-CBC";
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            $responseData = openssl_decrypt(base64_decode($responseData), $encrypt_method, $key, 0, $iv);
            //-------------------------------------------------

            $data = explode('&', $responseData);

            $value = '';
            $key = '';
            $allData = [];
            for ($i = 0; $i < count($data); $i++) {
                $val = explode('=', $data[$i]);
                for ($j = 0; $j < count($val); $j++) {
                    if ($j == 0) {
                        $key = $val[$j];
                    } else {
                        $value = $val[$j];
                    }
                    $allData[$key] = $value;  //Set Key value
                }
            }

            //Remove empty value fields from array
            $resData = [];
            foreach ($allData as $key => $val) {
                if (isset($allData[$key]) && !empty($allData[$key])) {
                    $resData[$key] = $val;
                }
            }

            if (isset($resData) && !empty($resData)) {

                // Assign required value to insert into DB
                $details = [];
                if (isset($resData['order_id']) && !empty($resData['order_id'])) {
                    $details['order_id'] = $resData['order_id'];
                }
                if (isset($resData['tracking_id']) && !empty($resData['tracking_id'])) {
                    $details['tracking_id'] = $resData['tracking_id'];
                }
                if (isset($resData['bank_ref_no']) && !empty($resData['bank_ref_no'])) {
                    $details['bank_ref_no'] = $resData['bank_ref_no'];
                }
                if (isset($resData['order_status']) && !empty($resData['order_status'])) {
                    $details['order_status'] = $resData['order_status'];
                }
                if (isset($resData['failure_message']) && !empty($resData['failure_message'])) {
                    $details['failure_message'] = $resData['failure_message'];
                }
                if (isset($resData['payment_mode']) && !empty($resData['payment_mode'])) {
                    $details['payment_mode'] = $resData['payment_mode'];
                }
                if (isset($resData['card_name']) && !empty($resData['card_name'])) {
                    $details['card_name'] = $resData['card_name'];
                }
                if (isset($resData['status_code']) && !empty($resData['status_code'])) {
                    $details['status_code'] = $resData['status_code'];
                }
                if (isset($resData['status_message']) && !empty($resData['status_message'])) {
                    $details['status_message'] = $resData['status_message'];
                }
                if (isset($resData['currency']) && !empty($resData['currency'])) {
                    $details['currency'] = $resData['currency'];
                }
                if (isset($resData['amount']) && !empty($resData['amount'])) {
                    $details['amount'] = $resData['amount'];
                }
                if (isset($resData['delivery_name']) && !empty($resData['delivery_name'])) {
                    $details['delivery_name'] = $resData['delivery_name'];
                }
                if (isset($resData['delivery_address']) && !empty($resData['delivery_address'])) {
                    $details['delivery_address'] = 'Address:' . $resData['delivery_address'] . ',City:' . $resData['delivery_city'] . ',State:' . $resData['delivery_state'] . ',Zip Code:' . $resData['delivery_zip'];
                }
                if (isset($resData['delivery_country']) && !empty($resData['delivery_country'])) {
                    $details['delivery_country'] = $resData['delivery_country'];
                }
                if (isset($resData['delivery_tel']) && !empty($resData['delivery_tel'])) {
                    $details['delivery_tel'] = $resData['delivery_tel'];
                }
                if (isset($resData['vault']) && !empty($resData['vault'])) {
                    $details['vault'] = $resData['vault'];
                }
                if (isset($resData['discount_value']) && !empty($resData['discount_value'])) {
                    $details['discount_value'] = $resData['discount_value'];
                }
                if (isset($resData['mer_amount']) && !empty($resData['mer_amount'])) {
                    $details['mer_amount'] = $resData['mer_amount'];
                }
                if (isset($resData['retry']) && !empty($resData['retry'])) {
                    $details['retry'] = $resData['retry'];
                }
                if (isset($resData['trans_date']) && !empty($resData['trans_date'])) {
                    $date = $resData['trans_date'];
                    $date = str_replace('/', '-', $date);
                    $details['trans_date'] = date('Y-m-d H:i:s', strtotime($date));
                }
                if (isset($resData['bin_country']) && !empty($resData['bin_country'])) {
                    $details['bin_country'] = $resData['bin_country'];
                }

//                dd($details,$resData);

                try {

//                    DB::table('hdfcpayment')->insert($details);
                    $hdfcPaymentId=DB::table('hdfcpayment')->insertGetId($details);
                    //=====================================

                    // Validation Tracking id and order id. Both must be Unique
                    // Tracking Id ia a payment reference number generated by HDFC for each order.

                    $countOrderId = (array)DB::table('hdfcpayment')->where('order_id', $details['order_id'])->count('order_id');
                    $countOrderId = $countOrderId[0];
                    if (!($countOrderId >= 2)) {
                        $countTrackingId = (array)DB::table('hdfcpayment')->where('tracking_id', $details['tracking_id'])->count('tracking_id');
                        $countTrackingId = $countTrackingId[0];

                        if (!($countTrackingId >= 2)) {

                            //Validate hdfc paymount Amount with order amount
                            $orderId = $details['order_id'];
                            $amount = $details['amount'];
                            $orderAmount = (array)DB::table('order_amount_detail')
                                ->where('order_detail_id', $orderId)
                                ->select('total_pay_cost')->first();
                            $orderAmount = isset($orderAmount['total_pay_cost']) ? $orderAmount['total_pay_cost'] : 0;

//                            dd($amount, $orderAmount);
                            if ($amount == $orderAmount && $orderAmount != 0) {

                                $orderDetails['payment_status'] = 1; //payment successfully done
                                if ($details['payment_mode'] == "Credit Card") {
                                    $orderDetails['pay_type'] = 1;
                                } elseif ($details['payment_mode'] == "Debit Card") {
                                    $orderDetails['pay_type'] = 2;
                                } elseif ($details['payment_mode'] == "Net Banking") {
                                    $orderDetails['pay_type'] = 3;
                                }
                                if (isset($details['tracking_id']) && !empty($details['tracking_id'])) {
                                    $orderDetails['tracking_id'] = $details['tracking_id'];
                                } else {
                                    $orderDetails['tracking_id'] = null;
                                }

                                //Commented this query just for testing purpose after completing test have to uncomment this DB query
                                DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                                    ->orderBy('order_detail_id','desc')
                                    ->limit(1)
                                    ->update([
                                        'pay_type' => $orderDetails['pay_type'],
                                        'payment_status' => $orderDetails['payment_status'],
                                        'tracking_id' => $orderDetails['tracking_id']
                                    ]);

                                return view('hdfcPayment.transMessage', ['data' => $details]);

                            } else {
                                //if ordered amount and hdfc payment transaction amount does not match
                                $orderDetails['payment_status'] = 2; //Payment Failed
                                if ($details['payment_mode'] == "Credit Card") {
                                    $orderDetails['pay_type'] = 1;
                                } elseif ($details['payment_mode'] == "Debit Card") {
                                    $orderDetails['pay_type'] = 2;
                                } elseif ($details['payment_mode'] == "Net Banking") {
                                    $orderDetails['pay_type'] = 3;
                                }
                                if (isset($details['tracking_id']) && !empty($details['tracking_id'])) {
                                    $orderDetails['tracking_id'] = $details['tracking_id'];
                                } else {
                                    $orderDetails['tracking_id'] = null;
                                }
//                        dd('Both amount does not matching',$details,$orderDetails);
                                //Commented this query just for testing purpose after completing test have to uncomment this DB query
                                DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                                    ->orderBy('order_detail_id','desc')
                                    ->limit(1)
                                    ->update([
                                        'pay_type' => $orderDetails['pay_type'],
                                        'payment_status' => $orderDetails['payment_status'],
                                        'tracking_id' => $orderDetails['tracking_id']
                                    ]);

                                $errorData['order_id'] = $details['order_id'];
                                $errorData['tracking_id'] = $details['tracking_id'];
                                $errorData['hdfcPaymentId'] =$hdfcPaymentId;
                                $errorData['amount'] = $details['amount'];
//                                $errorData['message'] = 'Ordered amount and hdfc payment transaction amount does not match';
                                $errorData['message'] = 'Your Ordered amount and Transaction amount does not match with the product price';
                                $errorData['value'] = 'Error on transaction amount: ->' . json_encode($details);
                                DB::table('payment_errors')->insert($errorData);

                                $error_message ='Your Ordered amount and Transaction amount does not match with the product price.';

//                                return view('hdfcPayment.paymentFailMessage', ['data' => $details]);
                                return view('hdfcPayment.paymentFailMessage', ['data' => $details,'error_message'=>$error_message]);
                            }
                        } else {
                            //if already Tracking id exist in hdfcpayment table

                            $orderDetails['payment_status'] = 2; //Payment Failed
                            if ($details['payment_mode'] == "Credit Card") {
                                $orderDetails['pay_type'] = 1;
                            } elseif ($details['payment_mode'] == "Debit Card") {
                                $orderDetails['pay_type'] = 2;
                            } elseif ($details['payment_mode'] == "Net Banking") {
                                $orderDetails['pay_type'] = 3;
                            }

                            DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                                ->orderBy('order_detail_id','desc')
                                ->limit(1)
                                ->update([
                                    'pay_type' => $orderDetails['pay_type'],
                                    'payment_status' => $orderDetails['payment_status'],
                                ]);


                            $errorData['order_id'] = $details['order_id'];
                            $errorData['tracking_id'] = $details['tracking_id'];
                            $errorData['hdfcPaymentId'] =$hdfcPaymentId;
                            $errorData['amount'] = $details['amount'];
//                            $errorData['message'] = 'Tracking Id already exist in hdfcpayment table';
                            $errorData['message'] = 'Your Tracking Id already exist in payment details';
                            $errorData['value'] = 'Error on duplicate Tracking id : ->' . json_encode($details);
                            DB::table('payment_errors')->insert($errorData);
                            $error_message = 'Your Tracking Id already exist in payment details';
//                            return view('hdfcPayment.paymentFailMessage', ['data' => $details]);
                            return view('hdfcPayment.paymentFailMessage', ['data' => $details,'error_message'=>$error_message]);
                        }
                    } else {
                        //if already order id exist in hdfcpayment table
                        $errorData['order_id'] = $details['order_id'];
                        $errorData['tracking_id'] = $details['tracking_id'];
                        $errorData['hdfcPaymentId'] =$hdfcPaymentId;
                        $errorData['amount'] = $details['amount'];
//                        $errorData['message'] = 'Order Id already exist in hdfcpayment table';
                        $errorData['message'] = 'Your Ordered id  already exist in payment details';
                        $errorData['value'] = 'Error on duplicate oredr id : ->' . json_encode($details);
                        DB::table('payment_errors')->insert($errorData);
                        $error_message = 'Your Ordered id  already exist in payment details';
//                        return view('hdfcPayment.paymentFailMessage', ['data' => $details]);

                        return view('hdfcPayment.paymentFailMessage', ['data' => $details,'error_message'=>$error_message]);

                    }
                } catch (\Exception $e) {
                    $errorData['order_id'] = $details['order_id'];
                    $errorData['tracking_id'] = $details['tracking_id'];
                    $errorData['hdfcPaymentId'] = null;
                    $errorData['amount'] = $details['amount'];
                    $errorData['message'] = 'Error on SQL Query';
                    $errorData['value'] = 'Error on oredr id : ->' . json_encode($details);
                    DB::table('payment_errors')->insert($errorData);

                    $error_message = 'Something went wrong. Please try again!';

//                    $details['failure_message'] = 'Something went wrong. Please try again!.';
//                    return view('hdfcPayment.paymentFailMessage', ['data' => $details]);
                    return view('hdfcPayment.paymentFailMessage', ['data' => $details,'error_message'=>$error_message]);
                }
            } else {

                //decryption error
                $errorData['order_id'] = null;
                $errorData['tracking_id'] = null;
                $errorData['message'] = 'Invalide secret_key using to decrypt response data';
                $errorData['value'] = 'Error on descypt key : ->' . json_encode($res);
                DB::table('payment_errors')->insert($errorData);

                $details['order_id'] = 0;
                $details['tracking_id'] = 0;
                $details['bank_ref_no'] = 0;
                $error_message = 'Something went wrong. Please try again!.';

//                $details['failure_message'] = 'Something went wrong. Please try again!.';
//                return view('hdfcPayment.paymentFailMessage', ['data' => $details]);

                return view('hdfcPayment.paymentFailMessage', ['data' => $details,'error_message'=>$error_message]);
            }

        } else {
            return view('hdfcPayment.transMessage', ['data' => null]);
        }

    }

    public function transactionSuccess($orderId = null)
    {
        return view('hdfcPayment.success');
    }

    /**
     * This function will be call, when payment Failure
     * @author Shankar Mandal <shankarmandal@globussoft.in>
     * @Desc: Update pay_type,payment_status and traking_id and Payment Response data also stored in hdfc table
     * @since 31 August 2018
     */
    public function dispayPaymentFailMessage(Request $request)
    {
        $responseData = $request->input('data');

//        $responseData='order_id=123345&tracking_id=307004291680&bank_ref_no=null&order_status=Failure&failure_message=&payment_mode=Credit Card&card_name=Visa&status_code=null&status_message=null&currency=INR&amount=400.0&billing_name=&billing_address=&billing_city=&billing_state=&billing_zip=&billing_country=&billing_tel=&billing_email=&delivery_name=sdfrsdr&delivery_address=dfgdfg&delivery_city=Bhilai&delivery_state=ghgjhghj&delivery_zip=490020&delivery_country=India&delivery_tel=8805696632&merchant_param1=&merchant_param2=&merchant_param3=&merchant_param4=&merchant_param5=&vault=N&offer_type=null&offer_code=null&discount_value=0.0&mer_amount=400.0&eci_value=7&retry=N&response_code=0&billing_notes=&trans_date=13/10/2018 12:12:14&bin_country=RUSSIAN FEDERATION\x04\x04\x04\x04';
        if (isset($responseData)) {

            //-----------------------------------------------
            $secret_key = 'shankarmandal@globussoft.in';
            $secret_iv = '456';//my_simple_secret_iv

            $encrypt_method = "AES-256-CBC";
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            $responseData = openssl_decrypt(base64_decode($responseData), $encrypt_method, $key, 0, $iv);
            //-------------------------------------------------

            $data = explode('&', $responseData);

            $value = '';
            $key = '';
            $allData = [];
            for ($i = 0; $i < count($data); $i++) {
                $val = explode('=', $data[$i]);
                for ($j = 0; $j < count($val); $j++) {
                    if ($j == 0) {
                        $key = $val[$j];
                    } else {
                        $value = $val[$j];
                    }
                    $allData[$key] = $value;  //Set Key value
                }
            }

            //Remove empty value fields from array
            foreach ($allData as $key => $val) {
                if (isset($allData[$key]) && !empty($allData[$key])) {
                    $resData[$key] = $val;
                }
            }
            // Assign required value to insert into DB
            $details = [];
            if (isset($resData['order_id']) && !empty($resData['order_id'])) {
                $details['order_id'] = $resData['order_id'];
            }
            if (isset($resData['tracking_id']) && !empty($resData['tracking_id'])) {
                $details['tracking_id'] = $resData['tracking_id'];
            }
            if (isset($resData['bank_ref_no']) && !empty($resData['bank_ref_no'])) {
                $details['bank_ref_no'] = $resData['bank_ref_no'];
            }
            if (isset($resData['order_status']) && !empty($resData['order_status'])) {
                $details['order_status'] = $resData['order_status'];
            }
            if (isset($resData['failure_message']) && !empty($resData['failure_message'])) {
                $details['failure_message'] = $resData['failure_message'];
            }
            if (isset($resData['payment_mode']) && !empty($resData['payment_mode'])) {
                $details['payment_mode'] = $resData['payment_mode'];
            }
            if (isset($resData['card_name']) && !empty($resData['card_name'])) {
                $details['card_name'] = $resData['card_name'];
            }
            if (isset($resData['status_code']) && !empty($resData['status_code'])) {
                $details['status_code'] = $resData['status_code'];
            }
            if (isset($resData['status_message']) && !empty($resData['status_message'])) {
                $details['status_message'] = $resData['status_message'];
            }
            if (isset($resData['currency']) && !empty($resData['currency'])) {
                $details['currency'] = $resData['currency'];
            }
            if (isset($resData['amount']) && !empty($resData['amount'])) {
                $details['amount'] = $resData['amount'];
            }
            if (isset($resData['delivery_name']) && !empty($resData['delivery_name'])) {
                $details['delivery_name'] = $resData['delivery_name'];
            }
            if (isset($resData['delivery_address']) && !empty($resData['delivery_address'])) {
                $details['delivery_address'] = 'Address:' . $resData['delivery_address'] . ',City:' . $resData['delivery_city'] . ',State:' . $resData['delivery_state'] . ',Zip Code:' . $resData['delivery_zip'];
            }
            if (isset($resData['delivery_country']) && !empty($resData['delivery_country'])) {
                $details['delivery_country'] = $resData['delivery_country'];
            }
            if (isset($resData['delivery_tel']) && !empty($resData['delivery_tel'])) {
                $details['delivery_tel'] = $resData['delivery_tel'];
            }
            if (isset($resData['vault']) && !empty($resData['vault'])) {
                $details['vault'] = $resData['vault'];
            }
            if (isset($resData['discount_value']) && !empty($resData['discount_value'])) {
                $details['discount_value'] = $resData['discount_value'];
            }
            if (isset($resData['mer_amount']) && !empty($resData['mer_amount'])) {
                $details['mer_amount'] = $resData['mer_amount'];
            }
            if (isset($resData['retry']) && !empty($resData['retry'])) {
                $details['retry'] = $resData['retry'];
            }
            if (isset($resData['trans_date']) && !empty($resData['trans_date'])) {
                $date = $resData['trans_date'];
                $date = str_replace('/', '-', $date);
                $details['trans_date'] = date('Y-m-d H:i:s', strtotime($date));
            }
            if (isset($resData['bin_country']) && !empty($resData['bin_country'])) {
                $details['bin_country'] = $resData['bin_country'];
            }

            DB::table('hdfcpayment')->insert($details);

            //=====================================
            $orderDetails['payment_status'] = 2; // 2 means payment Failed
            if ($details['payment_mode'] == "Credit Card") {
                $orderDetails['pay_type'] = 1;
            } elseif ($details['payment_mode'] == "Debit Card") {
                $orderDetails['pay_type'] = 2;
            } elseif ($details['payment_mode'] == "Net Banking") {
                $orderDetails['pay_type'] = 3;
            }
            if (isset($details['tracking_id']) && !empty($details['tracking_id'])) {
                $orderDetails['tracking_id'] = $details['tracking_id'];
            } else {
                $orderDetails['tracking_id'] = null;
            }

            //Commented for testing
            DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                ->update([
                    'pay_type' => $orderDetails['pay_type'],
                    'payment_status' => $orderDetails['payment_status'],
                    'tracking_id' => $orderDetails['tracking_id']
                ]);

            //=====================================
            return view('hdfcPayment.paymentFailMessage', ['data' => $details]);
        } else {
            return view('hdfcPayment.paymentFailMessage');
        }
    }

    //
    public function transactionFailed()
    {
        return view('hdfcPayment.fail');
    }

    /**
     * This function will be call, when payment failue due to Security Error. Illegal access detected
     * @author Shankar Mandal <shankarmandal@globussoft.in>
     * @Desc: Update pay_type,payment_status and traking_id and Payment Response data also stored in hdfc table
     * @since 12 September 2018
     */
    public function dispaySecurityErrorMessage(Request $request)
    {
        $responseData = $request->input('data');
//        dd('Sec error',$responseData);
        if (isset($responseData)) {

            //-----------------------------------------------
            $secret_key = 'shankarmandal@globussoft.in';
            $secret_iv = '456';//my_simple_secret_iv

            $encrypt_method = "AES-256-CBC";
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            $responseData = openssl_decrypt(base64_decode($responseData), $encrypt_method, $key, 0, $iv);
            //-------------------------------------------------

            $data = explode('&', $responseData);

            $value = '';
            $key = '';
            $allData = [];
            for ($i = 0; $i < count($data); $i++) {
                $val = explode('=', $data[$i]);
                for ($j = 0; $j < count($val); $j++) {
                    if ($j == 0) {
                        $key = $val[$j];
                    } else {
                        $value = $val[$j];
                    }
                    $allData[$key] = $value;  //Set Key value
                }
            }

            //Remove empty value fields from array
            foreach ($allData as $key => $val) {
                if (isset($allData[$key]) && !empty($allData[$key])) {
                    $resData[$key] = $val;
                }
            }

            // Assign required value to insert into DB
            $details = [];
            if (isset($resData['order_id']) && !empty($resData['order_id'])) {
                $details['order_id'] = $resData['order_id'];
            }
            if (isset($resData['tracking_id']) && !empty($resData['tracking_id'])) {
                $details['tracking_id'] = $resData['tracking_id'];
            }
            if (isset($resData['bank_ref_no']) && !empty($resData['bank_ref_no'])) {
                $details['bank_ref_no'] = $resData['bank_ref_no'];
            }
            if (isset($resData['order_status']) && !empty($resData['order_status'])) {
                $details['order_status'] = $resData['order_status'];
            }
            if (isset($resData['failure_message']) && !empty($resData['failure_message'])) {
                $details['failure_message'] = $resData['failure_message'];
            }
            if (isset($resData['payment_mode']) && !empty($resData['payment_mode'])) {
                $details['payment_mode'] = $resData['payment_mode'];
            }
            if (isset($resData['card_name']) && !empty($resData['card_name'])) {
                $details['card_name'] = $resData['card_name'];
            }
            if (isset($resData['status_code']) && !empty($resData['status_code'])) {
                $details['status_code'] = $resData['status_code'];
            }
            if (isset($resData['status_message']) && !empty($resData['status_message'])) {
                $details['status_message'] = $resData['status_message'];
            }
            if (isset($resData['currency']) && !empty($resData['currency'])) {
                $details['currency'] = $resData['currency'];
            }
            if (isset($resData['amount']) && !empty($resData['amount'])) {
                $details['amount'] = $resData['amount'];
            }
            if (isset($resData['delivery_name']) && !empty($resData['delivery_name'])) {
                $details['delivery_name'] = $resData['delivery_name'];
            }
            if (isset($resData['delivery_address']) && !empty($resData['delivery_address'])) {
                $details['delivery_address'] = 'Address:' . $resData['delivery_address'] . ',City:' . $resData['delivery_city'] . ',State:' . $resData['delivery_state'] . ',Zip Code:' . $resData['delivery_zip'];
            }
            if (isset($resData['delivery_country']) && !empty($resData['delivery_country'])) {
                $details['delivery_country'] = $resData['delivery_country'];
            }
            if (isset($resData['delivery_tel']) && !empty($resData['delivery_tel'])) {
                $details['delivery_tel'] = $resData['delivery_tel'];
            }
            if (isset($resData['vault']) && !empty($resData['vault'])) {
                $details['vault'] = $resData['vault'];
            }
            if (isset($resData['discount_value']) && !empty($resData['discount_value'])) {
                $details['discount_value'] = $resData['discount_value'];
            }
            if (isset($resData['mer_amount']) && !empty($resData['mer_amount'])) {
                $details['mer_amount'] = $resData['mer_amount'];
            }
            if (isset($resData['retry']) && !empty($resData['retry'])) {
                $details['retry'] = $resData['retry'];
            }
            if (isset($resData['trans_date']) && !empty($resData['trans_date'])) {
                $date = $resData['trans_date'];
                $date = str_replace('/', '-', $date);
                $details['trans_date'] = date('Y-m-d H:i:s', strtotime($date));
            }
            if (isset($resData['bin_country']) && !empty($resData['bin_country'])) {
                $details['bin_country'] = $resData['bin_country'];
            }
//            dd('failer Data',$details);

            DB::table('hdfcpayment')->insert($details);

            //=====================================
            $orderDetails['payment_status'] = 2; // 2 means Failed due to Security Error. Illegal access detected"
            if ($details['payment_mode'] == "Credit Card") {
                $orderDetails['pay_type'] = 1;
            } elseif ($details['payment_mode'] == "Debit Card") {
                $orderDetails['pay_type'] = 2;
            } elseif ($details['payment_mode'] == "Net Banking") {
                $orderDetails['pay_type'] = 3;
            }
            if (isset($details['tracking_id']) && !empty($details['tracking_id'])) {
                $orderDetails['tracking_id'] = $details['tracking_id'];
            } else {
                $orderDetails['tracking_id'] = null;
            }

//             Commented for Testing
            DB::table('order_detail')->where('order_detail_id', $details['order_id'])
                ->update([
                    'pay_type' => $orderDetails['pay_type'],
                    'payment_status' => $orderDetails['payment_status'],
                    'tracking_id' => $orderDetails['tracking_id']
                ]);

            //=====================================

            return view('hdfcPayment.errorMessage', ['data' => $details]);
        } else {
            return view('hdfcPayment.errorMessage');
        }

    }

    public function transactionError()
    {
        return view('hdfcPayment.errors');
    }

    /**
     * This function will be call, on Click on cancel button
     * @author Shankar Mandal <shankarmandal@globussoft.in>
     * @Desc:
     * @since 13 July 2018
     */
    public function paymentCancel(Request $request)
    {
        return view('hdfcPayment.paymentCancel');
    }


    public function test()
    {
        return view('hdfcPayment.transMessage');
    }
}