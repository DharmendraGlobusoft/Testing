<?php

namespace App\Http\Controllers\Shopkeeper;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class UserController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class UserController extends Controller
{
    /*
     |--------------------------------------------------------------------------
     | User Controller
     |--------------------------------------------------------------------------
     |
     | This controller handles the edit or update Shopkeeper/user personal information and password.
     |
     */

    /**
     * This function create or update Shopkeeper profile data.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 13th JUNE, 2016
     */
    public function editShopkeeperProfile(Request $request)
    {
        if ($request->isMethod('post')) {
            $profileDetail = array(
                'first_name' => $request->input('firstName'),
                'last_name' => $request->input('lastName'),
                'email' => $request->input('email'),
                'contact_number' => $request->input('phone'),
                'fullContact_number' => $request->input('phone-full'),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'address' => $request->input('address'),
            );

            $profileDetail['contact_number'] = str_replace(" ", "", $profileDetail['contact_number']);
            $profileDetail['fullContact_number'] = str_replace(" ", "", $profileDetail['fullContact_number']);

            $validationResponse = Validator::make($profileDetail, [
                    'first_name' => 'required|max:50',
                    'last_name' => 'required|max:50',
                    'email' => 'required|email|max:200',
                    'contact_number' => 'required|min:1|numeric|digits_between:10,18',
                    'age' => 'required|numeric|min:1|max:120',
                    'gender' => 'required|digits:1|in:1,2',
                    'address' => 'required|max:400',]
            );

            if ($validationResponse->fails()) {
                return back()
                    ->withErrors($validationResponse, 'editProfile')
                    ->withInput();
            } else {
                unset($profileDetail['email']);
                $profileDetail['contact_number'] = $profileDetail['fullContact_number'];
                unset($profileDetail['fullContact_number']);
                $profileDetail['id'] = Auth::user()->id;

                $objUsers = new User();
                $resultProfileUpdate = $objUsers->editOrUpdateShopkeeperProfile($profileDetail);

                if (is_array($resultProfileUpdate)) {
                    $resultProfileUpdate['success'] = 'you have successfully updated your profile.';
                    return view('shopkeeper.editProfile')->with(['userData' => $resultProfileUpdate]);
                } else
                    return back()
                        ->withErrors('Sorry ! your profile updation have failed.', 'fail')
                        ->withInput();
            }
        } else {
            $objUsers = new User();
            $userData = $objUsers->getShopkeeperProfileData(Auth::user()->id);
            if (is_array($userData))
                return view('shopkeeper.editProfile')->with(['userData' => $userData]);
            else
                return view('shopkeeper.editProfile', ['userData' => null, 'dataFetchFail' => 'Sorry ! your profile data have not fetched.']);
        }
    }

    /**
     * This function update the Shopkeeper profile picture.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function updateShopkeeperPicture(Request $request)
    {
        $imageData = array(
            'profile_picture' => $request->file('profilePicture'),
        );

        $validationResponse = Validator::make($imageData, [
            'profile_picture' => 'required|image|mimes:jpeg,bmp,png|max:200',
        ]);

        if ($validationResponse->fails()) {
            echo json_encode($validationResponse->errors()->first());
        } else {
            $imageData['profile_picture_name'] = explode(".", $imageData['profile_picture']->getClientOriginalName());
            unset($imageData['profile_picture_name'][sizeof($imageData['profile_picture_name']) - 1]);

            $profileImageName = '';
            foreach ($imageData['profile_picture_name'] as $value) {
                $profileImageName = $profileImageName . $value;
            }

            $imageData['profile_picture_name'] = $profileImageName . mt_rand() . '.' . $imageData['profile_picture']->getClientOriginalExtension();

            $imageData['profile_picture_movedPath'] = public_path() . '/assets/shopkeeper/profilePicture';
            $imageData['profile_picture_fetchedPath'] = Config::get('app.WEB_HOST') . 'assets/shopkeeper/profilePicture';

            $objUser = new User();
            $updatePictureResponse = $objUser->uploadShopkeeperProfilePicture($imageData);
            echo json_encode($updatePictureResponse);
        }
    }

    /**
     * This function update the Shopkeeper password.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function updateShopkeeperPassword(Request $request)
    {
        $passwordData = array(
            'oldPassword' => $request->input('oldPassword'),
            'password' => $request->input('newPassword'),
            'password_confirmation' => $request->input('password_confirmation'),
        );

        $validationResponse = Validator::make($passwordData, [
            'oldPassword' => 'required|min:8',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($validationResponse->fails()) {
            echo json_encode($validationResponse->errors()->first());
        } else {
            unset($passwordData['password_confirmation']);
            $passwordData['userId'] = Auth::user()->id;
            $objUser = new User();
            $updatePictureResponse = $objUser->updatePassword($passwordData);
            echo json_encode($updatePictureResponse);
        }
    }

    /**
     * This function fetch the all user details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getUserList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'id';
        else
            if ($column == 1)
                $column = 'name';
            else
                if ($column == 2)
                    $column = 'email';

        $objUser = new User();
        $result = $objUser->fetchUserListByLimit($offset, $length, $column, $direction, $searchValue, 1);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to user status and button status according to database information
                if ($value['status'] == 1)
                    $userStatus = '<span class="badge badge-success"> Active </span>';
                 else
                    $userStatus = ' <span class="badge badge-danger"> Inactive </span>';


                //Taking a records[] array for keeping fetched user list and info
                $records["data"][] = array(
                    $value['id'],
                    $value['name'],
                    $value['email'],
                    $userStatus,
                    '<a href="javascript:;" data-toggle="modal" data-target="#userDetailModal" id="viewUserDetail" value = "' . $value["id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-eye"></i></a>',
                );
            }
            $records["recordsTotal"] = $objUser->fetchNumberOfUsers('', 1);
            $records["recordsFiltered"] = $objUser->fetchNumberOfUsers($searchValue, 1);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function use for fetch user detail form db.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getUserListAjax(Request $request)
    {
        $action = $request->input('action');
        $objUser = new User();

        switch ($action) {
            //This case is responsible for fetch all detail of a particular user
            case "viewUserDetail":
                $userId = $request->input('userId');

                $result = $objUser->fetchAllDetailOfUser($userId);

                if(is_array($result)) {
                    echo json_encode($result);
                } else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


} //End of class

