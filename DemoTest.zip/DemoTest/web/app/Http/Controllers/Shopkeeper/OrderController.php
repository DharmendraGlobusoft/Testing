<?php

namespace App\Http\Controllers\Shopkeeper;

use App\OrderDetail;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class OrderController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class OrderController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Order Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view user Order details and change user Order status related functions.
    |
    */

    /**
     * This function fetch the list of user order [shop wise only] with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 13th JUNE, 2016
     */
    public function getOrderList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 1)
                $column = 'order_detail.order_detail_id';
            else
                if ($column == 2)
                    $column = 'users.name';
                else
                    if ($column == 3)
                        $column = 'shop.shop_name';
                    else
                        if ($column == 4)
                            $column = 'order_detail.order_date';

            $objOrderDetail = new OrderDetail();
            $result = $objOrderDetail->fetchOrderListByLimitAndShop($offset, $length, $column, $direction, $searchValue);

            if ($result) {
                $slNo = 0;
                foreach ($result as $key => $value) {
                    $value = (array)$value;
                    $slNo++;

                    //checking the user and shop name are present or deleted
                    if ($value['name'] == NULL || $value['name'] == '')
                        $value['name'] = 'Not Available';

                    if ($value['shop_name'] == NULL || $value['shop_name'] == '')
                        $value['shop_name'] = 'Not Available';

                    //Split the date and time.
                    $value['order_date'] = explode(' ', $value['order_date']);

                    //Checking for Payment Type [1->Credit Card, 2->Debit Card, 3->Net Banking, 4->COD]
                    if ($value['pay_type'] == 1)
                        $payType = 'Credit Card';
                    else
                        if ($value['pay_type'] == 2)
                            $payType = 'Debit Card';
                        else
                            if ($value['pay_type'] == 3)
                                $payType = 'Net Banking';
                            else
                                if ($value['pay_type'] == 4)
                                    $payType = 'COD';

                    //Checking for Payment Status [0->Not Done, 1->Successfully Done, 2-> Failed, 3->Transaction Deleted]
                    if ($value['payment_status'] == 0)
                        $paymentStatus = '<span class="badge badge-black-opacity-alt"> Not Done </span>';
                    else
                        if ($value['payment_status'] == 1)
                            $paymentStatus = ' <span class="badge badge-success"> Successfully Done </span>';
                        else
                            if ($value['payment_status'] == 2)
                                $paymentStatus = ' <span class="badge badge-danger"> Failed </span>';
                            else
                                if ($value['payment_status'] == 3)
                                    $paymentStatus = ' <span class="badge badge-black-opacity"> Transaction Deleted </span>';


                    //Checking for Order Status [0->Pending, 1->Process, 2->Dispatch, 3->Delivered]
                    if ($value['order_status'] == 0) {
                        $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0" selected>Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                        $orderStatus = '<span class="badge badge-black-opacity-alt"> Pending </span>';
                    } else
                        if ($value['order_status'] == 1) {
                            $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1" selected>Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                            $orderStatus = '<span class="badge badge-azure"> Process </span>';
                        } else
                            if ($value['order_status'] == 2) {
                                $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2" selected>Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                                $orderStatus = '<span class="badge badge-info"> Dispatch </span>';
                            } else
                                if ($value['order_status'] == 3) {
                                    $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3" selected>Delivered</option>
                                            </select>';
                                    $orderStatus = '<span class="badge badge-success"> Delivered </span>';
                                }

                    //Taking a records[] array for keeping fetched User Order list and info
                    $records["data"][] = array(
                        $slNo,
                        $value['order_detail_id'],
                        $value['name'],
                        $value['shop_name'],
                        $value['order_date'][0],
                        $value['total_pay_cost'],
                        $payType,
                        $paymentStatus,
                        $orderStatus,
                        $actionButton,
                        '<a href="javascript:;" data-toggle="modal" data-target="#viewOrderDetailModal" id="viewOrderDetail" value = "' . $value["order_detail_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-eye"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objOrderDetail->fetchNumberOfOrderByShop('');
                $records["recordsFiltered"] = $objOrderDetail->fetchNumberOfOrderByShop($searchValue);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }

        } else
            return view('shopkeeper.userOrderList');
    }

    /**
     * This function is responsible for change order status,
     * view  user order details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getOrderListAjax(Request $request)
    {
        $action = $request->input('action');
        $objOrderDetail = new OrderDetail();

        switch ($action) {
            //This case is responsible for change the order status
            case "changeOrderStatus":
                $orderId = $request->input('orderId');
                $orderStatus = $request->input('orderStatus');
                $result = $objOrderDetail->changeOrderStatus($orderId, $orderStatus);
                echo json_encode($result);
                break;

            //This case is responsible for fetch all detail of user order
            case "viewOrder":
                $orderId = $request->input('orderId');

                $result = $objOrderDetail->fetchAllDetailOfUserOrder($orderId);

                if (is_array($result)) {
                    //user id and name checking
                    if ($result['id'] == null || $result['id'] == '')
                        $result['id'] = 'Not Available';
                    if ($result['name'] == null || $result['name'] == '')
                        $result['name'] = 'Not Available';

                    //shop id and name checking
                    if ($result['shop_id'] == null || $result['shop_id'] == '')
                        $result['shop_id'] = 'Not Available';

                    if ($result['shop_name'] == null || $result['shop_name'] == '')
                        $result['shop_name'] = 'Not Available';

                    //order status checking
                    if ($result['order_status'] == 0)
                        $result['order_status'] = 'Pending';
                    else
                        if ($result['order_status'] == 1)
                            $result['order_status'] = 'Process';
                        else
                            if ($result['order_status'] == 2)
                                $result['order_status'] = 'Dispatch';
                            else
                                if ($result['order_status'] == 3)
                                    $result['order_status'] = 'Delivered';
                                else
                                    if ($result['order_status'] == 4)
                                        $result['order_status'] = 'cancelled';
                    //pay type checking
                    if ($result['pay_type'] == 1)
                        $result['pay_type'] = 'Credit Card';
                    else
                        if ($result['pay_type'] == 2)
                            $result['pay_type'] = 'Debit Card';
                        else
                            if ($result['pay_type'] == 3)
                                $result['pay_type'] = 'Net Banking';
                            else
                                if ($result['pay_type'] == 4)
                                    $result['pay_type'] = 'COD';

                    //payment status checking
                    if ($result['payment_status'] == 0)
                        $result['payment_status'] = 'Not Done';
                    else
                        if ($result['payment_status'] == 1)
                            $result['payment_status'] = 'Successfully Done';
                        else
                            if ($result['payment_status'] == 2)
                                $result['payment_status'] = 'Failed';
                            else
                                if ($result['payment_status'] == 3)
                                    $result['payment_status'] = 'Transaction Deleted';

                    echo json_encode($result);
                } else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

} //End of class

