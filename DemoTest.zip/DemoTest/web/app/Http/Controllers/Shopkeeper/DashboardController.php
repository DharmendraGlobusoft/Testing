<?php

namespace App\Http\Controllers\Shopkeeper;

use App\OrderDetail;
use App\Product;
use App\ProductList;
use App\Shop;
use App\ShopKeeperMeta;
use App\User;
use App\UserPayment;
use App\UsersMeta;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

/**
 * Class DashboardController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd MAY, 2016
 */
class DashboardController extends Controller
{
    /*
     |--------------------------------------------------------------------------
     | Dashboard Controller
     |--------------------------------------------------------------------------
     |
     | This controller handles the showing shopkeeper dashboard related activity and functionalities.
     |
     */

    /**
     * It put some values in session and redirect to shopkeeper dashboard.
     * And It send total numbers of user, shopkeeper, order, etc.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 13th JUNE, 2016
     */
    public function welcomeDashboard(Request $request)
    {
        $userData = ShopKeeperMeta::where('id', '=', Auth::user()->id)
            ->select('first_name', 'last_name', 'image')
            ->first();
        if ($userData) {
            if ($userData->image == null || $userData->image == '')
                $userData->image = Config::get('app.WEB_HOST') . 'assets/shopkeeper/ProfilePic.jpg';

                Session::put('imageUrl', $userData->image);

            if (($userData->first_name == null || $userData->first_name == '') && ($userData->last_name == null || $userData->last_name == ''))
                Session::put('fullName', Auth::user()->name);
            else
                Session::put('fullName', $userData->first_name . ' ' . $userData->last_name);
        } else {
            Session::put('fullName', Auth::user()->name);
            Session::put('imageUrl', Config::get('app.WEB_HOST') . 'assets/shopkeeper/ProfilePic.jpg');
        }

        $activeUsers = User::where('role', '=', 1)
            ->where('status', '=', 1)
            ->count();

        $inactiveUsers = User::where('role', '=', 1)
            ->where(function ($query) {
                $query->where('status', '=', 0)
                    ->orWhere('status', '=', 2);
            })
            ->count();

        $activeShopkeepers = User::where('role', '=', 2)
            ->where('status', '=', 1)
            ->count();

        $inactiveShopkeepers = User::where('role', '=', 2)
            ->where(function ($query) {
                $query->where('status', '=', 0)
                    ->orWhere('status', '=', 2);
            })
            ->count();

        $activeShops = Shop::where('status', '=', 1)
            ->count();

        $inactiveShops = Shop::where('status', '=', 2)
            ->count();

        $shopkeeperId = ShopKeeperMeta::where('id', '=', Auth::user()->id)->select('shopkeeper_meta_id')->first();

        if ($shopkeeperId) {

            $shopId = ShopKeeperMeta::where('id', '=', Auth::user()->id)->select('shop_id')->first();

            if ($shopId->shop_id != null) {

                Session::put('shopId', 'Available');

                $orders = OrderDetail::where('shop_id', '=', $shopId->shop_id)->count();

                if ($orders > 0) {
                    $ordersDetailId = OrderDetail::where('shop_id', '=', $shopId->shop_id)->select('order_detail_id')->get();
                    $ordersDetailId = $ordersDetailId->toArray();

                    foreach ($ordersDetailId as $key => $value)
                        $ordersDetailId[$key] = $value['order_detail_id'];

                    $transactions = UserPayment::whereIn('order_detail_id', $ordersDetailId)->count();
                } else
                    $transactions = 0;


                $productIds = ProductList::where('shop_id', '=', $shopId->shop_id)->select('product_id')->get();

                if (!$productIds->isEmpty()) {
                    $productIds = $productIds->toArray();

                    foreach ($productIds as $key => $value)
                        $productIds[$key] = $value['product_id'];

                    $activeProduct = Product::whereIn('product_id', $productIds)
                        ->where('status', '=', 1)
                        ->count();
                    $inactiveProduct = Product::whereIn('product_id', $productIds)
                        ->where('status', '=', 2)
                        ->count();
                } else {
                    $activeProduct = 0;
                    $inactiveProduct = 0;
                }
            }
            else{
                Session::put('shopId', 'NotAssign');
                $orders = 0;
                $transactions = 0;
                $activeProduct = 0;
                $inactiveProduct = 0;
            }
        } else {
            Session::put('shopId', 'NotAvailable');
            $orders = 0;
            $transactions = 0;
            $activeProduct = 0;
            $inactiveProduct = 0;
        }

        $dashboard = array([
            'activeUsers' => $activeUsers,
            'inactiveUsers' => $inactiveUsers,
            'activeShopkeepers' => $activeShopkeepers,
            'inactiveShopkeepers' => $inactiveShopkeepers,
            'activeShops' => $activeShops,
            'inactiveShops' => $inactiveShops,
            'orders' => $orders,
            'transactions' => $transactions,
            'activeProduct' => $activeProduct,
            'inactiveProduct' => $inactiveProduct,
        ]);

        return view('shopkeeper.dashboard')->with('dashboard', $dashboard);
    }

}//End of class