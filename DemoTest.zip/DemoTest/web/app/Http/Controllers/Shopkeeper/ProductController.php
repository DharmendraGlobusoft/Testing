<?php

namespace App\Http\Controllers\Shopkeeper;

use App\MainProduct;
use App\Product;
use App\SubProduct;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

/**
 * Class ProductController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 14th JUNE, 2016
 */
class ProductController extends Controller
{
    /*
   |--------------------------------------------------------------------------
   | Product Controller
   |--------------------------------------------------------------------------
   |
   | This controller handles the view list, edit/update and add new main product,
   | sub product and product detail related functions.
   |
   */

    /**
     * This function fetch the list of Main Product with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 14th JUNE, 2016
     */
    public function getMainProductList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'main_product_id';
        else
            if ($column == 1)
                $column = 'product_name';

        $objMainProduct = new MainProduct();
        $result = $objMainProduct->fetchMainProductListByLimit($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to MainProduct status and button status according to database information
                if ($value['status'] == 1)
                    $mainProductStatus = '<span class="badge badge-success"> Active </span>';
                else
                    $mainProductStatus = ' <span class="badge badge-danger"> Inactive </span>';

                //Taking a records[] array for keeping fetched MainProduct list and info
                $records["data"][] = array(
                    $value['main_product_id'],
                    $value['product_name'],
                    $mainProductStatus,
                );
            }
            $records["recordsTotal"] = $objMainProduct->fetchNumberOfMainProduct('');
            $records["recordsFiltered"] = $objMainProduct->fetchNumberOfMainProduct($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function fetch the list of Sub Product with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 14th JUNE, 2016
     */
    public function getSubProductList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $mainProductId = $request->input('mainProductId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'sub_product_id';
            else
                if ($column == 1)
                    $column = 'product_name';

            $objSubProduct = new SubProduct();
            $result = $objSubProduct->fetchSubProductListByLimit($offset, $length, $column, $direction, $searchValue, $mainProductId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to Sub Product status and button status according to database information
                    if ($value['status'] == 1)
                        $subProductStatus = '<span class="badge badge-success"> Active </span>';
                    else
                        $subProductStatus = ' <span class="badge badge-danger"> Inactive </span>';

                    //Taking a records[] array for keeping fetched Sub Product list and info
                    $records["data"][] = array(
                        $value['sub_product_id'],
                        $value['product_name'],
                        $subProductStatus,
                    );
                }
                $records["recordsTotal"] = $objSubProduct->fetchNumberOfSubProduct('', $mainProductId);
                $records["recordsFiltered"] = $objSubProduct->fetchNumberOfSubProduct($searchValue, $mainProductId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }
        } else {
            $objSubProduct = new SubProduct();
            $mainProductList = $objSubProduct->getMainProductList();
            if (is_array($mainProductList))
                return view('shopkeeper.subProductList')->with(['mainProduct' => $mainProductList]);
            else
                return view('shopkeeper.subProductList')->with(['mainProduct' => null]);
        }
    }

    /**
     * This function responsible for create new product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 14th JUNE, 2016
     */
    public function CreateNewProduct(Request $request)
    {
        if ($request->isMethod('post')) {
            $productDetail = array(
                'main_product' => $request->input('mainProduct'),
                'sub_product' => $request->input('subProduct'),
                'product_name' => $request->input('productName'),
                'product_image' => $request->file('productImage'),
                'product_weight' => $request->input('productWeight'),
                'product_cost' => $request->input('productCost'),
                'product_service_tax' => $request->input('productServiceTax'),
                'product_description' => $request->input('productDescription'),
            );

            $validationResponse = Validator::make($productDetail, [
                'main_product' => 'required|numeric|min:1',
                'sub_product' => 'required|numeric|min:1',
                'product_name' => 'required|max:190',
                'product_image' => 'required|image|mimes:jpeg,gif,png|max:10240',
                'product_weight' => 'required|max:10',
                'product_cost' => 'required|numeric|min:0',
                'product_service_tax' => 'required|numeric|min:0',
                'product_description' => 'required|max:490',
            ]);

            if ($validationResponse->fails()) {
                return back()
                    ->withErrors($validationResponse, 'createProductError')
                    ->withInput();
            } else {
                $productImage['product_picture_movedPath'] = public_path() . '/assets/productImage/productImage';
                $productImage['product_picture_fetchedPath'] = Config::get('app.WEB_HOST') . 'assets/productImage/productImage';

                $productImage['product_picture_name'] = explode(".", $productDetail['product_image']->getClientOriginalName());
                unset($productImage['product_picture_name'][sizeof($productImage['product_picture_name']) - 1]);
                $productImageName = '';
                foreach ($productImage['product_picture_name'] as $value) {
                    $productImageName = $productImageName . $value;
                }
                $productImage['product_picture_name'] = $productImageName . mt_rand() . '.' . $productDetail['product_image']->getClientOriginalExtension();

                $objProduct = new Product();
                $result = $objProduct->createNewProduct($productDetail, $productImage, $request->file('product_other_image'));
                $mainProductData = $objProduct->getProductList('mainProduct', 0);
                if ($result == 'success')
                    Session::flash('success', 'you have successfully created new Product.');
                else
                    Session::flash('fail', 'Sorry ! Product have not created.');

                return view('shopkeeper.addProduct')->with(['mainProductData' => $mainProductData]);
            }
        } else {
            $objProduct = new Product();
            $mainProductData = $objProduct->getProductList('mainProduct', 0);
            return view('shopkeeper.addProduct')->with(['mainProductData' => $mainProductData]);
        }
    }

    /**
     * This function is responsible for get Sub Product List
     * for use in create a new product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 14th JUNE, 2016
     */
    public function CreateNewProductAjax(Request $request)
    {
        $action = $request->input('action');
        $objProduct = new Product();

        switch ($action) {
            //This case is responsible for get Sub Product List
            case "getSubProductList":
                $mainProductId = $request->input('mainProductId');
                $subProductList = $objProduct->getProductList('subProduct', $mainProductId);
                if (!empty($subProductList) && is_array($subProductList)) {
                    echo json_encode($subProductList);
                    die;
                } else {
                    echo json_encode('fail');
                    die;
                }
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function is responsible for fetch the existing product details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @param Request $request
     * @return $this
     * @since 14th JUNE, 2016
     */
    public function getParticularProductDetails($productId, Request $request)
    {
        $objProduct = new Product();
        $productDetail = $objProduct->fetchAllDetailOfOneProduct($productId);
        $otherImages = $objProduct->fetchOtherImageOfOneProduct($productId);
        if (is_array($productDetail) && !empty($productDetail))
            return view('shopkeeper.viewProduct')->with(['productData' => $productDetail, 'otherImages' => $otherImages]);
        else
            return view('shopkeeper.viewProduct')->with(['productData' => null, 'otherImages' => $otherImages]);
    }

    /**
     * This function is responsible for fetch product list according to shop
     * and showing in dataTable  for assign product to shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 14th JUNE, 2016
     */
    public function viewProductListShopWise(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'product_list.created_at';
            else
                if ($column == 1)
                    $column = 'product.product_id';
                else
                    if ($column == 2)
                        $column = 'product.product_name';
                    else
                        if ($column == 3)
                            $column = 'sub_product.product_name';
                        else
                            if ($column == 4)
                                $column = 'main_product.product_name';

            $objProduct = new Product();
            $result = $objProduct->fetchProductListByLimitAndShopId($offset, $length, $column, $direction, $searchValue);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to Product status and button status according to database information
                    if ($value['status'] == 1)
                        $productStatus = '<span class="badge badge-success"> Active </span>';
                    else
                        $productStatus = ' <span class="badge badge-danger"> Inactive </span>';

                    //Split the date and time.
                    $value['created_at'] = explode(' ', $value['created_at']);

                    //Taking a records[] array for keeping fetched Product list and info
                    $records["data"][] = array(
                        $value['created_at'][0],
                        $value['product_id'],
                        $value['product_name'],
                        $value['sub_product_name'],
                        $value['main_product_name'],
                        $value['stock_quantity'],
                        $productStatus,
                        '<a href="javascript:;" data-toggle="modal" data-target="#updateStockQuantityModal" id="updateStockQuantity"
                        data-productId = "' . $value["product_id"] . '" data-productName = "' . $value["product_name"] . '"
                        data-shopId = "' . $value["shop_id"] . '" data-stockQuantity = "' . $value["stock_quantity"] . '"
                        class="btn btn-default"><i class="glyph-icon icon-linecons-pencil"></i></a>',

                        '<a href="javascript:;" data-toggle="modal" data-target="#removeProductModal" id="removeProduct"
                        data-shopId = "' . $value["shop_id"] . '" data-productId = "' . $value["product_id"] . '"
                        data-stockQuantity = "' . $value["stock_quantity"] . '"
                        class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',

                        '<a href="/viewProductDetails/' . $value["product_id"] . '" id="view" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-eye"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objProduct->fetchNumberOfProductByShop('');
                $records["recordsFiltered"] = $objProduct->fetchNumberOfProductByShop($searchValue);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }

        } else {
            $objProduct = new Product();
            $unAssignProductList = $objProduct->fetchUnassignedProductList();
            if (is_array($unAssignProductList))
                return view('shopkeeper.productList')->with(['unAssignProductList' => $unAssignProductList]);
            else
                return view('shopkeeper.productList')->with(['unAssignProductList' => null]);
        }
    }

    /**
     * This function is responsible for assign product to shop, update stock quantity,
     * get unassigned product list and remove product from a shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 14th JUNE, 2016
     */
    public function viewProductListShopWiseAjax(Request $request)
    {
        $action = $request->input('action');
        $objProduct = new Product();

        switch ($action) {

            //This case is responsible for add product to a shop
            case "assignProductToShop":
                $productAssignData = array(
                    'product' => $request->input('productId'),
                    'quantity' => $request->input('quantity'),
                );

                $validationResponse = Validator::make($productAssignData, [
                    'product' => 'required|numeric|min:0|digits_between:1,10',
                    'quantity' => 'required|numeric|min:0|digits_between:1,14',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors());
                } else {
                    $result = $objProduct->addProductToShop($productAssignData);
                    echo json_encode($result);
                }
                break;

            //This case is responsible for  update particular product stock quantity
            case "updateStockQuantity":
                $productUpdateData = array(
                    'productId' => $request->input('productId'),
                    'oldStockQuantity' => $request->input('oldStockQuantity'),
                    'stock_quantity' => $request->input('newStockQuantity'),
                );

                $validationResponse = Validator::make($productUpdateData, [
                    'stock_quantity' => 'required|numeric|min:0|digits_between:1,14',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors());
                } else {
                    $result = $objProduct->updateProductStockQuantity($productUpdateData);
                    echo json_encode($result);
                }
                break;

            //This case is responsible for  fetch unassigned product list form database.
            case "getUnassignedProductList":
                $result = $objProduct->fetchUnassignedProductList();
                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for unassigned a product from the shop.
            case "removeProduct":
                $shopId = $request->input('shopId');
                $productId = $request->input('productId');
                $stockQuantity = $request->input('stockQuantity');

                $result = $objProduct->removeProductFromShop($shopId, $productId, $stockQuantity);

                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


} //End of class
