<?php

namespace App\Http\Controllers\Shopkeeper;

use App\Shop;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

/**
 * Class ShopController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class ShopController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Shop Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view shop detail related functions.
    |
    */

    /**
     * This function is responsible for getting shop list with their details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getShopListDetails(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'shop.shop_id';
        else
            if ($column == 1)
                $column = 'shop.shop_name';
            else
                if ($column == 2)
                    $column = 'shopkeeper_meta.id';

        $objShop = new Shop();
        $result = $objShop->fetchShopListByLimit($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to shop status and button status according to database information
                if ($value['status'] == 1)
                    $shopStatus = '<span class="badge badge-success"> Active </span>';
                else
                    $shopStatus = ' <span class="badge badge-danger"> Inactive </span>';

                //Checking for shop assign to shopkeeper or not
                if ($value['assign_to_shopkeeper'] == 1)
                    $assignedShopkeeper = $value["id"] . '.  ' . $value["first_name"];
                else
                    $assignedShopkeeper = 'Not assigned';

                //Taking a records[] array for keeping fetched shop list and info
                $records["data"][] = array(
                    $value['shop_id'],
                    $value['shop_name'],
                    $assignedShopkeeper,
                    $shopStatus,
                    '<a href="/viewOnlyShopDetail/' . $value["shop_id"] . '" id="view" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-eye"></i></a>',
                );
            }
            $records["recordsTotal"] = $objShop->fetchNumberOfShops('');
            $records["recordsFiltered"] = $objShop->fetchNumberOfShops($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function is responsible for fetching particular shop details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @param Request $request
     * @return $this
     * @since 13th JUNE, 2016
     */
    public function getOrUpdateParticularShopDetails($shopId, Request $request)
    {
        $objShop = new Shop();
        $shopDetail = $objShop->fetchAllDetailOfOneShop($shopId);

        if (is_array($shopDetail) && !empty($shopDetail))
            return view('shopkeeper.viewShop')->with(['shopData' => $shopDetail]);
        else
            return view('shopkeeper.viewShop')->with(['shopData' => null]);
    }


} //End of class

