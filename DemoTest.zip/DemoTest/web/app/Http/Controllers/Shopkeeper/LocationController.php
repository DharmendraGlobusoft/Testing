<?php

namespace App\Http\Controllers\Shopkeeper;

use App\City;
use App\Country;
use App\State;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

/**
 * Class LocationController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class LocationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Location Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view Location detail related functions.
    |
    */


    /**
     * This function fetch the list of country with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getCountryList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'country_id';
        else
            if ($column == 1)
                $column = 'country_name';

        $objCountry = new Country();
        $result = $objCountry->fetchCountryListByLimit($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to Country status and button status according to database information
                if ($value['status'] == 1)
                    $countryStatus = '<span class="badge badge-success"> Active </span>';
                 else
                    $countryStatus = ' <span class="badge badge-danger"> Inactive </span>';

                //Taking a records[] array for keeping fetched Country list and info
                $records["data"][] = array(
                    $value['country_id'],
                    $value['country_name'],
                    $countryStatus,
                );
            }
            $records["recordsTotal"] = $objCountry->fetchNumberOfCountry('');
            $records["recordsFiltered"] = $objCountry->fetchNumberOfCountry($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function fetch the list of State with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 13th JUNE, 2016
     */
    public function getStateList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $countryId = $request->input('countryId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'state_id';
            else
                if ($column == 1)
                    $column = 'state_name';

            $objState = new State();
            $result = $objState->fetchStateListByLimit($offset, $length, $column, $direction, $searchValue, $countryId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to State status and button status according to database information
                    if ($value['status'] == 1)
                        $stateStatus = '<span class="badge badge-success"> Active </span>';
                     else
                        $stateStatus = ' <span class="badge badge-danger"> Inactive </span>';

                    //Taking a records[] array for keeping fetched State list and info
                    $records["data"][] = array(
                        $value['state_id'],
                        $value['state_name'],
                        $stateStatus,
                    );
                }
                $records["recordsTotal"] = $objState->fetchNumberOfState('', $countryId);
                $records["recordsFiltered"] = $objState->fetchNumberOfState($searchValue, $countryId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }
        } else {
            $objState = new State();
            $countryList = $objState->getLocation('country', 0);
            if (is_array($countryList))
                return view('shopkeeper.stateList')->with(['country' => $countryList]);
            else
                return view('shopkeeper.stateList')->with(['country' => null]);
        }
    }

    /**
     * This function fetch the list of City with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 13th JUNE, 2016
     */
    public function getCityList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $stateId = $request->input('stateId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'city_id';
            else
                if ($column == 1)
                    $column = 'city_name';

            $objCity = new City();
            $result = $objCity->fetchCityListByLimit($offset, $length, $column, $direction, $searchValue, $stateId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to City status and button status according to database information
                    if ($value['status'] == 1)
                        $cityStatus = '<span class="badge badge-success"> Active </span>';
                    else
                        $cityStatus = ' <span class="badge badge-danger"> Inactive </span>';

                    //Taking a records[] array for keeping fetched City list and info
                    $records["data"][] = array(
                        $value['city_id'],
                        $value['city_name'],
                        $cityStatus,
                    );
                }
                $records["recordsTotal"] = $objCity->fetchNumberOfCity('', $stateId);
                $records["recordsFiltered"] = $objCity->fetchNumberOfCity($searchValue, $stateId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }
        } else {
            $objCity = new City();
            $countryList = $objCity->getLocation('country', 0);
            if (is_array($countryList))
                return view('shopkeeper.cityList')->with(['country' => $countryList]);
            else
                return view('shopkeeper.cityList')->with(['country' => null]);
        }
    }

    /**
     * This function is responsible for fetch State List.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getCityListAjax(Request $request)
    {
        $action = $request->input('action');
        $objCity = new City();

        switch ($action) {
            //This case is responsible for  fetch State list form database.
            case "getStateList":
                $countryId = $request->input('countryId');

                $result = $objCity->getLocation('state', $countryId);
                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


} //End of class
