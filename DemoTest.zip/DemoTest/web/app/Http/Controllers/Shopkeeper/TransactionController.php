<?php

namespace App\Http\Controllers\Shopkeeper;

use App\UserPayment;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class TransactionController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class TransactionController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Transaction Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view  user transaction details related functions.
    |
    */


    /**
     * This function fetch the list of User Transaction with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getTransactionList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 1)
            $column = 'users.id';
        else
            if ($column == 2)
                $column = 'users.name';
            else
                if ($column == 3)
                    $column = 'user_payment.transaction_id';
                else
                    if ($column == 4)
                        $column = 'user_payment.transaction_date';
                    else
                        if ($column == 5)
                            $column = 'order_detail.order_detail_id';

        $objUserPayment = new UserPayment();
        $result = $objUserPayment->fetchTransactionListByLimitAndShopId($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            $slNo = 0;
            foreach ($result as $key => $value) {
                $value = (array)$value;
                $slNo++;

                //Checking for Transaction status according to database information.
                if ($value['transaction_status'] == 1)
                    $transactionStatus = '<span class="badge badge-success"> Success </span>';
                else
                    $transactionStatus = ' <span class="badge badge-danger"> Failed </span>';

                //Checking for pay type status according to database information.
                if ($value['pay_type'] == 1)
                    $payTypeStatus = '<span class="badge badge-azure"> Credit Card </span>';
                else
                    if ($value['pay_type'] == 2)
                        $payTypeStatus = '<span class="badge badge-azure"> Debit Card </span>';
                    else
                        if ($value['pay_type'] == 3)
                            $payTypeStatus = '<span class="badge badge-azure"> Net Banking </span>';
                        else
                            if ($value['pay_type'] == 4)
                                $payTypeStatus = ' <span class="badge badge-azure"> COD </span>';

                //Split the date and time.
                $value['transaction_date'] = explode(' ', $value['transaction_date']);

                //checking the user is present or deleted and set the value Not Available
                if ($value['id'] == NULL || $value['id'] == '')
                    $value['id'] = 'Not Available';

                if ($value['name'] == NULL || $value['name'] == '')
                    $value['name'] = 'Not Available';

                //Taking a records[] array for keeping fetched Transaction list and info
                $records["data"][] = array(
                    $slNo,
                    $value['id'],
                    $value['name'],
                    $value['transaction_id'],
                    $value['transaction_date'][0],
                    $value['order_detail_id'],
                    $value['transaction_amount'],
                    $transactionStatus,
                    $payTypeStatus,
                );
            }
            $records["recordsTotal"] = $objUserPayment->fetchNumberOfTransactionByShopId('');
            $records["recordsFiltered"] = $objUserPayment->fetchNumberOfTransactionByShopId($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

} //End of class

