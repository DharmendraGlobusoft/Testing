<?php

namespace App\Http\Controllers\Shopkeeper;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class ShopkeeperController
 * @package App\Http\Controllers\Shopkeeper
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th JUNE, 2016
 */
class ShopkeeperController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Shopkeeper Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view shopkeeper personal information.
    |
    */

    /**
     * This function fetch the all shopkeeper details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getShopkeeperList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'id';
        else
            if ($column == 1)
                $column = 'name';
            else
                if ($column == 2)
                    $column = 'email';

        $objUser = new User();
        $result = $objUser->fetchUserListByLimit($offset, $length, $column, $direction, $searchValue, 2);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to shopkeeper status and button status according to database information
                if ($value['status'] == 1)
                    $shopkeeperStatus = '<span class="badge badge-success"> Active </span>';
                 else
                    $shopkeeperStatus = ' <span class="badge badge-danger"> Inactive </span>';

                //Taking a records[] array for keeping fetched shopkeeper list and info
                $records["data"][] = array(
                    $value['id'],
                    $value['name'],
                    $value['email'],
                    $shopkeeperStatus,
                    '<a href="javascript:;" data-toggle="modal" data-target="#shopkeeperDetailModal" id="viewShopkeeperDetail" value = "' . $value["id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-eye"></i></a>',
                );
            }
            $records["recordsTotal"] = $objUser->fetchNumberOfUsers('', 2);
            $records["recordsFiltered"] = $objUser->fetchNumberOfUsers($searchValue, 2);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function use for fetch shopkeeper detail form db.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 13th JUNE, 2016
     */
    public function getShopkeeperListAjax(Request $request)
    {
        $action = $request->input('action');
        $objUser = new User();

        switch ($action) {
            //This case is responsible for fetch all detail of a particular shopkeeper
            case "viewShopkeeperDetail":
                $shopkeeperId = $request->input('shopkeeperId');

                $result = $objUser->fetchAllDetailOfShopkeeper($shopkeeperId);

                if (is_array($result)) {
                    echo json_encode($result);
                } else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


} //End of class
