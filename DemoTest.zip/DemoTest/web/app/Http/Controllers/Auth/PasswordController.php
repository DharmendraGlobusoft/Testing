<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\PasswordResets;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * Class PasswordController
 * @package App\Http\Controllers\Auth
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 27th FEB, 2016
 */
class PasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    /**
     * Create a new password controller instance.
     * PasswordController constructor.
     * @return void
     * @since 27th FEB, 2016
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * This is used for display reset password view page with valid token id and email id
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $email
     * @param $token
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 8th MARCH, 2016
     */
    public function resetPasswordGet($email, $token)
    {
        return view('userAuthentication.resetPassword', ['email' => $email, 'token' => $token]);
    }

    /**
     * This is used for reset the user password through reset link calling to PasswordResets model
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 8th MARCH, 2016
     */
    public function resetPasswordPost(Request $request)
    {
        $userData = array(
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'password_confirmation' => $request->input('password_confirmation'),
            'token' => $request->input('token'),
        );

        $validationResponse = Validator::make($userData, [
            'email' => 'required|email|max:200',
            'password' => 'required|confirmed|min:8',
            'token' => 'required',
        ]);

        if ($validationResponse->fails()) {
            return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageErrorArray' => $validationResponse->errors()->all()]);
        } else {
            $objPasswordResets = new PasswordResets();
            $resetResponse = $objPasswordResets->resetUserPassword($userData);

            if ($resetResponse == 'success')
                return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageSuccess' => 'Your Password has been successfully Updated. Please go for login.']);
            else
                if ($resetResponse == 'Please check your Email, It has not registered.')
                    return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageError' => 'Please check your Email, It has not registered.']);
                else
                    if ($resetResponse == 'This reset link has been expired.')
                        return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageError' => 'This reset link has been expired.']);
                    else
                        if ($resetResponse == 'This reset link is invalid.')
                            return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageError' => 'This reset link is invalid.']);
                        else
                            return view('userAuthentication.resetPassword', ['email' => $userData['email'], 'token' => $userData['token'], 'messageError' => 'There are some error occurring. Please Try again...']);
        }
    }


} //End of class
