<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\UserSession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use stdClass;

/**
 * Class AuthController
 * @package App\Http\Controllers\Auth
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 27th FEB, 2016
 */
class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => ['adminOrShopkeeperLogOut', 'lockUserScreen']]);
    }

    /**
     * It verified the user email and activated the their account.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $email
     * @param $token
     * @since 3rd MARCH, 2016
     */
    public function activateAccount($email, $token)
    {
        $response = new stdClass();

        if ($authUser = User::where('email', $email)->first()) {
            if ($authUser->token != 'used') {
                if (Hash::check($token, $authUser->token)) {
                    if ($authUser->status == 0) {
                        DB::table('users')
                            ->where('email', $email)
                            ->update(['status' => 1, 'token' => 'used']);
                        return view('userAuthentication.activateUserAccount')->with('message', 'Your account has been successfully verified.');
                    } else
                        if ($authUser->status == 1)
                            return view('userAuthentication.activateUserAccount')->with('message', 'Your account has been already verified.');
                        else
                            if ($authUser->status == 2)
                                return view('userAuthentication.activateUserAccount')->with('message', 'Sorry! You have deactivated by admin.');
                } else
                    return view('userAuthentication.activateUserAccount')->with('message', 'You have a invalid verification link.');

            } else {
                if ($authUser->status == 0)
                    return view('userAuthentication.activateUserAccount')->with('message', 'You have a invalid verification link.');
                else
                    if ($authUser->status == 2)
                        return view('userAuthentication.activateUserAccount')->with('message', 'Sorry! You have deactivated by admin.');
                    else
                        return view('userAuthentication.activateUserAccount')->with('message', 'You account has been already verified.');
            }
        } else
            return view('userAuthentication.activateUserAccount')->with('message', 'You have a invalid verification link.');
    }

    /**
     * This function allows sign up to shopkeepers into Grocery Application
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 6th MAY, 2016
     */
    public function shopkeeperSignUp(Request $request)
    {
        $signUpDetail = array(
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'password_confirmation' => $request->input('password_confirmation'),
            'termCondition' => $request->input('termCondition'),
        );

        $validationResponse = Validator::make($signUpDetail, [
            'name' => 'required|max:100',
            'email' => 'required|email|max:200|unique:users',
            'password' => 'required|min:8|confirmed',
            'termCondition' => 'required',
        ], [
                'password.confirmed' => 'The password confirmation does not match with password field value.',
                'termCondition.required' => 'You should tick the term and condition field.',
            ]
        );

        if ($validationResponse->fails()) {
            return back()
                ->withErrors($validationResponse, 'signUP')
                ->withInput($request->except(['password', 'password_confirmation']));
        } else {
            unset($signUpDetail['password_confirmation']);
            unset($signUpDetail['termCondition']);
            $signUpDetail['password'] = Hash::make($signUpDetail['password']);
            $signUpDetail['role'] = 2;
            $signUpDetail['timezone'] = $request->input('timezone');
            $signUpDetail['token'] = 'used';

            $objUsers = new User();
            $result = $objUsers->createShopkeeper($signUpDetail);

            if ($result == 'success')
                return back()->withErrors('you have successfully registered.', 'success');
            else
                return back()->withErrors('Sorry ! your registration have failed.', 'fail');
        }
    }


    /**
     * Log In the admin or shopkeeper into the application
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @since 3rd MAY, 2016
     */
    public function adminOrShopkeeperLogIn(Request $request)
    {
        $userCred = array(
            'role' => $request->input('role'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
        );

        $validationResponse = Validator::make($userCred, [
            'role' => 'required|in:2,3',
            'email' => 'required|email|max:200',
            'password' => 'required|min:8',
        ]);

        if ($validationResponse->fails()) {
            return redirect('/')
                ->withErrors($validationResponse, 'login')
                ->withInput($request->except('password'));
        } else {

            if (Auth::attempt(['email' => $userCred['email'], 'password' => $userCred['password'], 'role' => $userCred['role'], 'status' => 1])) {

                UserSession::create([
                    'session_id' => Session::getId(),
                    'id' => Auth::user()->id,
                ]);

                if (Auth::user()->role == 3)
                    return redirect('/adminDashboard');
                else
                    if (Auth::user()->role == 2)
                        return redirect('/shopkeeperDashboard');
            } else {
                return redirect('/')
                    ->withErrors('Entered email or password is wrong.', 'authError')
                    ->withInput($request->except('password'));
            }
        }
    }

    /**
     * Log the admin or shopkeeper out of the application
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @since 3rd MAY, 2016
     */
    public function adminOrShopkeeperLogOut()
    {
        UserSession::where('session_id', '=', Session::getId())
            ->delete();
        Auth::logout();
        Session::forget('fullName');
        Session::forget('imageUrl');
        Session::forget('email');
        Session::forget('role');
        Session::forget('type');
        return redirect('/');
    }

    /**
     * This function put some session values and lock user screen through logout method
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 4th MAY, 2016
     */
    public function lockUserScreen()
    {
        if (Auth::check()) {
            Session::put('email', Auth::user()->email);
            Session::put('role', Auth::user()->role);
            if (Auth::user()->role == 3)
                Session::put('type', 'Administrative Person');
            else
                if (Auth::user()->role == 2)
                    Session::put('type', 'Shopkeeper');

            Auth::logout();
        }
        return view('lockScreen');
    }

    /**
     * This function unlock the user screen through authentication process
     * using session values and user input password.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @since 4th MAY, 2016
     */
    public function unlockUserScreen(Request $request)
    {
        $userCred = array(
            'role' => Session::get('role'),
            'email' => Session::get('email'),
            'password' => $request->input('password'),
        );

        $validationResponse = Validator::make($userCred, [
            'password' => 'required|min:8',
        ]);

        if ($validationResponse->fails()) {
            return redirect('/lockScreen')
                ->withErrors($validationResponse, 'login');
        } else {
            if (Auth::attempt(['email' => $userCred['email'], 'password' => $userCred['password'], 'role' => $userCred['role']])) {

                if (Auth::user()->role == 3)
                    return redirect('/adminDashboard');
                else
                    if (Auth::user()->role == 2)
                        return redirect('/shopkeeperDashboard');
            } else {
                return redirect('/lockScreen')
                    ->withErrors('Entered password is wrong', 'authError');
            }
        }
    }

    /**
     * This function is for content support
     * @author Sibani Mishra <sibanimishra@globussoft.com>
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @since 19th APRIL, 2017
     */
    public function supportPage()
    {
        return view('support');
    }

    /**
     * This function is for content Privacy
     * @author Nitish Kumar <nitishkumar@globussoft.in>
     * @param Request $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @since 04th JULY, 2017
     */
    public function privacyPolicy()
    {
        return view('privacyPolicy');
    }

} //End of class
