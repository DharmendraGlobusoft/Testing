<?php

namespace App\Http\Controllers\admin;

use App\Notification;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class NotificationController
 * @package App\Http\Controllers\admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 17th JUNE, 2016
 */
class NotificationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Notification Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the showing admin Notification related activity and functionalities.
    |
    */


    /**
     * This function called by ajax and responsible for view notification
     * list and change their status[seen and unseen]
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 28th JUNE, 2016
     */
    public function getNotificationAjax(Request $request)
    {
        $action = $request->input('action');
        $objNotification = new Notification();

        switch ($action) {
            //This case is responsible for view new notification list in notification bar.
            case "viewNewNotificationList":
                $result = $objNotification->getNewOrderNotification();

                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for fetch new notification list by limit wise.
            case "notificationListWithLimit":
                $offset = $request->input('offset');
                $result = $objNotification->getNewOrderNotificationByLimit($offset);

                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for change notification status.
            case "changeNotificationStatus":
                $notificationId = $request->input('notificationId');

                $result = $objNotification->changeOrderNotification($notificationId, 1);

                if ($result == 'success')
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


}//End of class
