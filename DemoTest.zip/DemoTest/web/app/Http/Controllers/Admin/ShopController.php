<?php

namespace App\Http\Controllers\Admin;

use App\Shop;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

/**
 * Class ShopController
 * @package App\Http\Controllers\Admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 16th MAY, 2016
 */
class ShopController extends Controller
{
    /*
     |--------------------------------------------------------------------------
     | Shop Controller
     |--------------------------------------------------------------------------
     |
     | This controller handles the edit, update, delete and add new shop detail related functions.
     |
     */

    /**
     * This function responsible for create a new shop
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 18th MAY, 2016
     */
    public function CreateNewShop(Request $request)
    {
        if ($request->isMethod('post')) {
            $shopDetail = array(
                'country' => $request->input('country'),
                'state' => $request->input('state'),
                'city' => $request->input('city'),
                'location' => $request->input('location'),
                'shop_name' => $request->input('shopName'),
                'shop_image' => $request->file('shopImage'),
                'shopkeeper' => $request->input('shopkeeperId'),
            );

            $validationResponse = Validator::make($shopDetail, [
                'country' => 'required|numeric|min:1',
                'state' => 'required|numeric|min:1',
                'city' => 'required|numeric|min:1',
                'location' => 'required|max:150',
                'shop_name' => 'required|max:90',
                'shop_image' => 'required|image|mimes:jpeg,bmp,png|max:200',
                'shopkeeper' => 'required|digits_between:1,10|numeric|min:0',
            ]);

            if ($validationResponse->fails()) {
                return back()
                    ->withErrors($validationResponse, 'createShopError')
                    ->withInput();
            } else {
                $shopImage['shop_picture_movedPath'] = public_path() . '/assets/shop/shopPicture';
                $shopImage['shop_picture_fetchedPath'] = Config::get('app.WEB_HOST') . 'assets/shop/shopPicture';

                $shopImage['shop_picture_name']= explode(".",$shopDetail['shop_image']->getClientOriginalName());
                unset($shopImage['shop_picture_name'][sizeof($shopImage['shop_picture_name'])-1]);
                $shopImageName = '';
                foreach ($shopImage['shop_picture_name'] as $value) {
                    $shopImageName = $shopImageName.$value;
                }
                $shopImage['shop_picture_name']=$shopImageName. mt_rand().'.'.$shopDetail['shop_image']->getClientOriginalExtension();

                $objShop = new Shop();
                $result = $objShop->createShop($shopDetail, $shopImage);
                $initialShopData = $objShop->getInitialDataForAddNewShop();
                if ($result == 'success')
                    Session::flash('success', 'you have successfully created new shop.');
                else
                    Session::flash('fail', 'Sorry ! shop have not created.');

                return view('admin.addShop')->with(['initialShopData' => $initialShopData]);
            }
        } else {
            $objShop = new Shop();
            $initialShopData = $objShop->getInitialDataForAddNewShop();
            return view('admin.addShop')->with(['initialShopData' => $initialShopData]);
        }
    }

    /**
     * This function is responsible for getting state and city list based on country.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 18th MAY, 2016
     */
    public function CreateNewShopAjax(Request $request)
    {
        $action = $request->input('action');
        $objShop = new Shop();

        switch ($action) {
            //This case is responsible for get state list
            case "getStateList":
                $countryId = $request->input('countryId');
                $stateList = $objShop->getLocation('state', $countryId);
                if (!empty($stateList) && is_array($stateList)) {
                    echo json_encode($stateList);
                    die;
                } else {
                    echo json_encode('fail');
                    die;
                }
                break;
            //This case is responsible for get city list
            case "getCityList":
                $stateId = $request->input('stateId');
                $cityList = $objShop->getLocation('city', $stateId);
                if (!empty($cityList) && is_array($cityList)) {
                    echo json_encode($cityList);
                    die;
                } else {
                    echo json_encode('fail');
                    die;
                }
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function is responsible for getting shop list with their details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 21th MAY, 2016
     */
    public function getShopListDetails(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'shop.shop_id';
        else
            if ($column == 1)
                $column = 'shop.shop_name';
            else
                if ($column == 2)
                    $column = 'shopkeeper_meta.id';

        $objShop = new Shop();
        $result = $objShop->fetchShopListByLimit($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to shop status and button status according to database information
                if ($value['status'] == 1) {
                    $activationButton = '<a href="" id="deActivate" value = "' . $value["shop_id"] . '" > <span class="bs-label label-danger">Deactivate</span> </a>';
                    $shopStatus = '<span class="badge badge-success"> Active </span>';
                } else {
                    $activationButton = '<a href="" id="activate" value = "' . $value["shop_id"] . '"  > <span class="bs-label label-success">Activate</span> </a> ';
                    $shopStatus = ' <span class="badge badge-danger"> Inactive </span>';
                }

                //Checking for shop assign to shopkeeper or not
                if ($value['assign_to_shopkeeper'] == 1)
                    $assignedShopkeeper = $value["id"] . '.  ' . $value["first_name"];
                else
                    $assignedShopkeeper = 'Not assigned';


                //Taking a records[] array for keeping fetched shop list and info
                $records["data"][] = array(
                    $value['shop_id'],
                    $value['shop_name'],
                    $assignedShopkeeper,
                    $shopStatus,
                    $activationButton,
                    '<a href="/viewShopDetail/' . $value["shop_id"] . '" id="view" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-eye"> / <i class="glyph-icon icon-linecons-pencil"></i></i></a>',
                    '<a href="javascript:;" data-toggle="modal" data-target="#deleteShopModal" id="deleteShop" value = "' . $value["shop_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                );
            }
            $records["recordsTotal"] = $objShop->fetchNumberOfShops('');
            $records["recordsFiltered"] = $objShop->fetchNumberOfShops($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function is responsible for activate, deactivate and delete particular shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 21th MAY, 2016
     */
    public function getShopListDetailsAjax(Request $request)
    {
        $action = $request->input('action');
        $objShop = new Shop();

        switch ($action) {
            //This case is responsible for shop Activated
            case "activate":
                $shopId = $request->input('shopId');
                $result = $objShop->activateOrDeactivateShop($shopId, 1);
                echo json_encode($result);
                break;

            //This case is responsible for shop Deactivated
            case "deactivate":
                $shopId = $request->input('shopId');
                $result = $objShop->activateOrDeactivateShop($shopId, 2);
                echo json_encode($result);
                break;
            //This case is responsible for fetch shop id and name
            case "shopDetail":
                $shopId = $request->input('shopId');

                $result = $objShop->fetchOneShopDetail($shopId);
                echo json_encode($result);
                break;

            //This case is responsible for shop deletion
            case "delete":
                $shopId = $request->input('shopId');

                $result = $objShop->deleteShop($shopId);
                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function is responsible for fetching or updating particular shop details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @param Request $request
     * @return $this
     * @since 21th MAY, 2016
     */
    public function getOrUpdateParticularShopDetails($shopId, Request $request)
    {
        $objShop = new Shop();
        if ($request->isMethod('post')) {

            $shopDetail = array(
                'shopId' => $shopId,
                'shop_name' => $request->input('shopName'),
                'shop_image' => $request->file('shopImage'),
                'shop_image_path' => $request->input('shopImagePath'),
                'shopkeeper' => $request->input('shopkeeperId'),
            );
            $imagePathArray = explode("/",$shopDetail['shop_image_path']);
            $shopDetail['shop_image_path']=public_path().'/'.$imagePathArray[3].'/'.$imagePathArray[4].'/'.$imagePathArray[5].'/'.$imagePathArray[6];
            $validationResponse = Validator::make($shopDetail, [
                'shop_name' => 'required|max:90',
                'shop_image' => 'image|mimes:jpeg,bmp,png|max:200',
                'shopkeeper' => 'required|digits_between:1,10|numeric|min:0',
            ]);

            if ($validationResponse->fails()) {
                Session::flash('error', 'true');
                return back()
                    ->withErrors($validationResponse, 'shopError')
                    ->withInput();
            } else {
                if (!empty($shopDetail['shop_image'])) {
                    $shopImage['shop_picture_movedPath'] = public_path() . '/assets/shop/shopPicture';

                    $shopImage['shop_picture_name']= explode(".",$shopDetail['shop_image']->getClientOriginalName());
                    unset($shopImage['shop_picture_name'][sizeof($shopImage['shop_picture_name'])-1]);
                    $shopImageName = '';
                    foreach ($shopImage['shop_picture_name'] as $value) {
                        $shopImageName = $shopImageName.$value;
                    }
                    $shopImage['shop_picture_name']=$shopImageName. mt_rand().'.'.$shopDetail['shop_image']->getClientOriginalExtension();

                    $shopImage['shop_picture_savedPath'] = Config::get('app.WEB_HOST') . 'assets/shop/shopPicture/' . $shopImage['shop_picture_name'];
                } else
                    $shopImage = null;

                $updateResult = $objShop->updateShop($shopDetail, $shopImage);

                $shopDetail = $objShop->fetchAllDetailOfOneShop($shopDetail['shopId']);

                if ($updateResult == 'success') {
                    Session::flash('success', 'you have successfully updated the shop.');
                    if (is_array($shopDetail) && !empty($shopDetail))
                        return view('admin.viewShop')->with(['shopData' => $shopDetail]);
                    else
                        return view('admin.viewShop')->with(['shopData' => null]);
                } else {
                    Session::flash('fail', 'Sorry ! your shop updation have been failed.');
                    return view('admin.viewShop')->with(['shopData' => null]);
                }
            }

        } else {
            $shopDetail = $objShop->fetchAllDetailOfOneShop($shopId);

            if (is_array($shopDetail) && !empty($shopDetail))
                return view('admin.viewShop')->with(['shopData' => $shopDetail]);
            else
                return view('admin.viewShop')->with(['shopData' => null]);
        }
    }


} //End of class

