<?php

namespace App\Http\Controllers\Admin;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

/**
 * Class ShopkeeperController
 * @package App\Http\Controllers\Admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 13th MAY, 2016
 */
class ShopkeeperController extends Controller
{
    /*
      |--------------------------------------------------------------------------
      | Shopkeeper Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles the edit or update or delete shopkeeper personal information.
      |
      */

    /**
     * This function fetch the all shopkeeper details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 14th MAY, 2016
     */
    public function getShopkeeperList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'id';
        else
            if ($column == 1)
                $column = 'name';
            else
                if ($column == 2)
                    $column = 'email';

        $objUser = new User();
        $result = $objUser->fetchUserListByLimit($offset, $length, $column, $direction, $searchValue, 2);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to shopkeeper status and button status according to database information
                if ($value['status'] == 1) {
                    $activationButton = '<a href="" id="deActivate" value = "' . $value["id"] . '" > <span class="bs-label label-danger">Deactivate</span> </a>';
                    $shopkeeperStatus = '<span class="badge badge-success"> Active </span>';
                } else {
                    $activationButton = '<a href="" id="activate" value = "' . $value["id"] . '"  > <span class="bs-label label-success">Activate</span> </a> ';
                    $shopkeeperStatus = ' <span class="badge badge-danger"> Inactive </span>';
                }

                //Taking a records[] array for keeping fetched shopkeeper list and info
                $records["data"][] = array(
                    $value['id'],
                    $value['name'],
                    $value['email'],
                    $shopkeeperStatus,
                    $activationButton,
                    '<a href="javascript:;" data-toggle="modal" data-target="#shopkeeperDetailModal" id="viewShopkeeperDetail" value = "' . $value["id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-eye"></i></a>',
                    '<a href="javascript:;" data-toggle="modal" data-target="#deleteShopkeeperModal" id="deleteShopkeeper" value = "' . $value["id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                );
            }
            $records["recordsTotal"] = $objUser->fetchNumberOfUsers('', 2);
            $records["recordsFiltered"] = $objUser->fetchNumberOfUsers($searchValue, 2);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function use for shopkeeper status activate or deactivate and
     * fetch shopkeeper detail and delete shopkeeper with their all detail form db.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 14th MAY, 2016
     */
    public function getShopkeeperListAjax(Request $request)
    {
        $action = $request->input('action');
        $objUser = new User();

        switch ($action) {
            //This case is responsible for shopkeeper Activated
            case "activate":
                $shopkeeperId = $request->input('shopkeeperId');
                $result = $objUser->activateOrDeactivateUser($shopkeeperId, 1);
                echo json_encode($result);
                break;

            //This case is responsible for shopkeeper Deactivated
            case "deactivate":
                $shopkeeperId = $request->input('shopkeeperId');
                $result = $objUser->activateOrDeactivateUser($shopkeeperId, 2);
                echo json_encode($result);
                break;
            //This case is responsible for fetch shopkeeper id and name
            case "shopkeeperDetail":
                $shopkeeperId = $request->input('shopkeeperId');

                $result = $objUser->fetchOneUserOrShopkeeperDetail($shopkeeperId);
                echo json_encode($result);
                break;

            //This case is responsible for shopkeeper deletion
            case "delete":
                $shopkeeperId = $request->input('shopkeeperId');

                $result = $objUser->deleteShopkeeper($shopkeeperId);
                echo json_encode($result);
                break;

            //This case is responsible for fetch all detail of a particular shopkeeper
            case "viewShopkeeperDetail":
                $shopkeeperId = $request->input('shopkeeperId');

                $result = $objUser->fetchAllDetailOfShopkeeper($shopkeeperId);

                if (is_array($result)) {
                    echo json_encode($result);
                } else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function create a new shopkeeper with their credentials
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 8th JUNE, 2016
     */
    public function CreateNewShopkeeper(Request $request)
    {
        $signUpDetail = array(
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => $request->input('password'),
            'password_confirmation' => $request->input('password_confirmation'),
        );

        $validationResponse = Validator::make($signUpDetail, [
            'name' => 'required|max:100',
            'email' => 'required|email|max:200|unique:users',
            'password' => 'required|min:8|confirmed',
        ], [
                'password.confirmed' => 'The password confirmation does not match with password field value.',
            ]
        );

        if ($validationResponse->fails()) {
            echo json_encode($validationResponse->errors());
        } else {
            unset($signUpDetail['password_confirmation']);
            $signUpDetail['password'] = Hash::make($signUpDetail['password']);
            $signUpDetail['role'] = 2;
            $signUpDetail['timezone'] = $request->input('timezone');
            $signUpDetail['token'] = 'used';

            $objUsers = new User();
            $result = $objUsers->createShopkeeper($signUpDetail);

            if ($result == 'success')
                echo json_encode('success');
            else
                echo json_encode('fail');
        }
    }


} //End of class
