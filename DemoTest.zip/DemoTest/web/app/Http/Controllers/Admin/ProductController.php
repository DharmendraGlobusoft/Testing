<?php

namespace App\Http\Controllers\Admin;

use App\MainProduct;
use App\Product;
use App\SubProduct;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

/**
 * Class ProductController
 * @package App\Http\Controllers\Admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 26th MAY, 2016
 */
class ProductController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Product Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view list, edit/update and add new main product,
    | sub product and product detail related functions.
    |
    */

    /**
     * This function fetch the list of Main Product with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function getMainProductList(Request $request)
    {
        $length = $request->input('length');
        $offset = $request->input('start');
        $searchValue = $request->input('search')['value'];
        $column = $request->input('order')[0]['column'];
        $direction = $request->input('order')[0]['dir'];

        //It replace the column number by corresponding column name which exist in DB for setting the order of column
        if ($column == 0)
            $column = 'main_product_id';
        else
            if ($column == 1)
                $column = 'product_name';

        $objMainProduct = new MainProduct();
        $result = $objMainProduct->fetchMainProductListByLimit($offset, $length, $column, $direction, $searchValue);

        if ($result) {
            foreach ($result as $key => $value) {
                $value = (array)$value;

                //Checking for dynamic update to MainProduct status and button status according to database information
                if ($value['status'] == 1) {
                    $activationButton = '<a href="" id="deActivate" value = "' . $value["main_product_id"] . '" > <span class="bs-label label-danger">Deactivate</span> </a>';
                    $mainProductStatus = '<span class="badge badge-success"> Active </span>';
                } else {
                    $activationButton = '<a href="" id="activate" value = "' . $value["main_product_id"] . '"  > <span class="bs-label label-success">Activate</span> </a> ';
                    $mainProductStatus = ' <span class="badge badge-danger"> Inactive </span>';
                }

                //Taking a records[] array for keeping fetched MainProduct list and info
                $records["data"][] = array(
                    $value['main_product_id'],
                    $value['product_name'],
                    $mainProductStatus,
                    $activationButton,
                    '<a href="" value ="' . $value["main_product_id"] . '" id="editButton" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-pencil"></i></a>',
                    '<a href="javascript:;" data-toggle="modal" data-target="#deleteMainProductModal" id="deleteMainProduct" value = "' . $value["main_product_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                );
            }
            $records["recordsTotal"] = $objMainProduct->fetchNumberOfMainProduct('');
            $records["recordsFiltered"] = $objMainProduct->fetchNumberOfMainProduct($searchValue);
            echo json_encode($records);
        } else {
            $records['data'][] = array(
                null, null, null, null, null,
            );
            $records["recordsTotal"] = 0;
            $records["recordsFiltered"] = 0;
            echo json_encode($records);
        }
    }

    /**
     * This function is responsible for activate, deactivate, create, update
     * and delete Main Product detail.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function getMainProductListAjax(Request $request)
    {
        $action = $request->input('action');
        $objMainProduct = new MainProduct();

        switch ($action) {
            //This case is responsible for MainProduct Activated
            case "activate":
                $mainProductId = $request->input('mainProductId');
                $result = $objMainProduct->activateOrDeactivateMainProduct($mainProductId, 1);
                echo json_encode($result);
                break;

            //This case is responsible for MainProduct Deactivated
            case "deactivate":
                $mainProductId = $request->input('mainProductId');
                $result = $objMainProduct->activateOrDeactivateMainProduct($mainProductId, 2);
                echo json_encode($result);
                break;
            //This case is responsible for fetch MainProduct name and id
            case "mainProductNameAndId":
                $mainProductId = $request->input('mainProductId');

                $result = $objMainProduct->fetchMainProductNameAndId($mainProductId);
                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for  create new MainProduct
            case "create":
                $mainProductData = array(
                    'main_product_name' => $request->input('mainProductName'),
                );

                $validationResponse = Validator::make($mainProductData, [
                    'main_product_name' => 'required|max:190',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors()->first());
                } else {
                    $result = $objMainProduct->createMainProduct($mainProductData['main_product_name']);
                    echo json_encode($result);
                }

                break;

            //This case is responsible for  update particular MainProduct detail
            case "update":
                $mainProductId = $request->input('mainProductId');
                $mainProductName = $request->input('mainProductName');

                $result = $objMainProduct->updateMainProduct($mainProductId, $mainProductName);
                echo json_encode($result);
                break;

            //This case is responsible for Main Product deletion
            case "delete":
                $mainProductId = $request->input('mainProductId');

                $result = $objMainProduct->deleteMainProduct($mainProductId);
                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function fetch the list of Sub Product with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 3rd JUNE, 2016
     */
    public function getSubProductList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $mainProductId = $request->input('mainProductId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'sub_product_id';
            else
                if ($column == 1)
                    $column = 'product_name';

            $objSubProduct = new SubProduct();
            $result = $objSubProduct->fetchSubProductListByLimit($offset, $length, $column, $direction, $searchValue, $mainProductId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to Sub Product status and button status according to database information
                    if ($value['status'] == 1) {
                        $activationButton = '<a href="" id="deActivate" value = "' . $value["sub_product_id"] . '" > <span class="bs-label label-danger">Deactivate</span> </a>';
                        $subProductStatus = '<span class="badge badge-success"> Active </span>';
                    } else {
                        $activationButton = '<a href="" id="activate" value = "' . $value["sub_product_id"] . '"  > <span class="bs-label label-success">Activate</span> </a> ';
                        $subProductStatus = ' <span class="badge badge-danger"> Inactive </span>';
                    }

                    //Taking a records[] array for keeping fetched Sub Product list and info
                    $records["data"][] = array(
                        $value['sub_product_id'],
                        $value['product_name'],
                        $subProductStatus,
                        $activationButton,
                        '<a href="" value ="' . $value["sub_product_id"] . '" id="editButton" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-pencil"></i></a>',
                        '<a href="javascript:;" data-toggle="modal" data-target="#deleteSubProductModal" id="deleteSubProduct" value = "' . $value["sub_product_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objSubProduct->fetchNumberOfSubProduct('', $mainProductId);
                $records["recordsFiltered"] = $objSubProduct->fetchNumberOfSubProduct($searchValue, $mainProductId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }
        } else {
            $objSubProduct = new SubProduct();
            $mainProductList = $objSubProduct->getMainProductList();
            if (is_array($mainProductList))
                return view('admin.subProductList')->with(['mainProduct' => $mainProductList]);
            else
                return view('admin.subProductList')->with(['mainProduct' => null]);
        }
    }

    /**
     * This function is responsible for activate, deactivate, create, update
     * and delete Sub Product detail.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function getSubProductListAjax(Request $request)
    {
        $action = $request->input('action');
        $objSubProduct = new SubProduct();

        switch ($action) {
            //This case is responsible for Sub Product Activated
            case "activate":
                $subProductId = $request->input('subProductId');
                $result = $objSubProduct->activateOrDeactivateSubProduct($subProductId, 1);
                echo json_encode($result);
                break;

            //This case is responsible for Sub Product Deactivated
            case "deactivate":
                $subProductId = $request->input('subProductId');
                $result = $objSubProduct->activateOrDeactivateSubProduct($subProductId, 2);
                echo json_encode($result);
                break;

            //This case is responsible for fetch Sub Product name and id
            case "subProductNameAndId":
                $subProductId = $request->input('subProductId');

                $result = $objSubProduct->fetchSubProductNameAndId($subProductId);
                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for  create new Sub Product
            case "create":
                $subProductData = array(
                    'main_product_id' => $request->input('mainProductId'),
                    'sub_product_name' => $request->input('subProductName'),
                );

                $validationResponse = Validator::make($subProductData, [
                    'sub_product_name' => 'required|max:190',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors()->first());
                } else {
                    $result = $objSubProduct->createSubProduct($subProductData['sub_product_name'], $subProductData['main_product_id']);
                    echo json_encode($result);
                }

                break;

            //This case is responsible for  update particular Sub Product detail
            case "update":
                $subProductId = $request->input('subProductId');
                $subProductName = $request->input('subProductName');

                $result = $objSubProduct->updateSubProduct($subProductId, $subProductName);
                echo json_encode($result);
                break;

            //This case is responsible for Sub Product deletion
            case "delete":
                $subProductId = $request->input('subProductId');

                $result = $objSubProduct->deleteSubProduct($subProductId);
                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function responsible for create new product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 3rd JUNE, 2016
     */
    public function CreateNewProduct(Request $request)
    {
        if ($request->isMethod('post')) {

            $productDetail = array(
                'main_product' => $request->input('mainProduct'),
                'sub_product' => $request->input('subProduct'),
                'product_name' => $request->input('productName'),
                'product_image' => $request->file('productImage'),
                'product_weight' => $request->input('productWeight'),
                'product_cost' => $request->input('productCost'),
                'product_service_tax' => $request->input('productServiceTax'),
                'product_description' => $request->input('productDescription'),
                'product_features' => $request->input('productFeatures'),
            );

//            echo "<pre>";
//            print_r($productDetail);
//            die('here');

            $validationResponse = Validator::make($productDetail, [
                'main_product' => 'required|numeric|min:1',
                'sub_product' => 'required|numeric|min:1',
                'product_name' => 'required|max:190',
                'product_image' => 'required|image|mimes:jpeg,gif,png|max:10240',
                'product_weight' => 'required|max:10',
                'product_cost' => 'required|numeric|min:0',
                'product_service_tax' => 'required|numeric|min:0',
                'product_description' => 'required|max:490',
            ]);

            if ($validationResponse->fails()) {
                return back()
                    ->withErrors($validationResponse, 'createProductError')
                    ->withInput();
            } else {
// ==================================Added By Dharmendra=====================================

                if ($request->input('subProduct') == 43) {
                    $productDetail['productType']=json_encode(['Footwear'=>$request->input('subProduct')]);
                    $sizeQuantity=[
                        'size6'=>$request->input('size6'),
                        'size7'=>$request->input('size7'),
                        'size8'=>$request->input('size8'),
                        'size9'=>$request->input('size9'),
                        'size10'=>$request->input('size10')
                    ];
                }elseif ($request->input('subProduct') == 44){
                    $productDetail['productType']=json_encode(['Clothes'=>$request->input('subProduct')]);
                    $sizeQuantity=[
                        'sizeS'=>$request->input('sizeS'),
                        'sizeM'=>$request->input('sizeM'),
                        'sizeL'=>$request->input('sizeL'),
                        'sizeXL'=>$request->input('sizeXL'),
                        'sizeXXL'=>$request->input('sizeXXL')
                    ];
                }else{
                    $productDetail['productType']=json_encode(['Others'=>'']);
                    $sizeQuantity='0';
                }




                $productImage['product_picture_movedPath'] = public_path() . '/assets/productImage/productImage';
                $productImage['product_picture_fetchedPath'] = Config::get('app.WEB_HOST') . 'assets/productImage/productImage';

                $productImage['product_picture_name'] = explode(".", $productDetail['product_image']->getClientOriginalName());
                unset($productImage['product_picture_name'][sizeof($productImage['product_picture_name']) - 1]);
                $productImageName = '';
                foreach ($productImage['product_picture_name'] as $value) {
                    $productImageName = $productImageName . $value;
                }
                $productImageName=preg_replace('/\s+/', '', $productImageName);
                $productImage['product_picture_name'] = $productImageName . mt_rand() . '.' . $productDetail['product_image']->getClientOriginalExtension();

                $objProduct = new Product();
                $result = $objProduct->createProduct($productDetail, $productImage, $request->file('product_other_image'),json_encode($sizeQuantity));
                $mainProductData = $objProduct->getProductList('mainProduct', 0);
                if ($result == 'success')
                    Session::flash('success', 'you have successfully created new Product.');
                else
                    Session::flash('fail', 'Sorry ! Product have not created.');

                return view('admin.addProduct')->with(['mainProductData' => $mainProductData]);
            }
        } else {
            $objProduct = new Product();
            $mainProductData = $objProduct->getProductList('mainProduct', 0);
            return view('admin.addProduct')->with(['mainProductData' => $mainProductData]);
        }
    }

    /**
     * This function is responsible for get Sub Product List
     * for use in create a new product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function CreateNewProductAjax(Request $request)
    {
        $action = $request->input('action');
        $objProduct = new Product();

        switch ($action) {
            //This case is responsible for get Sub Product List
            case "getSubProductList":
                $mainProductId = $request->input('mainProductId');
                $subProductList = $objProduct->getProductList('subProduct', $mainProductId);
                if (!empty($subProductList) && is_array($subProductList)) {
                    echo json_encode($subProductList);
                    die;
                } else {
                    echo json_encode('fail');
                    die;
                }
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function fetch the list of Product with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 3rd JUNE, 2016
     */
    public function getProductListDetails(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $category = $request->input('category');
            if ($category == 1)
                $shopId = null;
            else
                $shopId = $request->input('shopId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'product.product_id';
            else
                if ($column == 1)
                    $column = 'product.product_name';
                else
                    if ($column == 2)
                        $column = 'sub_product.product_name';
                    else
                        if ($column == 3)
                            $column = 'main_product.product_name';

            $objProduct = new Product();
            $result = $objProduct->fetchProductListByLimit($offset, $length, $column, $direction, $searchValue, $shopId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to Product status and button status according to database information
                    if ($value['status'] == 1) {
                        $activationButton = '<a href="" id="deActivate" value = "' . $value["product_id"] . '" > <span class="bs-label label-danger">Deactivate</span> </a>';
                        $productStatus = '<span class="badge badge-success"> Active </span>';
                    } else {
                        $activationButton = '<a href="" id="activate" value = "' . $value["product_id"] . '"  > <span class="bs-label label-success">Activate</span> </a> ';
                        $productStatus = ' <span class="badge badge-danger"> Inactive </span>';
                    }

                    //Taking a records[] array for keeping fetched Product list and info
                    $records["data"][] = array(
                        $value['product_id'],
                        $value['product_name'],
                        $value['sub_product_name'],
                        $value['main_product_name'],
                        $value['stock_quantity'],
                        $productStatus,
                        $activationButton,
                        '<a href="/viewProductDetail/' . $value["product_id"] . '" id="view" class="btn btn-default showEdit"><i class="glyph-icon icon-linecons-eye"> / <i class="glyph-icon icon-linecons-pencil"></i></i></a>',
                        '<a href="javascript:;" data-toggle="modal" data-target="#deleteProductModal" id="deleteProduct" value = "' . $value["product_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objProduct->fetchNumberOfProduct('', $shopId);
                $records["recordsFiltered"] = $objProduct->fetchNumberOfProduct($searchValue, $shopId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }

        } else {
            $objProduct = new Product();
            $shopList = $objProduct->getAllShopList();

            if (is_array($shopList))
                return view('admin.productList')->with(['shopList' => $shopList]);
            else
                return view('admin.productList')->with(['shopList' => null]);
        }
    }

    /**
     * This function is responsible for activate, deactivate, fetch product detail
     * and delete Product detail.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function getProductListDetailsAjax(Request $request)
    {
        $action = $request->input('action');
        $objProduct = new Product();

        switch ($action) {
            //This case is responsible for Product Activated
            case "activate":
                $productId = $request->input('productId');
                $result = $objProduct->activateOrDeactivateProduct($productId, 1);
                echo json_encode($result);
                break;

            //This case is responsible for Product Deactivated
            case "deactivate":
                $productId = $request->input('productId');
                $result = $objProduct->activateOrDeactivateProduct($productId, 2);
                echo json_encode($result);
                break;
            //This case is responsible for fetch Product id and name
            case "productDetail":
                $productId = $request->input('productId');

                $result = $objProduct->fetchOneProductDetail($productId);
                echo json_encode($result);
                break;

            //This case is responsible for Product deletion
            case "delete":
                $productId = $request->input('productId');

                $result = $objProduct->deleteProduct($productId);
                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    /**
     * This function is responsible for fetch and update the existing product details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @param Request $request
     * @return $this
     * @since 3rd JUNE, 2016
     */
    public function getOrUpdateParticularProductDetails($productId, Request $request)
    {
        $objProduct = new Product();
        if ($request->isMethod('post')) {



            // ==================================Added By Dharmendra=====================================

            if ($request->input('subProduct') == 43) {
                $sizeQuantity=[
                    'size6'=>$request->input('size6'),
                    'size7'=>$request->input('size7'),
                    'size8'=>$request->input('size8'),
                    'size9'=>$request->input('size9'),
                    'size10'=>$request->input('size10')
                ];
            }elseif ($request->input('subProduct') == 44){
                $sizeQuantity=[
                    'sizeS'=>$request->input('sizeS'),
                    'sizeM'=>$request->input('sizeM'),
                    'sizeL'=>$request->input('sizeL'),
                    'sizeXL'=>$request->input('sizeXL'),
                    'sizeXXL'=>$request->input('sizeXXL')
                ];
            }else{
                $sizeQuantity='0';
            }

            $productDetail = array(
                'productId' => $productId,
                'product_name' => $request->input('productName'),
                'product_image' => $request->file('productImage'),
                'product_image_path' => $request->input('productImagePath'),
                'product_weight' => $request->input('productWeight'),
                'product_cost' => $request->input('productCost'),
                'stockdetails' => json_encode($sizeQuantity),
                'product_service_tax' => $request->input('productServiceTax'),
                'product_description' => $request->input('productDescription'),
                'product_features' => $request->input('productFeatures'),
            );
            $imagePathArray = explode("/", $productDetail['product_image_path']);
            $productDetail['product_image_path'] = public_path() . '/' . $imagePathArray[3] . '/' . $imagePathArray[4] . '/' . $imagePathArray[5] . '/' . $imagePathArray[6];
            $validationResponse = Validator::make($productDetail, [
                'product_name' => 'required|max:190',
                'product_image' => 'image|mimes:jpeg,gif,png|max:200',
                'product_weight' => 'required|max:10',
                'product_cost' => 'required|numeric|min:0',
                'product_service_tax' => 'required|numeric|min:0',
                'product_description' => 'required|max:490',
                'product_features' => 'required|max:490',
            ]);

            if ($validationResponse->fails()) {
                Session::flash('error', 'true');
                return back()
                    ->withErrors($validationResponse, 'productError')
                    ->withInput();
            } else {
                if (!empty($productDetail['product_image'])) {
                    $productImage['product_picture_movedPath'] = public_path() . '/assets/productImage/productImage';

                    $productImage['product_picture_name'] = explode(".", $productDetail['product_image']->getClientOriginalName());
                    unset($productImage['product_picture_name'][sizeof($productImage['product_picture_name']) - 1]);
                    $productImageName = '';
                    foreach ($productImage['product_picture_name'] as $value) {
                        $productImageName = $productImageName . $value;
                    }
                    $productImage['product_picture_name'] = $productImageName . mt_rand() . '.' . $productDetail['product_image']->getClientOriginalExtension();

                    $productImage['product_picture_savedPath'] = Config::get('app.WEB_HOST') . 'assets/productImage/productImage/' . $productImage['product_picture_name'];
                } else
                    $productImage = null;

                if($request->input('exist_other_image') == 'change'){
                    $updateResult = $objProduct->updateProduct($productDetail, $productImage, $request->file('product_other_image'));
                }
                else{
                    $updateResult = $objProduct->updateProduct($productDetail, $productImage);
                }

                $productDetailAfterUpdate = $objProduct->fetchAllDetailOfOneProduct($productDetail['productId']);
                $otherImages = $objProduct->fetchOtherImageOfOneProduct($productId);
                $size=json_decode($productDetailAfterUpdate['stockdetails'],true);
                $productDetailAfterUpdate['stockdetails']=$size;

                if ($updateResult == 'success') {
                    Session::flash('success', 'you have successfully updated the product.');
                    if (is_array($productDetailAfterUpdate) && !empty($productDetailAfterUpdate))
                        return view('admin.viewProduct')->with(['productData' => $productDetailAfterUpdate, 'otherImages' => $otherImages]);
                    else
                        return view('admin.viewProduct')->with(['productData' => null, 'otherImages' => $otherImages]);
                } else {
                    Session::flash('fail', 'Sorry ! your product updation have been failed.');
                    return view('admin.viewProduct')->with(['productData' => null, 'otherImages' => $otherImages]);
                }
            }

        } else {
            $productDetail = $objProduct->fetchAllDetailOfOneProduct($productId);
            $otherImages = $objProduct->fetchOtherImageOfOneProduct($productId);

            $size=json_decode($productDetail['stockdetails'], true);
            $productDetail['stockdetails']=$size;
//            echo '<pre>';
//            print_r($productDetail);
//            die('ok');


            if (is_array($productDetail) && !empty($productDetail))
                return view('admin.viewProduct')->with(['productData' => $productDetail, 'otherImages' => $otherImages]);
            else
                return view('admin.viewProduct')->with(['productData' => null, 'otherImages' => $otherImages]);
        }
    }

    /**
     * This function is responsible for fetch product list according to shop
     * and showing in dataTable  for "assign product to shop" module.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 3rd JUNE, 2016
     */

    public function assignProductToShop(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $shopId = $request->input('shopId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 0)
                $column = 'product_list.created_at';
            else
                if ($column == 1)
                    $column = 'product.product_id';
                else
                    if ($column == 2)
                        $column = 'product.product_name';
                    else
                        if ($column == 3)
                            $column = 'sub_product.product_name';
                        else
                            if ($column == 4)
                                $column = 'main_product.product_name';

            $objProduct = new Product();
            $result = $objProduct->fetchProductListByLimit($offset, $length, $column, $direction, $searchValue, $shopId);

            if ($result) {
                foreach ($result as $key => $value) {
                    $value = (array)$value;

                    //Checking for dynamic update to Product status and button status according to database information
                    if ($value['status'] == 1)
                        $productStatus = '<span class="badge badge-success"> Active </span>';
                    else
                        $productStatus = ' <span class="badge badge-danger"> Inactive </span>';

                    //Split the date and time.
                    $value['created_at'] = explode(' ', $value['created_at']);

                    //Taking a records[] array for keeping fetched Product list and info
                    $records["data"][] = array(
                        $value['created_at'][0],
                        $value['product_id'],
                        $value['product_name'],
                        $value['sub_product_name'],
                        $value['main_product_name'],
                        $value['stock_quantity'],
                        $productStatus,
                        '<a href="javascript:;" data-toggle="modal" data-target="#updateStockQuantityModal" id="updateStockQuantity"
                        data-productId = "' . $value["product_id"] . '" data-productName = "' . $value["product_name"] . '"
                        data-shopId = "' . $shopId . '" data-stockQuantity = "' . $value["stock_quantity"] . '"
                        class="btn btn-default"><i class="glyph-icon icon-linecons-pencil"></i></a>',

                        '<a href="javascript:;" data-toggle="modal" data-target="#removeProductModal" id="removeProduct"
                        data-shopId = "' . $shopId . '" data-productId = "' . $value["product_id"] . '"
                        data-stockQuantity = "' . $value["stock_quantity"] . '"
                        class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objProduct->fetchNumberOfProduct('', $shopId);
                $records["recordsFiltered"] = $objProduct->fetchNumberOfProduct($searchValue, $shopId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }

        } else {
            $objProduct = new Product();
            $shopList = $objProduct->getAllShopList();

            if (is_array($shopList))
                return view('admin.assignProduct')->with(['shopList' => $shopList]);
            else
                return view('admin.assignProduct')->with(['shopList' => null]);
        }
    }

    /**
     * This function is responsible for assign product to shop, update stock quantity,
     * get unassigned product list and remove product from a shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 3rd JUNE, 2016
     */
    public function assignProductToShopAjax(Request $request)
    {
        $action = $request->input('action');
        $objProduct = new Product();

        switch ($action) {

            //This case is responsible for add product to a shop
            case "assignProductToShop":
                $productAssignData = array(
                    'shop' => $request->input('shopId'),
                    'product' => $request->input('productId'),
                    'quantity' => $request->input('quantity'),
                );

                $validationResponse = Validator::make($productAssignData, [
                    'shop' => 'required|numeric|min:0|digits_between:1,10',
                    'product' => 'required|numeric|min:0|digits_between:1,10',
                    'quantity' => 'required|numeric|min:0|digits_between:1,14',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors());
                } else {
                    $result = $objProduct->assignProductToShop($productAssignData);
                    echo json_encode($result);
                }
                break;

            //This case is responsible for  update particular product stock quantity
            case "updateStockQuantity":
                $productUpdateData = array(
                    'shopId' => $request->input('shopId'),
                    'productId' => $request->input('productId'),
                    'oldStockQuantity' => $request->input('oldStockQuantity'),
                    'stock_quantity' => $request->input('newStockQuantity'),
                );

                $validationResponse = Validator::make($productUpdateData, [
                    'stock_quantity' => 'required|numeric|min:0|digits_between:1,14',
                ]);

                if ($validationResponse->fails()) {
                    echo json_encode($validationResponse->errors());
                } else {
                    $result = $objProduct->updateStockQuantity($productUpdateData);
                    echo json_encode($result);
                }
                break;

            //This case is responsible for  fetch unassigned product list form database.
            case "getUnassignedProductList":
                $shopId = $request->input('shopId');

                $result = $objProduct->getUnassignedProductList($shopId);
                if (is_array($result))
                    echo json_encode($result);
                else
                    echo json_encode('fail');
                break;

            //This case is responsible for unassigned a product from the shop.
            case "removeProduct":
                $shopId = $request->input('shopId');
                $productId = $request->input('productId');
                $stockQuantity = $request->input('stockQuantity');

                $result = $objProduct->removeProductFromShop($shopId, $productId, $stockQuantity);

                echo json_encode($result);
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }


} //End of class
