<?php

namespace App\Http\Controllers\Admin;

use App\Notification;
use App\OrderDetail;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;

use PDF;

/**
 * Class OrderController
 * @package App\Http\Controllers\Admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 4th JUNE, 2016
 */
class OrderController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Order Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the view, change status and delete user Order details related functions.
    |
    */

    /**
     * This function fetch the list of user order with details for show in dataTable
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return $this
     * @since 8th JUNE, 2016
     */
    public function getOrderList(Request $request)
    {
        if ($request->isMethod('post')) {
            $length = $request->input('length');
            $offset = $request->input('start');
            $searchValue = $request->input('search')['value'];
            $column = $request->input('order')[0]['column'];
            $direction = $request->input('order')[0]['dir'];

            $category = $request->input('category');
            if ($category == 1)
                $shopId = null;
            else
                $shopId = $request->input('shopId');

            //It replace the column number by corresponding column name which exist in DB for setting the order of column
            if ($column == 1)
                $column = 'order_detail.order_detail_id';
            else
                if ($column == 2)
                    $column = 'users.name';
                else
                    if ($column == 3)
                        $column = 'shop.shop_name';
                    else
                        if ($column == 4)
                            $column = 'order_detail.order_date';

            $objOrderDetail = new OrderDetail();
            $result = $objOrderDetail->fetchOrderListByLimit($offset, $length, $column, $direction, $searchValue, $shopId);

            if ($result) {
                $slNo = 0;
                foreach ($result as $key => $value) {
                    $value = (array)$value;
                    $slNo++;

                    //checking the user and shop name are present or deleted
                    if ($value['name'] == NULL || $value['name'] == '')
                        $value['name'] = 'Not Available';

                    if ($value['shop_name'] == NULL || $value['shop_name'] == '')
                        $value['shop_name'] = 'Not Available';

                    //Split the date and time.
                    $value['order_date'] = explode(' ', $value['order_date']);

                    //Checking for Payment Type [0->Payment Not Done,1->Credit/Debit Card,2->Credit/Debit Card,3->Net Banking,4->COD, 5->Wallet,6->UPI]
                    if ($value['pay_type'] == 1)
//                        $payType = 'Credit Card';
                            $payType = 'Card'; //updated on 18/01/2019
                    else
                        if ($value['pay_type'] == 2)
//                            $payType = 'Debit Card';
                            $payType = 'Card';//updated on 18/01/2019
                        else
                            if ($value['pay_type'] == 3)
                                $payType = 'Net Banking';
                            else
                                if ($value['pay_type'] == 4)
                                    $payType = 'COD';
                                //Added by shankar on 11/10/2018
                                else
                                    if ($value['pay_type'] == 5)
                                        $payType = 'Wallet';
                                    else
                                        if ($value['pay_type'] == 6)
                                            $payType = 'UPI';
                                        else
                                            if ($value['pay_type'] == 0)
                                                $payType = 'Payment Failure';

                    //Checking for Payment Status [0->Not Done, 1->Successfully Done, 2-> Failed, 3->Transaction Deleted]
                    if ($value['payment_status'] == 0)
                        $paymentStatus = '<span class="badge badge-black-opacity-alt"> Not Done </span>';
                    else
                        if ($value['payment_status'] == 1)
                            $paymentStatus = ' <span class="badge badge-success"> Successfully Done </span>';
                        else
                            if ($value['payment_status'] == 2)
                                $paymentStatus = ' <span class="badge badge-danger"> Failed </span>';
                            else
                                if ($value['payment_status'] == 3)
                                    $paymentStatus = ' <span class="badge badge-black-opacity"> Transaction Deleted </span>';


                    //Checking for Order Status [0->Pending, 1->Process, 2->Dispatch, 3->Delivered]
                    if ($value['order_status'] == 0) {
                        $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0" selected>Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                        $orderStatus = '<span class="badge badge-black-opacity-alt"> Pending </span>';
                    } else
                        if ($value['order_status'] == 1) {
                            $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1" selected>Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                            $orderStatus = '<span class="badge badge-azure"> Process </span>';
                        } else
                            if ($value['order_status'] == 2) {
                                $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2" selected>Dispatch</option>
                                                 <option value="3">Delivered</option>
                                            </select>';
                                $orderStatus = '<span class="badge badge-info"> Dispatch </span>';
                            } else
                                if ($value['order_status'] == 3) {
                                    $actionButton = '<select id="orderStatus" data-orderId="' . $value['order_detail_id'] . '">
                                                 <option value="0">Pending</option>
                                                 <option value="1">Process</option>
                                                 <option value="2">Dispatch</option>
                                                 <option value="3" selected>Delivered</option>
                                            </select>';
                                    $orderStatus = '<span class="badge badge-success"> Delivered </span>';
                                }

                    //Taking a records[] array for keeping fetched User Order list and info
                    $records["data"][] = array(
                        $slNo,
                        $value['order_detail_id'],
                        $value['name'],
                        $value['shop_name'],
                        $value['order_date'][0],
                        $value['total_pay_cost'],
                        $payType,
                        $paymentStatus,
                        $orderStatus,
                        $actionButton,
                        '<a href="javascript:;" data-toggle="modal" data-target="#viewOrderDetailModal" id="viewOrderDetail" value = "' . $value["order_detail_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-eye"></i></a>
                        <a href="javascript:;" data-toggle="modal" data-target="#deleteOrderDetailModal" id="deleteOrderDetail" value = "' . $value["order_detail_id"] . '" class="btn btn-default"><i class="glyph-icon icon-linecons-trash"></i></a>',
                    );
                }
                $records["recordsTotal"] = $objOrderDetail->fetchNumberOfOrder('', $shopId);
                $records["recordsFiltered"] = $objOrderDetail->fetchNumberOfOrder($searchValue, $shopId);
                echo json_encode($records);
            } else {
                $records['data'][] = array(
                    null, null, null, null, null, null, null, null, null, null, null,
                );
                $records["recordsTotal"] = 0;
                $records["recordsFiltered"] = 0;
                echo json_encode($records);
            }

        } else {
            $objOrderDetail = new OrderDetail();
            $shopList = $objOrderDetail->getAllShopList();

            if (is_array($shopList))
                return view('admin.userOrderList')->with(['shopList' => $shopList]);
            else
                return view('admin.userOrderList')->with(['shopList' => null]);
        }
    }

    /**
     * This function is responsible for change order status, delete order,
     * view  user order details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @since 8th JUNE, 2016
     */
    public function getOrderListAjax(Request $request)
    {
        $action = $request->input('action');
        $objOrderDetail = new OrderDetail();

        switch ($action) {
            //This case is responsible for change the order status
            case "changeOrderStatus":
                $orderId = $request->input('orderId');
                $orderStatus = $request->input('orderStatus');
                $changeStatusResult = $objOrderDetail->changeOrderStatus($orderId, $orderStatus);

                //start the code for sending notification to android mobile users
                $url = 'https://android.googleapis.com/gcm/send';
                $headers = array(
                    'Authorization: key=' . Config::get('app.GOOGLE_SERVER_KEY'), //Google api key
                    'Content-Type: application/json'
                );
                $notificationDataForAndroid = $objOrderDetail->getNotificationDataForAndroid($orderId);

                if (is_array($notificationDataForAndroid)) {
                    if ($notificationDataForAndroid['order_status'] == 0)
                        $notificationDataForAndroid['order_status'] = 'This order is now pending.';
                    else
                        if ($notificationDataForAndroid['order_status'] == 1)
                            $notificationDataForAndroid['order_status'] = 'This order is now in under process.';
                        else
                            if ($notificationDataForAndroid['order_status'] == 2)
                                $notificationDataForAndroid['order_status'] = 'This order has been dispatched form our shop.';
                            else
                                if ($notificationDataForAndroid['order_status'] == 3)
                                    $notificationDataForAndroid['order_status'] = 'This order has been delivered to you.';

                    $messageForAndroid = 'Your order Id is ' . $notificationDataForAndroid["order_detail_id"] . '. ' . $notificationDataForAndroid['order_status'];
                    $messageFormat = array(
                        'message' => $messageForAndroid,
                        'title' => Config::get('app.APPLICATION_NAME') . " Order",
                        'subtitle' => 'Admin changed Your order status',
                        'vibrate' => 1,
                        'sound' => 1,
                        'largeIcon' => 'large_icon',
                        'smallIcon' => 'small_icon',
                        "content-available" => false,
                        "priority" => "high"
                    );

                    $ids[] = $notificationDataForAndroid['device_token_id_android'];
                    $fields = array(
                        'registration_ids' => $ids,
                        'data' => $messageFormat,
                    );

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                    $result = curl_exec($ch);
//                    if ($result === FALSE) {
//                        die('Curl failed: ' . curl_error($ch));
//                    }
                    curl_close($ch);
                }

                //start the code for sending notification to IOS mobile users
                $notificationDataForIos = $objOrderDetail->getNotificationDataForIOS($orderId);

                if (is_array($notificationDataForIos)) {
                    if ($notificationDataForIos['order_status'] == 0)
                        $notificationDataForIos['order_status'] = 'This order is now pending.';
                    else
                        if ($notificationDataForIos['order_status'] == 1)
                            $notificationDataForIos['order_status'] = 'This order is now in under process.';
                        else
                            if ($notificationDataForIos['order_status'] == 2)
                                $notificationDataForIos['order_status'] = 'This order has been dispatched form our shop.';
                            else
                                if ($notificationDataForIos['order_status'] == 3)
                                    $notificationDataForIos['order_status'] = 'This order has been delivered to you.';

                    // Put your device token here (without spaces):
                    $deviceToken = $notificationDataForIos['device_token_id_ios'];

                    // Put your private key's passphrase here:
                    $passphrase = 'globussoft';

                    // Put your alert message here:
                    $messageForIOS = 'Your order Id is ' . $notificationDataForIos["order_detail_id"] . '. ' . $notificationDataForIos['order_status'];

                    $path = 'assets/pushNotification/GroceryPushCertificates.pem';
                    $ctx = stream_context_create();
                    stream_context_set_option($ctx, 'ssl', 'local_cert', $path);

                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

                    // Open a connection to the APNS server
                    $fp = @stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

                    if (!$fp)
                        exit("Failed to connect: $err $errstr" . PHP_EOL);

//                    echo 'Connected to APNS' . PHP_EOL;

                    // Create the payload body
                    $body['aps'] = array(
                        'alert' => $messageForIOS,
                        'sound' => 'default',
                        'category' => "NEWS_CATEGORY",
                    );

                    // Encode the payload as JSON
                    $payload = json_encode($body);

                    // Build the binary notification
                    $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

                    // Send it to the server
                    $result = fwrite($fp, $msg, strlen($msg));

//                    if (!$result)
//                        echo 'Message not delivered' . PHP_EOL;
//                    else
//                        echo 'Message successfully delivered' . PHP_EOL;

                    // Close the connection to the server
                    fclose($fp);
                }

                //start the code for saving notification in db
                $objNotification = new Notification();
                $objNotification->saveUserNotification($orderId);

                echo json_encode($changeStatusResult);
                break;

            //This case is responsible for delete order
            case "deleteOrder":
                $orderId = $request->input('orderId');
                $result = $objOrderDetail->deleteUserOrder($orderId);
                echo json_encode($result);
                break;

            //This case is responsible for fetch all detail of user order
            case "viewOrder":
                $orderId = $request->input('orderId');

                $result = $objOrderDetail->fetchAllDetailOfUserOrder($orderId);

                if (is_array($result)) {
                    //user id and name checking
                    if ($result['id'] == null || $result['id'] == '')
                        $result['id'] = 'Not Available';
                    if ($result['name'] == null || $result['name'] == '')
                        $result['name'] = 'Not Available';

                    //shop id and name checking
                    if ($result['shop_id'] == null || $result['shop_id'] == '')
                        $result['shop_id'] = 'Not Available';

                    if ($result['shop_name'] == null || $result['shop_name'] == '')
                        $result['shop_name'] = 'Not Available';

                    //order status checking
                    if ($result['order_status'] == 0)
                        $result['order_status'] = 'Pending';
                    else
                        if ($result['order_status'] == 1)
                            $result['order_status'] = 'Process';
                        else
                            if ($result['order_status'] == 2)
                                $result['order_status'] = 'Dispatch';
                            else
                                if ($result['order_status'] == 3)
                                    $result['order_status'] = 'Delivered';
                                else
                                    if ($result['order_status'] == 4)
                                        $result['order_status'] = 'cancelled';
                    //pay type checking
                    if ($result['pay_type'] == 1)
//                        $result['pay_type'] = 'Credit Card';
                        $result['pay_type'] = 'Card';
                    else
                        if ($result['pay_type'] == 2)
//                            $result['pay_type'] = 'Debit Card';
                            $result['pay_type'] = 'Card';
                        else
                            if ($result['pay_type'] == 3)
                                $result['pay_type'] = 'Net Banking';
                            else
                                if ($result['pay_type'] == 4)
                                    $result['pay_type'] = 'COD';
                                //Added by shankar on 30/01/2019
                                else
                                    if ($result['pay_type'] == 5)
                                        $result['pay_type'] = 'Wallet';
                                    else
                                        if ($result['pay_type'] == 6)
                                            $result['pay_type'] = 'UPI';
                                        else
                                            if ($result['pay_type'] == 0)
                                                $result['pay_type'] = 'Payment Failure';

                    //payment status checking
                    if ($result['payment_status'] == 0)
                        $result['payment_status'] = 'Not Done';
                    else
                        if ($result['payment_status'] == 1)
                            $result['payment_status'] = 'Successfully Done';
                        else
                            if ($result['payment_status'] == 2)
                                $result['payment_status'] = 'Failed';
                            else
                                if ($result['payment_status'] == 3)
                                    $result['payment_status'] = 'Transaction Deleted';

                    echo json_encode($result);
                } else
                    echo json_encode('fail');
                break;

            //This is a default case which execute if condition will not match
            default :
                break;
        } //End of switch case
    }

    //Updated On 02-02-2019 for PDF fun.
    //================= Start ==========================
    function ConvertIntoPDF(Request $request)
    {
        $orderId = $request->input('orderId');
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadHTML($this->convert_customer_data_to_html($orderId))->setPaper('a4', 'landscape')->save('myfile.pdf');
        return $pdf->stream();
    }

    function get_customer_data($orderId = null)
    {
//        dd('Stop',$orderId);
        $objOrderDetail = new OrderDetail();
        $result = $objOrderDetail->fetchAllDetailOfUserOrder($orderId);

        if (is_array($result)) {
            //user id and name checking
            if ($result['id'] == null || $result['id'] == '')
                $result['id'] = 'Not Available';
            if ($result['name'] == null || $result['name'] == '')
                $result['name'] = 'Not Available';

            //shop id and name checking
            if ($result['shop_id'] == null || $result['shop_id'] == '')
                $result['shop_id'] = 'Not Available';

            if ($result['shop_name'] == null || $result['shop_name'] == '')
                $result['shop_name'] = 'Not Available';

            //order status checking
            if ($result['order_status'] == 0)
                $result['order_status'] = 'Pending';
            else
                if ($result['order_status'] == 1)
                    $result['order_status'] = 'Process';
                else
                    if ($result['order_status'] == 2)
                        $result['order_status'] = 'Dispatch';
                    else
                        if ($result['order_status'] == 3)
                            $result['order_status'] = 'Delivered';
                        else
                            if ($result['order_status'] == 4)
                                $result['order_status'] = 'cancelled';
            //pay type checking
            if ($result['pay_type'] == 1)
                $result['pay_type'] = 'Card';
            else
                if ($result['pay_type'] == 2)
                    $result['pay_type'] = 'Card';
                else
                    if ($result['pay_type'] == 3)
                        $result['pay_type'] = 'Net Banking';
                    else
                        if ($result['pay_type'] == 4)
                            $result['pay_type'] = 'COD';
                        else
                            if ($result['pay_type'] == 5)
                                $result['pay_type'] = 'Wallet';
                            else
                                if ($result['pay_type'] == 6)
                                    $result['pay_type'] = 'UPI';
                                else
                                    if ($result['pay_type'] == 0)
                                        $result['pay_type'] = 'Payment Failure';

            //payment status checking
            if ($result['payment_status'] == 0)
                $result['payment_status'] = 'Not Done';
            else
                if ($result['payment_status'] == 1)
                    $result['payment_status'] = 'Successfully Done';
                else
                    if ($result['payment_status'] == 2)
                        $result['payment_status'] = 'Failed';
                    else
                        if ($result['payment_status'] == 3)
                            $result['payment_status'] = 'Transaction Deleted';
            return $result;
        } else
            return 0;
//            echo json_encode('fail');
    }

    function convert_customer_data_to_html($orderId)
    {
        $customer_data = $this->get_customer_data($orderId);
        $output = '<h2>Payment Invoice:</h2>';
        $output .= '<table border="2" style="width:100%;background-color:white;border-color:#151313;font-family: arial, sans-serif;">';

        $output .= '<tr><th colspan="2" style="text-align: center;border: 0px solid #dddddd;"><b style="font-size: 15px;">Primary Details</b></th></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding: 0px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #dddddd;">';
        $output .= '<table border="0" style="width: 80%;margin-left: 30px;padding: 5px;">';
        $output .= '<tr>
                                    <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Order Id :</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['order_detail_id'] . '</td>
                                    <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Order Date :</th>
                                     <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['order_date'] . '</td>
                               </tr>';

        $output .= '<tr>
                                    <th style="text-align:left;border: 0px solid #dddddd;padding: 4px;">User Id :</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['id'] . '</td>
                                    <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Delivery Date :</th>
                                    <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['delivery_date'] . '</td>
                                </tr>';

        $output .= '<tr>
                                     <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">User Name :</th>
                                     <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['name'] . '</td>
                                     <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Shop Id :</th>
                                     <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['shop_id'] . '</td>
                                </tr>';

        $output .= '<tr>
                                        <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Shop Name :</th>
                                        <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['shop_name'] . '</td>
                                    </tr>';
        $output .= '</table>';
        $output .= '</td></tr>';

        //Delivery Address
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><th colspan="2" style="text-align: center;border: 0px solid #dddddd;"><b style="font-size: 15px;">Delivery Address</b></th></tr></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #dddddd;padding: 0px;">';
        $output .= '<table style="width: 80%;margin-left: 30px;padding: 5px;">';
        $output .= '<tr>
                                        <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Name :</th>
                                        <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['first_name'] . ' ' . $customer_data['last_name'] . '</td>
                                        <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Address :</th>
                                        <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['address_line1'] . '</td>
                                    </tr>';

        $output .= '<tr>
                                        <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Email :</th>
                                        <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['email'] . '</td>
                                        <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">District :</th>
                                        <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['district'] . '</td>
                                    </tr>';
        $output .= '<tr>
                                        <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Contact :</th>
                                        <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['contact_country_code'] . '-' . $customer_data['contact_number'] . '</td>
                                        <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">State :</th>
                                        <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['state'] . '</td>                                        
                                        
                                   </tr>';
        $output .= '<tr>
                                        <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Pin :</th>
                                        <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['pin'] . '</td>
                                        <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Country :</th>
                                        <td style="text-align: right;border: 0px solid #dddddd;padding: 4px4px;">' . $customer_data['country'] . '</td>
                                    </tr>';
        $output .= '</table>';
        $output .='</td></tr>';

        //Amount Details
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><th colspan="2" style="text-align: center;border: 0px solid #dddddd;"><b style="font-size: 15px;">Amount Details</b></th></tr></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #dddddd;padding: 0px;"">';
        $output .= '<table style="width: 80%;margin-left: 30px;padding: 5px;">';
        $output .= '<tr>
                                    <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Total Cost :</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['total_cost'] . '</td>
                                    <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Total Service Tax :</th>
                                    <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['total_service_tax'] . '</td>
                                </tr>';
        $output .= '<tr>
                                    <th style="text-align: left;border: 0px solid #dddddd;padding: 4px;">Total Discount Amount :</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['total_discount_amount'] . '</td>
                                    <th style="text-align: right;border: 0px solid #dddddd;padding: 4px;">Total Payable Cost :</th>
                                    <td style="text-align: right;border: 0px solid #dddddd;padding: 4px;">' . $customer_data['total_pay_cost'] . '</td>
                                 </tr>';
        $output .= '</table>';
        $output .= '</td></tr>';

        $output .= '</table><br><br><br><br><br><br>'; //Outer Table

        //Product Details
        $output .= '<table border="2" style="width:100%;border-color:#151313;font-family: arial, sans-serif;">';
        $output .= '<tr><th colspan="2" style="text-align: center;border: 0px solid #dddddd;"><b style="font-size: 15px;">Product Details</b></th></tr></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</td></tr>';
        $output .= '<tr><td style="text-align: left;border: 0px solid #dddddd;padding: 0px;"">';
        $output .= '<table style="width: 60%;margin-left: 30px;">';
        $c = 1;
        foreach ($customer_data['product_detail'] as $customer) {
            if ($c != 1)
                $output .= '<tr><td style="text-align: left;border: 0px solid #000000;padding:-2px;">----------------------------------------------------------------------------------------------------</td></tr>';

            $output .= '
                                <tr>
                                    <th style="text-align: left;border: 0px solid #dddddd;padding: 2px;">Product Id:</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 2px;">' . $customer->product_id . '</td>
                                    <th style="text-align: right;border: 0px solid #dddddd;padding: 2px;">Product Name:</th>
                                    <td style="text-align: right;border: 0px solid #dddddd;padding: 2px;">' . $customer->product_name . '</td>
                                </tr>
                                 <tr>
                                    <th style="text-align: left;border: 0px solid #dddddd;padding: 2px;">Quantity:</th>
                                    <td style="text-align: left;border: 0px solid #dddddd;padding: 0px;">' . $customer->quantity . '</td>
                                </tr>
                        ';
            $c++;
        }

        $output .= '</table>';
        $output .= '</td></tr>';

        $output .= '</table>';

        return $output;
    }

    //================= End ==========================

} //End of class

