<?php

namespace App\Http\Controllers\Admin;

use App\OrderDetail;
use App\Product;
use App\Shop;
use App\User;
use App\UserPayment;
use App\UsersMeta;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;

/**
 * Class DashboardController
 * @package App\Http\Controllers\Admin
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd MAY, 2016
 */
class DashboardController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Dashboard Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the showing admin dashboard related activity and functionalities.
    |
    */

    /**
     * It put some values in session and redirect to admin dashboard.
     * And It send total numbers of user, shopkeeper, order, etc.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @since 4th MAY, 2016
     */
    public function welcomeDashboard(Request $request)
    {
        $userData = UsersMeta::where('id', '=', Auth::user()->id)
            ->select('first_name', 'last_name', 'image')
            ->first();
        if ($userData) {
            if ($userData->image == null || $userData->image == '')
                $userData->image = Config::get('app.WEB_HOST') . 'assets/admin/ProfilePic.jpg';

                Session::put('imageUrl', $userData->image);

            if (($userData->first_name == null || $userData->first_name == '') && ($userData->last_name == null || $userData->last_name == ''))
                Session::put('fullName', Auth::user()->name);
            else
                Session::put('fullName', $userData->first_name . ' ' . $userData->last_name);
        } else {
            Session::put('fullName', Auth::user()->name);
            Session::put('imageUrl', Config::get('app.WEB_HOST') . 'assets/admin/ProfilePic.jpg');
        }

        $activeUsers = User::where('role', '=', 1)
            ->where('status', '=', 1)
            ->count();

        $inactiveUsers = User::where('role', '=', 1)
            ->where(function ($query) {
                $query->where('status', '=', 0)
                    ->orWhere('status', '=', 2);
            })
            ->count();

        $activeShopkeepers = User::where('role', '=', 2)
            ->where('status', '=', 1)
            ->count();

        $inactiveShopkeepers = User::where('role', '=', 2)
            ->where(function ($query) {
                $query->where('status', '=', 0)
                    ->orWhere('status', '=', 2);
            })
            ->count();

        $activeShops = Shop::where('status', '=', 1)
            ->count();

        $inactiveShops = Shop::where('status', '=', 2)
            ->count();

        $orders = OrderDetail::count();

        $transactions = UserPayment::count();

        $activeProduct = Product::where('status', '=', 1)
            ->count();

        $inactiveProduct = Product::where('status', '=', 2)
            ->count();

        $dashboard = array([
            'activeUsers' => $activeUsers,
            'inactiveUsers' => $inactiveUsers,
            'activeShopkeepers' => $activeShopkeepers,
            'inactiveShopkeepers' => $inactiveShopkeepers,
            'activeShops' => $activeShops,
            'inactiveShops' => $inactiveShops,
            'orders' => $orders,
            'transactions' => $transactions,
            'activeProduct' => $activeProduct,
            'inactiveProduct' => $inactiveProduct,
        ]);

        return view('admin.dashboard')->with('dashboard', $dashboard);
    }

}//End of class
