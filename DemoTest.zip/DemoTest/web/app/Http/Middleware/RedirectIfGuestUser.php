<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

/**
 * Class RedirectIfGuestUser
 * @package App\Http\Middleware
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 5th MAY, 2016
 */
class RedirectIfGuestUser
{
    /**
     * This middleware authenticate the user whether he/she logged out or not?
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $request
     * @param Closure $next
     * @param null $guard
     * @return \Illuminate\Http\RedirectResponse
     * @since 5th MAY, 2016
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard($guard)->check()) {
            return back();
        }
        return $next($request);
    }

}//End of class
