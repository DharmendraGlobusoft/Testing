<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

/**
 * Class RedirectIfNotAdmin
 * @package App\Http\Middleware
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 4th MAY, 2016
 */
class RedirectIfNotAdmin
{
    /**
     * This middleware authenticate the user role for admin
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param \Illuminate\Http\Request $request
     * @param Closure $next
     * @return \Illuminate\Http\RedirectResponse
     * @since 4th MAY, 2016
     */
    public function handle($request, Closure $next)
    {
        if (Auth::user()->role != 3)
            return redirect()->guest('/');
        return $next($request);
    }

} //End of class
