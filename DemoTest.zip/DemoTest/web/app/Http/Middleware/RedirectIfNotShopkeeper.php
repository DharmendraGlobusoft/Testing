<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

/**
 * Class RedirectIfNotShopkeeper
 * @package App\Http\Middleware
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 4th MAY, 2016
 */
class RedirectIfNotShopkeeper
{
    /**
     * This middleware authenticate the user role for shopkeeper
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param \Illuminate\Http\Request $request
     * @param Closure $next
     * @return \Illuminate\Http\RedirectResponse
     * @since 4th MAY, 2016
     */
    public function handle($request, Closure $next)
    {
        if (Auth::user()->role != 2)
            return redirect()->guest('/');
        return $next($request);
    }

} //End of class
