<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/**
 * This route group applies the "web" middleware group to every route
 * it contains. The "web" middleware group is defined in your HTTP
 * kernel and includes session state, CSRF protection, and more.
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd MARCH, 2016
 */

Route::group(['middleware' => ['web']], function () {

    /**
     * This route group applies the "guest" middleware group to every route
     * it allow to access the routes only to guest[Logged out] users.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @since 5th MAY, 2016
     */


    /*
        * Related to HDEF Paymemnt Gateway
        */
    //================================ Shankar Mandal added on 23-07-2018 ============================

    //For Testing purpose for HDFC Dept. 12/09/2018
    Route::get('/hdfcPayment','HdfcPayment\PaymentController@paymentCheckout');
    Route::post('/hdfcPayment','HdfcPayment\PaymentController@paymentCheckout');
    //End on 12/09/2018

    Route::get('/hdfcPayment/{orderId}/{price}','HdfcPayment\PaymentController@hdfcPayment');

    Route::get('/response-data','HdfcPayment\PaymentController@responseData');// return response from HDFC
    Route::get('/transaction-success/{orderId}','HdfcPayment\PaymentController@transactionSuccess');

    Route::get('/transaction/failed-data', 'HdfcPayment\PaymentController@dispayPaymentFailMessage');
    Route::get('/transaction-failed/{orderId}', 'HdfcPayment\PaymentController@transactionFailed');

    Route::get('/transaction/error-data','HdfcPayment\PaymentController@dispaySecurityErrorMessage');
    Route::get('/transaction-error','HdfcPayment\PaymentController@transactionError');

    Route::get('/payment-cancel', 'HdfcPayment\PaymentController@paymentCancel');

    //On Validation Failed
    Route::get('/failed', function (){
        return view('hdfcPayment.validationFailed');
    });

    //================================ End== ============================

    Route::group(['middleware' => ['guest']], function () {

        /**
         * Related to users account verification
         */
        Route::get('verifyEmailForAccount/{email}/{token}', 'Auth\AuthController@activateAccount');

        /**
         * Related to users reset password for forgot password option
         */
        Route::get('password/reset/{email}/{token}', 'Auth\PasswordController@resetPasswordGet');
        Route::post('/password/forgotPassword', 'Auth\PasswordController@resetPasswordPost');

        /**
         * Related to Admin or Shopkeeper welcome and login page
         */
        Route::get('/', function () {
            return view('welcome');
        });

        Route::post('/login', 'Auth\AuthController@adminOrShopkeeperLogIn');

        /**
         * Related to Shopkeeper signUp page
         */
        Route::get('/signUP', function () {
            return view('shopkeeper.signUp');
        });
        Route::post('/signUP', 'Auth\AuthController@shopkeeperSignUp');

        /**
         * Related to Support
         */
        Route::get('/support', 'Auth\AuthController@supportPage');

        /*
        * Related to privacy policy
        */
        Route::get('/privacy/policy', 'Auth\AuthController@privacyPolicy');
    }); //End of guest middleware


    /**
     * Related to Admin or Shopkeeper lock and unlock screen page
     */
    Route::get('/lockScreen', 'Auth\AuthController@lockUserScreen');
    Route::post('/unlock', 'Auth\AuthController@unlockUserScreen');


    /**
     * This route group applies the "auth" middleware group to every route
     * it allow to access the routes only to logged users.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @since 5th MAY, 2016
     */
    Route::group(['middleware' => ['auth']], function () {

        /**
         * Related to Admin or Shopkeeper logout functionality
         */
        Route::get('/logout', 'Auth\AuthController@adminOrShopkeeperLogOut');


        /**
         * This route group applies the "admin" middleware group to every route
         * it allow to access the routes only to admin persons whose role will be 3.
         * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
         * @since 5th MAY, 2016
         */
        Route::group(['middleware' => ['admin']], function () {

            /**
             * Related to Admin Dashboard
             */
            Route::get('/adminDashboard', 'Admin\DashboardController@welcomeDashboard');

            /**
             * Related to Admin update password
             */
            Route::post('/updatePassword', 'Admin\UserController@updateAdminPassword');

            /**
             * Related to Admin update profile picture
             */
            Route::post('/updatePic', 'Admin\UserController@updateAdminPicture');

            /**
             * Related to Admin Edit Profile
             */
            Route::get('/editProfile', 'Admin\UserController@editAdminProfile');
            Route::post('/editProfile', 'Admin\UserController@editAdminProfile');

            /**
             * Related to view user List
             */
            Route::get('/viewUser', function () {
                return view('admin.userList');
            });
            Route::post('/viewUser', 'Admin\UserController@getUserList');
            Route::post('/viewUserAjax', 'Admin\UserController@getUserListAjax');

            /**
             * Related to add new shopkeeper
             */
            Route::get('/addShopkeeper', function () {
                return view('admin.addShopkeeper');
            });
            Route::post('/addShopkeeper', 'Admin\ShopkeeperController@CreateNewShopkeeper');

            /**
             * Related to view shopkeeper List
             */
            Route::get('/viewShopkeeper', function () {
                return view('admin.shopkeeperList');
            });
            Route::post('/viewShopkeeper', 'Admin\ShopkeeperController@getShopkeeperList');
            Route::post('/viewShopkeeperAjax', 'Admin\ShopkeeperController@getShopkeeperListAjax');

            /**
             * Related to add new shop
             */
            Route::get('/addShop', 'Admin\ShopController@CreateNewShop');
            Route::post('/addShop', 'Admin\ShopController@CreateNewShop');
            Route::post('/addShopAjax', 'Admin\ShopController@CreateNewShopAjax');

            /**
             * Related to view shop List
             */
            Route::get('/viewShop', function () {
                return view('admin.shopList');
            });
            Route::post('/viewShop', 'Admin\ShopController@getShopListDetails');
            Route::post('/viewShopAjax', 'Admin\ShopController@getShopListDetailsAjax');

            /**
             * Related to view/update particular shop detail
             */
            Route::get('/viewShopDetail/{shopId}', 'Admin\ShopController@getOrUpdateParticularShopDetails');
            Route::post('/viewShopDetail/{shopId}', 'Admin\ShopController@getOrUpdateParticularShopDetails');

            /**
             * Related to view/add/update Location [country, state and city] List
             */
            Route::get('/viewCountry', function () {
                return view('admin.countryList');
            });
            Route::post('/viewCountry', 'Admin\LocationController@getCountryList');
            Route::post('/viewCountryAjax', 'Admin\LocationController@getCountryListAjax');

            Route::get('/viewState', 'Admin\LocationController@getStateList');
            Route::post('/viewState', 'Admin\LocationController@getStateList');
            Route::post('/viewStateAjax', 'Admin\LocationController@getStateListAjax');

            Route::get('/viewCity', 'Admin\LocationController@getCityList');
            Route::post('/viewCity', 'Admin\LocationController@getCityList');
            Route::post('/viewCityAjax', 'Admin\LocationController@getCityListAjax');

            /**
             * Related to view/add/update Main and Sub Product List
             */
            Route::get('/addMainProduct', function () {
                return view('admin.mainProductList');
            });
            Route::post('/addMainProduct', 'Admin\ProductController@getMainProductList');
            Route::post('/addMainProductAjax', 'Admin\ProductController@getMainProductListAjax');

            Route::get('/addSubProduct', 'Admin\ProductController@getSubProductList');
            Route::post('/addSubProduct', 'Admin\ProductController@getSubProductList');
            Route::post('/addSubProductAjax', 'Admin\ProductController@getSubProductListAjax');

            /**
             * Related to add new Product
             */

            Route::get('/addProduct', 'Admin\ProductController@CreateNewProduct');
            Route::post('/addProduct', 'Admin\ProductController@CreateNewProduct');
            Route::post('/addProductAjax', 'Admin\ProductController@CreateNewProductAjax');

            /**
             * Related to view Product List
             */
            Route::get('/viewProduct', 'Admin\ProductController@getProductListDetails');
            Route::post('/viewProduct', 'Admin\ProductController@getProductListDetails');
            Route::post('/viewProductAjax', 'Admin\ProductController@getProductListDetailsAjax');

            /**
             * Related to view/update particular Product detail
             */
            Route::get('/viewProductDetail/{productId}', 'Admin\ProductController@getOrUpdateParticularProductDetails');
            Route::post('/viewProductDetail/{productId}', 'Admin\ProductController@getOrUpdateParticularProductDetails');

            /**
             * Related to assign the product in shop with stock quantity
             */
            Route::get('/assignProduct', 'Admin\ProductController@assignProductToShop');
            Route::post('/assignProduct', 'Admin\ProductController@assignProductToShop');
            Route::post('/assignProductAjax', 'Admin\ProductController@assignProductToShopAjax');


            /**
             * Related to view user transaction List
             */
            Route::get('/viewTransaction', function () {
                return view('admin.userTransactionList');
            });
            Route::post('/viewTransaction', 'Admin\TransactionController@getTransactionList');
            Route::post('/viewTransactionAjax', 'Admin\TransactionController@getTransactionListAjax');

            /**
             * Related to view user order List
             */
            Route::get('/viewOrder', 'Admin\OrderController@getOrderList');
            Route::post('/viewOrder', 'Admin\OrderController@getOrderList');
            Route::post('/viewOrderAjax', 'Admin\OrderController@getOrderListAjax');

            //======== Added by shankar on 21/01/2019 =================

            Route::get('/generate-pdf/print', 'Admin\OrderController@ConvertIntoPDF');

            /**
             * Related to Admin New Notification
             */
            Route::get('/newNotification', function () {
                return view('admin.newNotificationList');
            });
            Route::post('/notificationAjax', 'Admin\NotificationController@getNotificationAjax');

        }); //End of admin middleware


        /**
         * This route group applies the "shopkeeper" middleware group to every route
         * it allow to access the routes only to shopkeeper persons whose role will be 2.
         * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
         * @since 5th MAY, 2016
         */
        Route::group(['middleware' => ['shopkeeper']], function () {

            /**
             * Related to Shopkeeper Dashboard
             */
            Route::get('/shopkeeperDashboard', 'Shopkeeper\DashboardController@welcomeDashboard');

            /**
             * Related to Shopkeeper update password
             */
            Route::post('/updateShopkeeperPassword', 'Shopkeeper\UserController@updateShopkeeperPassword');

            /**
             * Related to Shopkeeper update profile picture
             */
            Route::post('/updateShopkeeperPic', 'Shopkeeper\UserController@updateShopkeeperPicture');

            /**
             * Related to Shopkeeper Edit Profile
             */
            Route::get('/editShopkeeperProfile', 'Shopkeeper\UserController@editShopkeeperProfile');
            Route::post('/editShopkeeperProfile', 'Shopkeeper\UserController@editShopkeeperProfile');

            /**
             * Related to view user List
             */
            Route::get('/viewUserList', function () {
                return view('shopkeeper.userList');
            });
            Route::post('/viewUserList', 'Shopkeeper\UserController@getUserList');
            Route::post('/viewUserListAjax', 'Shopkeeper\UserController@getUserListAjax');

            /**
             * Related to view shopkeeper List
             */
            Route::get('/viewShopkeeperList', function () {
                return view('shopkeeper.shopkeeperList');
            });
            Route::post('/viewShopkeeperList', 'Shopkeeper\ShopkeeperController@getShopkeeperList');
            Route::post('/viewShopkeeperListAjax', 'Shopkeeper\ShopkeeperController@getShopkeeperListAjax');

            /**
             * Related to view shop List
             */
            Route::get('/viewShopList', function () {
                return view('shopkeeper.shopList');
            });
            Route::post('/viewShopList', 'Shopkeeper\ShopController@getShopListDetails');

            /**
             * Related to view particular shop detail
             */
            Route::get('/viewOnlyShopDetail/{shopId}', 'Shopkeeper\ShopController@getOrUpdateParticularShopDetails');

            /**
             * Related to view Location [country, state and city] List
             */
            Route::get('/viewCountryList', function () {
                return view('shopkeeper.countryList');
            });
            Route::post('/viewCountryList', 'Shopkeeper\LocationController@getCountryList');

            Route::get('/viewStateList', 'Shopkeeper\LocationController@getStateList');
            Route::post('/viewStateList', 'Shopkeeper\LocationController@getStateList');

            Route::get('/viewCityList', 'Shopkeeper\LocationController@getCityList');
            Route::post('/viewCityList', 'Shopkeeper\LocationController@getCityList');
            Route::post('/viewCityListAjax', 'Shopkeeper\LocationController@getCityListAjax');

            /**
             * Related to view Main and Sub Product List
             */
            Route::get('/viewMainProduct', function () {
                return view('shopkeeper.mainProductList');
            });
            Route::post('/viewMainProduct', 'Shopkeeper\ProductController@getMainProductList');

            Route::get('/viewSubProduct', 'Shopkeeper\ProductController@getSubProductList');
            Route::post('/viewSubProduct', 'Shopkeeper\ProductController@getSubProductList');

            /**
             * Related to add new Product
             */
            Route::get('/addNewProduct', 'Shopkeeper\ProductController@CreateNewProduct');
            Route::post('/addNewProduct', 'Shopkeeper\ProductController@CreateNewProduct');
            Route::post('/addNewProductAjax', 'Shopkeeper\ProductController@CreateNewProductAjax');

            /**
             * Related to view product list and assign the product in shop with stock quantity
             */
            Route::get('/viewProductList', 'Shopkeeper\ProductController@viewProductListShopWise');
            Route::post('/viewProductList', 'Shopkeeper\ProductController@viewProductListShopWise');
            Route::post('/viewProductListAjax', 'Shopkeeper\ProductController@viewProductListShopWiseAjax');

            /**
             * Related to view particular Product detail
             */
            Route::get('/viewProductDetails/{productId}', 'Shopkeeper\ProductController@getParticularProductDetails');

            /**
             * Related to view user transaction List for particular shop wise
             */
            Route::get('/viewTransactionList', function () {
                return view('shopkeeper.userTransactionList');
            });
            Route::post('/viewTransactionList', 'Shopkeeper\TransactionController@getTransactionList');

            /**
             * Related to view user order List particular shop wise
             */
            Route::get('/viewOrderList', 'Shopkeeper\OrderController@getOrderList');
            Route::post('/viewOrderList', 'Shopkeeper\OrderController@getOrderList');
            Route::post('/viewOrderListAjax', 'Shopkeeper\OrderController@getOrderListAjax');

        }); //End of shopkeeper middleware
    }); //End of auth middleware

}); //End of Route::group(['middleware' => ['web']], function () {});
