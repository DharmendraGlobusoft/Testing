<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Class MainProduct
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 25th MAY, 2016
 */
class MainProduct extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $table = 'main_product';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $primaryKey = 'main_product_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 25th MAY, 2016
     */
    protected $fillable = [
        'product_name', 'status',
    ];


    /**
     * It returns the list of main product with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchMainProductListByLimit($offset, $limit, $column, $direction, $searchValue)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('main_product')
                    ->skip($offset)->take($limit)
                    ->select('main_product_id', 'product_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('main_product')
                    ->skip($offset)->take($limit)
                    ->where('main_product_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('product_name', 'like', '%' . $searchValue . '%')
                    ->select('main_product_id', 'product_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of main product present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchNumberOfMainProduct($searchValue)
    {
        try {
            if ($searchValue != '') {
                $select = (array)DB::table('main_product')
                    ->where('main_product_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('product_name', 'like', '%' . $searchValue . '%')
                    ->select('main_product_id')
                    ->count();
                return $select;
            } else {
                $select = (array)DB::table('main_product')
                    ->select('main_product_id')
                    ->count();
                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It activates or deactivates to a main product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $mainProductId
     * @param $status
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function activateOrDeactivateMainProduct($mainProductId, $status)
    {
        try {
            $result = DB::table('main_product')
                ->where('main_product_id', '=', $mainProductId)
                ->update(['status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns main product id and name of a called main product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $mainProductId
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function fetchMainProductNameAndId($mainProductId)
    {
        try {
            $result = DB::table('main_product')
                ->where('main_product_id', '=', $mainProductId)
                ->select('main_product_id', 'product_name')
                ->first();
            $result = (array)$result;
            return $result;
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It creates a new main product in database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $mainProductName
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function createMainProduct($mainProductName)
    {
        try {
            MainProduct::create([
                'product_name' => $mainProductName,
                'status' => 2,
            ]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the existing main product details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $mainProductId
     * @param $mainProductName
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function updateMainProduct($mainProductId, $mainProductName)
    {
        try {
            MainProduct::where('main_product_id', '=', $mainProductId)
                ->update(['product_name' => $mainProductName]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It delete a particular main product and their related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $mainProductId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function deleteMainProduct($mainProductId)
    {
        try {
            DB::beginTransaction();

            $subProductIds = (array)DB::table('sub_product')
                ->where('main_product_id', '=', $mainProductId)
                ->select('sub_product_id')
                ->get();
            if (!empty($subProductIds)) {

                foreach ($subProductIds as $key => $value) {
                    $subProductIds[$key] = $value->sub_product_id;
                }
                $productIds = (array)DB::table('product')
                    ->whereIn('sub_product_id', $subProductIds)
                    ->select('product_id')
                    ->get();

                if (!empty($productIds)) {
                    foreach ($productIds as $key => $value) {
                        $productIds[$key] = $value->product_id;
                    }

                    DB::table('discount')->whereIn('product_id', $productIds)
                        ->delete();
                    DB::table('review')->whereIn('product_id', $productIds)
                        ->delete();
                    DB::table('cart')->whereIn('product_id', $productIds)
                        ->delete();
                    DB::table('product_list')->whereIn('product_id', $productIds)
                        ->delete();
                    DB::table('product')->whereIn('product_id', $productIds)
                        ->delete();
                    DB::table('sub_product')->where('main_product_id', '=', $mainProductId)
                        ->delete();
                    $finalDeletion = DB::table('main_product')->where('main_product_id', '=', $mainProductId)
                        ->delete();
                } else {
                    DB::table('sub_product')->where('main_product_id', '=', $mainProductId)
                        ->delete();
                    $finalDeletion = DB::table('main_product')->where('main_product_id', '=', $mainProductId)
                        ->delete();
                }
            } else {
                $finalDeletion = DB::table('main_product')->where('main_product_id', '=', $mainProductId)
                    ->delete();
            }

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


} //End of class