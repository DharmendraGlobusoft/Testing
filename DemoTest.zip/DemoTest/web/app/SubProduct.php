<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Class SubProduct
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 25th MAY, 2016
 */
class SubProduct extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $table = 'sub_product';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $primaryKey = 'sub_product_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 25th MAY, 2016
     */
    protected $fillable = [
        'product_name', 'status', 'main_product_id',
    ];


    /**
     * It returns the list of sub product with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $mainProductId
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchSubProductListByLimit($offset, $limit, $column, $direction, $searchValue, $mainProductId)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('sub_product')
                    ->where('main_product_id', '=', $mainProductId)
                    ->skip($offset)->take($limit)
                    ->select('sub_product_id', 'product_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('sub_product')
                    ->skip($offset)->take($limit)
                    ->where('main_product_id', '=', $mainProductId)
                    ->where(function ($query) use ($searchValue) {
                        $query->orWhere('sub_product_id', 'like', '%' . $searchValue . '%')
                            ->orWhere('product_name', 'like', '%' . $searchValue . '%');
                    })
                    ->select('sub_product_id', 'product_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of sub product present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $mainProductId
     * @return int
     * @since 3rd JUNE, 2016
     */
    public function fetchNumberOfSubProduct($searchValue, $mainProductId)
    {
        try {
            if ($searchValue != '') {
                $select = DB::table('sub_product')
                    ->where('main_product_id', '=', $mainProductId)
                    ->where(function ($query) use ($searchValue) {
                        $query->orWhere('sub_product_id', 'like', '%' . $searchValue . '%')
                            ->orWhere('product_name', 'like', '%' . $searchValue . '%');
                    })
                    ->select('sub_product_id')
                    ->count();
                return $select;
            } else {
                $select = DB::table('sub_product')
                    ->where('main_product_id', '=', $mainProductId)
                    ->select('sub_product_id')
                    ->count();
                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It activates or deactivates to a sub product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $subProductId
     * @param $status
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function activateOrDeactivateSubProduct($subProductId, $status)
    {
        try {
            $result = DB::table('sub_product')
                ->where('sub_product_id', '=', $subProductId)
                ->update(['status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns sub product id and name of a called sub product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $subProductId
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function fetchSubProductNameAndId($subProductId)
    {
        try {
            $result = (array)DB::table('sub_product')
                ->where('sub_product_id', '=', $subProductId)
                ->select('sub_product_id', 'product_name')
                ->first();

            return $result;
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It creates a new sub product in database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $subProductName
     * @param $mainProductId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function createSubProduct($subProductName, $mainProductId)
    {
        try {
            SubProduct::create([
                'product_name' => $subProductName,
                'status' => 2,
                'main_product_id' => $mainProductId,
            ]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the existing sub product details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $subProductId
     * @param $subProductName
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function updateSubProduct($subProductId, $subProductName)
    {
        try {
            SubProduct::where('sub_product_id', '=', $subProductId)
                ->update(['product_name' => $subProductName]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It delete a particular sub product and their related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $subProductId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function deleteSubProduct($subProductId)
    {
        try {
            DB::beginTransaction();

            $productIds = (array)DB::table('product')
                ->where('sub_product_id', '=', $subProductId)
                ->select('product_id')
                ->get();

            if (!empty($productIds)) {
                foreach ($productIds as $key => $value) {
                    $productIds[$key] = $value->product_id;
                }
                DB::table('discount')->whereIn('product_id', $productIds)
                    ->delete();
                DB::table('review')->whereIn('product_id', $productIds)
                    ->delete();
                DB::table('cart')->whereIn('product_id', $productIds)
                    ->delete();
                DB::table('product_list')->whereIn('product_id', $productIds)
                    ->delete();
                DB::table('product')->whereIn('product_id', $productIds)
                    ->delete();
                $finalDeletion = DB::table('sub_product')->where('sub_product_id', '=', $subProductId)
                    ->delete();
            } else
                $finalDeletion = DB::table('sub_product')->where('sub_product_id', '=', $subProductId)
                    ->delete();

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return a list of main product for showing it at the time of create sub product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function getMainProductList()
    {
        try {
            return (array)DB::table('main_product')
                ->where('status', '=', 1)
                ->select('main_product_id', 'product_name')
                ->orderBy('product_name', 'asc')
                ->get();
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


} //End of class
