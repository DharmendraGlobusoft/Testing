<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Class State
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 21th MAY, 2016
 */
class State extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 21th MAY, 2016
     */
    protected $table = 'state';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 21th MAY, 2016
     */
    protected $primaryKey = 'state_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 21th MAY, 2016
     */
    protected $fillable = [
        'state_name', 'status', 'country_id',
    ];


    /**
     * It return the list of state with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $countryId
     * @return array|int
     * @since 25th MAY, 2016
     */
    public function fetchStateListByLimit($offset, $limit, $column, $direction, $searchValue, $countryId)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('state')
                    ->where('country_id','=',$countryId)
                    ->skip($offset)->take($limit)
                    ->select('state_id', 'state_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('state')
                    ->skip($offset)->take($limit)
                    ->where('country_id','=',$countryId)
                    ->where(function ($query) use($searchValue) {
                        $query->orWhere('state_id', 'like', '%' . $searchValue . '%')
                            ->orWhere('state_name', 'like', '%' . $searchValue . '%');
                    })
                    ->select('state_id', 'state_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It count the number of state present in DB according the condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $countryId
     * @return int
     * @since 25th MAY, 2016
     */
    public function fetchNumberOfState($searchValue, $countryId)
    {
        try {
            if ($searchValue != '') {
                $select = DB::table('state')
                    ->where('country_id','=',$countryId)
                    ->where(function ($query) use($searchValue) {
                        $query->orWhere('state_id', 'like', '%' . $searchValue . '%')
                            ->orWhere('state_name', 'like', '%' . $searchValue . '%');
                    })
                    ->select('state_id')
                    ->count();
                return $select;
            } else {
                $select =DB::table('state')
                    ->where('country_id','=',$countryId)
                    ->select('state_id')
                    ->count();
                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It activate or deactivate the state status.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $stateId
     * @param $status
     * @return string
     * @since 25th MAY, 2016
     */
    public function activateOrDeactivateState($stateId, $status)
    {
        try {
            $result = DB::table('state')
                ->where('state_id', '=', $stateId)
                ->update(['status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return the only name and id of called state.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $stateId
     * @return array|string
     * @since 25th MAY, 2016
     */
    public function fetchStateNameAndId($stateId)
    {
        try {
            $result =(array) DB::table('state')
                ->where('state_id', '=', $stateId)
                ->select('state_id', 'state_name')
                ->first();

            return $result;
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It create the new state in DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $stateName
     * @param $countryId
     * @return string
     * @since 25th MAY, 2016
     */
    public function createState($stateName, $countryId)
    {
        try {
            State::create([
                'state_name' => $stateName,
                'status' => 2,
                'country_id' => $countryId,
            ]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the detail of exist state.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $stateId
     * @param $stateName
     * @return string
     * @since 25th MAY, 2016
     */
    public function updateState($stateId, $stateName)
    {
        try {
            State::where('state_id', '=', $stateId)
                ->update(['state_name' => $stateName]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return the list of Country, State and City according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $location
     * @param $locationId
     * @return array|string
     * @since 25th MAY, 2016
     */
    public function getLocation($location, $locationId)
    {
        try {
            if ($location == 'country') {
                return (array)DB::table('country')
                    ->where('status', '=', 1)
                    ->select('country_id', 'country_name')
                    ->orderBy('country_name', 'asc')
                    ->get();
            } else
                if ($location == 'state') {
                    return (array)DB::table('state')
                        ->where('country_id', '=', $locationId)
                        ->where('status', '=', 1)
                        ->select('state_id', 'state_name')
                        ->orderBy('state_name', 'asc')
                        ->get();
                } else
                    if ($location == 'city') {
                        return (array)DB::table('city')
                            ->where('state_id', '=', $locationId)
                            ->where('status', '=', 1)
                            ->select('city_id', 'city_name')
                            ->orderBy('city_name', 'asc')
                            ->get();
                    }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


} //End of class
