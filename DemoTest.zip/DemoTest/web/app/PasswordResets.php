<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Class PasswordResets
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 8th MARCH, 2016
 */
class PasswordResets extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 8th MARCH, 2016
     */
    protected $table = 'password_resets';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 8th MARCH, 2016
     */
    protected $fillable = [
        'email', 'token',
    ];


    /**
     * This function validate the password link and update the new password in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $userData
     * @return string
     * @since 8th MARCH, 2016
     */
    public function resetUserPassword($userData)
    {
        $checkUserEmail = DB::table('users')
            ->select('id')
            ->where('email', $userData['email'])
            ->first();

        if ($checkUserEmail) {
            $checkUserToken = DB::table('password_resets')
                ->select()
                ->where('email', $userData['email'])
                ->first();
            if ($checkUserToken) {

                if (Hash::check($userData['token'], $checkUserToken->token)) {

                    DB::beginTransaction();

                    $updatePassword1 = DB::table('users')
                         ->where('email', $userData['email'])
                        ->update(['password' => 'password null']);

                    $updatePassword2 = DB::table('users')
                        ->where('email', $userData['email'])
                        ->update(['password' => Hash::make($userData['password'])]);

                    $deleteToken = DB::table('password_resets')
                        ->where('email', $userData['email'])
                        ->delete();

                    if ($updatePassword1 == 1 && $updatePassword2 == 1 && $deleteToken == 1) {
                        DB::commit();
                        return 'success';
                    } else {
                        DB::rollBack();
                        return 'Transaction has been failed, due to one of the above query has not been executed.';
                    }
                } else
                    return 'This reset link is invalid.';
            } else
                return 'This reset link has been expired.';
        } else
            return 'Please check your Email, It has not registered.';
    }

} //End of class
