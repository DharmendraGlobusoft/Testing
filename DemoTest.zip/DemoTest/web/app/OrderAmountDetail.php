<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderAmountDetail
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd JUNE, 2016
 */
class OrderAmountDetail extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $table = 'order_amount_detail';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $primaryKey = 'order_amount_detail_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd JUNE, 2016
     */
    protected $fillable = [
        'total_cost', 'total_service_tax', 'total_discount_amount', 'total_pay_cost', 'order_detail_id',
    ];



}//End of class