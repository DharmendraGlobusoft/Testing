<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

/**
 * Class Product
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 25th MAY, 2016
 */
class Product extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $table = 'product';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 25th MAY, 2016
     */
    protected $primaryKey = 'product_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 25th MAY, 2016
     */
    protected $fillable = [
        'product_name', 'product_detail','product_features','product_type', 'product_weight', 'status', 'cost', 'service_tax', 'stock_quantity','stockdetails', 'image', 'sub_product_id',
    ];

    /**
     * It creates a new product in database and keep it as inactive by default
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productDetail
     * @param $productImage
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function createProduct($productDetail, $productImage, $otherImages,$sizeQuantity)
    {
        try {
            DB::beginTransaction();
            $imagePath = $productImage['product_picture_fetchedPath'] . '/' . $productImage['product_picture_name'];
            $createdProductId = Product::create([
                'product_name' => $productDetail['product_name'],
                'product_detail' => $productDetail['product_description'],
                'product_features' => $productDetail['product_features'],   //added by dharmendra
                'product_type' => $productDetail['productType'],   //added by dharmendra
                'product_weight' => $productDetail['product_weight'],
                'status' => 2,
                'cost' => $productDetail['product_cost'],
                'service_tax' => $productDetail['product_service_tax'],
                'stockdetails' => $sizeQuantity,   //added by dharmendra
                'image' => $imagePath,
                'sub_product_id' => $productDetail['sub_product'],
            ])->product_id;

            if ($createdProductId) {
                $i = 1;
                if (!empty($otherImages[0])) {
                    $otherImagesData = [];
                    foreach ($otherImages as $key => $value) {
                        $imageName = explode('.', $productImage['product_picture_name']);
                        $imageName = $imageName[0] . '_' . $i . '.' . $imageName[1];
                        $imagePath = $productImage['product_picture_fetchedPath'] . '/' . $imageName;
                        $otherImagesData[$i]['product_id'] = $createdProductId;
                        $otherImagesData[$i]['image_url'] = $imagePath;
                        $value->move($productImage['product_picture_movedPath'], $imageName);
                        $i++;
                    }
                    DB::table('product_other_image')->insert($otherImagesData);
                }

                $productDetail['product_image']->move($productImage['product_picture_movedPath'], $productImage['product_picture_name']);
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns the list of product with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchProductListByLimit($offset, $limit, $column, $direction, $searchValue, $shopId)
    {
        try {
            if ($shopId == null) {
                if ($searchValue == '') {
                    $select = (array)DB::table('product')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->select('product.product_id', 'product.product_name', 'product.status', 'product.stock_quantity',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('product')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product.product_id', 'product.product_name', 'product.status', 'product.stock_quantity',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();
                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            } else {
                if ($searchValue == '') {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('product_list.shop_id', '=', $shopId)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->select('product_list.stock_quantity', 'product_list.created_at', 'product.product_id', 'product.product_name', 'product.status',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();
                    return $select;
                } else {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('product_list.shop_id', '=', $shopId)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product_list.stock_quantity', 'product_list.created_at', 'product.product_id', 'product.product_name', 'product.status',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();

                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of product present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 3rd JUNE, 2016
     */
    public function fetchNumberOfProduct($searchValue, $shopId)
    {
        try {
            if ($shopId == null) {
                if ($searchValue != '') {
                    $select = (array)DB::table('product')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product.product_id')
                        ->count();
                    return $select;
                } else {
                    $select = (array)DB::table('product')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->select('product.product_id')
                        ->count();
                    return $select;
                }
            } else {
                if ($searchValue != '') {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('product_list.shop_id', '=', $shopId)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product.product_id')
                        ->count();
                    return $select;
                } else {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('product_list.shop_id', '=', $shopId)
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->select('product.product_id')
                        ->count();
                    return $select;
                }
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It returns main and sub product list according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $product
     * @param $productId
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function getProductList($product, $productId)
    {
        try {
            if ($product == 'mainProduct') {
                return (array)DB::table('main_product')
                    ->where('status', '=', 1)
                    ->select('main_product_id', 'product_name')
                    ->orderBy('product_name', 'asc')
                    ->get();
            } else
                if ($product == 'subProduct') {
                    return (array)DB::table('sub_product')
                        ->where('main_product_id', '=', $productId)
                        ->where('status', '=', 1)
                        ->select('sub_product_id', 'product_name')
                        ->orderBy('product_name', 'asc')
                        ->get();
                }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It activates or deactivates to a product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @param $status
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function activateOrDeactivateProduct($productId, $status)
    {
        try {
            $result = DB::table('product')
                ->where('product_id', '=', $productId)
                ->update(['status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns product id and name of a called product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function fetchOneProductDetail($productId)
    {
        try {
            $result = Product::where('product_id', '=', $productId)
                ->select('product_id', 'product_name')
                ->first();
            if ($result)
                return $result->toArray();
            else
                return 'fail';
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 'fail';
        }
    }

    /**
     * It delete a particular product and their related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function deleteProduct($productId)
    {
        try {
            DB::beginTransaction();

            DB::table('discount')->where('product_id', '=', $productId)
                ->delete();
            DB::table('review')->where('product_id', '=', $productId)
                ->delete();
            DB::table('cart')->where('product_id', '=', $productId)
                ->delete();
            DB::table('product_list')->where('product_id', '=', $productId)
                ->delete();
            $finalDeletion = DB::table('product')->where('product_id', '=', $productId)
                ->delete();

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns all detail of a particular called product.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productId
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function fetchAllDetailOfOneProduct($productId)
    {
        try {
            $productDetail = Product::join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                ->where('product.product_id', '=', $productId)
                ->select('product.product_id', 'product.product_name', 'product.product_detail', 'product.product_features', 'product.stockdetails',
                    'product.product_weight', DB::raw('TRUNCATE(product.cost,2) as cost, TRUNCATE(product.service_tax,2) as service_tax'),
                    'product.image', 'sub_product.sub_product_id', 'sub_product.product_name as sub_product_name',
                    'main_product.main_product_id', 'main_product.product_name as main_product_name')
                ->first();
            if (!empty($productDetail = $productDetail->toArray()))
                return $productDetail;
            else
                return 'fail';

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 'fail';
        }
    }

    /**
     * It returns the list of other images details
     * @author Nitin Kumar Gupta <nitingupta@globussoft.in>
     * @param $productId
     * @return array
     * @since 21st February, 2017
     */
    public function fetchOtherImageOfOneProduct($productId)
    {
        try {
            $productDetail = DB::table('product_other_image')
                ->where('product_id', '=', $productId)
                ->select('image_url')
                ->get();
            if (!empty($productDetail))
                return $productDetail;
            else
                return array();

        } catch (QueryException $exception) {
            return array();
        }
    }

    /**
     * It modifies the other image of a product in DB and and image folder
     * @author Nitin Kumar Gupta <nitingupta@globussoft.in>
     * @param $otherImages
     * @param $productDetail
     * @param null $productImage
     * @since 21st February, 2017
     */
    public function updateOtherImage($otherImages, $productDetail, $productImage = NULL)
    {
        $oldImageUrl = DB::table('product_other_image')->where('product_id', '=', $productDetail['productId'])->get();
        $deleteImageUrl = DB::table('product_other_image')->where('product_id', '=', $productDetail['productId'])->delete();
        if ($deleteImageUrl)
            foreach ($oldImageUrl as $value) {
                $imageName = explode('/', $value->image_url);
                unlink(public_path() . '/assets/productImage/productImage/'.end($imageName));
            }

        $i = 0;
        $otherImagesData = array();
        if ($productImage != NULL && !empty($otherImages[0])) {
            foreach ($otherImages as $key => $value) {
                $imageName = explode('.', $productImage['product_picture_name']);
                $imageName = $imageName[0].rand(1000000,9999999). '_' . $i . '.' . $imageName[1];
                $imageSavedPath = Config::get('app.WEB_HOST') . 'assets/productImage/productImage/' . $imageName;
                $otherImagesData[$i]['product_id'] = $productDetail['productId'];
                $otherImagesData[$i]['image_url'] = $imageSavedPath;
                $value->move($productImage['product_picture_movedPath'], $imageName);
                $i++;
            }
            DB::table('product_other_image')->insert($otherImagesData);
        } else
            if ($productImage == NULL && !empty($otherImages[0])) {
                foreach ($otherImages as $key => $value) {
                    $imageName = explode('/', $productDetail['product_image_path']);
                    $imageName = explode('.', end($imageName));
                    $imageName = $imageName[0] .rand(1000000,9999999). '_' . $i . '.' . $imageName[1];
                    $imageSavedPath = Config::get('app.WEB_HOST') . 'assets/productImage/productImage/' . $imageName;
                    $otherImagesData[$i]['product_id'] = $productDetail['productId'];
                    $otherImagesData[$i]['image_url'] = $imageSavedPath;
                    $value->move(public_path() . '/assets/productImage/productImage', $imageName);
                    $i++;
                }
                DB::table('product_other_image')->insert($otherImagesData);
            }
    }

    /**
     * It update the existing product details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productDetail
     * @param $productImage
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function updateProduct($productDetail, $productImage, $otherImages = NULL)
    {

//            echo '<pre>';
//            print_r($productDetail);
//            die('ok');
        try {
            if ($productImage) {
                $updateProduct = Product::where('product_id', '=', $productDetail['productId'])
                    ->update([
                        'product_name' => $productDetail['product_name'],
                        'product_detail' => $productDetail['product_description'],
                        'product_features' => $productDetail['product_features'],
                        'stockdetails' => $productDetail['stockdetails'],
                        'product_weight' => $productDetail['product_weight'],
                        'cost' => $productDetail['product_cost'],
                        'service_tax' => $productDetail['product_service_tax'],
                        'image' => $productImage['product_picture_savedPath'],
                    ]);

                unlink($productDetail['product_image_path']);
                $productDetail['product_image']->move($productImage['product_picture_movedPath'], $productImage['product_picture_name']);

                if ($otherImages != NULL)
                    $this->updateOtherImage($otherImages, $productDetail, $productImage);
            } else {
                $updateProduct = Product::where('product_id', '=', $productDetail['productId'])
                    ->update([
                        'product_name' => $productDetail['product_name'],
                        'product_detail' => $productDetail['product_description'],
                        'product_features' => $productDetail['product_features'],
                        'stockdetails' => $productDetail['stockdetails'],
                        'product_weight' => $productDetail['product_weight'],
                        'cost' => $productDetail['product_cost'],
                        'service_tax' => $productDetail['product_service_tax'],
                    ]);
                if ($otherImages != NULL)
                    $this->updateOtherImage($otherImages, $productDetail);
            }

            if ($updateProduct)
                return 'success';
            else
                return 'fail';

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns all shop list with their id and name.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function getAllShopList()
    {
        try {
            return (array)DB::table('shop')
                ->where('status', '=', 1)
                ->select('shop_id', 'shop_name')
                ->orderBy('shop_name', 'asc')
                ->get();

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns a list those product which is not assigned to a shop till now.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @return array|string
     * @since 3rd JUNE, 2016
     */
    public function getUnassignedProductList($shopId)
    {
        try {
            $assignedProductList = (array)DB::table('product_list')
                ->where('shop_id', '=', $shopId)
                ->select('product_id')
                ->get();

            if (!empty($assignedProductList)) {

                foreach ($assignedProductList as $key => $value) {
                    $assignedProductList[$key] = $value->product_id;
                }

                return (array)DB::table('product')
                    ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                    ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                    ->where('sub_product.status', '=', 1)
                    ->where('main_product.status', '=', 1)
                    ->where('product.status', '=', 1)
                    ->whereNotIn('product.product_id', $assignedProductList)
                    ->select('product.product_id', 'product.product_name')
                    ->orderBy('product.product_name', 'asc')
                    ->get();
            } else {
                return (array)DB::table('product')
                    ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                    ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                    ->where('sub_product.status', '=', 1)
                    ->where('main_product.status', '=', 1)
                    ->where('product.status', '=', 1)
                    ->select('product.product_id', 'product.product_name')
                    ->orderBy('product.product_name', 'asc')
                    ->get();
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It assigns product to a shop and maintain the stock quantity
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productAssignData
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function assignProductToShop($productAssignData)
    {
        try {
            DB::beginTransaction();

            $productDetails = (array)DB::table('product')
                ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                ->where('product.product_id', '=', $productAssignData['product'])
                ->select('product.product_id', 'product.stock_quantity',
                    'sub_product.sub_product_id', 'main_product.main_product_id')
                ->first();

            $productDetails['stock_quantity'] = $productDetails['stock_quantity'] + $productAssignData['quantity'];

            $productListCreated = ProductList::create([
                'product_id' => $productDetails['product_id'],
                'sub_product_id' => $productDetails['sub_product_id'],
                'main_product_id' => $productDetails['main_product_id'],
                'shop_id' => $productAssignData['shop'],
                'stock_quantity' => $productAssignData['quantity']
            ]);

            $productUpdated = Product::where('product_id', '=', $productDetails['product_id'])
                ->update(['stock_quantity' => $productDetails['stock_quantity']]);

            if ($productDetails && $productListCreated && $productUpdated) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the product quantity in database
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productUpdateData
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function updateStockQuantity($productUpdateData)
    {
        try {
            DB::beginTransaction();

            $productListUpdated = ProductList::where('shop_id', '=', $productUpdateData['shopId'])
                ->where('product_id', '=', $productUpdateData['productId'])
                ->update(['stock_quantity' => $productUpdateData['stock_quantity']]);

            $stockQuantityDecrement = Product::where('product_id', '=', $productUpdateData['productId'])
                ->decrement('stock_quantity', $productUpdateData['oldStockQuantity']);

            $stockQuantityIncrement = Product::where('product_id', '=', $productUpdateData['productId'])
                ->increment('stock_quantity', $productUpdateData['stock_quantity']);

            if ($productUpdateData['stock_quantity'] == 0)
                $stockQuantityIncrement = 1;

            if ($productListUpdated && $stockQuantityDecrement && $stockQuantityIncrement) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It remove a product from the shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @param $productId
     * @param $stockQuantity
     * @return string
     * @since 3rd JUNE, 2016
     */
    public function removeProductFromShop($shopId, $productId, $stockQuantity)
    {
        try {
            DB::beginTransaction();

            $productRemoved = ProductList::where('shop_id', '=', $shopId)
                ->where('product_id', '=', $productId)
                ->delete();

            $productStockQuantityUpdate = Product::where('product_id', '=', $productId)
                ->decrement('stock_quantity', $stockQuantity);

            if ($productRemoved && $productStockQuantityUpdate) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


//================================================Shopkeeper====================================
    /**
     * It creates a new product in database and keep it as active by default.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productDetail
     * @param $productImage
     * @return string
     * @since 14th JUNE, 2016
     */
    public function createNewProduct($productDetail, $productImage, $otherImages)
    {
        try {
            DB::beginTransaction();
            $imagePath = $productImage['product_picture_fetchedPath'] . '/' . $productImage['product_picture_name'];
            $createdProductId = Product::create([
                'product_name' => $productDetail['product_name'],
                'product_detail' => $productDetail['product_description'],
                'product_weight' => $productDetail['product_weight'],
                'status' => 1,
                'cost' => $productDetail['product_cost'],
                'service_tax' => $productDetail['product_service_tax'],
                'image' => $imagePath,
                'sub_product_id' => $productDetail['sub_product'],
            ])->product_id;

            if ($createdProductId) {
                $i = 1;
                if (!empty($otherImages[0])) {
                    $otherImagesData = [];
                    foreach ($otherImages as $key => $value) {
                        $imageName = explode('.', $productImage['product_picture_name']);
                        $imageName = $imageName[0] . '_' . $i . '.' . $imageName[1];
                        $imagePath = $productImage['product_picture_fetchedPath'] . '/' . $imageName;
                        $otherImagesData[$i]['product_id'] = $createdProductId;
                        $otherImagesData[$i]['image_url'] = $imagePath;
                        $value->move($productImage['product_picture_movedPath'], $imageName);
                        $i++;
                    }
                    DB::table('product_other_image')->insert($otherImagesData);
                }

                $productDetail['product_image']->move($productImage['product_picture_movedPath'], $productImage['product_picture_name']);
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


    /**
     * It returns the list of product [shop wise] with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 14th JUNE, 2016
     */
    public function fetchProductListByLimitAndShopId($offset, $limit, $column, $direction, $searchValue)
    {
        try {

            $shopId = (array)DB::table('shopkeeper_meta')
                ->where('id', '=', Auth::user()->id)
                ->select('shop_id')
                ->first();

            if (!empty($shopId)) {

                if ($searchValue == '') {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('product_list.shop_id', '=', $shopId['shop_id'])
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->select('product_list.shop_id', 'product_list.stock_quantity', 'product_list.created_at', 'product.product_id', 'product.product_name', 'product.status',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();

                    return $select;
                } else {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->skip($offset)->take($limit)
                        ->where('product_list.shop_id', '=', $shopId['shop_id'])
                        ->where('sub_product.status', '=', 1)
                        ->where('main_product.status', '=', 1)
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product_list.shop_id', 'product_list.stock_quantity', 'product_list.created_at', 'product.product_id', 'product.product_name', 'product.status',
                            'sub_product.product_name as sub_product_name', 'main_product.product_name as main_product_name')
                        ->orderBy($column, $direction)
                        ->get();

                    if (empty($select))
                        return 0;
                    else
                        return $select;
                }
            } else
                return 0;

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It counts the number of product[shop wise] present in DB according to condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @param $shopId
     * @return array|int
     * @since 14th JUNE, 2016
     */
    public function fetchNumberOfProductByShop($searchValue)
    {
        try {

            $shopId = (array)DB::table('shopkeeper_meta')
                ->where('id', '=', Auth::user()->id)
                ->select('shop_id')
                ->first();

            if (!empty($shopId)) {

                if ($searchValue != '') {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('product_list.shop_id', '=', $shopId['shop_id'])
                        ->where(function ($query) use ($searchValue) {
                            $query->orWhere('product.product_id', 'like', '%' . $searchValue . '%')
                                ->orWhere('product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('sub_product.product_name', 'like', '%' . $searchValue . '%')
                                ->orWhere('main_product.product_name', 'like', '%' . $searchValue . '%');
                        })
                        ->select('product.product_id')
                        ->count();
                    return $select;
                } else {
                    $select = (array)DB::table('product_list')
                        ->join('product', 'product_list.product_id', '=', 'product.product_id')
                        ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                        ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                        ->where('product_list.shop_id', '=', $shopId['shop_id'])
                        ->select('product.product_id')
                        ->count();
                    return $select;
                }
            } else
                return 0;

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It returns a list those product which is not assigned to a shop till now.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @return array|string
     * @since 14th JUNE, 2016
     */
    public function fetchUnassignedProductList()
    {
        try {

            $assignedProductIds = (array)DB::table('shopkeeper_meta')
                ->join('product_list', 'shopkeeper_meta.shop_id', '=', 'product_list.shop_id')
                ->where('shopkeeper_meta.id', '=', Auth::user()->id)
                ->select('product_list.product_id')
                ->get();

            if (!empty($assignedProductIds)) {

                foreach ($assignedProductIds as $key => $value) {
                    $assignedProductIds[$key] = $value->product_id;
                }
            }

            return (array)DB::table('product')
                ->where('status', '=', 1)
                ->whereNotIn('product_id', $assignedProductIds)
                ->select('product_id', 'product_name')
                ->orderBy('product_name', 'asc')
                ->get();

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It assigns product to a shop and maintain the stock quantity
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productAssignData
     * @return string
     * @since 14th JUNE, 2016
     */
    public function addProductToShop($productAssignData)
    {
        try {
            $shopId = (array)DB::table('shopkeeper_meta')
                ->where('id', '=', Auth::user()->id)
                ->select('shop_id')
                ->first();

            if (!empty($shopId)) {

                DB::beginTransaction();

                $productDetails = (array)DB::table('product')
                    ->join('sub_product', 'product.sub_product_id', '=', 'sub_product.sub_product_id')
                    ->join('main_product', 'sub_product.main_product_id', '=', 'main_product.main_product_id')
                    ->where('product.product_id', '=', $productAssignData['product'])
                    ->select('product.product_id', 'product.stock_quantity',
                        'sub_product.sub_product_id', 'main_product.main_product_id')
                    ->first();

                $productDetails['stock_quantity'] = $productDetails['stock_quantity'] + $productAssignData['quantity'];

                $productListCreated = ProductList::create([
                    'product_id' => $productDetails['product_id'],
                    'sub_product_id' => $productDetails['sub_product_id'],
                    'main_product_id' => $productDetails['main_product_id'],
                    'shop_id' => $shopId['shop_id'],
                    'stock_quantity' => $productAssignData['quantity']
                ]);

                $productUpdated = Product::where('product_id', '=', $productDetails['product_id'])
                    ->update(['stock_quantity' => $productDetails['stock_quantity']]);

                if ($productDetails && $productListCreated && $productUpdated) {
                    DB::commit();
                    return 'success';
                } else {
                    DB::rollBack();
                    return 'fail';
                }
            } else
                return 'fail';

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the product quantity in database
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $productUpdateData
     * @return string
     * @since 14th JUNE, 2016
     */
    public function updateProductStockQuantity($productUpdateData)
    {
        try {
            $shopId = (array)DB::table('shopkeeper_meta')
                ->where('id', '=', Auth::user()->id)
                ->select('shop_id')
                ->first();

            if (!empty($shopId)) {

                DB::beginTransaction();

                $productListUpdated = ProductList::where('shop_id', '=', $shopId['shop_id'])
                    ->where('product_id', '=', $productUpdateData['productId'])
                    ->update(['stock_quantity' => $productUpdateData['stock_quantity']]);

                $stockQuantityDecrement = Product::where('product_id', '=', $productUpdateData['productId'])
                    ->decrement('stock_quantity', $productUpdateData['oldStockQuantity']);

                $stockQuantityIncrement = Product::where('product_id', '=', $productUpdateData['productId'])
                    ->increment('stock_quantity', $productUpdateData['stock_quantity']);

                if ($productUpdateData['stock_quantity'] == 0)
                    $stockQuantityIncrement = 1;

                if ($productListUpdated && $stockQuantityDecrement && $stockQuantityIncrement) {
                    DB::commit();
                    return 'success';
                } else {
                    DB::rollBack();
                    return 'fail';
                }
            } else
                return 'fail';

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

} //End of class
