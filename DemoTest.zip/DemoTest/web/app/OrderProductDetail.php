<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class OrderProductDetail
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 3rd JUNE, 2016
 */
class OrderProductDetail extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $table = 'order_product_detail';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 3rd JUNE, 2016
     */
    protected $primaryKey = 'order_product_detail_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 3rd JUNE, 2016
     */
    protected $fillable = [
        'quantity', 'product_cost', 'discount_type', 'discount_amount', 'service_tax', 'restore_token', 'id','product_id','order_detail_id',
    ];


}//End of class
