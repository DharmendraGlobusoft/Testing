<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ProductList
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 26th MAY, 2016
 */
class ProductList extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 26th MAY, 2016
     */
    protected $table = 'product_list';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 26th MAY, 2016
     */
    protected $primaryKey = 'product_list_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 26th MAY, 2016
     */
    protected $fillable = [
        'product_id', 'sub_product_id', 'main_product_id', 'shop_id', 'stock_quantity',
    ];

} //End of class
