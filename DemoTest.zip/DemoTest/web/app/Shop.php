<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Class Shop
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 16th MAY, 2016
 */
class Shop extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 16th MAY, 2016
     */
    protected $table = 'shop';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 16th MAY, 2016
     */
    protected $primaryKey = 'shop_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 16th MAY, 2016
     */
    protected $fillable = [
        'shop_name', 'status', 'assign_to_shopkeeper', 'image', 'street_id',
    ];

    /**
     * It return the list of location[country, state and city] available in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $location
     * @param $locationId
     * @return array|string
     * @since 18th MAY, 2016
     */
    public function getLocation($location, $locationId)
    {
        try {
            if ($location == 'country') {
                return (array)DB::table('country')
                    ->where('status', '=', 1)
                    ->select('country_id', 'country_name')
                    ->orderBy('country_name', 'asc')
                    ->get();
            } else
                if ($location == 'state') {
                    return (array)DB::table('state')
                        ->where('country_id', '=', $locationId)
                        ->where('status', '=', 1)
                        ->select('state_id', 'state_name')
                        ->orderBy('state_name', 'asc')
                        ->get();
                } else
                    if ($location == 'city') {
                        return (array)DB::table('city')
                            ->where('state_id', '=', $locationId)
                            ->where('status', '=', 1)
                            ->select('city_id', 'city_name')
                            ->orderBy('city_name', 'asc')
                            ->get();
                    }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return the initial info[country list and unsigned shopkeeper list] for adding a new shop in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return array|string
     * @since 18th MAY, 2016
     */
    public function getInitialDataForAddNewShop()
    {
        try {
            $countryList = $this->getLocation('country', 0);
            $initialData = array();
            $shopkeepers = (array)DB::table('shopkeeper_meta')
                ->join('users', 'shopkeeper_meta.id', '=', 'users.id')
                ->where('shopkeeper_meta.shop_id', '=', null)
                ->where('users.status', '=', 1)
                ->select('shopkeeper_meta.shopkeeper_meta_id', 'shopkeeper_meta.id', 'shopkeeper_meta.first_name')
                ->get();

            if (!empty($shopkeepers))
                $initialData['shopkeepers'] = $shopkeepers;
            else
                $initialData['shopkeepers'] = null;

            if (!empty($countryList) && is_array($countryList))
                $initialData['countryList'] = $countryList;
            else
                $initialData['countryList'] = null;

            return $initialData;

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It create a new unique shop in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopDetail
     * @param $shopImage
     * @return string
     * @since 18th MAY, 2016
     */
    public function createShop($shopDetail, $shopImage)
    {
        try {
            DB::beginTransaction();

            $createdLocationId = Street::create([
                'street_name' => $shopDetail['location'],
                'status' => 1,
                'assign_to_shop' => 1,
                'city_id' => $shopDetail['city'],
            ]);

            $createdLocationId = $createdLocationId->street_id;

            $imagePath = $shopImage['shop_picture_fetchedPath'] . '/' . $shopImage['shop_picture_name'];

            if ($shopDetail['shopkeeper'] != 0) {
                $createdShopId = Shop::create([
                    'shop_name' => $shopDetail['shop_name'],
                    'status' => 2,
                    'assign_to_shopkeeper' => 1,
                    'image' => $imagePath,
                    'street_id' => $createdLocationId,
                ]);
                $createdShopId = $createdShopId->shop_id;

                $assignShopToShopkeeper = ShopKeeperMeta::where('shopkeeper_meta_id', '=', $shopDetail['shopkeeper'])
                    ->update(['shop_id' => $createdShopId]);
            } else {
                $createdShopId = Shop::create([
                    'shop_name' => $shopDetail['shop_name'],
                    'status' => 2,
                    'assign_to_shopkeeper' => 0,
                    'image' => $imagePath,
                    'street_id' => $createdLocationId,
                ]);
            }

            if ($createdLocationId && $createdShopId) {
                $shopDetail['shop_image']->move($shopImage['shop_picture_movedPath'], $shopImage['shop_picture_name']);
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns the shop list with their details.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 21th MAY, 2016
     */
    public function fetchShopListByLimit($offset, $limit, $column, $direction, $searchValue)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('shop')
                    ->leftJoin('shopkeeper_meta', 'shop.shop_id', '=', 'shopkeeper_meta.shop_id')
                    ->skip($offset)->take($limit)
                    ->select('shop.shop_id', 'shop.shop_name', 'shop.status',
                        'shop.assign_to_shopkeeper', 'shopkeeper_meta.id', 'shopkeeper_meta.first_name')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('shop')
                    ->leftJoin('shopkeeper_meta', 'shop.shop_id', '=', 'shopkeeper_meta.shop_id')
                    ->skip($offset)->take($limit)
                    ->where('shop.shop_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%')
                    ->orWhere('shopkeeper_meta.first_name', 'like', '%' . $searchValue . '%')
                    ->select('shop.shop_id', 'shop.shop_name', 'shop.status',
                        'shop.assign_to_shopkeeper', 'shopkeeper_meta.id', 'shopkeeper_meta.first_name')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It returns the number of available shop in DB according to given search value.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return array|int
     * @since 21th MAY, 2016
     */
    public function fetchNumberOfShops($searchValue)
    {
        try {
            if ($searchValue != '') {
                $select = (array)DB::table('shop')
                    ->leftJoin('shopkeeper_meta', 'shop.shop_id', '=', 'shopkeeper_meta.shop_id')
                    ->where('shop.shop_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('shop.shop_name', 'like', '%' . $searchValue . '%')
                    ->orWhere('shopkeeper_meta.first_name', 'like', '%' . $searchValue . '%')
                    ->select('shop.shop_id')
                    ->count();
                return $select;
            } else {
                $select = (array)DB::table('shop')
                    ->leftJoin('shopkeeper_meta', 'shop.shop_id', '=', 'shopkeeper_meta.shop_id')
                    ->select('shop.shop_id')
                    ->count();
                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It activate or deactivate the shop status in DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @param $status
     * @return string
     * @since 21th MAY, 2016
     */
    public function activateOrDeactivateShop($shopId, $status)
    {
        try {
            $result = DB::table('shop')
                ->join('street', 'shop.street_id', '=', 'street.street_id')
                ->where('shop.shop_id', '=', $shopId)
                ->update(['shop.status' => $status, 'street.status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns the particular called shop id and name.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @return string
     * @since 21th MAY, 2016
     */
    public function fetchOneShopDetail($shopId)
    {
        try {
            $result = Shop::where('shop_id', '=', $shopId)
                ->select('shop_id', 'shop_name')
                ->first();
            if ($result)
                return $result->toArray();
            else
                return 'fail';
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 'fail';
        }
    }

    /**
     * It delete the particular shop with their all related data from database.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @return string
     * @since 21th MAY, 2016
     */
    public function deleteShop($shopId)
    {
        try {
            DB::beginTransaction();

            DB::table('cart')->where('shop_id', '=', $shopId)
                ->delete();
            DB::table('product_list')->where('shop_id', '=', $shopId)
                ->delete();

            DB::table('shopkeeper_meta')
                ->where('shop_id', '=', $shopId)
                ->update(['shop_id' => null]);

            $streetId = DB::table('shop')
                ->where('shop_id', '=', $shopId)
                ->select('street_id')
                ->first();

            DB::table('shop')->where('shop_id', '=', $shopId)
                ->delete();
            $finalDeletion = DB::table('street')->where('street_id', '=', $streetId->street_id)
                ->delete();

            if ($finalDeletion) {
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It returns the all available details of particular shop.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopId
     * @return string
     * @since 21th MAY, 2016
     */
    public function fetchAllDetailOfOneShop($shopId)
    {
        try {
            $shopDetail = Shop::join('street', 'shop.street_id', '=', 'street.street_id')
                ->join('city', 'street.city_id', '=', 'city.city_id')
                ->join('state', 'city.state_id', '=', 'state.state_id')
                ->join('country', 'state.country_id', '=', 'country.country_id')
                ->leftJoin('shopkeeper_meta', 'shop.shop_id', '=', 'shopkeeper_meta.shop_id')
                ->where('shop.shop_id', '=', $shopId)
                ->select('shop.shop_id', 'shop.shop_name', 'shop.image as shop_image',
                    'street.street_name', 'city.city_name', 'state.state_name',
                    'country.country_name', 'shopkeeper_meta.shopkeeper_meta_id',
                    'shopkeeper_meta.first_name', 'shopkeeper_meta.image as shopkeeper_image',
                    'shopkeeper_meta.id')
                ->first();

            $shopkeepers = ShopKeeperMeta::join('users','shopkeeper_meta.id','=','users.id')
                ->where('shopkeeper_meta.shop_id', '=', null)
                ->where('users.status', '=', 1)
                ->orWhere('shopkeeper_meta.shop_id', '=', $shopId)
                ->select('shopkeeper_meta.shopkeeper_meta_id', 'shopkeeper_meta.first_name',
                    'shopkeeper_meta.id')
                ->get();

            if (!empty($shopDetail->toArray())) {
                $shopDetail = $shopDetail->toArray();

                if (!empty($shopkeepers->toArray()))
                    $shopDetail['shopkeepers'] = $shopkeepers->toArray();
                else
                    $shopDetail['shopkeepers'] = null;
                return $shopDetail;
            } else
                return 'fail';

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 'fail';
        }
    }

    /**
     * It update the particular shop detail in DB
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $shopDetail
     * @param $shopImage
     * @return string
     * @since 21th MAY, 2016
     */
    public function updateShop($shopDetail, $shopImage)
    {
        try {
            DB::beginTransaction();
            if ($shopImage) {
                if ($shopDetail['shopkeeper'] == 0) {
                    $updateShop = Shop::where('shop_id', '=', $shopDetail['shopId'])
                        ->update([
                            'shop_name' => $shopDetail['shop_name'],
                            'assign_to_shopkeeper' => 0,
                            'image' => $shopImage['shop_picture_savedPath'],
                        ]);
                    $removeShopToShopkeeper = ShopKeeperMeta::where('shop_id', '=', $shopDetail['shopId'])
                        ->update(['shop_id' => null]);
                    $assignShopToShopkeeper = 1;
                } else {
                    $updateShop = Shop::where('shop_id', '=', $shopDetail['shopId'])
                        ->update([
                            'shop_name' => $shopDetail['shop_name'],
                            'assign_to_shopkeeper' => 1,
                            'image' => $shopImage['shop_picture_savedPath'],
                        ]);

                    $removeShopToShopkeeper = ShopKeeperMeta::where('shop_id', '=', $shopDetail['shopId'])
                        ->update(['shop_id' => null]);

                    $assignShopToShopkeeper = ShopKeeperMeta::where('shopkeeper_meta_id', '=', $shopDetail['shopkeeper'])
                        ->update(['shop_id' => $shopDetail['shopId']]);
                }
            } else {

                if ($shopDetail['shopkeeper'] == 0) {
                    $updateShop = Shop::where('shop_id', '=', $shopDetail['shopId'])
                        ->update([
                            'shop_name' => $shopDetail['shop_name'],
                            'assign_to_shopkeeper' => 0,
                        ]);

                    $removeShopToShopkeeper = ShopKeeperMeta::where('shop_id', '=', $shopDetail['shopId'])
                        ->update(['shop_id' => null]);
                    $assignShopToShopkeeper = 1;
                } else {
                    $updateShop = Shop::where('shop_id', '=', $shopDetail['shopId'])
                        ->update([
                            'shop_name' => $shopDetail['shop_name'],
                            'assign_to_shopkeeper' => 1,
                        ]);

                    $removeShopToShopkeeper = ShopKeeperMeta::where('shop_id', '=', $shopDetail['shopId'])
                        ->update(['shop_id' => null]);
                    $assignShopToShopkeeper = ShopKeeperMeta::where('shopkeeper_meta_id', '=', $shopDetail['shopkeeper'])
                        ->update(['shop_id' => $shopDetail['shopId']]);
                }
            }

            if ($updateShop && $assignShopToShopkeeper) {
                if ($shopImage) {
                    unlink($shopDetail['shop_image_path']);
                    $shopDetail['shop_image']->move($shopImage['shop_picture_movedPath'], $shopImage['shop_picture_name']);
                }
                DB::commit();
                return 'success';
            } else {
                DB::rollBack();
                return 'fail';
            }

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

}//End of class
