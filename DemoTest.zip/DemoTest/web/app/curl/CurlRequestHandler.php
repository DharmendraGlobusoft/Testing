<?php
namespace App\curl;

use stdClass;
use Input;

/**
 * Class CurlRequestHandler
 * @package Illuminate\curl
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 27th FEB, 2016
 */
class CurlRequestHandler
{

    private static $_instance = null;

    /**
     * Check instance of this class is available or not.
     * If not then only create an instance of this class and return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return CurlRequestHandler|null
     * @since 27th FEB, 2016
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new self();
        return self::$_instance;
    }

    /**
     * If we need curl using post method then only we call it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $url
     * @param $data
     * @return stdClass
     * @since 27th FEB, 2016
     */
    public function curlUsingPost($url, $data)
    {

        $response = new stdClass();
        if (empty($url) || empty($data)) {
            $response->code = 180;
            $response->message = 'You should pass the parameters for curl services.';
            return $response;
        }
        $fields_string = '';
        foreach ($data as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }

        $fields_string = rtrim($fields_string, '&');

        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POST, count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); # timeout after 10 seconds, you can increase it

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  # Set curl to return the data instead of printing it to the browser.
        // curl_setopt($ch,  CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)"); # Some server may refuse your request if you dont pass user agent
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        //execute post
        $result = curl_exec($ch);

        $result = json_decode($result, true);
        curl_close($ch);

        if ($result) {
            @$response->code = $result['code'];
            @$response->message = $result['message'];
            @$response->data = $result['data'];
            return @$response;
        } else {
            $response->code = 190;
            $response->message = 'Some error has been occurred due to curl.';
            return $response;
        }
    }

    /**
     * If we need curl using get method then only we call it.
     * Here we should not send data, If we want then should use curl using post method only
     * because it is more secure than curl using get method for sending data.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $url
     * @return mixed|stdClass
     * @since 27th FEB, 2016
     */
    public function curlUsingGet($url)
    {
        $response = new stdClass();
        if (empty($url)) {
            $response->code = 180;
            $response->message = 'You should pass the parameters for curl services.';
            return $response;
        }

        //open connection
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10); # timeout after 10 seconds, you can increase it
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  # Set curl to return the data instead of printing it to the browser.
        // curl_setopt($ch,  CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)"); # Some server may refuse your request if you dont pass user agent
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        //execute post
        $result = curl_exec($ch);

        $result = json_decode($result, true);
        //close connection
        curl_close($ch);

        if ($result) {
            @$response->code = $result['code'];
            @$response->message = $result['message'];
            @$response->data = $result['data'];
            return @$response;
        } else {
            $response->code = 190;
            $response->message = 'Some error has been occurred due to curl.';
            return $response;
        }
    }

}// End of class

?>