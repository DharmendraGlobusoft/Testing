<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * Class Notification
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 17th JUNE, 2016
 */
class Notification extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 17th JUNE, 2016
     */
    protected $table = 'notification';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 17th JUNE, 2016
     */
    protected $primaryKey = 'notification_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 17th JUNE, 2016
     */
    protected $fillable = [
        'message', 'notify_status', 'id', 'order_detail_id',
    ];


    /**
     * It return new notification list for order from db.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @return array|string
     * @since 28th JUNE, 2016
     */
    public function getNewOrderNotification()
    {
        try {
            return (array)DB::table('notification')
                ->where('notify_status', '=', 0)
                ->select('notification_id', 'message', 'id', 'order_detail_id', 'created_at')
                ->orderBy('notification_id', 'desc')
                ->get();

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }


    /**
     * It change the status [seen or not seen] of notification.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $notificationId
     * @param $notifyStatus
     * @return string
     * @since 28th JUNE, 2016
     */
    public function changeOrderNotification($notificationId, $notifyStatus)
    {
        try {
            DB::table('notification')
                ->where('notification_id', '=', $notificationId)
                ->update(['notify_status' => $notifyStatus]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return new notification list for order from db by using limit.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @return array|string
     * @since 28th JUNE, 2016
     */
    public function getNewOrderNotificationByLimit($offset)
    {
        try {
            return (array)DB::table('notification')
                ->where('notify_status', '=', 0)
                ->skip($offset)->take(10)
                ->select('notification_id', 'message', 'id', 'order_detail_id', 'created_at')
                ->orderBy('notification_id', 'desc')
                ->get();

        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It save notification detail in db for user in future use
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $orderId
     * @return string
     * @since 29th JUNE, 2016
     */
    public function saveUserNotification($orderId)
    {
        try {
            $notificationDetail = OrderDetail::join('users', 'order_detail.id', '=', 'users.id')
                ->where('order_detail.order_detail_id', '=', $orderId)
                ->select('order_detail.order_detail_id', 'order_detail.order_status',
                    'order_detail.id', 'users.device_token_id_ios')
                ->first();
            if ($notificationDetail) {

                $notificationDetail = $notificationDetail->toArray();
                if ($notificationDetail['order_status'] == 0)
                    $notificationDetail['order_status'] = 'This order is now pending.';
                else
                    if ($notificationDetail['order_status'] == 1)
                        $notificationDetail['order_status'] = 'This order is now in under process.';
                    else
                        if ($notificationDetail['order_status'] == 2)
                            $notificationDetail['order_status'] = 'This order has been dispatched form our shop.';
                        else
                            if ($notificationDetail['order_status'] == 3)
                                $notificationDetail['order_status'] = 'This order has been delivered to you.';

                $message = 'Your order Id is ' . $notificationDetail["order_detail_id"] . '. ' . $notificationDetail['order_status'];

                UserNotification::create([
                    'message' => $message,
                    'id' => $notificationDetail["id"],
                    'order_detail_id' => $notificationDetail["order_detail_id"],
                ]);
                return 'success';
            } else
                return 'fail';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

}//End of class