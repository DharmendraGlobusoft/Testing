<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

/**
 * Class Country
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 21th MAY, 2016
 */
class Country extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 21th MAY, 2016
     */
    protected $table = 'country';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 21th MAY, 2016
     */
    protected $primaryKey = 'country_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 21th MAY, 2016
     */
    protected $fillable = [
        'country_name', 'status',
    ];


    /**
     * It return the list of country with their details according to condition.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $offset
     * @param $limit
     * @param $column
     * @param $direction
     * @param $searchValue
     * @return array|int
     * @since 25th MAY, 2016
     */
    public function fetchCountryListByLimit($offset, $limit, $column, $direction, $searchValue)
    {
        try {
            if ($searchValue == '') {
                $select = (array)DB::table('country')
                    ->skip($offset)->take($limit)
                    ->select('country_id', 'country_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                return $select;
            } else {
                $select = (array)DB::table('country')
                    ->skip($offset)->take($limit)
                    ->where('country_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('country_name', 'like', '%' . $searchValue . '%')
                    ->select('country_id', 'country_name', 'status')
                    ->orderBy($column, $direction)
                    ->get();
                if (empty($select))
                    return 0;
                else
                    return $select;
            }

        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It count the number of country present in DB according the condition and  return it.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $searchValue
     * @return array|int
     * @since 25th MAY, 2016
     */
    public function fetchNumberOfCountry($searchValue)
    {
        try {
            if ($searchValue != '') {
                $select = (array)DB::table('country')
                    ->where('country_id', 'like', '%' . $searchValue . '%')
                    ->orWhere('country_name', 'like', '%' . $searchValue . '%')
                    ->select('country_id')
                    ->count();
                return $select;
            } else {
                $select = (array)DB::table('country')
                    ->select('country_id')
                    ->count();
                return $select;
            }
        } catch (QueryException $exception) {
            echo 'There are some sql exception.';
            return 0;
        }
    }

    /**
     * It activate or deactivate the country status.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $countryId
     * @param $status
     * @return string
     * @since 25th MAY, 2016
     */
    public function activateOrDeactivateCountry($countryId, $status)
    {
        try {
            $result = DB::table('country')
                ->where('country_id', '=', $countryId)
                ->update(['status' => $status]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It return the only name and id of called country.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $countryId
     * @return array|string
     * @since 25th MAY, 2016
     */
    public function fetchCountryNameAndId($countryId)
    {
        try {
            $result = DB::table('country')
                ->where('country_id', '=', $countryId)
                ->select('country_id', 'country_name')
                ->first();
            $result = (array)$result;
            return $result;
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It create the new country in DB.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $countryName
     * @return string
     * @since 25th MAY, 2016
     */
    public function createCountry($countryName)
    {
        try {
            Country::create([
                'country_name' => $countryName,
                'status' => 2,
            ]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

    /**
     * It update the detail of exist country.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @param $countryId
     * @param $countryName
     * @return string
     * @since 25th MAY, 2016
     */
    public function updateCountry($countryId, $countryName)
    {
        try {
            Country::where('country_id', '=', $countryId)
                ->update(['country_name' => $countryName]);
            return 'success';
        } catch (QueryException $exception) {
            return 'There are some sql exception.';
        }
    }

} //End of class
