<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class ShopKeeperMeta
 * @package App
 * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
 * @since 16th MAY, 2016
 */
class ShopKeeperMeta extends Model
{
    /**
     * It have existing DB table name and it connect to this model with existing DB table
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 16th MAY, 2016
     */
    protected $table = 'shopkeeper_meta';

    /**
     * It have existing table's primary Key column name and it connect to this model with existing table's primary Key
     * Primary key should have always auto increment property.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var string
     * @since 16th MAY, 2016
     */
    protected $primaryKey = 'shopkeeper_meta_id';

    /**
     * The attributes that are mass assignable.
     * @author Nitin Kumar Gupta <nitingupta@globussoft.com>
     * @var array
     * @since 16th MAY, 2016
     */
    protected $fillable = [
        'first_name', 'last_name', 'contact_number', 'age', 'gender','address','image','id','shop_id',
    ];


}//End of class