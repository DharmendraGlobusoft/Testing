<?php session_start(); ?>
<html>
<head>
    <title>Billing Page</title>
</head>
<body>
<center>

    <?php include('Crypto.php') ?>
    <?php


    error_reporting(0);

    //---------------------------- Post data Validation -------------------
    if (empty($_POST['tid'])) {
//        header("Location:{$_SERVER['HTTP_REFERER']}"); //Go back to previous page
        header("Location: https://citytreq.com/failed");
        exit;
    }

    if (empty($_POST['merchant_id'])) {
        header("Location: https://citytreq.com/failed");
        exit;
    } else {
        if ($_POST['merchant_id'] != '182682') {
            header("Location: https://citytreq.com/failed");
            exit;
        }
    }

    if (empty($_POST['order_id'])) {
        header("Location: https://citytreq.com/failed");
        exit;
    } else {
        $orderId = trim($_POST['order_id']);
        if (!preg_match("/^[0-9]*$/", $orderId)) {
            header("Location: https://citytreq.com/failed");
            exit;
        }
        elseif ($orderId != $_SESSION['orderId']) {
//            die('okff='.$orderId.'='.$_SESSION['orderId']);
            header("Location: https://citytreq.com/failed");
            exit;
        }
    }

    if (empty($_POST['amount'])) {
        header("Location: https://citytreq.com/failed");
        exit;
    } else {
        $amount = trim($_POST['amount']);
        if ($amount < 1) {
            header("Location: https://citytreq.com/failed");
            exit;
        } elseif ($amount != $_SESSION['p_amt']) {
            header("Location: https://citytreq.com/failed");
            exit;
        }
    }

    if (empty($_POST['redirect_url'])) {
        header("Location: https://citytreq.com/failed");
        exit;
    } else {
        if ($_POST['redirect_url'] != "https://citytreq.com/payment/ccavResponseHandler.php") {
            header("Location: https://citytreq.com/failed");
            exit;
        }
    }

    if (empty($_POST['cancel_url'])) {
        header("Location: https://citytreq.com/failed");
        exit;
    } else {
        if ($_POST['cancel_url'] != "https://citytreq.com/payment/ccavResponseHandler.php") {
            header("Location: https://citytreq.com/failed");
            exit;
        }
    }


    if (!(isset($_SESSION['p_amt']) && !empty($_SESSION['p_amt']))) {
        header("Location: https://citytreq.com/failed");
        exit;
    }

//            echo "Transaction Id=" . $_POST['tid'] . "<br>";
//            echo 'merchant_id=' . $_POST['merchant_id'] . "<br>";
//            echo 'Order Id=' . $_POST['order_id'] . "<br>";
//            echo 'Session Order Id=' . $_SESSION['orderId'] . "<br>";
//            echo 'Post Amount=' . $_POST['amount'] . " Session Amount=" . $_SESSION['p_amt'] . "<br>";
//            echo 'redirect_url=' . $_POST['redirect_url'] . "<br>";
//            echo 'cancel_url=' . $_POST['cancel_url'] . "<br>";
//            echo "<br><br>";
//            die('Stop');
    //---------------------------------------------------------------------

    $merchant_data = '';
    $working_key = '88E65CF7C51293FB8A7E5039157ED0D3';//Shared by CCAVENUES
    $access_code = 'AVYS79FG02AL65SYLA';//Shared by CCAVENUES

//    die('here='.$_POST);

    foreach ($_POST as $key => $value) {
        if ($key == "amount") {
//            $value = isset($_SESSION['p_amt']) ? $_SESSION['p_amt'] : $value;
            $amount = $_SESSION['p_amt'];
            $merchant_data .= $key . '=' . urlencode($amount) . '&';
        }
        else {
            $merchant_data .= $key . '=' . urlencode($value) . '&';
        }
    }

    $encrypted_data1 = encrypt($merchant_data, $working_key); // Method for encrypting the data.

//        $data=decrypt($encrypted_data,$working_key);
//        echo "Encrypt Amount=".$encrypted_data;
//        echo "<br><br>";
//        echo "Decrypt Amount=".$data.'<br>';
//        die('Stop');

//        die('encRequest= '.$encrypted_data);

    // destroy the session
     session_destroy();

    //    die('here'.$merchant_data.'<br>'.$encrypted_data);

    ?>
    <!--    <form method="post" name="redirect" action="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction">-->
<!--    This will redirect to HDFC with encripted order ID, Amount and access key-->
<!--    This will return to   Route::get('/response-data','HdfcPayment\PaymentController@responseData');-->
    <form method="post" name="redirect"
          action="https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction">
        <?php
        echo "<input type=hidden name=encRequest value=$encrypted_data1>";
        echo "<input type=hidden name=access_code value=$access_code>";
        ?>
    </form>
</center>
<script language='javascript'>document.redirect.submit();</script>
</body>
</html>

