<?php include('Crypto.php')?>
<?php

	error_reporting(0);

	$workingKey='88E65CF7C51293FB8A7E5039157ED0D3';		//Working Key should be provided here.
	$encResponse=$_POST["encResp"];			//This is the response sent by the CCAvenue Server

//	dd('Stop', $encResponse);
	$rcvdString=decrypt($encResponse,$workingKey);		//Crypto Decryption used as per the specified working key.
	$order_status="";
	$decryptValues=explode('&', $rcvdString);

	//-------------------------------
    $secret_key = 'shankarmandal@globussoft.in';
    $secret_iv = '456';//my_simple_secret_iv

    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

    $responseData = base64_encode( openssl_encrypt( $rcvdString, $encrypt_method, $key, 0, $iv ) );
	//-------------------------

	$dataSize=sizeof($decryptValues);
	echo "<center>";

	for($i = 0; $i < $dataSize; $i++)
	{
		$information=explode('=',$decryptValues[$i]);
		if($i==3)	$order_status=$information[1];
	}

	if($order_status==="Success")
	{
//		echo "<br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.";
//        header("Location: https://citytreq.com/response-data?data=".urlencode($rcvdString));
        header("Location: https://citytreq.com/response-data?data=".$responseData);
	}
	else if($order_status==="Aborted")
	{
//		echo "<br>Thank you for shopping with us.We will keep you posted regarding the status of your order through e-mail";
        header("Location: https://citytreq.com/payment-cancel");
	}
	else if($order_status==="Failure")
	{
//		echo "<br>Thank you for shopping with us.However,the transaction has been declined.";
//        header("Location: https://citytreq.com/transaction/failed-data?data=".urlencode($rcvdString));
        header("Location: https://citytreq.com/transaction/failed-data?data=".$responseData);
	}
	else
	{
//		echo "<br>Security Error. Illegal access detected";
//        header("Location: https://citytreq.com/transaction/error-data?data=".urlencode($rcvdString));
        header("Location: https://citytreq.com/transaction/error-data?data=".$responseData);
	}

	echo "<br><br>";

	echo "<table cellspacing=4 cellpadding=4>";
	for($i = 0; $i < $dataSize; $i++)
	{
		$information=explode('=',$decryptValues[$i]);
	    	echo '<tr><td>'.$information[0].'</td><td>'.urldecode($information[1]).'</td></tr>';
	}

	echo "</table><br>";
	echo "</center>";
?>
