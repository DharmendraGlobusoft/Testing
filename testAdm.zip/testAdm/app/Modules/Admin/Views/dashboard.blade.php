<?php
/**
 * Created by Nitin Kumar Gupta <nitingupta@globussoft.com>
 * Date: 5/3/2016
 * Time: 7:18 PM
 */
?>

@extends('Admin::layout.master')

@section('content')
    <div id="page-title">
        <h2 style="color:#FB0007;">Dashboard</h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3">
                    <a href="#" title="Active Users" class="tile-box tile-box-shortcut btn-success">
                        <span class="bs-badge badge-absolute">12</span>
                        <div class="tile-header">Active Users</div>
                        <div class="tile-content-wrapper"><i class="glyph-icon icon-desktop"></i></div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="InActive Users" class="tile-box tile-box-shortcut btn-black-opacity-alt">
                        <span class="bs-badge badge-absolute">13</span>
                        <div class="tile-header">Inactive Users</div>
                        <div class="tile-content-wrapper">
                            <i class="glyph-icon icon-file-photo-o"></i>
                        </div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="Active Shopkeepers" class="tile-box tile-box-shortcut btn-success">
                        <span class="bs-badge badge-absolute">14</span>
                        <div class="tile-header">Active Shopkeepers</div>
                        <div class="tile-content-wrapper">
                            <i class="glyph-icon icon-download"></i>
                        </div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="InActive Shopkeepers" class="tile-box tile-box-shortcut btn-black-opacity-alt">
                        <span class="bs-badge badge-absolute">9</span>
                        <div class="tile-header">Inactive Shopkeepers</div>
                        <div class="tile-content-wrapper"><i class="glyph-icon icon-code-fork"></i></div>
                    </a>
                </div>
            </div>
        </div>
        <br><br><br>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3">
                    <a href="#" title="Active Shops" class="tile-box tile-box-shortcut btn-success">
                        <span class="bs-badge badge-absolute">8</span>
                        <div class="tile-header">Active Shops</div>
                        <div class="tile-content-wrapper">
                            <i class="glyph-icon icon-file-photo-o"></i>
                        </div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="InActive Shops" class="tile-box tile-box-shortcut btn-black-opacity-alt">
                        <span class="bs-badge badge-absolute">5</span>
                        <div class="tile-header">Inactive Shops</div>
                        <div class="tile-content-wrapper"><i class="glyph-icon icon-desktop"></i></div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="Active Products" class="tile-box tile-box-shortcut btn-success">
                        <span class="bs-badge badge-absolute">7</span>
                        <div class="tile-header">Active Products</div>
                        <div class="tile-content-wrapper">
                            <i class="glyph-icon icon-file-photo-o"></i>
                        </div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="InActive Products" class="tile-box tile-box-shortcut btn-black-opacity-alt">
                        <span class="bs-badge badge-absolute">2</span>
                        <div class="tile-header">Inactive Products</div>
                        <div class="tile-content-wrapper"><i class="glyph-icon icon-desktop"></i></div>
                    </a>
                </div>
            </div>
        </div>
        <br><br><br>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3">
                    <a href="#" title="User Orders" class="tile-box tile-box-shortcut btn-info">
                        <span class="bs-badge badge-absolute">7</span>
                        <div class="tile-header">Total User Orders</div>
                        <div class="tile-content-wrapper">
                            <i class="glyph-icon icon-download"></i>
                        </div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="#" title="User Transactions" class="tile-box tile-box-shortcut btn-blue-alt">
                        <span class="bs-badge badge-absolute">6</span>
                        <div class="tile-header">Total User Transaction</div>
                        <div class="tile-content-wrapper"><i class="glyph-icon icon-code-fork"></i></div>
                    </a>
                </div>
            </div>
        </div>
    </div>
@endsection
