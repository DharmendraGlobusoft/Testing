


<div id="page-sidebar">
    <div id="header-logo" class="logo-bg">
{{--        <a href="/adminDashboard" class="logo-content-big" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}} </a>--}}
        <a href="/adminDashboard" class="logo-content-small" title="{{Config::get('app.APPLICATION_NAME')}}">{{Config::get('app.APPLICATION_NAME')}} </a>
        <a id="close-sidebar"  href="#" title="Close sidebar"><i class="glyph-icon icon-outdent"></i></a>
    </div>
    <div class="scroll-sidebar">
        <ul id="sidebar-menu">
            <li class="header"><span>Menu List</span></li>
            <li>
                <a href="/adminDashboard" title="Dashboard">
                    <i class="glyph-icon icon-linecons-tv"></i> <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="javascript:void(0);" title="Users">
                    <i class="glyph-icon icon-linecons-user"></i> <span>Users</span>
                </a>
                <div class="sidebar-submenu">
                    <ul>
                        <li><a  href="/userList" title=" View user list"><span>User List</span></a></li>
                    </ul>
                </div>
            </li>

            <li>
                <a href="javascript:void(0);" title="Product">
                    <i class="glyph-icon icon-linecons-cup"></i> <span>Product</span>
                </a>
                <div class="sidebar-submenu">
                    <ul>
                        {{--<li><a  href="/addMainProduct" title="Add / View main product"><span>Add / View Main Product</span></a></li>--}}
                        {{--<li><a  href="/addSubProduct" title="Add / View sub product"><span>Add / View Sub Product</span></a></li>--}}
                        <li><a  href="/addProduct" title="Add new product"><span>Add New Product</span></a></li>
                        <li><a  href="/viewProductList" title="View product List"><span>View Product List</span></a></li>
                        {{--<li><a  href="/assignProduct" title="Assign product in shop"><span>Assign Product In Shop</span></a></li>--}}
                    </ul>
                </div>
            </li>
            <li>
                <a  href="/viewOrder" title="Order Details">
                    <i class="glyph-icon icon-linecons-note"></i> <span>Order Details</span>
                </a>
            </li>
            <li>
                <a  href="/viewTransaction" title="Transaction Details">
                    <i class="glyph-icon icon-linecons-money"></i> <span>Transaction Details</span>
                </a>
            </li>
        </ul>
    </div>
</div>
