


        <!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
@include("Admin::layout.head")
        <!-- END HEAD -->
<body>
<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<div id="sb-site">
    <div id="loading">
        <div class="svg-icon-loader"><img src="{{Config::get('app.WEB_HOST')}}assets/admin/images/bars.svg" width="40"
                                          alt=""></div>
    </div>
    <div id="page-wrapper">
        <div id="mobile-navigation">
            <button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span>
            </button>
        </div>
        <!-- BEGIN SIDE MENU -->
        @include("Admin::layout.sideMenu")
                <!-- END SIDE MENU -->
        <div id="page-content-wrapper">
            <div id="page-content">
                <!-- BEGIN HEADER -->
                @include("Admin::layout.header")
                        <!-- END HEADER -->
                <!-- BEGIN MAIN CONTENT -->
                @yield('content')
                        <!-- END MAIN CONTENT -->
            </div>
        </div>
    </div>
</div>

<!-- BEGIN MODAL -->
<!-- MODAL -->
<div class="modal fade" id="changephoto" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="" name="profilePicForm" method="post" enctype="multipart/form-data" files="true">
            {{ csrf_field() }}
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Change Photo</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group text-center">
                        <label class="control-label">Profile Picture:</label>
                        <div class="">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src="{{Config::get('app.WEB_HOST')}}/assets/admin/noImage.png"/>
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail"
                                     style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                <div id="photoArea">
                                    <span class="btn btn-success btn-file">
									<span class="fileinput-new" id="fileInputNew">Choose</span>
                                    <span class="fileinput-exists" id="fileInputExist1">Change</span>
                                    <input type="file" name="profilePicture">
                                    </span>
                                    <a href="#" id="fileInputExist2" class="btn btn-danger fileinput-exists"
                                       data-dismiss="fileinput">Remove</a>
                                </div>
                                <span id="error" style="color: #FB0007;"></span>
                                <span id="success" style="color: green;"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </form>
    </div>
</div>


<div class="modal fade" id="changepass" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Change Password</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form name="updatePassForm" class="form-horizontal pad15L pad15R bordered-row">
                            {{ csrf_field() }}
                            <div class="form-group remove-border">
                                <label class="col-sm-3 control-label">Old Password:</label>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control" id="oldPassword" name="oldPassword"
                                           placeholder="Enter Old Password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">New Password:</label>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control" id="newPassword" name="newPassword"
                                           placeholder="Enter New Password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Confirm Password:</label>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control" id="password_confirmation"
                                           name="password_confirmation" placeholder="Enter Confirm Password">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <br>
                <span id="passwordError" style="color: #FB0007; margin-left: 153px;"></span>
                <span id="passwordSuccess" style="color: green;"></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="updatePassword">Save changes</button>
            </div>

        </div>
    </div>
</div>
<!-- END MODAL -->

<!-- BEGIN OPTIONAL MODAL -->
@yield('modal')
        <!-- END OPTIONAL MODAL -->

<!-- BEGIN COMMON JAVASCRIPT -->
<script src="/assets/admin/js/jquery-core.js"></script>
<script src="/assets/admin/js/jquery-ui-core.js"></script>
<script src="/assets/admin/js/dropdown.js"></script>
<script src="/assets/admin/js/tooltip.js"></script>
<script src="/assets/admin/js/collapse.js"></script>
<script src="/assets/admin/js/superclick.js"></script>
<script src="/assets/admin/js/slimscroll.js"></script>
<script src="/assets/admin/js/slidebars.js"></script>
<script src="/assets/admin/js/material.js"></script>
<script src="/assets/admin/js/ripples.js"></script>
<script src="/assets/admin/js/custom.js"></script>
<script src="/assets/admin/js/layout.js"></script>
<script>
    $(window).load(function () {
        setTimeout(function () {
            $('#loading').fadeOut(400, "linear");
        }, 300);
    });
</script>
<script>
    +function (t) {
        "use strict";
        function e(e, i) {
            return this.each(function () {
                var s = t(this), n = s.data("bs.modal"), a = t.extend({}, o.DEFAULTS, s.data(), "object" == typeof e && e);
                n || s.data("bs.modal", n = new o(this, a)), "string" == typeof e ? n[e](i) : a.show && n.show(i)
            })
        }

        var o = function (e, o) {
            this.options = o, this.$body = t(document.body), this.$element = t(e), this.$dialog = this.$element.find(".modal-dialog"), this.$backdrop = null, this.isShown = null, this.originalBodyPad = null, this.scrollbarWidth = 0, this.ignoreBackdropClick = !1, this.options.remote && this.$element.find(".modal-content").load(this.options.remote, t.proxy(function () {
                this.$element.trigger("loaded.bs.modal")
            }, this))
        };
        o.VERSION = "3.3.6", o.TRANSITION_DURATION = 300, o.BACKDROP_TRANSITION_DURATION = 150, o.DEFAULTS = {
            backdrop: !0,
            keyboard: !0,
            show: !0
        }, o.prototype.toggle = function (t) {
            return this.isShown ? this.hide() : this.show(t)
        }, o.prototype.show = function (e) {
            var i = this, s = t.Event("show.bs.modal", {relatedTarget: e});
            this.$element.trigger(s), this.isShown || s.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', t.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal", function () {
                i.$element.one("mouseup.dismiss.bs.modal", function (e) {
                    t(e.target).is(i.$element) && (i.ignoreBackdropClick = !0)
                })
            }), this.backdrop(function () {
                var s = t.support.transition && i.$element.hasClass("fade");
                i.$element.parent().length || i.$element.appendTo(i.$body), i.$element.show().scrollTop(0), i.adjustDialog(), s && i.$element[0].offsetWidth, i.$element.addClass("in"), i.enforceFocus();
                var n = t.Event("shown.bs.modal", {relatedTarget: e});
                s ? i.$dialog.one("bsTransitionEnd", function () {
                    i.$element.trigger("focus").trigger(n)
                }).emulateTransitionEnd(o.TRANSITION_DURATION) : i.$element.trigger("focus").trigger(n)
            }))
        }, o.prototype.hide = function (e) {
            e && e.preventDefault(), e = t.Event("hide.bs.modal"), this.$element.trigger(e), this.isShown && !e.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), t(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), t.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", t.proxy(this.hideModal, this)).emulateTransitionEnd(o.TRANSITION_DURATION) : this.hideModal())
        }, o.prototype.enforceFocus = function () {
            t(document).off("focusin.bs.modal").on("focusin.bs.modal", t.proxy(function (t) {
                this.$element[0] === t.target || this.$element.has(t.target).length || this.$element.trigger("focus")
            }, this))
        }, o.prototype.escape = function () {
            this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", t.proxy(function (t) {
                27 == t.which && this.hide()
            }, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
        }, o.prototype.resize = function () {
            this.isShown ? t(window).on("resize.bs.modal", t.proxy(this.handleUpdate, this)) : t(window).off("resize.bs.modal")
        }, o.prototype.hideModal = function () {
            var t = this;
            this.$element.hide(), this.backdrop(function () {
                t.$body.removeClass("modal-open"), t.resetAdjustments(), t.resetScrollbar(), t.$element.trigger("hidden.bs.modal")
            })
        }, o.prototype.removeBackdrop = function () {
            this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
        }, o.prototype.backdrop = function (e) {
            var i = this, s = this.$element.hasClass("fade") ? "fade" : "";
            if (this.isShown && this.options.backdrop) {
                var n = t.support.transition && s;
                if (this.$backdrop = t(document.createElement("div")).addClass("modal-backdrop " + s).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", t.proxy(function (t) {
                            return this.ignoreBackdropClick ? void(this.ignoreBackdropClick = !1) : void(t.target === t.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide()))
                        }, this)), n && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), !e)return;
                n ? this.$backdrop.one("bsTransitionEnd", e).emulateTransitionEnd(o.BACKDROP_TRANSITION_DURATION) : e()
            } else if (!this.isShown && this.$backdrop) {
                this.$backdrop.removeClass("in");
                var a = function () {
                    i.removeBackdrop(), e && e()
                };
                t.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", a).emulateTransitionEnd(o.BACKDROP_TRANSITION_DURATION) : a()
            } else e && e()
        }, o.prototype.handleUpdate = function () {
            this.adjustDialog()
        }, o.prototype.adjustDialog = function () {
            var t = this.$element[0].scrollHeight > document.documentElement.clientHeight;
            this.$element.css({
                paddingLeft: !this.bodyIsOverflowing && t ? this.scrollbarWidth : "",
                paddingRight: this.bodyIsOverflowing && !t ? this.scrollbarWidth : ""
            })
        }, o.prototype.resetAdjustments = function () {
            this.$element.css({paddingLeft: "", paddingRight: ""})
        }, o.prototype.checkScrollbar = function () {
            var t = window.innerWidth;
            if (!t) {
                var e = document.documentElement.getBoundingClientRect();
                t = e.right - Math.abs(e.left)
            }
            this.bodyIsOverflowing = document.body.clientWidth < t, this.scrollbarWidth = this.measureScrollbar()
        }, o.prototype.setScrollbar = function () {
            var t = parseInt(this.$body.css("padding-right") || 0, 10);
            this.originalBodyPad = document.body.style.paddingRight || "", this.bodyIsOverflowing && this.$body.css("padding-right", t + this.scrollbarWidth)
        }, o.prototype.resetScrollbar = function () {
            this.$body.css("padding-right", this.originalBodyPad)
        }, o.prototype.measureScrollbar = function () {
            var t = document.createElement("div");
            t.className = "modal-scrollbar-measure", this.$body.append(t);
            var e = t.offsetWidth - t.clientWidth;
            return this.$body[0].removeChild(t), e
        };
        var i = t.fn.modal;
        t.fn.modal = e, t.fn.modal.Constructor = o, t.fn.modal.noConflict = function () {
            return t.fn.modal = i, this
        }, t(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function (o) {
            var i = t(this), s = i.attr("href"), n = t(i.attr("data-target") || s && s.replace(/.*(?=#[^\s]+$)/, "")), a = n.data("bs.modal") ? "toggle" : t.extend({remote: !/#/.test(s) && s}, n.data(), i.data());
            i.is("a") && o.preventDefault(), n.one("show.bs.modal", function (t) {
                t.isDefaultPrevented() || n.one("hidden.bs.modal", function () {
                    i.is(":visible") && i.trigger("focus")
                })
            }), e.call(n, a, this)
        })
    }(jQuery);
    +function (a) {
        "use strict";
        var b = "Microsoft Internet Explorer" == window.navigator.appName, c = function (b, c) {
            if (this.$element = a(b), this.$input = this.$element.find(":file"), 0 !== this.$input.length) {
                this.name = this.$input.attr("name") || c.name, this.$hidden = this.$element.find('input[type=hidden][name="' + this.name + '"]'), 0 === this.$hidden.length && (this.$hidden = a('<input type="hidden">').insertBefore(this.$input)), this.$preview = this.$element.find(".fileinput-preview");
                var d = this.$preview.css("height");
                "inline" !== this.$preview.css("display") && "0px" !== d && "none" !== d && this.$preview.css("line-height", d), this.original = {
                    exists: this.$element.hasClass("fileinput-exists"),
                    preview: this.$preview.html(),
                    hiddenVal: this.$hidden.val()
                }, this.listen()
            }
        };
        c.prototype.listen = function () {
            this.$input.on("change.bs.fileinput", a.proxy(this.change, this)), a(this.$input[0].form).on("reset.bs.fileinput", a.proxy(this.reset, this)), this.$element.find('[data-trigger="fileinput"]').on("click.bs.fileinput", a.proxy(this.trigger, this)), this.$element.find('[data-dismiss="fileinput"]').on("click.bs.fileinput", a.proxy(this.clear, this))
        }, c.prototype.change = function (b) {
            var c = void 0 === b.target.files ? b.target && b.target.value ? [{name: b.target.value.replace(/^.+\\/, "")}] : [] : b.target.files;
            if (b.stopPropagation(), 0 === c.length)return void this.clear();
            this.$hidden.val(""), this.$hidden.attr("name", ""), this.$input.attr("name", this.name);
            var d = c[0];
            if (this.$preview.length > 0 && ("undefined" != typeof d.type ? d.type.match(/^image\/(gif|png|jpeg)$/) : d.name.match(/\.(gif|png|jpe?g)$/i)) && "undefined" != typeof FileReader) {
                var e = new FileReader, f = this.$preview, g = this.$element;
                e.onload = function (b) {
                    var e = a("<img>");
                    e[0].src = b.target.result, c[0].result = b.target.result, g.find(".fileinput-filename").text(d.name), "none" != f.css("max-height") && e.css("max-height", parseInt(f.css("max-height"), 10) - parseInt(f.css("padding-top"), 10) - parseInt(f.css("padding-bottom"), 10) - parseInt(f.css("border-top"), 10) - parseInt(f.css("border-bottom"), 10)), f.html(e), g.addClass("fileinput-exists").removeClass("fileinput-new"), g.trigger("change.bs.fileinput", c)
                }, e.readAsDataURL(d)
            } else this.$element.find(".fileinput-filename").text(d.name), this.$preview.text(d.name), this.$element.addClass("fileinput-exists").removeClass("fileinput-new"), this.$element.trigger("change.bs.fileinput")
        }, c.prototype.clear = function (a) {
            if (a && a.preventDefault(), this.$hidden.val(""), this.$hidden.attr("name", this.name), this.$input.attr("name", ""), b) {
                var c = this.$input.clone(!0);
                this.$input.after(c), this.$input.remove(), this.$input = c
            } else this.$input.val("");
            this.$preview.html(""), this.$element.find(".fileinput-filename").text(""), this.$element.addClass("fileinput-new").removeClass("fileinput-exists"), void 0 !== a && (this.$input.trigger("change"), this.$element.trigger("clear.bs.fileinput"))
        }, c.prototype.reset = function () {
            this.clear(), this.$hidden.val(this.original.hiddenVal), this.$preview.html(this.original.preview), this.$element.find(".fileinput-filename").text(""), this.original.exists ? this.$element.addClass("fileinput-exists").removeClass("fileinput-new") : this.$element.addClass("fileinput-new").removeClass("fileinput-exists"), this.$element.trigger("reset.bs.fileinput")
        }, c.prototype.trigger = function (a) {
            this.$input.trigger("click"), a.preventDefault()
        };
        var d = a.fn.fileinput;
        a.fn.fileinput = function (b) {
            return this.each(function () {
                var d = a(this), e = d.data("bs.fileinput");
                e || d.data("bs.fileinput", e = new c(this, b)), "string" == typeof b && e[b]()
            })
        }, a.fn.fileinput.Constructor = c, a.fn.fileinput.noConflict = function () {
            return a.fn.fileinput = d, this
        }, a(document).on("click.fileinput.data-api", '[data-provides="fileinput"]', function (b) {
            var c = a(this);
            if (!c.data("bs.fileinput")) {
                c.fileinput(c.data());
                var d = a(b.target).closest('[data-dismiss="fileinput"],[data-trigger="fileinput"]');
                d.length > 0 && (b.preventDefault(), d.trigger("click.bs.fileinput"))
            }
        })
    }(window.jQuery);
</script>
<!-- END COMMON JAVASCRIPT -->

<!-- BEGIN AJAX FOR UPDATE IMAGE-->
<script>
    $(document).ready(function () {


        $(document.body).on("click", '#close-sidebar', function () {
            if (typeof menuStatus != 'undefined') {
                if (menuStatus == true) {
                    menuStatus = false;
                    $(this).attr('title', 'Close sidebar');
                }
                else {
                    $(this).attr('title', 'Open sidebar');
                    menuStatus = true;
                }
            }
            else {
                $(this).attr('title', 'Open sidebar');
                menuStatus = true;
            }
        });

        $('#success').html('');
        $('#error').html('');
        $('#passwordSuccess').html('');
        $('#passwordError').html('');

        $(document.body).on("click", '.change-img', function () {
            $('#success').html('');
            $('#error').html('');
            $('.fileinput').fileinput('reset');
        });

        $(document.body).on("click", '.change-pass', function () {
            $('#passwordSuccess').html('');
            $('#passwordError').html('');
            $('#oldPassword').val('');
            $('#newPassword').val('');
            $('#password_confirmation').val('');
        });

        $(document.body).on("click", '#photoArea', function () {
            $('#success').html('');
            $('#error').html('');
            $('#fileInputExist1').removeClass('hidden');
            $('#fileInputExist2').removeClass('hidden');
            $('#fileInputNew').removeClass('show');
        });

        $("form[name='profilePicForm']").submit(function (event) {
            $('#success').html('');
            $('#error').html('');
            var formData = new FormData($(this)[0]);
            $.ajax({
                url: "/updatePic",
                type: "POST",
                data: formData,
                async: false,
                cache: false,
                contentType: false,
                processData: false,
                dataType: 'JSON',
                success: function (response) {
                    if (response == 'success') {
                        $('#success').html('Your profile picture has been successfully updated.');
                        $('#fileInputExist1').addClass('hidden');
                        $('#fileInputExist2').addClass('hidden');
                        $('#fileInputNew').addClass('show');
                    }
                    else if (response == 'fail')
                        $('#error').html('Sorry! Your profile picture has not been updated.');
                    else
                        $('#error').html(response);
                }
            });
            event.preventDefault();
        });


        $(document.body).on("click", '#updatePassword', function (event) {
            $('#passwordSuccess').html('');
            $('#passwordError').html('');
            var oldPassword = $('#oldPassword').val();
            var newPassword = $('#newPassword').val();
            var password_confirmation = $('#password_confirmation').val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "/updatePassword",
                type: "POST",
                data: {
                    oldPassword: oldPassword,
                    newPassword: newPassword,
                    password_confirmation: password_confirmation,
                },
                dataType: 'JSON',
                success: function (response) {
                    if (response == 'success') {
                        $('#passwordSuccess').html('Your password has been successfully updated.');
                        $('#oldPassword').val('');
                        $('#newPassword').val('');
                        $('#password_confirmation').val('');
                    }
                    else if (response == 'Your old password was wrong.') {
                        $('#passwordError').html(response);
                        $('#oldPassword').val('');
                        $('#newPassword').val('');
                        $('#password_confirmation').val('');
                    }
                    else
                        $('#passwordError').html(response);
                }
            });
            event.preventDefault();
        });
    });
</script>
<!-- END AJAX FOR UPDATE IMAGE-->

<!-- BEGIN AJAX FOR NOTIFICATION -->


<script type="text/javascript">

    $(document).ready(function () {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        getNotification();

        setInterval(function () {
            getNotification();
        }, 10000);

        function getNotification() {
            $.ajax({
                url: "/notificationAjax",
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'viewNewNotificationList',
                },
                success: function (response) {
                    if (response != 'fail') {
                        if (response.length == 0) {
                            $('.notifications-count').html('');
                            $('.notifications-box').html('<li>' +
                                    '<span  style="margin-left: 88px;" class="notification-text font-blue">' +
                                    'There are no new notification.' +
                                    '</span>' +
                                    '</li>');
                        }
                        else {
                            $('.notifications-box').html('');
                            $('.notifications-count').html('');
                            $('.notifications-count').html(response.length);
                            var notification = '';

                            $.each(response, function (key, value) {
                                var diff = Math.abs(new Date() - new Date(value['created_at']));
                                var seconds = Math.floor(diff / 1000); //ignore any left over units smaller than a second
                                var minutes = Math.floor(seconds / 60);
                                seconds = seconds % 60;
                                var hours = Math.floor(minutes / 60);
                                minutes = minutes % 60;
                                var day = null;
                                if (hours > 24) {
                                    day = Math.floor(hours / 24);
                                    hours = Math.floor(hours - (24 * day));
                                }
                                var finalTime = '';

                                if (minutes == 0)
                                    finalTime = seconds + ' seconds ago';
                                else if (hours == 0)
                                    finalTime = minutes + ' minutes ago';
                                else if (day == null)
                                    finalTime = hours + ' hours ago';
                                else
                                    finalTime = day + ' day ago';

                                notification = notification + '<li>' +
                                        '<span class="bg-warning icon-notification glyph-icon icon-linecons-note"></span>' +
                                        ' <span class="notification-text font-gray-dark">' +
                                        ' <a id="notifications" data-notificationId="' + value.notification_id + '" href="">' + value.message +
                                        '<br><i style="color:#03A9F4;">' + finalTime + '</i>' +
                                        ' </a>' +
                                        ' </span>' +
                                        ' </li>';
                            });
                            $('.notifications-box').html(notification);
                        }
                    }
                    else
                        console.log(response);
                }
            });
        }

        $(document.body).on("click", '#notifications', function (event) {
            event.preventDefault();
            $.ajax({
                url: "/notificationAjax",
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'changeNotificationStatus',
                    notificationId: $(this).attr('data-notificationId'),
                },
                success: function (response) {
                    if (response != 'fail') {
                        window.location.replace("/viewOrder");
                    }
                    else
                        console.log(response);
                }
            });
        });

    });

</script>

<!-- END  AJAX FOR NOTIFICATION  -->

<!-- BEGIN OPTIONAL JAVASCRIPT -->
@yield('script')
        <!-- END OPTIONAL JAVASCRIPT -->


</body>
</html>
