<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>
    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <!--<title>Ali-Club</title>-->
    <title>Ali-Club</title>
    <meta name="description" content="Grocery - online Grocery">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="author" content="AllThatIsRam">

    <link rel="stylesheet" href="/assets/admin/css/animate.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/plugin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/widget.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/admin.min.css" />
    <link rel="stylesheet" href="/assets/admin/css/custom.css" />

    <!-- BEGIN OPTIONAL HEAD -->
    <style>
        html,
        body {
            height: 100%;
            background: #fff
        }

        .error {
            color: #FB0007;
        }

        .shop-pic, #signUp {
            display: none;
            text-align: center;
        }
    </style>
    <!-- END OPTIONAL HEAD -->
</head>
<!-- END HEAD -->
<body>

<!-- BEGIN MAIN CONTENT -->
<div id="loading">
    <div class="svg-icon-loader">
        <img src="assets/admin/images/bars.svg" width="40" alt="loader">
    </div>
</div>
<div class="center-vertical login-bg">
    <div class="center-content">
        <form action="/login" class="col-md-4 col-sm-5 col-xs-11 col-lg-3 center-margin"
              method="post">
            {{csrf_field()}}
            {{--<input type="hidden" name="_token" value="mqpFHsEPN67VeTWhd6gkyf74H1lhMPWKTrwRx9St">--}}
            <div id="header-logo" class="logo-bg"
                 style="background-color: white; border-radius: 8px 8px 0px 0px; margin: 0px 0px -2px; height: 62px;">
            </div>
            <div id="login-form" class="content-box bg-default">
                <div class="content-box-wrapper pad20A">
                    <center>
                        <img class="mrg25B center-margin radius-all-100 login-user-pic admin-pic"
                             src="assets/admin/images/default_admin.png" alt="Admin"/>
                    </center>
                    <span class="error"></span>
                    <span class="error"> </span>
                    <div class="form-group" style="display: inline-flex;">
                        <div class="radio-danger">
                            <label>
                                <input type="radio" name="role" class="custom-radio" id="role_admin"
                                       value="3" checked /> Admin
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-envelope-o"></i></span>
                            <input type="text" name="email" class="form-control"
                                   placeholder="Enter email" value=""/>
                            <span class="error"> </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                                <span class="input-group-addon addon-inside bg-gray"><i
                                            class="glyph-icon icon-unlock-alt"></i></span>
                            <input type="password" name="password" class="form-control"
                                   placeholder="Password"/>
                            <span class="error"> </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-block btn-primary">Login</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- END MAIN CONTENT -->

<!-- BEGIN COMMON JAVASCRIPT -->
<script src="/assets/admin/js/jquery-core.js"></script>
<script src="/assets/admin/js/jquery-ui-core.js"></script>
<script src="/assets/admin/js/slimscroll.js"></script>
<script src="/assets/admin/js/material.js"></script>
<script src="/assets/admin/js/ripples.js"></script>
<script src="/assets/admin/js/custom.js"></script>
<script src="/assets/admin/js/layout.js"></script>

<script>
    $(window).load(function () {
        setTimeout(function () {
            $('#loading').fadeOut(400, "linear");
        }, 300);
    });
</script>
<!-- END COMMON JAVASCRIPT -->

<!-- BEGIN OPTIONAL JAVASCRIPT -->

<script>
    $(document).ready(function () {

        if ($("#role_admin:checked").val()) {
            $('.admin-pic').show();
            $('.shop-pic').hide();
            $('#signUp').hide();
        }
        else {
        }
    });

    $("#role_admin").change(function () {
        if (this.checked) {
            $('.admin-pic').show();
            $('.shop-pic').hide();
            $('#signUp').hide();
        }
    });

</script>

<!-- END OPTIONAL JAVASCRIPT -->
</body>
</html>
