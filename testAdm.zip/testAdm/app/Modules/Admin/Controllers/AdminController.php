<?php

namespace App\Modules\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{


    public function login(Request $request)
    {
//        dd('login');
        if ($request->isMethod('get')){
            return view('Admin::login');
        }else{
            return redirect()->route('adminDashboard');
            return redirect('/adminDashboard');
        }

    }

    public function dashboard(Request $request)
    {
        if ($request->isMethod('get')){
//            dd('Get Dashboard');
            return view('Admin::dashboard');
        }else{
            dd('post Dashboard');
            return redirect()->route('dashboard');
        }

    }

    public function userList(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::userList');
        }else{
            dd('post Dashboard');
            return redirect()->route('dashboard');
        }

    }

    public function addProduct(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::addProduct');
        }else{
            dd($request->all(),'post Dashboard');
            return redirect()->route('dashboard');
        }

    }

    public function viewProductDetail(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::viewProduct');
        }else{
            dd('post Dashboard');
            return redirect()->route('viewProduct');
        }

    }

    public function viewProductList(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::viewProductList');
        }else{
            dd('post Dashboard');
            return redirect()->route('viewProductList');
        }

    }

    public function editProductDetail(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::viewProduct');
        }else{

            dd($request->all(),'post editProductDetail');
            return redirect()->route('viewProductList');
        }

    }

    public function addProductType(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Admin::addProduct');
        }else{

            dd($request->all(),'post addProductType');
        }

    }
}
