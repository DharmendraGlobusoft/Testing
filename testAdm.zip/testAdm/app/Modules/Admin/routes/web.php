<?php

Route::group(['module' => 'Admin', 'middleware' => ['web'], 'namespace' => 'App\Modules\Admin\Controllers'], function() {

    Route::resource('Admin', 'AdminController');

    Route::match(['get','post'],'/login','AdminController@login');
    Route::match(['get','post'],'/logout','AdminController@login');
    Route::match(['get','post'],'/adminDashboard','AdminController@dashboard')->name('adminDashboard');
    Route::match(['get','post'],'/userList','AdminController@userList')->name('userList');
    Route::match(['get','post'],'/addProduct','AdminController@addProduct')->name('addProduct');
    Route::match(['get','post'],'/editProductDetail','AdminController@editProductDetail')->name('editProductDetail');
    Route::match(['get','post'],'/viewProductList','AdminController@viewProductList')->name('viewProductList');
    Route::match(['get','post'],'/viewProductDetail','AdminController@viewProductDetail')->name('viewProductDetail');
    Route::match(['get','post'],'/addProductType','AdminController@addProductType')->name('addProductType');


});
