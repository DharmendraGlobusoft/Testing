<?php

/**
 *	Admin Helper  
 */