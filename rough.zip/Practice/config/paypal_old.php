<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/6/2018
 * Time: 10:50 AM
 */
?>
<?php

return array(

    /** set your paypal credential **/
    //App Client id and secret key
    'client_id' => 'AQQ0jLYlcUmWRLGW8DtzYrweU7HSRubPaE4W2uhMwawNQw1azf83NCd-0bJyy5PrCilnofBxzV8Cdopy',
    'secret' => 'EFqWe5MoKX5xhMBdZUzPHYcQlCx_OrSYJTxNnxu1UQOhqT3h3Q2NZq2wTMzwmaE_sozu27cAXRc47m09',

    //Business Account Username,PW and Signature
    'username'  => 'sharmaglobussoft-facilitator_api1.gmail.com',
    'password'  => 'HYYTY6RTA2P7Q9X9',
    'signature' => 'A0htNNVz3Y6mOXvZAhNukqvso5kDAO5WL..ZnDMG6LjrJ45W8659Cnqn',

//    'currencyCodeType' => 'INR',
//    'paymentType' => 'Sale',

    //For Live specially use for Recurring
//    'sandboxFlag' => false,

    //For Sandbox specially use for Recurring
    'sandboxFlag' => true,

    /**
     * SDK configuration
     */
    'settings' => array(
        /**
         * Available option 'sandbox' or 'live'
         */
        'mode' => 'sandbox',
//        'mode' => 'live',
        /**
         * Specify the max request time in seconds
         */
        'http.ConnectionTimeOut' => 1000,
        /**
         * Whether want to log to a file
         */
        'log.LogEnabled' => true,
        /**
         * Specify the file that want to write on
         */
        'log.FileName' => storage_path() . '/logs/paypal.log',
        /**
         * Available option 'FINE', 'INFO', 'WARN' or 'ERROR'
         * Logging is most verbose in the 'FINE' level and decreases as you
         * proceed towards ERROR
         */
        'log.LogLevel' => 'FINE'
    ),
);
