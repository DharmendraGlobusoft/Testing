<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/checkApi', 'CheckController@ckApi');  //http://localhost.practice.com/checkApi   give this url in postman
//Route::get('/checkApi', function (){
//    return Response::json(["check" => "From main web route"]);
//});  //http://localhost.practice.com/checkApi   give this url in postman

//=========================== Recurring Payment Section =================================================

Route::get('/recurring-payment', 'PaymentController@payment');
Route::get('/paymentReturn', 'PaymentController@paymentReturn');
Route::get('/cancelPayment','PaymentController@cancelPayment');

Route::post('/cancel-recurring-subscriptions', 'PaymentController@cancelReurringSubscriptions');




//-----------------------------resize image----------------------------------------------------
Route::get('resizeImage', 'CheckController@resizeImage');
Route::post('resizeImagePost',['as'=>'resizeImagePost','uses'=>'CheckController@resizeImagePost']);

//-----------------------------Speed up your website------------------------------------

Route::get('mySource', function () {

    return view('mySource');

});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
