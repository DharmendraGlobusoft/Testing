<!DOCTYPE html>

<html>

<head>

    <title>My Source</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />

</head>

<body>


<div class="container">

    <h1>My Source</h1>

    <table class="table table-bordered sortable">

        <thead>

        <tr>

            <th>No</th>

            <th>Name</th>

            <th>Email</th>

        </tr>

        </thead>

        <tbody>

        <tr>

            <td>1</td>

            <td>Haresh</td>

            <td>haresh@gmail.com</td>

        </tr>

        <tr>

            <td>2</td>

            <td>Vimal</td>

            <td>vimal@gmail.com</td>

        </tr>

        <tr>

            <td>3</td>

            <td>Harshad</td>

            <td>harshad@gmail.com</td>

        </tr>

        <tr>

            <td>4</td>

            <td>Raju</td>

            <td>raju@gmail.com</td>

        </tr>

        <tr>

            <td>5</td>

            <td>Paresh</td>

            <td>paresh@gmail.com</td>

        </tr>

        </tbody>

    </table>

</div>


</body>

</html>
