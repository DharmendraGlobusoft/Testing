<?php

namespace App\Modules\Staff\Models;

use Illuminate\Database\Eloquent\Model;

class Staff extends Model {

    //

}
