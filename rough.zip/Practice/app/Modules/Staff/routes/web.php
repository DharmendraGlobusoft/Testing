<?php

Route::group(['module' => 'Staff', 'middleware' => ['web'], 'namespace' => 'App\Modules\Staff\Controllers'], function() {




    Route::group(array('prefix' => 'staff'), function () {

//---------------------------------These are the routes having only prefix-----------------------------

        Route::match(['get','post'],'/staffLogin', 'StaffController@staffLogin')->name('staffLogin');


//-----------------------------------These routes have middleware--------------------------------------

        Route::group(['middleware' => 'differentiate:staff'], function () {

            Route::get('/staffDashboard', 'StaffController@staffDashboard')->name('staffDashboard');
            Route::get('/staffLogout', 'StaffController@staffLogout')->name('staffLogout');


        });


    });





});
