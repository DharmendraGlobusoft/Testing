<?php

namespace App\Modules\Staff\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class StaffController extends Controller
{


    public function staffLogin(Request $request)
    {

        if ($request->isMethod('get')){

            return view('Staff::staffLogin');

        }else{
            Session::put(['staffId'=>'staffId']);
            return redirect()->route('staffDashboard');
        }

    }

    public function staffDashboard(Request $request)
    {
        return view('Staff::staffDashboard');
    }


    public function staffLogout(Request $request)
    {
        Session::forget('staffId');
        return redirect()->route('staffLogin');
    }



}
