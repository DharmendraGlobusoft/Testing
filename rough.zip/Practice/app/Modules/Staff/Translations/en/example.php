<?php 

return [
    'welcome' => 'Welcome, this is Staff module.'
];
