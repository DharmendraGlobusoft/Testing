<?php 

return [
    'welcome' => 'Welcome, this is Demo module.'
];
