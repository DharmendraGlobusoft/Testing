<?php

namespace App\Modules\Demo\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Demo extends Model {

    //



    public function verifyUserName($username)
    {
        return DB::table('users')->where('user_name',$username)->first();
    }

    public function insertData($value)
    {
        return DB::table('users')->insertGetId($value);
    }

    public function getAllData()
    {
        return DB::table('users')->get();
    }

    public function getData($id)
    {
        return DB::table('users')->where('id',$id)->first();
    }

    public function editData($data)
    {
//        dd($data);
        if (DB::table('users')->where('id',$data['id'])->update($data))
        {
            return DB::table('users')->where('id',$data['id'])->first();
        }
        return 0;
    }

}
