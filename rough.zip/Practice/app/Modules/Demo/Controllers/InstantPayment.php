<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 10/1/2018
 * Time: 3:48 PM
 */

namespace App\Modules\Demo\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Srmklive\PayPal\Facades\PayPal;
use Srmklive\PayPal\Services\ExpressCheckout;
use Srmklive\PayPal\Services\AdaptivePayments;

class InstantPayment extends Controller
{
    public function instantPayment(Request $request)
    {
        if ($request->isMethod('get')){
            return view('Demo::instantPayment');
        }else{

            $data = [];
            $data['items'] = [
                [
                    'name' => 'Instant Payment Recharge',
                    'price' =>$request->all()['amount']
                ]
            ];

            $data['invoice_id'] = 1;
            $data['invoice_description'] = "Order #{$data['invoice_id']} Invoice";
            $data['return_url'] = url('/paymentReturn');
            $data['cancel_url'] = url('/cancelPayment');
            $data['total'] = $request->all()['amount'];
            $provider = new ExpressCheckout();
            $response = $provider->setExpressCheckout($data,true);
            dd($response,'lolf');
        }
    }

}