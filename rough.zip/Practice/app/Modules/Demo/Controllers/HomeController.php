<?php


namespace App\Modules\Demo\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class HomeController extends Controller

{

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function myCaptcha()

    {

        return view('Demo::myCaptcha');

    }


    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function myCaptchaPost(Request $request)

    {
//        dd($request->all());

        request()->validate([

            'email' => 'required|email',

            'password' => 'required',

            'captcha' => 'required|captcha'

        ],

            ['captcha.captcha' => 'Invalid captcha code.']);

        dd("You are here :) .");

    }


    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function refreshCaptcha()

    {
        $result = captcha_img();
        $pattern = "/^<img ([^ ]+)/";


        if (preg_match($pattern, $result, $list)) {
            return response()->json(['captcha'=> $list[1]]);
        }else{
            dd('Error');
        }



    }

}
