<?php


namespace App\Modules\Demo\Controllers;

use Illuminate\Http\Request;


use Illuminate\Support\Facades\Session;
use Stripe;
use App\Http\Controllers\Controller;

class StripePaymentController extends Controller
{

    /**

     * success response method.

     *

     * @return \Illuminate\Http\Response

     */

    public function stripe()

    {

        return view('Demo::stripe');

    }



    /**

     * success response method.

     *

     * @return \Illuminate\Http\Response

     */

    public function stripePost(Request $request)

    {

        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

        Stripe\Charge::create ([

            "amount" => 10*100 , //to make payment of $10 have to write like 10*100 for $5, 5*100 means 100 is required

            "currency" => "usd",

            "source" => $request->stripeToken,

            "description" => "Test payment from itsolutionstuff.com."

        ]);

       Session::flash('success', 'Payment successful!');

        return back();

    }
}
