<?php

namespace App\Modules\Demo\Controllers\API;

use App\Http\Controllers\Controller;

class APIController extends Controller
{
    public function apiTest()
    {
        return response()->json(['check' => "Data From Module Route api"]);
    }

}
