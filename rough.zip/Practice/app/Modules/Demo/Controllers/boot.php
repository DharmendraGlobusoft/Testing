<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 10/11/2018
 * Time: 5:42 PM
 */


//require vendor/autoload.php;  D:\laravel\Practice\app\Modules\Demo\Controllers\boot.php

//require(base_path() . '/app/Modules/Staff/Controllers/copyscape_premium_api.php');
include(base_path('vendor').'\braintree\braintree_php\lib\autoload.php');

$gateway = new Braintree_Gateway([
    'environment' => 'sandbox',
    'merchantId' => 'hz5vrs7ygkzm4zmk',
    'publicKey' => '57bjs6kt5sp8hy5y',
    'privateKey' => '90ef97123dbc9e53d45e8322ddfe41b4'
]);


?>