<?php


namespace App\Modules\Demo\Controllers;


use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Excel;
//use Excel;

class PracticeController extends Controller
{

    public function ajaxImageUpload(Request $request)
    {
        if ($request->isMethod('get')) {
            return view('Demo::ajaxImageUpload');
        } else {

            $validator = Validator::make($request->all(), [
                'title' => 'required',
                'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

            if ($validator->passes()) {

//                This is to generate unique random characters
                $seed = str_split('abcdefghijklmnopqrstuvwxyz'
                    . 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                    . '0123456789!@#$%^&*()'); // and any other characters
                $rand = '';
                foreach (array_rand($seed, 20) as $k) $rand .= $seed[$k];

                $input = $request->all();
                $input['image'] = time() . '-' . $rand . '.' . $request->image->getClientOriginalExtension();
                $request->image->move(public_path('images'), $input['image']);

//            AjaxImage::create($input);    //This is for saving image path to db
                return response()->json(['code' => 200, 'success' => 'done', 'msg' => 'Dharmendra Kumar Sharma']);
            }
            return response()->json(['error' => $validator->errors()->all()]);
        }

    }

    public function tooltip(Request $request)
    {
        return view('Demo::tooltip');
        dd('tooltip');
    }

    public function frontvalidation(Request $request)
    {
        return view('Demo::frontValidation');
    }

    public function checkMD()
    {
        dd('This Request Passed Middleware Successfully');
    }

    public function generatePdf()
    {


    }


}
