<?php

namespace App\Modules\Demo\Controllers;

use App\bear;
use App\Modules\Demo\Models\Demo;
use App\test;
use App\User;
use function GuzzleHttp\Promise\all;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\QrCode;
use Yajra\DataTables\Services\DataTable;
use File;

class DemoController extends Controller
{


//*******************Signup*************************
    public function signup(Request $request)
    {
//        use this for validation

//        $rules = ['api_token' => 'required'];
//        $message = ['api_token.required' => 'Please Enter API TOKEN'];
//        $response = array('response' => '', 'Success' => false);
//        $validator = Validator::make($request->input(), $rules, $message);
//        if ($validator->fails()) {
//            //
//        }else{
//            //
//        }




        $code = json_decode(json_encode(DB::table('countryCode')->get(), true), true);
        if ($request->isMethod('get')) {
            return view('Demo::signup', ['code' => $code]);
        } else {
            $data = $request->all();
            $validationResponse = Validator::make($data, [
                'name' => 'required',
                'username' => 'required',
                'email' => 'required|email',
                'password' => 'required',
            ]);
            if ($validationResponse->fails()) {
                return Redirect::back()->withErrors($validationResponse)->withInput($request->input());
            }


            $username = $data['username'];
            $obj = new Demo();
            $res = $obj->verifyUserName($username);

            $result = json_decode(json_encode($res, true), true);
            if ($result['user_name'] == $data['username']) {
                return view('Demo::signup', ['code' => $code]);
            }
            $a = array(
                0 => 2,
                1 => 3,
                2 => 4
            );

            $d = implode(",", $a); // this will convert array to string

            $value = array();
//            $value['name'] = "[" .$d. "]";//this will store data in db in array format,to use it as array use explode "$c=explode(',',$d);"
            $value['name'] = $data['name'];
//            $value['name'] = ($a);
            $value['user_name'] = $data['username'];
            $value['email'] = $data['email'];
            $value['password'] = Hash::make($data['password']);
            $value['confirm_password'] = $data['confirm_password'];
            $obj = new Demo();
            $res = $obj->insertData($value);
            if ($res) {
                return redirect('/login', ['code' => $code]);
            } else {
                return redirect()->back()->with('msg', 'Failed to Signup, please try Again..!!');
            }
        }
    }

//*****************************AJAX VERIFY********************************
    public function ajaxVerify(Request $request)
    {
        $username = $request->all()['username'];
        $obj = new Demo();
        $result = $obj->verifyUserName($username);
        if ($result) {
            return Response::json(['msg' => 1]);
        } else {
            return Response::json(['msg' => 0]);
        }
    }

//****************************Login*********************************
    public function login(Request $request)
    {
        if ($request->isMethod('get')) {
            return view('Demo::login');
        } else {
            $data = $request->all();
            $email = $data['email'];
            $password = $data['password'];
            if (Auth::attempt(['email' => $email, 'password' => $password])) {
                return redirect('/table');
            } else {
                return redirect()->back()->with('msg', "Please enter valid credentials..!!");
            }
        }
    }

//****************************Table**********************************
    public function table(Request $request)
    {
        if ($request->isMethod('get')) {
            $obj = new Demo();
            $res = $obj->getAllData();
            $result = json_decode(json_encode($res, true), true);
            dd($result);

            return view('Demo::table', ['result' => $result]);
        }
    }

    public function editData(Request $request)
    {
        $obj = new Demo();
        $arr = array();
        $arr['id'] = $request->all()['id'];
        $arr['name'] = $request->all()['name'];
        $arr['user_name'] = $request->all()['username'];
        $arr['email'] = $request->all()['email'];
        $res = $obj->editData($arr);
        if ($res) {
            return Response::json(['msg' => $res]);
        }
        return Response::json(['msg' => 0]);

    }

    public function getData(Request $request)
    {
        $obj = new Demo();
        $res = $obj->getData($request->all()['id']);
        $result = json_encode($res, true);
//        $result = json_decode(json_encode($res, true),true);
//        return Response::json(['data'=>$result]);

        return $result;
    }

    public function apiCheck()
    {
        $client = new \GuzzleHttp\Client();
        $headers = ['Content-Type' => 'application/json'];
        $url = env('APP_URL') . "/checkApi";
        $res = $client->request('GET', $url, ['headers' => $headers]);
        $getCatData = json_decode($res->getBody());
        dd($getCatData, 'Sharma');// from here we can write our signup or login logics
    }

    public function demo()
    {
        return Response::json(['Msg' => 'This is my first Api']);
    }

    public function invoice(Request $request)
    {
        return view('Demo::invoice');
    }

    public function test()
    {
        $url="http://localhost.practice.com/test1";
//================================================================================================================

//        $data = json_decode(file_get_contents($url), true);  //we can use only this line to get file content as curl
//        dd($data);

// =======================Both will work same the above and below code=======================

        $cSession = curl_init();
        curl_setopt($cSession, CURLOPT_URL, $url);
        curl_setopt($cSession, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($cSession, CURLOPT_HEADER, false);
        $result = curl_exec($cSession);
        curl_close($cSession);
        dd(trim($result), 'completed');

//================================================================================================================

//
////create a new cURL resource
//        $ch = curl_init($url);
//
////setup request to send json via POST
//        $data = array(
//            'username' => 'codexworld',
//            'password' => '123456'
//        );
//        $payload = json_encode(array("user" => $data));
//
////attach encoded JSON string to the POST fields
//        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
//
////set the content type to application/json
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
//
////return response instead of outputting
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//
////execute the POST request
//        $result = curl_exec($ch);
//
////close cURL resource
//        curl_close($ch);
//
//        echo $result;





    }

    public function test1(Request $request)
    {
        $post = [
        'username' => 'Dharmendra',
        'password' => 'passuser1',
        'gender'   => 1,
    ];
//        $json=json_encode($data['name']=$post);
        return $post;
    }

    public function test2()
    {
        dd('test');
    }

    public function redis()
    {
//        $data = json_decode(file_get_contents('http://ip-api.io/api/json'));
//        $data1 = json_encode(file_get_contents('http://ip-api.io/api/json'));
//        dd(json_decode(json_decode($data1,true),true));
//        dd(file_get_contents('http://ip-api.io/api/json'),$data,$data1,json_encode($data,true));


        $cars = [1, 2, 3, 4, 5, 6];

//        dd($cars);

//        Redis::RPUSH('no',$cars);      // insert data into redis
//        $value = Redis::LRANGE('no',0,-1);   // print all datas
        $value = Redis::LRANGE('no', 0, -1);
//        $value = Redis::LTRIM('no',50,-1);
        dd($value);
        $redis = new Redis();
        $connect = $redis->connect('127.0.0.1', 6379);
        dd($connect);

    }

    public function config()
    {
        $id2 = 2;
        $id3 = 3;
        $id4 = 4;
        $webConfigPath = base_path() . '/config/userInfo.php';
        $fileContent = "<?php
            return [
             '1' => [
                'first_name'=>'Ashu',
                'last_name'=>'Sharma1',
                    ]
            ];";

        file_put_contents($webConfigPath, $fileContent);

//        $configData = Config::get('userInfo.1' );
//        dd($configData);
        $userId = 10;
        $arr = array();
        $arr['name'] = 'Sharma';
        $arr['email'] = 'Sharma@gmail.com';
        $arr['pwd'] = 'Sharma@123';


        Config::set([
            'userInfo.' . $id2 . '.first_name' => 'first_name22',
            'userInfo.' . $id3 . '.first_name' => 'first_name33',
            'userInfo.' . $id4 . '.first_name' => 'first_name44',
            'userInfo.' . $userId . '.data' => $arr,
        ]);


        $name1 = Config::get('userInfo.' . $id2 . '.first_name');
        $name2 = Config::get('userInfo.' . $id3 . '.first_name');
        $name3 = Config::get('userInfo.' . $id4 . '.first_name');
        $userData = Config::get('userInfo.' . $userId );
        $configData = Config::get('userInfo.1');

        dd($name1, $name2, $name3, $userData,$configData);
    }

    public function popup()
    {
        dd('test');
        return view('Demo::popup');
    }

    public function fact()
    {
        $num = 10;
        $sum = 1;
        if ($num == 1) {
            echo 'Factorial of given number is 1';
        } else {
            function fun($num, $sum)
            {
                $temp = $sum * $num;
                $num = $num - 1;
                $sum = $temp;
                if ($num == 1) {
                    echo 'Factorial of given number is:' . $sum;
                    return false;
                }
                fun($num, $sum);
            }

            fun($num, $sum);

        }

    }

    public function distance()
    {
        $addressFrom = 'sr nagar,hyderabad';
        $addressTo = 'kukatpalle,hyderabad';
//        $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$addressTo.'&sensor=false&key=AIzaSyBK7R4gcOXGiNcPW7quD4lyReHudeUP0NQ');
//        $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$addressTo.'&sensor=false&key=AIzaSyAPBuw5pMayuW4kGTttoVaBqTa2E6MNysc');
//        $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$addressTo.'&sensor=false&key=AlzaSyCW-LxWC1ML0a6FbUzgC6ExKfh6xrb8oZM');
//        $geocode = file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$addressTo.'&sensor=false&key=AIzaSyAAjFSClVYqS8uWbI4-2-DJwAEg-i2mg-U');
//        $api = file_get_contents("https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=".$addressFrom."&destinations=".$addressTo."&key=AIzaSyAAjFSClVYqS8uWbI4-2-DJwAEg-i2mg-U");
        $data = file_get_contents("http://maps.googleapis.com/maps/api/geocode/json?address=" . urlencode($addressFrom) . "&sensor=true");

        $details = json_decode($data, true);
        dd($details);

    }

    public function hcf($num1 = null, $num2 = null)
    {
        $data = $this->getLcmHcf($num1, $num2);
        dd($data, '====ok====');

    }

    public function getLcmHcf($num1, $num2)
    {
        global $n1;    //greater number
        global $n2;    //smaller number
        if ($num1 == null || $num2 == null) {
            dd('Pass two numbers in url to see result,  Example http://localhost.practice.com/hcf/14/18');
        } elseif ($num1 == $num2) {
            dd('HCF is ' . $num1);
        } elseif ($num1 > $num2) {
            $n1 = $num1;
            $n2 = $num2;
        } elseif ($num2 > $num1) {
            $n1 = $num2;
            $n2 = $num1;
        }
        function lcm($b)
        {
            $arr = array();
            global $n1;
            global $n2;
            $lcm = ($n1 * $n2) / $b;
            $arr['LCM'] = $lcm;
            $arr['HCF'] = $b;
            return $arr;
        }

        function hcf($a, $b)
        {
            $temp1 = $a % $b;
            if ($temp1 == 0) {
                $Lcm = lcm($b);
                return $Lcm;
            } else {
                return hcf($b, $temp1);
            }
        }

        $data = hcf($n1, $n2);
        return $data;
    }

    public function QRcode(Request $request)
    {
        return view('Demo::Qrcode');
    }

    public function NewQRcode(Request $request)
    {

        $data = array();
        $data['name'] = 'Dharmendra';
        $data['email'] = 'sharmaglobussoft@gmail.com';
        $data['mobile'] = '7205189279';
        $res = json_encode($data, true);
        $qrCode = new QrCode($res);
        $qrCode->setWriterByName('png');
        $qrCode->setMargin(10);
        $qrCode->setEncoding('UTF-8');
        $qrCode->setErrorCorrectionLevel(ErrorCorrectionLevel::HIGH);
        $qrCode->setForegroundColor(['r' => 0, 'g' => 0, 'b' => 0, 'a' => 0]);
        $qrCode->setBackgroundColor(['r' => 255, 'g' => 255, 'b' => 255, 'a' => 0]);
        $qrCode->setLogoSize(150, 200);
        $qrCode->setRoundBlockSize(true);
        $qrCode->setValidateResult(false);
        $qrCode->setWriterOptions(['exclude_xml_declaration' => true]);
        header('Content-Type: ' . $qrCode->getContentType());
        echo $qrCode->writeString();
        $qrCode->writeFile('D:\laravel\Practice\public\assets\images\qrcode.png');
        dd('ok');
    }

    public function Blade()
    {
        $a = 5;
        return view('Demo::testBlade', ['data' => $a]);
    }

    public function DataTable()
    {
        $obj = new Demo();
        $res = $obj->getAllData();
        $result = json_decode(json_encode($res, true), true);
        return view('Demo::datatable', ['data' => $result]);
    }


    public function tableAjax(Request $request)
    {
        $obj = new Demo();
        $res = $obj->getAllData();
        $result = json_decode(json_encode($res, true), true);

        $fullData = new Collection();
        $i = 1;
        foreach ($result as $key => $val) {
            $fullData->push([
                'id' => $i,
                'name' => $val['name'],
                'user_name' => $val['user_name'],
                'email' => $val['email'],
            ]);

            $i++;
        }
        return DataTable::of($fullData)
            ->make(true);
    }

    public function TestArray()
    {

        echo date("Y-m-d H:i:s", strtotime("2018-09-02T07:00:00Z")) . "\n";
        echo date("Y-m-d H:i:s", strtotime("2018-12-01T22:18:00Z")) . "\n";
        dd('ok');

    }

    public function sendEmail()
    {
        dd('email', 'Only use this much code to send email usind send grid');

        $pass = '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';// not the key, but the token
        $url = 'https://api.sendgrid.com/';
        $res = templetForEmail('Hii Dharmendra Sharma');
        $params = array(
            'to' => 'sharmaglobussoft@gmail.com',
            'subject' => 'Testing Send grid',
//            'html' => 'Hii this is for testing',
            'html' => $res,
            'from' => 'dharmendrasharma@globussoft.in',
        );
        $request = $url . 'api/mail.send.json';
        $headr = array();
// set authorization header
        $headr[] = 'Authorization: Bearer ' . $pass;

        $session = curl_init($request);
        curl_setopt($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_POSTFIELDS, $params);
        curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($session, CURLOPT_HTTPHEADER, $headr);
        $response = curl_exec($session);
        curl_close($session);
        dd($response, 'Response from Send grid');
    }

    public function palindrome()
    {
//        ========================Enter Your string===================
        $testStr = 'aaagH75Hgaaa';
        $str = strtolower($testStr);
        $arr = str_split($str);
        $a = 0;
        $len = count($arr);
        $k = floor($len / 2);
        for ($i = 0; $i < $len; $i++) {
            if ($arr[$i] == $arr[$len - ($i + 1)]) {
                if ($i == $k) {
                    break;
                } else {
                    $i++;
                }
            } else {
                $a++;
                break;
            }
        }
        if ($a == 0) {
            dd('Input', $testStr, 'Output ', 'PALINDROME');
        } else {
            dd('Input', $testStr, 'Output ', 'NOT PALINDROME');
        }
    }

    public function assArray(Request $request)
    {
//        ========================Enter Your array===================

        $testArray = [
            'a' => 1,
            'b' => 4,
            'e' => 3,
            'c' => 1,
            'd' => 4,
            'g' => 1,
            'h' => 5,
            'q' => 3,
            'f' => 1,
        ];
        $str = '';
        $arr2 = array_unique($testArray);
        $res = [];
        foreach ($arr2 as $k => $v) {
            foreach ($testArray as $k1 => $v1) {
                if ($v == $v1) {
                    $str = $str . ',' . $k1;
                }
            }
            $res[$v] = '[' . substr($str, 1) . ']';
            $str = '';
        }
        dd('Input', $testArray, 'Output ', $res);

    }

    public function oddAraay()
    {
//        ========================Enter Your array===================
        $testArray = [2, 3, 2, 3, 5, 5, 3];
        $arr1 = array_count_values($testArray);
        $str = '';
        foreach ($arr1 as $k => $v) {
            if ($v % 2 != 0) {
                $str = $str . ',' . $k;
            }
        }
        $res = substr($str, 1);
        dd('Input ', $testArray, 'Output ', $res, 'Occured odd no of times');
    }

    public function search()
    {

//        ========================Enter Your array===================
        $testArray = ['buy' => ['purchase'], 'big' => ['great', 'large']];
//        ========================Enter Your word to search===================
        $word = 'big';
        $res = [];
        foreach ($testArray as $k => $v) {
            if ($k == $word) {
                $res = $v;
                break;
            }
        }
        $str = implode($res, ',');
        $output = "{'word':$word,'synonyms':[$str]}";
        dd('Input word ', $word, 'Json Output ', $output);
    }

    public function helper()
    {
        $res = helper1('Sharma ');
        dd($res);
    }

    public function checkDay()
    {
        return view('Demo::day');
        dd('checkDay');
    }

    public function program()
    {
        $arr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
        $res = '';
        for ($i = 0; $i < count($arr); $i++) {
            $str = '';
            for ($j = 0; $j < count($arr); $j++) {
                $str1 = '';
                for ($k = 0; $k <= $i; $k++) {
                    $str1 = $str1 . $arr[$j];
                }
                $str = $str . $str1;
            }
            $res = $res . $str . ',';
        }
        echo substr($res, 0, -1);
    }

    public function localStorage(Request $request)
    {
        if ($request->isMethod('get')) {
            dd('here');
            dd($request);
            return Response::json(['msg' => 1]);
        } else {
            return view('Demo::shopping');
        }


    }

    public function eloquent()
    {
        $obj = new User();
        $dataBeforeInsert = json_decode(json_encode($obj::all(), true), true);
        $user = User::where('id', 2)->first();   //this one line is for fetching user data in eloquent

        dd($user->toArray());

        dd('sharma', $dataBeforeInsert);


        $num = count($dataBeforeInsert);
        $obj->name = 'Dharmendra' . $num;
        $obj->user_name = 'dhiru' . $num;
        $obj->email = 'dharmendra' . $num . '@gmail.com';
        $obj->password = Hash::make('12345');
        $obj->confirm_password = '12345';
        $obj->remember_token = '';
//        $obj->save();   //        Un-comment the below code to see insert operation
        $dataAfterInsert = json_decode(json_encode($obj::all(), true), true);

        $updatedData = $obj::where('user_name', 'dhiru0')
            ->update(['remember_token' => 1]);
        $dataAfterUpdate = json_decode(json_encode($obj::all(), true), true);
        dd('BeforeInsert', $dataBeforeInsert, 'AfterInsert', $dataAfterInsert, 'AfterUpdate', $dataAfterUpdate);

        $res = User::where('id', 4)->delete(); // only this line to delete a particular id

    }

    public function eloqtest()
    {
//        calling eloquent model with different name of table her users table is called through test model
        $test = new test();
        $allData = json_decode(json_encode($test::all(), true), true);
        dd($allData);
    }

    public function relationEloqtest()
    {
//        $test = new bear();
//
//        for($i=0;$i<10;$i++){
//            $arr=array();
//            $arr['name']='bear'.$i;
//            $arr['type']='type'.$i;
//            $arr['danger_level']='danger_level'.$i;
//            $arr['created_at']=time();
//            $arr['updated_at']=time();
//            $test::create($arr);                //this for inserting data in bear table
//
//
////  ==========================This is to update data in bear table=====================
//
//            bear::where(['danger_level'=>'danger_level'.$i])->update(['danger_level'=>$i]);
//        }
//        $allData = json_decode(json_encode($test::all(), true), true);
//        dd($allData);





    }



    public function ckeditor(Request $request)
    {
        if ($request->isMethod('post')) {

        } else {
//            dd(Hash::make('12345'));

            return view('Demo::ckeditor');
        }
    }

    public function bullet(Request $request)
    {
        if ($request->isMethod('get')) {
            return view('Demo::bullet');
        }

    }

    public function sendgrid(Request $request)
    {
        $to = 'sharmaglobussoft@gmail.com';
        $subject = 'the subject';
        $message = 'hello';
        $headers = 'From: Jack Sparrow <dharmendrasharma@globussoft.in>' . PHP_EOL .
            'Reply-To: Jack Sparrow <jsparrow@blackpearl.com>' . PHP_EOL .
            'X-Mailer: PHP/' . phpversion();

        dd(mail($to, $subject, $message, $headers), 'response');

    }

    public function array_multisort()
    {
        $arr = array();
        $arr[0] = ['brand' => 'blah3',
            'zip' => '90213',
            'distance' => '3.08'
        ];
        $arr[1] = ['brand' => 'blah5',
            'zip' => '90215',
            'distance' => '5'
        ];

        foreach ($arr as $key => $row) {
            $distance[$key] = $row['distance'];
        }

        array_multisort($distance, SORT_DESC, $arr);

        dd($arr);
    }

    public function delay()
    {

        echo 'hello';
        sleep('5');
        echo 'world';
    }

    public function folder()
    {
        $path = public_path('upload/itsolutionstuff');

        if(!File::isDirectory($path)){

            File::makeDirectory($path, 0777, true, true);
            dd('folder created');

        }else{
            dd('folder exists');
        }
    }

    public function myform(Request $request)
    {
        if($request->isMethod('get')){
            return view('Demo::ajaxValidation');
        }else{
//            dd($request->all());
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'email' => 'required',
                'address' => 'required',
            ]);

            if ($validator->passes()) {
                return response()->json(['success'=>'Added new records.']);
            }
            return response()->json(['error'=>$validator->errors()->all()]);
        }
    }





}
















