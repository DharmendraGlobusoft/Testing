<?php

/**
 *    Demo Helper
 */

if (!function_exists('helper1')) {
    function helper1($param1)
    {
        return $param1 . 'value from helper function';
    }
}


if (!function_exists('templetForEmail')) {
    function templetForEmail($param1)
    {
        $templet = "<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<h1>$param1</h1>
<p>This is a test email templet message.</p>

</body>
</html>
";
        return $templet;
    }
}