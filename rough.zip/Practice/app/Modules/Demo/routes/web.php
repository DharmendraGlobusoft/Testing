<?php

Route::group(['module' => 'Demo', 'middleware' => ['web'], 'namespace' => 'App\Modules\Demo\Controllers'], function () {

    Route::resource('Demo', 'DemoController');

// --------------------------------------Use of middleware---------------------------

//-----------------------in place of any value we can pass our module name------------------
//  url to test this   http://localhost.practice.com//check-md?type=2  give type value greater than 2 to see difference
    Route::group(['middleware' => ['checkType:anyValue']], function () {

//        check kernel for declaration

//        Route::get("check-md",["uses"=>"PracticeController@checkMD","middleware"=>"checkType"]);
        Route::get("/check-md", "PracticeController@checkMD");

    });


//--------------------------------------------------------------------------------------------


    Route::get('/default_route', function () {

        return view('Demo::default', ['name' => 'Dharmendra Kumar Sharma']);

    });


    Route::get('/signup', 'DemoController@signup');
    Route::post('/signup', 'DemoController@signup');
    Route::post('/ajaxVerify', 'DemoController@ajaxVerify');
    Route::get('/login', 'DemoController@login');
    Route::post('/login', 'DemoController@login');
//    Route::get('/table1', 'DemoController@table');
    Route::post('/editData', 'DemoController@editData');
    Route::post('/getData', 'DemoController@getData');
    Route::get('/checkDemo', 'DemoController@demo');
    Route::get('/invoice', 'DemoController@invoice');
    Route::get('/fact', 'DemoController@fact');
    Route::get('/distance', 'DemoController@distance');
    Route::get('/dist', 'DemoController@dist');

    Route::get('/test', 'DemoController@test');
    Route::get('/test1', 'DemoController@test1');
    Route::post('/test1', 'DemoController@test1');
    Route::get('/test2', 'DemoController@test2');
    Route::get('/redis', 'DemoController@redis');
    Route::get('/config', 'DemoController@config');
    Route::get('/popup', 'DemoController@popup');
    Route::get('/instant', 'InstantPayment@instantPayment');
    Route::post('/instant', 'InstantPayment@instantPayment');


    Route::get('/start', 'BraintreeController@startTrans');
    Route::post('/start', 'BraintreeController@startTrans');

    Route::get('user/{name?}', function ($name = 'Sharma') {
        dd($name);
    });
    Route::get('/hcf/{num1?}/{num2?}', 'DemoController@hcf');

    Route::get('/qrcode', 'DemoController@QRcode');
    Route::get('/newqr', 'DemoController@NewQRcode');
    Route::get('/blade', 'DemoController@Blade');
    Route::get('/table', 'DemoController@DataTable');
    Route::get('/tableAjax', 'DemoController@tableAjax');
    Route::post('/tableAjax', 'DemoController@tableAjax');
    Route::get('/testTimeFormat', 'DemoController@TestArray');
    Route::get('/email', 'DemoController@sendEmail');
    Route::get('/sendgrid', 'DemoController@sendgrid');
    Route::get('/helper', 'DemoController@helper');


    Route::get('/binary', 'DemoController@binary');
    Route::get('/palindrome', 'DemoController@palindrome');
    Route::get('/array', 'DemoController@assArray');
    Route::get('/odd', 'DemoController@oddAraay');
    Route::get('/search', 'DemoController@search');
    Route::get('/day', 'DemoController@checkDay');
    Route::get('/delay', 'DemoController@delay');
    Route::get('/pro', 'DemoController@Program');

//    ==============================LocalStorage===================================

    Route::get('/localStorage', 'DemoController@localStorage');
    Route::post('/localStorage', 'DemoController@localStorage');


//    ==============================API===================================

    Route::get('/check', 'DemoController@apiCheck');

//    ===================================================================

    Route::get('/eloquent', 'DemoController@eloquent');
    Route::get('/eloqtest', 'DemoController@eloqtest');
    Route::get('/relation', 'DemoController@relationEloqtest');


    Route::get('/ck', 'DemoController@ckeditor');
    Route::get('/folder', 'DemoController@folder');
    Route::get('/bullet', 'DemoController@bullet');
    Route::get('/array_multisort', 'DemoController@array_multisort');

    //============================Stripe Payment======only this two r required=====================

    Route::get('stripe', 'StripePaymentController@stripe');
    Route::post('stripe', 'StripePaymentController@stripePost')->name('stripe.post');

//=================================work with ajax================================

    Route::match(['get', 'post'], '/myform', 'DemoController@myform');
    Route::match(['get', 'post'], '/ajaxImageUpload', 'PracticeController@ajaxImageUpload')->name('ajaxImageUpload');

    Route::match(['get', 'post'], '/tooltip', 'PracticeController@tooltip');
    Route::match(['get', 'post'], '/frontvalidation', 'PracticeController@frontvalidation');


//    ==========Google Captcha===================

    Route::get('my-captcha', 'HomeController@myCaptcha')->name('myCaptcha');
    Route::post('my-captcha', 'HomeController@myCaptchaPost')->name('myCaptcha.post');
    Route::get('refresh_captcha', 'HomeController@refreshCaptcha')->name('refresh_captcha');
//    ------------------------------generate Pdf------------------------

    Route::get('/pdf', 'PracticeController@generatePdf')->name('generatePdf');

});
