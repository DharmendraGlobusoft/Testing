<?php

Route::group(['module' => 'Demo', 'middleware' => ['api'], 'namespace' => 'App\Modules\Demo\Controllers'], function() {

    Route::resource('Demo', 'DemoController');


    Route::get('demo','DemoController@demo');



    Route::get('checkApi','API\ApiController@apiTest');


});

