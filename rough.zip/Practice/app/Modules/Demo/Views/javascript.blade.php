<!DOCTYPE html>
<html>

<head>
    <title>Text Input Control</title>
</head>

<body>
<form >
    First name: <input type = "text" name = "first_name" />
    <br>
    Last name: <input type = "text" name = "last_name" />
</form>


<script>

</script>
</body>

</html>
