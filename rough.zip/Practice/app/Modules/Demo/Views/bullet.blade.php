<!DOCTYPE html>
<html>
<head>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


    <style>
        #todolist {width:100%;}
    </style>
</head>
<body>

<h2>HTML Forms</h2>

<form>
    <textarea id="todolist" class="todolist" name="todolist" rows="10" placeholder="Maintain your pending tasks"></textarea>
</form>

<script>
    $(".todolist").focus(function() {
        if(document.getElementById('todolist').value === ''){
            document.getElementById('todolist').value +='• ';
        }
    });
    $(".todolist").keyup(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            document.getElementById('todolist').value +='• ';
        }
        var txtval = document.getElementById('todolist').value;
        if(txtval.substr(txtval.length - 1) == '\n'){
            document.getElementById('todolist').value = txtval.substring(0,txtval.length - 1);
        }
    });
</script>

</body>
</html>
