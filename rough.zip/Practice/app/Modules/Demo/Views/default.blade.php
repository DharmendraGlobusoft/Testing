<!DOCTYPE html>
<html>
<head>
    <title>Default page</title>

    <style>
        .alert {
            padding: 15px;
            border: 1px solid #d6e9c6;
            border-radius: 4px;
            color: #3c763d;
            background-color: #dff0d8;
        }

        #myBar {
            background-color: purple;
            height: 5px;
        }
    </style>
</head>
<body>

<div id="alert"></div>
<h1 id="name">Dharmendra Kumar</h1>
<h3>This is a default path if any route does not match this will be excuted.</h3>
<p>For more see.</p>
<p>app/Exceptions/Handler.php</p>
<p>render function</p>

{{-----------------------------------------Testing Part--------------------------------------------}}



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

    $(document).ready(function () {
        var name='{{$name}}';



        var html = `<div class="alert">
                        <strong>Hi ${name}!</strong><br>  You've reached to default page.

                    </div> <div id="myBar" style="width: 10%;"></div>
                    `;

        $('#alert').html(html);
        setTimeout(function () {
            $('#alert').remove();
        },10000);



        function sayHi(name) {
            // return 'Welcome '+name;
            return `Hello ${name}`;
        }
        $('h1').text(sayHi(name));
        document.body.style.background = "gray";
        // setTimeout(() => document.body.style.background = "", 3000);


    });

    $(document).ready(function () {



    });



</script>
</body>
</html>
