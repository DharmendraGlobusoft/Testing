<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>A Simple Page with CKEditor</title>
    <!-- Make sure the path to CKEditor is correct. -->
    <script src="//cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>

</head>
<body>
<form>
    <textarea name="text" id="text">This is a demo .</textarea>


    <script> CKEDITOR.replace( 'text' );</script>

</form>


</body>
</html>
