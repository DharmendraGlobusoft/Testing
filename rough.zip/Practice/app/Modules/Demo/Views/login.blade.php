<html>
<head>
</head>
<body>
<h1>{{\Illuminate\Support\Facades\Session::has('msg')?\Illuminate\Support\Facades\Session::get('msg'):""}}</h1>
<form action="/login" method="post">
    {{csrf_field()}}
    {{env('APP_URL')}}
    <h1>Login</h1>
    <p>Email<input type="text" name="email" placeholder="Enter Your Email"/></p>
    <p>Password<input type="text" name="password" placeholder="Enter Your Password"/></p>
    <button>Submit</button>
</form>
</body>
</html>
