<!DOCTYPE html>
<html>
<head>
    <title>Braintree Payment</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://js.braintreegateway.com/js/braintree-2.31.0.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <br><br>
            <legend>Welcome to Braintree Payment</legend>
        </div>
        <!-- panel preview -->
        <div class="col-sm-5">
            <h4>Payment Details:</h4>
            <div class="panel panel-default">
                <div class="panel-body form-horizontal payment-form">
                    <form method="post" action="/start">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label for="description" class="col-sm-3 control-label">Name</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="name" name="description">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="amount" class="col-sm-3 control-label">Amount</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="amount" name="amount">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-12 text-right">
                                <button type="submit" class="btn btn-default btn-success">
                                    PAY
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> <!-- / panel preview -->
    </div>
</div>

</body>
</html>


