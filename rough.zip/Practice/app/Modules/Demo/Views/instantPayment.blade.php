<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 10/1/2018
 * Time: 3:43 PM
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Page Title</title>
</head>
<body>
<form action="instant" method="post">
    {{csrf_field()}}
    Enter amount for Payment:
    <input type="text" name="amount" >
    <button type="submit">PAY</button>

</form>

</body>
</html>
