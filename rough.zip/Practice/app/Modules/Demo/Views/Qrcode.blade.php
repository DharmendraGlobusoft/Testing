<!DOCTYPE html>
<html>
<head>
    <title>basic example</title>

</head>
<body>
<div id="qr-example"></div>
<p><input type="text" placeholder="Name" id="name"/></p>
<p><input type="text" placeholder="Email" id="email"/></p>
<p><input type="text" placeholder="Contact number" id="contactNo"/></p>
<p><input type="text" hidden id="gn-val"/></p>
<input type="button" value="Generate QRCode" id="gn-btn"/>
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="/qrcode.js"></script>
<script>
    $(window).load(function(){
        $('#gn-btn').click(function(){
            $('#qr-example').empty();
            var data;
            if($('#name').val()=='' || $('#email').val()=='' || $('#contactNo').val()==''){
                alert('All fields are required');
                return false;
            }else{
                data='Name ='+$('#name').val()+'\nEmail ='+$('#email').val()+'\n ContactNumber ='+$('#contactNo').val();
            }
            var val =data;
            $('#gn-val').val(data);
            var val = $('#gn-val').val();
            if(val){
                $('#qr-example').qrcode(val);
                $('#name').hide();
                $('#email').hide();
                $('#contactNo').hide();
            }else{
                alert("Please provide some text or url !");
            }

        });
    });
</script>
</body>
</html>