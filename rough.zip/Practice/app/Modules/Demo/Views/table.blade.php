<html>
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>

        .dropbtn {
            background-color: #3498DB;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        .dropbtn:hover, .dropbtn:focus {
            background-color: #2980B9;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown a:hover {
            background-color: #ddd
        }

        .show {
            display: block;
        }

        .nav-tabs {
            margin-bottom: 15px;
        }

        .sign-with {
            margin-top: 25px;
            padding: 20px;
        }

        div#OR {
            height: 30px;
            width: 30px;
            border: 1px solid #C2C2C2;
            border-radius: 50%;
            font-weight: bold;
            line-height: 28px;
            text-align: center;
            font-size: 12px;
            float: right;
            position: absolute;
            right: -16px;
            top: 40%;
            z-index: 1;
            background: #DFDFDF;
        }
    </style>
</head>
<body>
<div id="mylocation"></div>
<table border="1">
    <thead style="height: 50px">
    <tr style="color: #3064f2;">
        <td>SI.No</td>
        <td>Name</td>
        <td>User Name</td>
        <td>Email</td>
        <td>Action</td>
    </tr>
    </thead>
    <tbody>
    @foreach($result as $key=>$val)
        <tr id="{{$val['id']}}">
            <td>{{$val['id']}}</td>
            <td>{{$val['name']}}</td>
            <td>{{$val['user_name']}}</td>
            <td>{{$val['email']}}</td>
            <td>
                <div class="dropdown">
                    <button onclick="myFunction({{$val['id']}})" class="dropbtn">Dropdown</button>
                    <div id="myDropdown{{$val['id']}}" class="dropdown-content">
                        <a onclick="editForm({{$val['id']}})" class="w3-bar-item w3-button">EDIT</a>
                        <a class="w3-bar-item w3-button">DELETE</a>
                    </div>
                </div>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>


<!-- Large modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×
                </button>
                <h4 class="modal-title" id="myModalLabel">Update Page</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <form id="formid" role="form" class="form-horizontal">
                                <input id="editId" type="text" name="id" hidden>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <input type="text" id="name" name="name" class="form-control" placeholder="Name"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        User Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <input type="text" id="username" name="username" class="form-control"
                                                       placeholder="User Name"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" name="email" class="form-control" id="email"
                                               placeholder="Email"/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="http://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script type="text/javascript">

    function myFunction(id) {
        document.getElementById("myDropdown" + id).classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function (event) {
        if (!event.target.matches('.dropbtn')) {

            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    };


    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });



    function editForm(id) {

        $.ajax({
            url: "/getData",
            method: "post",
            data: {
                'id': id
            },
            dataType: "json",
            success: function (response) {
                $('#editId').val(id);
                $('#name').val(response.name);
                $('#username').val(response.user_name);
                $('#email').val(response.email);
            }
        });

        $('#myModal').modal('show');
    }

    $('#formid').submit(function (e) {
        e.preventDefault();
        var userdata = new FormData(this);
        $.ajax({
            url: "/editData",
            method: "post",
            data: userdata,
            dataType: "json",
            contentType: false,
            cache: false,
            processData: false,
            success: function (response) {
                if (response.msg) {
                    $('#myModal').modal('hide');


                    var appendData =  "<td>"+response.msg.id+"</td>" +
                        "<td>"+response.msg.name+"</td>" +
                        "<td>"+response.msg.user_name+"</td>" +
                        "<td>"+response.msg.email+"</td>" +
                        '<td>' +
                        '<div class="dropdown">' +
                        '<button onclick="myFunction('+response.msg.id+')" class="dropbtn">Dropdown</button>' +
                        '<div id="myDropdown'+response.msg.id+'" class="dropdown-content">' +
                        '<a onclick="editForm('+response.msg.id+')" class="w3-bar-item w3-button">EDIT</a>' +
                        '<a class="w3-bar-item w3-button">DELETE</a>' +
                        '</div>' +
                        '</div>' +
                        '</td>';

                    $('#' + response.msg.id).html(appendData);
                } else {
                    alert('Please change somthing for updation!!!');
                }
            }
        });
    });


</script>
</body>
</html>