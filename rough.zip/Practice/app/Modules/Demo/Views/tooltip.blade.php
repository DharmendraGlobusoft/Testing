<html lang="en">

<head>
<title>Tooltip example</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>

    <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>


</head>

<body style="text-align: center">

<h1>Tool Tip Example</h1>
<div class="container">


    <a class="btn btn-primary" title="Jquery UI Tooltip Example">See Toltip</a>
    <a class="btn btn-info" title="This is Dharmendra Kumar Sharma">See Name</a>

    </div>


    <script type="text/javascript">

        $( function() {

            $( document ).tooltip();

        } );

    </script>


</div>


</body>

</html>
