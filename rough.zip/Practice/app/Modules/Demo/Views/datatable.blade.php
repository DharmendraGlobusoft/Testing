<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Final Output</title>
    <meta name="description" content="Bootstrap.">
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <style>


    </style>
</head>
<body style="margin:20px auto">
<div class="container">
    <div class="row header" style="text-align:center;color:green">
        <h3>Data Table</h3>
    </div>
    <table id="myTable" class="table table-striped">
        <thead>
        <tr>
            <th>SI.nO</th>
            <th>Name</th>
            <th>User Name</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($data as $key=>$val)
        <tr>
            <td>{{$val['id']}}</td>
            <td>{{$val['name']}}</td>
            <td>{{$val['user_name']}}</td>
            <td>{{$val['email']}}</td>
            <td> <form>
                    <select>
                        <option>Choose</option>
                        <option onclick="editFunction('Edit')" value="edit">Edit</option>
                        <option onclick="deleteFunction('Delete')" value="delete">Delete</option>
                        <option onclick="viewFunction('View')" value="view">View</option>
                    </select>
                </form>
            </td>
        </tr>
        @endforeach
        </tbody>
    </table>

</div>
</body>
<script>
    $(document).ready(function () {

        $('#myTable').dataTable({
            lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]] //this optional
        });

    });
</script>

<script>
    // This is not part of Datatable this is for scroll testing
    console.log($(document).height(), $(window).scrollTop(), $(window).height());
    $(window).scroll(function () {
        if ($(document).height() == $(window).scrollTop() + $(window).height()) {
            console.log($(document).height(), $(window).scrollTop(), $(window).height());
            alert('I am at the bottom');
        }
    });
</script>
<script>

    function editFunction(val) {
        alert(val)
    }
    function deleteFunction(val) {
        alert(val)
    }
    function viewFunction(val) {
        alert(val)
    }
</script>
</html>

