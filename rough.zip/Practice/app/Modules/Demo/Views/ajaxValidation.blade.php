<!DOCTYPE html>
<html>
<head>
    <title>Laravel Ajax Validation Example</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
</head>
<body>
<div class="container">
    <h2>Laravel Ajax Form</h2>

    <div class="alert alert-danger print-error-msg" style="display:none">
        <ul></ul>
    </div>

    <form>
        {{ csrf_field() }}
        <div class="form-group">
            <label>First Name:</label>
            <input type="text" name="first_name" class="form-control" placeholder="First Name">
        </div>
        <div class="form-group">
            <strong>Email:</strong>
            <input type="text" name="email" class="form-control" placeholder="Email">
        </div>
        <div class="form-group">
            <strong>Address:</strong>
            <textarea class="form-control" name="address" placeholder="Address"></textarea>
        </div>
        <div class="form-group">
            <strong>Single File Upload:</strong>
            <input id="single_file"  type="file" name="file">
        </div>
        <div class="form-group">
            <strong>Multiple File Upload:</strong>
            <input id="image_file"  type="file" name="file[]" multiple>
        </div>
        <div class="form-group">
            <button class="btn btn-success btn-submit">Submit</button>
        </div>
    </form>
</div>

<script type="text/javascript">

    $(document).ready(function () {

        $(".btn-submit").click(function (e) {

            e.preventDefault();

            var _token = $("input[name='_token']").val();
            var first_name = $("input[name='first_name']").val();
            var email = $("input[name='email']").val();
            var address = $("textarea[name='address']").val();
            var singleFile=document.querySelector('#single_file').files[0];
            var myfiles = document.getElementById("image_file");
            var files = myfiles.files;

            var data = new FormData();

            for (var i = 0; i < files.length; ++i) {
                data.append('userfiles[]', files[i]);
            }

            data.append('_token',_token);
            data.append('first_name',first_name);
            data.append('email',email);
            data.append('address',address);
            data.append('singleFile',singleFile);


            $.ajax({
                type: "post",
                enctype: 'multipart/form-data',
                url: "/myform",
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 600000,
                success: function (data) {

                    console.log('===========','Ajax called Successfully','=================');

                    if($.isEmptyObject(data.error)){

                        alert(data.success);

                    }else{

                        printErrorMsg(data.error);

                    }


                },
                error: function (e) {
                    alert('error');
                }
            });

            function printErrorMsg (msg) {

                $(".print-error-msg").find("ul").html('');

                $(".print-error-msg").css('display','block');
                console.log('===========',msg);

                $.each( msg, function( key, value ) {

                    $(".print-error-msg").find("ul").append('<li>'+value+'</li>');

                });

            }
        });
    });

</script>

</body>
</html>
