<html>
<head>
    <link rel="stylesheet" href="build/css/intlTelInput.css">
    <style>
        .error {
            color: darkred;
        }
    </style>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
{{\Illuminate\Support\Facades\Session::has('msg')?\Illuminate\Support\Facades\Session::get('msg'):""}}
<form action="/signup" method="post" id="formId">
        {{csrf_field()}}
        <h1>SIGNUP</h1>
{{--    {{dd($code)}}--}}

        <p>Name:<input type="text" name="name"  value="{!! old('name') !!}" placeholder="Enter Your Name"/></P>
    <span class="error">{{$errors->first('name')}}</span></p>
        <p>User Name:<input type="text" id="username"  value="{!! old('username') !!}" onkeyup="verifyUserName()" name="username"
                            placeholder="Enter Your User Name"/>
            </p>
    <span class="error">{{$errors->first('username')}}</span>
            <span id="message"></span>
        <p>Email:<input type="text" name="email" value="{!! old('email') !!}" placeholder="Enter Your Email"/></p>
    <span class="error">{{$errors->first('email')}}</span></p>
        <p>Password:<input type="text" id="password"  name="password" value="{!! old('password') !!}" placeholder="Enter Your Password"/></p>
    <span class="error">{{$errors->first('password')}}</span></p>
    SelectCountry:
    <select onchange="jsFunction(this.value);">
{{--    <?php--}}
{{--    foreach ($code as $value){?>--}}
{{--        <option value="{{$value['code']}}" name="{{$value['country']}}">{{$value['country']}}</option>--}}
{{--        <?php }--}}
{{--    ?>--}}
    </select>

        <p>Mobile_no :<input type="text" id="code" name="code" /><input type="text" id="number" name="number" placeholder="09876543211"/></p>
        <p>Confirm Password:<input type="text" name="confirm_password" placeholder="Confirm Your Password"/></p>
        <button id="button" type="submit">Submit</button>

</form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<script src="build/js/intlTelInput.js"></script>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function () {
        $("#formId").validate({
            rules: {
                name: {
                    required: true,
                    minlength: 4
                },
                username: {
                    required: true,
                    minlength: 4
                },
                email: {
                    required: true,
                    email: true
                },
                password: {
                    required: true,
                    minlength: 4
                },
                confirm_password: {
                    required: true,
                    equalTo: "#password"
                }
            },
            messages: {
                name: {
                    required: 'Name is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                },
                username: {
                    required: 'User Name is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                },
                email: {
                    required: "Email address is required..!!",
                    email: "Please Enter Valid Email..!!"
                },
                password: {
                    required: 'Password is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                },
                confirm_password: {
                    required: 'Confirm password is Required..!!',
                    equalTo: "Password do not matched..!!"
                }
            }
        });

    });

    function verifyUserName() {
        $username = $('#username').val();
        if ($username.length > 3) {
            $.ajax({
                url: "/ajaxVerify",
                method: "post",
                data: {
                    'username': $('#username').val()
                },
                dataType: "json",
                success: function (verify) {
                    console.log(verify.msg);
                    if (verify.msg == 1) {
                        // $('#message').text('This user name already exists');
                        $("#button").hide();
                        document.getElementById('message').innerHTML = 'This user name already exists';
                        $('#message').css('color', 'red');

                    } else {
                        // $('#message').text('This is valid user name');
                        $("#button").show();
                        document.getElementById('message').innerHTML = 'This is valid user name';
                        $('#message').css('color', 'green');
                    }
                }
            });
        } else {
            document.getElementById('message').innerHTML = '';
        }
    }

    function jsFunction(value)
    {
        // alert(value);
        $('#code').val(value);
    }

</script>
</body>
</html>
