<!DOCTYPE html>
<html>
<head>
    <title>Page Title</title>
</head>
<body>

@if($data)
    @for($i=$data;$i>0;$i--)
    <h1>This is If block</h1>
    @endfor
@else
    <h1>This is Else block</h1>
@endif

</body>
</html>