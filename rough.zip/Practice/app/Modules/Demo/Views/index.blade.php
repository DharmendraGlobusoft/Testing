<?php

echo trans('Demo::example.welcome');