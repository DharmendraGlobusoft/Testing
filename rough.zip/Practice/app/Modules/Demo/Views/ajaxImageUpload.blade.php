<!DOCTYPE html>

<html>

<head>

    <title>Ajax Image Uploading </title>

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

{{---------------------------Use below cdn or file link below the cdn for ajax---------------------------------}}
{{--<script src="http://malsup.github.com/jquery.form.js"></script>--}}

    <script src="/ajaxJqueryPlugin/form.js"></script>

</head>

<body>


<div class="container">

    <h1>Ajax Image Uploading</h1>


    <form id="form1" action="{{ route('ajaxImageUpload') }}" enctype="multipart/form-data" method="POST">


        <div class="alert alert-danger print-error-msg" style="display:none">

            <ul></ul>

        </div>


        <input type="hidden" name="_token" value="{{ csrf_token() }}">


        <div class="form-group">

            <label>Alt Title:</label>

            <input type="text" name="title" class="form-control" placeholder="Add Title">

        </div>


        <div class="form-group">

            <label>Image:</label>

            <input type="file" name="image" >

        </div>


        <div class="form-group">

            <button class="btn btn-success upload-image" type="submit">Upload Image</button>

        </div>


    </form>


</div>


<script type="text/javascript">




{{--------------------we can use either of the below fun1 or fun2 to call ajax ---------------------}}

    $("body").on("click", ".upload-image", function (e) {    //===================fun1

        //------we can use the ajax by below both methods----------
        // $(this).parents("form").ajaxForm(options);
        $('#form1').ajaxForm(options);

    });

    // $(document).ready(function() {                             //===================fun2
    //     $('#form1').on('submit', function(e) {
    //         e.preventDefault(); // <-- important
    //         $(this).ajaxSubmit(options);
    //     });
    // });


    var options = {

        complete: function (response) {

            if ($.isEmptyObject(response.responseJSON.error)) {

                $("input[name='title']").val('');

                alert('Request Completed Successfully');

            } else {

                printErrorMsg(response.responseJSON.error);

            }

        },
        success: function (response) {
            if (response.code == 200) {
                console.log('================', response.msg, '================');
                alert('success')
            } else {
                alert('error')
            }

        },
        beforeSend: function (response) {
            alert('beforeSend')

        }

    };


    function printErrorMsg(msg) {

        $(".print-error-msg").find("ul").html('');

        $(".print-error-msg").css('display', 'block');

        $.each(msg, function (key, value) {

            $(".print-error-msg").find("ul").append('<li>' + value + '</li>');

        });

    }

</script>


</body>

</html>
