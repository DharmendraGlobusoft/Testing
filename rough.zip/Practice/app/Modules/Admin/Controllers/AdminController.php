<?php

namespace App\Modules\Admin\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{


    public function adminLogin(Request $request)
    {

        if ($request->isMethod('get')){

            if (Session::has('adminId')){
                return redirect()->route('adminDashboard');
            }else{
                return view('Admin::adminLogin');
            }

        }else{
            Session::put(['adminId'=>'adminId']);
            return redirect()->route('adminDashboard');
        }

    }

    public function adminDashboard(Request $request)
    {
        return view('Admin::adminDashboard');
    }

    public function adminLogout(Request $request)
    {
        Session::forget('adminId');
        return redirect()->route('adminLogin');
    }
}
