


<html>
<head>
    <title>Admin Dashboard</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <style>
        body{
            margin-top: auto;
            background-color: #f1f1f1;
        }
        .border{
            border-bottom:1px solid #F1F1F1;
            margin-bottom:10px;
        }
        .main-secction{
            box-shadow: 10px 10px 10px;
        }
        .image-section{
            padding: 0px;
        }
        .image-section img{
            width: 100%;
            height:250px;
            position: relative;
        }
        .user-image{
            position: absolute;
            margin-top:-50px;
        }
        .user-left-part{
            margin: 0px;
        }
        .user-image img{
            width:100px;
            height:100px;
        }
        .user-profil-part{
            padding-bottom:30px;
            background-color:#FAFAFA;
        }
        .follow{
            margin-top:70px;
        }
        .user-detail-row{
            margin:0px;
        }
        .user-detail-section2 p{
            font-size:12px;
            padding: 0px;
            margin: 0px;
        }
        .user-detail-section2{
            margin-top:10px;
        }
        .user-detail-section2 span{
            color:#7CBBC3;
            font-size: 20px;
        }
        .user-detail-section2 small{
            font-size:12px;
            color:#D3A86A;
        }
        .profile-right-section{
            padding: 20px 0px 10px 15px;
            background-color: #FFFFFF;
        }
        .profile-right-section-row{
            margin: 0px;
        }
        .profile-header-section1 h1{
            font-size: 25px;
            margin: 0px;
        }
        .profile-header-section1 h5{
            color: #0062cc;
        }
        .req-btn{
            height:30px;
            font-size:12px;
        }
        .profile-tag{
            padding: 10px;
            border:1px solid #F6F6F6;
        }
        .profile-tag p{
            font-size: 12px;
            color:black;
        }
        .profile-tag i{
            color:#ADADAD;
            font-size: 20px;
        }
        .image-right-part{
            background-color: #FCFCFC;
            margin: 0px;
            padding: 5px;
        }
        .img-main-rightPart{
            background-color: #FCFCFC;
            margin-top: auto;
        }
        .image-right-detail{
            padding: 0px;
        }
        .image-right-detail p{
            font-size: 12px;
        }
        .image-right-detail a:hover{
            text-decoration: none;
        }
        .image-right img{
            width: 100%;
        }
        .image-right-detail-section2{
            margin: 0px;
        }
        .image-right-detail-section2 p{
            color:#38ACDF;
            margin:0px;
        }
        .image-right-detail-section2 span{
            color:#7F7F7F;
        }

        .nav-link{
            font-size: 1.2em;
        }

    </style>
</head>
<body>
<div class="container main-secction">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 image-section">
            <img src="https://png.pngtree.com/thumb_back/fw800/back_pic/00/08/57/41562ad4a92b16a.jpg">
        </div>
        <div class="row user-left-part">
            <div class="col-md-3 col-sm-3 col-xs-12 user-profil-part pull-left">
                <div class="row ">
                    <div class="col-md-12 col-md-12-sm-12 col-xs-12 user-image text-center">
{{--                        <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" class="rounded-circle">--}}
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEhISEhIPFRUQFRIXFRYVEBAVFRAVFxIXFxUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDQ0NFQ8PFS0ZFR0rLSsrLSsrNystKystKzctKystKysrLSstLSstKys3LSsrLTctLS0rLS0rKy0rLS0rK//AABEIAKgBKwMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQMCBAUGB//EADgQAAIBAgMECAUCBgMBAAAAAAABAgMRBCExBRJBUQYTImFxgaGxMpHB0eFi8BRCUnKC8RUjQwf/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAGBEBAQADAAAAAAAAAAAAAAAAAAECETH/2gAMAwEAAhEDEQA/APhoAAAAAAAAAAAAAAABNgiQABtUqFtQKFTZPVmzKJVJAVOJDiWGLAraMSxmLAxBLRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASiQTFXduYF+Ep3d+WnibjRFKFkkuBbuMClornE2XAqqAabILZxK2BgzFmUjECCGjINAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbmzqF3fkaZ6HA4e0Enxt82Ao0ePMudM3adHIy6rnkByalJ2NepTaOxUS0saNeObA5s4lMom3KJU4gazRiWzRW4gY2JsS0QgMJIgsaKwQAAVAJARAAAAAAAAAAAAAAAAAAAAAAAAAAA29mYffmuSzf0PVUcPdx8fp+Tl9GqF4uXN+iX5Z6Khi8PCV51IKz58F+bgX0cHlnZCrs9visvQmPSDCZ/9kOS+5tw2thnl1kH2VyzYVy6uzuLz/epy8Vh3d2TPR4ivReS3JWjqna8m0+HA16uETsk3fd3r3T8u4I8rXpW5mrM9DtDByi93st28Lczg14WYGnMwbM6qKWwLEVtEwkGELXXgVyRZFk1Y5BYpABGkAkgqIBJAQAAAAAAAAAAAAAAAAAAAAACUrkG1s9JScn/5py89I+rQG7XquEFRi9M5tcZPVX5I59SGnNl9NN5vV5siN95WV7apagbOEwHM3o4PuNzAzp1Et2Ud7jHSStreL91kb0KAGlhdkSmnK+7CHxS5dy7zQxWPlC7hKTSdt5vK64X4nd6X7QjQhRoLNbinKKdt+Uop9prO2a78rd681gcDUxUk5vdjHglZRXCMY6IDKn0hqt5xUvmT/FQne6cW76m/icJCmt2KSt6nMlSz0IKMRFcDUkjpzoq1jTr0reHsUaqM0yJIhAZSLIcismLCK2iC6pG+fzKSOnUBgBlBBJBUAAAAAAAAAAAAAAAAAAAAAA2qTtTf65JeUVf3a+Rql8X2PCT9V+ANumsl4FcpOLUlqndGeFleK7jGsgOu8Xha0d6cZRlGyckmnFvTtL6nR6P111sYPEU5wkrLea6y+Vlfj4s5vRBU3UnTqJNVEmk0mna918n6H0TZnRLAtqXVRys+7y5AeS6c7IjGtTqScm3GKcXot1WjbyRw6GOnCMlFXeqPp3/0nZl6FKtyST9vofM1ZWyIrRqV8TN6S8Evub2z9kYmTTlveF8vPn5HpNiOm7XSPR1cXRhFtbt7FHkZ7GUI3lqcfE0Fnkbe0dvVJVXHdyuVVZ5Z8QuWNnXBrU7O3yKJG/i45eGf3NCoGRMlMxTJAuiyucbGUWZ2uCXTXaILJRsYEaYgkgqIAAQAAAAAAAAAAAAAAAAAAAtovVc8/Nfi5USnYDYw1SztwZtTVzSnG6uuPozYwtS+T1XqBlDei1JNpxd01wZ7Xo10rcbQm+02klZ9pvJJefA8nukVaX7XDvCyvum35LEbI6zdlFpTyazTjUlF+x8Wny4n17ZG3f4zYz3rdYlUpVNO1UXa3/8AJSjLxbPklenutt5buvcQIVZx+Fm9F1pRvdPzOLHFb2cbPvbzXfY7mCqKFK8pRil/NOW6n4cZf4psI52Lp1EpztFbkd6Und2ztFeLbSXnyNei5OmnJ3cn6cDLHYzr2qcL9Wpb05NWdWSVllwik2kte1JvWyirLNJaRCqcQjm1I2uuR1MS8m3wObUd3f8AqSf0fsVFJmkYmfACYmaZihN2CEp8DBoiBY8yLKqZiyyUSoRaAAqAAAAAAAAAAAAAAAAAAAAADOnO3g9UWSjazXkygto1bZPR+neB0sNWUl38S2TOZnF3X+0bUayeYG9hcdWpKSp1JRU7XWqk1o2uZ6LZfRmpXpOop08TTk7vq91VKT3co1INpxd2766Jps8hvGdHHToyU4ScZLk2rrk7cCK6mM6GYmLvCLgl/XUpq3hZt+hqf8Oou9We8+5t+rN/pDXr9TRxVOtOVKs91xk03SqJZwb8n8imnT34KfNJ+F1f9+ARS5RiuyimnF5t8SxxNTH4rdW6viev6V9wrW2hiLvdWi172UJ9mPc2vZ/cpLqKvGX6bS+Ts/cqMTJaENGS0AIrlK5NSXAwAm5lFmBlcDJSJlFMwgWMIqlBmJeYyiFVAlxIAAAAAAAAAAAAAAAAAAAAAALaNTg80/TwLp0pQdmmuaaOxsLZqjapP4uC5d/idrG4enWS3lml8S1X3XcB5CLb0/0Zug5anRxGx6kM7by4ON7+cdUV0ovuYVbgpWpVcO/gq2f9lRfDNfKz7ivZ86kV1cou8bpZOzV7qz8W/mWRVuDNmFW3B+gRpY9zhG6Sv7LmcOcr58zv4qfO3mzi4iEbtprwQXbXNzZ6+O6ycJr0v9CcLhIT/meWtoP3OhUhGztpGL4NcAjkXMZTIm+BgAAAGUQ2EyGBMTMwii1QAhGRlawSCK2jBxLmjBoKqIMmRYCAAAAAAAAAAAAAAAADc2ZQ3pq+kc39DTOrs1WjfmwO06uhnSr/AL1OfOqYxqgdqOItz9DZpwpyi3KMJPm0vexw+sd1mdDDVsvEo2auEw6j8LzWVpyX1OU8JGTybS/uZljKsufqMJLiQRjNmR4I0lstLgeghNMiSVwORXptRyirnLxVSpJWyiuSTR6uVKLRyNo4Fax48LgeddBmPVO1zp9RbVFc6WTsgOc4ix0OouYVcPZXA1N0bhs06IhRzAwjDQuhTsXxplWLlZFRRUlmkWxgVYSndm3KJFa88iiS4lt7vuXuV1ZAVsxJAGIAAAAAAAAAAAAAAAJR1KDsrciQBNWZjTqEgDYUzLr7AATVrXM8PVsABvUqxn1+YAESxBrValwANWqzBwWoAFUu4xm75MACVARgAUXNZHJxU7tkADcwMOzfmYYqpwWrAIMGt2Jq6gASzAAD/9k=" class="rounded-circle">
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 user-detail-section1 text-center">
                        <button id="btn-contact" (click)="clearModal()" data-toggle="modal" data-target="#contact" class="btn btn-success btn-block follow">Admin Pannel</button>
                        <button class="btn btn-warning btn-block">Dharmendra Kumar Sharma</button>
                    </div>

                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-12 pull-right profile-right-section">
                <div class="row profile-right-section-row">
                    <div class="col-md-12 profile-header">
                        <div class="row">
                            <div class="col-md-8 col-sm-6 col-xs-6 profile-header-section1 pull-left">
                                <h1>Dharmendra Kumar Sharma</h1>
                                <h5>Web Developer</h5>
                            </div>
                            <div class="col-md-4 col-sm-6 col-xs-6 profile-header-section1 text-right pull-rigth">
                                <a href="{{'adminLogout'}}" class="btn btn-danger btn-block">Logout</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-8">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link " role="tab" data-toggle="tab"><i class="fas fa-user-circle"></i>Software Developer At</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link"  role="tab" data-toggle="tab"><i class="fas fa-info-circle"></i>Globussoft Technologies</a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>


