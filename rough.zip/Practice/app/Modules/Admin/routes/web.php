<?php


Route::group(['module' => 'Admin', 'middleware' => ['web'], 'namespace' => 'App\Modules\Admin\Controllers'], function() {
//    dd('ok');







    Route::group(array('prefix' => 'admin'), function () {

//---------------------------------These are the routes having only prefix-----------------------------
//        http://multiplelogin.com/admin/adminLogin

        Route::match(['get','post'],'/adminLogin', 'AdminController@adminLogin')->name('adminLogin');

//-----------------------------------These routes have middleware--------------------------------------

        Route::group(['middleware' => 'differentiate:admin'], function () {

            Route::get('/adminDashboard', 'AdminController@adminDashboard')->name('adminDashboard');
            Route::get('/adminLogout', 'AdminController@adminLogout')->name('adminLogout');

        });


    });









});


