<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tree extends Model
{
    //


    public function bear() {
        return $this->belongsTo('Bear');
    }
}
