<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class picnic extends Model
{
    //

    public function bears() {
        return $this->belongsToMany('Bear', 'bears_picnics', 'picnic_id', 'bear_id');
    }
}
