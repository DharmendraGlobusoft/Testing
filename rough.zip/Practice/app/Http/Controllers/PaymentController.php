<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/6/2018
 * Time: 10:49 AM
 */

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use SaurabhBond\RecurringPayment\PaymentController as Payment;

class PaymentController extends Controller
{
    public function payment(Request $request){
//        dd('paymentReturn');
        $description = 'ABCSubscription';
        $returnUrl = env('APP_URL') . '/paymentReturn';
        $cancelUrl = env('APP_URL') . '/cancelPayment';
        $ipnUrl = env('APP_URL') . '/ipn/handler';

        $paymentObj = Payment::createObject();
        $details = $paymentObj->createRecurringProfile($description, $cancelUrl, $returnUrl, $ipnUrl);
        $details = json_decode($details, true);
//        dd($details);
        if ($details['status'] == 200) {
            //Have to Redirect this URL
            $redirectUrl = $details['url'];
           return Redirect::away($redirectUrl);
        }
        $response = ['code' => 400, 'message' => 'Some error occure.Try after sometimes'];
        return $response;
    }

    public function paymentReturn(Request $request)
    {
        dd('paymentReturn');
        $token = $request->token;
//        $userId = Session::get('userId');
        $userId = 2; //Login user id have to take from session userId
        $description = 'ABCSubscription';
//        $description = 'Ziingo Fruits Subscription';
        $amount = 1; //mannually assign now
        $initialAmount = $amount;
        $billingPeriod = 'Day';
//        $billingFrequency = config('customApp.SUBSCRIPTION_VALIDITY_DAYS', 3);
        $billingFrequency = 2;
        $paymentObj = Payment::createObject();

        $confirm = $paymentObj->confirmPayment($token, $description, $amount, $initialAmount, $billingPeriod, $billingFrequency);
        $confirm = json_decode($confirm, true);
        dd('confirm',$token,$confirm);
        if ($confirm['status'] == 200) {
            $data = [
                'user_id' => $userId,
                'status' => $confirm['status'],
                'message' => $confirm['message'],
                'paypal_recurring_profile_id' => $confirm['paypal_recurring_profile_id'],
                'profile_status' => $confirm['profile_status'], //Recurring profile status is PendingProfile
                'data' => json_encode($confirm['data']),
            ];
            // profile_status="pendingProfile". it will be Updated to "ActiveProfile" at the time of IPN.
            // it will come from paypal site

            $recurringProfileId = DB::table('recurring_profiles')->insertGetId($data);

            $subscriptionData = [
                'user_id' => $userId,
                'subscription_status' => 'P',
                'recurring_profile_id' => $recurringProfileId,
                'subscribed_at' => date("Y-m-d H:i:s"),
            ];
            //subscription_status will be 'A'=Active at the time of IPN. it will come from paypal site
            DB::table('subscriptions')->insert($subscriptionData);
            $response = ['code' => 200, 'message' => $confirm['message'], 'data' => null];
        } else {
            $response = ['code' => 400, 'message' => $confirm['message'], 'data' => $confirm['status']];
        }
        return $response;

    }

    public function cancelPayment(Request $request){
        dd('cancelPayment');
    }
}