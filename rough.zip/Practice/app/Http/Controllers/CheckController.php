<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 3/27/2018
 * Time: 5:09 PM
 */

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Image;

class CheckController extends Controller
{


    public function ckApi(){
        return Response::json(["check" => "Successfull"]);// this response will be the output on postman
    }






//---------------------------------Resize image--------------------------------
    public function resizeImage()
    {
        return view('resizeImage');
    }

    public function resizeImagePost(Request $request)
    {
//        dd($request->all());

        $this->validate($request, [
            'title' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $image = $request->file('image');
        $input['imagename'] = time().'.'.$image->getClientOriginalExtension();

        $destinationPath = public_path('/thumbnail');
        $img = Image::make($image->getRealPath());
        $img->resize(100, 100, function ($constraint) {
            $constraint->aspectRatio();
        })->save($destinationPath.'/'.$input['imagename']);

        $destinationPath = public_path('/images');
        $image->move($destinationPath, $input['imagename']);

        return back()

            ->with('success','Image Upload successful')

            ->with('imageName',$input['imagename']);

    }






}
