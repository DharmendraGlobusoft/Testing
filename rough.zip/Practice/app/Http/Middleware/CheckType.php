<?php

namespace App\Http\Middleware;

use Closure;

class CheckType
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next, $anyValue)
    {
//        dd($anyValue);

        if ($anyValue == 'anyValue' && $request->type > 2) {

//            if route get nerified it will redirect to the next request

            return $next($request);

        } else if ($anyValue == 'Admin') {

            dd('This will go to admin module');

        } else if ($anyValue == 'Staff') {
            dd('This will go to staff module');
        }
        if ($request->type > 2) {

            return response()->json('Please enter valid type');
        } else {

            dd('Not passed middleware validation');
        }


    }
}
