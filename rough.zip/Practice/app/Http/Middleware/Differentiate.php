<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;

class Differentiate
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next, $dataFromMiddleware)
    {
//        dd($next,$dataFromMiddleware);

        if ($dataFromMiddleware == 'admin' && Session::has('adminId')) {
            return $next($request);
        } else if ($dataFromMiddleware == 'user' && Session::has('userId')) {
            return $next($request);
        }else if ($dataFromMiddleware == 'staff' && Session::has('staffId')) {
            return $next($request);
        }else{
            dd('not a valid request');
        }


    }
}
