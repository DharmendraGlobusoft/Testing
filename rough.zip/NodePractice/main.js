var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');

var app = express();

app.use(session({
    secret: 'Sharma', // session secret
    resave: true,
    saveUninitialized: true
}));

// app.set('views', __dirname + '/app/module/User/view');   // this is used when only one module is there say only user

app.set('views', [__dirname + '/app/module/User/view', __dirname + '/app/module/Admin/view']);

app.engine('ejs', require('ejs').__express);

app.set('view engine', 'ejs');

app.use(express.static(__dirname + '/public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


var adminRoutes = require('./app/module/Admin/route/adminRoutes.js');

var userRoutes = require('./app/module/User/route/userRoute.js');


app.use('/', userRoutes);
// app.use('/user', userRoutes);
// app.use('/admin', adminRoutes);

app.listen('8000', function (req, res) {
    console.log('Server started at', 'localhost:8000/user  or  localhost:8000/admin');
});

module.exports = app;