//************ Using Mongo DB,  This will make connection with Database*************

var MongoClient = require('mongodb').MongoClient;
//Create a database named "demoMongo":
var url = "mongodb://localhost:27017/demoMongo";
const ObjectID = require('mongodb').ObjectID;

module.exports.register = function (data, callback) {

    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("demoMongo");
        dbo.createCollection("users", function (err, res) { //This will create table in demoMongo database if it is not there
            if (err) throw err;
            dbo.collection("users").insertOne(data, function (err, res) {
                if (err) {

                    var result = {
                        code: 404,
                        msg: "Failed To SignUp",
                    }
                } else {

                    var result = {
                        code: 200,
                        msg: "Successfully SignUp",
                    }
                }
                callback(result);
                console.log("1 document inserted");
                db.close();
            });
        });
    });
};

exports.userLogin = function (data, callback) {

    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("demoMongo");
        var query = {
            email: data.email,
            password: data.password
        };
        dbo.collection("users").find(query).toArray(function (err, info) {
            if (err) {

                var result = {
                    code: 404,
                    msg: "Failed To Login",
                    dataDb: info
                }
            } else {
                var result = {
                    code: 200,
                    msg: "Successfully Logged In",
                    dataDb: info
                }
            }
            callback(result);
            db.close();
        });
    });
};

exports.getUserData = function (data, callback) {


    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("demoMongo");
        var query = {
            _id: ObjectID(data)
        };
        dbo.collection("users").find(query).toArray(function (err, info) {
            if (err) {

                var result = {
                    code: 404,
                    msg: "Failed to fetch data",
                    dataDb: info
                }
            } else {
                var result = {
                    code: 200,
                    msg: "Successfully fetched data",
                    dataDb: info
                }
            }
            callback(result);
            db.close();
        });
    });
};

exports.editDetails = function (oldData, dataToUpdate, callback) {


    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("demoMongo");
        var myquery = {
            fname: oldData.fname,
            lname: oldData.lname
        };
        var newvalues = {
            $set: {
                fname: dataToUpdate.fname,
                lname: dataToUpdate.lname
            }
        };
        dbo.collection("users").updateOne(myquery, newvalues, function (err, info) {
            if (err) {
                var result = {
                    code: 404,
                    msg: "Failed To edit",
                    dataDb: info
                }
            } else {

                var result = {
                    code: 200,
                    msg: "Successfully edited",
                    dataDb: info
                }
            }
            callback(result);
            db.close();
        });
    });
};

exports.getAllDetails = function (callback) {
// console.log('=======here=====');   db.collectionName.find()
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("demoMongo");
        dbo.collection("users").find({}).toArray(function (err, info) {
            if (err) {

                var result = {
                    code: 404,
                    dataDb: info
                }
            } else {
                var result = {
                    code: 200,
                    dataDb: info
                }
            }
            callback(result);
            db.close();
        });
    });
};