function sendGridge() {
    var apiKey = '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';
    return apiKey;
}


function Helper1(var1, callback) {

    this.test2(var1, function (result) {
        callback(result)
    });
}

Helper1.prototype.test2 = function (param2, callback) {

    callback('Dharmendra '+param2)
};

module.exports.Helper1 = Helper1;