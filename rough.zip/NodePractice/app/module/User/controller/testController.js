var usercontroller = require('./userController.js');
var helper = require('../helper');
var creds = require('../../../../creds.js');



module.exports.appUrl = function (req, res) {
    console.log('============= c',creds.app_url);
    res.render('test', {'data':creds.app_url });
    return false;
};

module.exports.testRoute = function (req, res, id, val) {
    res.render('test', {'data': id + '=======' + val});
    return false;
};

module.exports.testing = function (req, res) {
    var param1 = 'Hello';
    var param2 = 'Kumar';
    var doc = usercontroller.test(param1, param2);
    res.render('test', {'data': doc});

};

module.exports.fun1 = function (req, res) {
    var raw = this.testing1();
    var val = this.testing2('first', 'second');
    res.render('test', {'data': raw + '=======' + val});
};

module.exports.testing1 = function (req, res) {
    return 'Sharma';
};

module.exports.constTesting = function (req, res) {
    var doc = new usercontroller.Test(req, res, function (result) {
        res.render('test', {'data': result});
    });
};

module.exports.testing2 = function (a, b) {
    switch (true) {
        case (a == 'first'):
            var r = first('2');
            return r;
            break;

        case (a == 'second'):
            return 'second1';
            break;

        default:
            return 'Invalid Parameter passed';
    }

    function first(q) {
        return q + 'passed parameter';
    }

};

module.exports.helper = function (req, res) {

    var param1 = 'Sharma';
    var val = new helper.Helper1(param1, function (result) {

        res.render('test', {'data': result});
    });
    // res.render('test', {'data': val});
};

// module.exports.sessionData = function (param1, param2) {
//     req.session.data = {
//         param1: param1,
//         param2: param2
//     };
//     console.log('==========', req.session.data, '=========');
//     req.session.data.param3 = null;
//     req.session.data.id = 12;
//     console.log('==========', req.session.data, '=========');
//     return false;
// };