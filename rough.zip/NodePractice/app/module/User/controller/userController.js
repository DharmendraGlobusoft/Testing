'use strict';
var model = require('../model/userModel');
var nodemailer = require('nodemailer');
var credentials = require('../../../../creds');
const sgMail = require('../../../../node_modules/@sendgrid/mail');
var Paypal = require('paypal-express-checkout');

module.exports.welcomePage = function (req, res) {
    res.render('userView', {data: 'hello', code: 200});
};

module.exports.loginPage = function (req, res) {
    // res.render('userView', { data: 'hello', code: 200 }); this is the way to pass data to ejs(html) page


    // req.session.data ={
    //     userName:req.body.username,
    //     password:req.body.password
    // };
    // console.log(req.session.data);
    // req.session.data.id=null;
    // req.session.data.id=12;
    // console.log('==========',req.session.data,'=========');
    // return false;


    if (req.method == 'POST') {

        var userData = {
            email: req.body.username,
            password: req.body.password
        };
        model.userLogin(userData, function (data) {

            if (data.code == 200) {

                if (data.dataDb[0] != undefined) {

                    req.session.success = data.dataDb[0];
                    res.redirect('/dashboard/' + data.dataDb[0]['_id']);

                } else {
                    res.render('login', {'message': 'Failed to Login, Provide valid credentials...!!'});
                }
            } else {
                res.render('login', {'message': 'Failed to Login, Provide valid credentials...!!'});
            }
        });
    } else {
        res.render('login');
    }
};

module.exports.editDetails = function (req, res) {
    var sesData = req.session.success;
    if (req.method == 'POST') {
        var dataToUpdate = {
            fname: req.body.fname,
            lname: req.body.lname
        };
        var oldData = {
            fname: sesData.fname,
            lname: sesData.lname
        };
        model.editDetails(oldData, dataToUpdate, function (data) {
            console.log(data);
            if (data.code == 200) {
                req.session.success.fname = req.body.fname;
                req.session.success.lname = req.body.lname;
                // res.end('{"success" : "Updated Successfully", "status" : 200}');
                var response = {
                    status: 200,
                    data: req.session.success,
                    message: 'Successfully updated'
                };
                res.json(response);
                // res.json({data:response})
            } else {
                var response = {
                    status: 400,
                    data: req.session.success,
                    message: 'Failed to update, Please try again...!!'
                };
                res.json(response);
            }
        });

    } else {
        // console.log('===============', sesData, '===========');
        res.render('editDetails', {'data': sesData});
    }

};

module.exports.dataTable = function (req, res) {
    // if (req.method == 'POST') {
    console.log('post');
    var response;
    model.getAllDetails(function (data) {
        // console.log('===============', data);
        if (data.code == 200) {
            // res.end('{"success" : "Updated Successfully", "status" : 200}');
            response = {
                status: 200,
                data: data
            };
            console.log('=====================', response);
            // res.json({reportList:response.data.dataDb});
            res.render('table', {
                reportList: response.data.dataDb
            });
            // res.json(response);
        } else {
            var response = {
                status: 400
            };
            res.json(response);
        }
    });
    // } else {
    //     res.render('table');
    // }

};

module.exports.registerPage = function (req, res) {
    if (req.method === 'POST') {
        var pic = '/images/profilePic/' + req.file.filename;
        var dob = new Date(req.body.dob).getTime() / 1000;

        var userData = {
            fname: req.body.firstName,
            lname: req.body.lastName,
            email: req.body.email,
            password: req.body.password,
            dob: dob,
            mobNumber: req.body.phoneNumber,
            image: pic,
            gender: req.body.gender
        };
        model.register(userData, function (data) {

            if (data.code == 200) {
                req.session.signed = 'Registration is successfully done. Please Login Here!!';
                res.redirect('/login');

            }
            if (data.code == 404) {
                res.render('register', {
                    'result': 'Failed to SignUp Try Again...!!',
                    data: userData
                });
            }
        });
    } else {
        res.render('register');
    }
};

module.exports.dashboardPage = function (req, res, id) {

    model.getUserData(id, function (data) {
        if (data.code == 200) {
            if (data.dataDb[0] != undefined) {
                req.session.success = data.dataDb[0];
                var dashboardData = req.session.success;
                res.render('dashboard', {'data': dashboardData});

            } else {
                req.session.success = 'Failed to Login, Provide valid credentials...!!';
                res.redirect('/login');
            }
        } else {
            console.log("Failed to Login");
        }
    });
};

module.exports.sendEmail = function (req, res) {

    if (req.method == 'POST') {
        // console.log(req.body.toEmail);
        // return false;
        // var obj=new helper();


        var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: credentials.userEmail,
                pass: credentials.pass
            }
        });

        var mailOptions = {
            from: 'sharmaglobussoft@gmail.com',
            //   to: 'shankarmandal.globussoft64@gmail.com',
            // to: 'sharmaglobussoft@gmail.com',//if required to send too many email at a time separate each email by(,)e.g  "a,b,c" where a,b,c are emailId
            to: req.body.toEmail,//if required to send too many email at a time separate each email by(,)e.g  "a,b,c" where a,b,c are emailId
            subject: 'Sending Email using Node.js',
            html: '<h1>Welcome</h1><p>This is for testing</p>'
        };

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log('Email sent: ' + info.response);
                res.render('sendEmail', {'data': req.session.success});
                // res.render('sendEmail', {'message': 'Mail sent Successfully..!!'});
            }
        });


    } else {
        res.render('sendEmail', {'data': req.session.success});
    }
};

module.exports.smsPage = function (req, res) {

    if (req.method == 'POST') {
        console.log(req.body);
        var number = req.body.conCode + req.body.phone;
// =============this code is to send sms using Nexmo==================
        const Nexmo = require('nexmo');
        const nexmo = new Nexmo({
            apiKey: 'fd67b14e',
            apiSecret: 'q4XKD2nfN0ASeHxz'
        });

        const from = 'DharmendraSharma';
        const to = number;
        const text = req.body.message;
        // console.log(nexmo.message.sendSms(from, to, text));
// ============================================================================


    } else {
        res.render('sms', {'data': req.session.success});
        // res.render('sendSms');
    }
};

function Test(req, res, callback) {

    this.test2('dharmendra', function (result) {
        callback(result)
    });
}

Test.prototype.test2 = function (param1, callback) {

    callback(param1)
};

module.exports.Test = Test;

module.exports.test = function (param1, param2) {
    return param1 + ' Dharmendra ' + param2;
};

module.exports.makePayment = function (req, res) {

    if(req.method == 'POST'){



        // debug = optional, defaults to false, if true then paypal's sandbox url is used
// paypal.init('some username', 'some password', 'signature', 'return url', 'cancel url', debug);
        var username = credentials.username;
        var password = credentials.password;
        var signature = credentials.signature;
        var returnUrl = credentials.returnUrl;
        var cancelUrl = credentials.cancelUrl;
        var amount = req.body.amount;
        // var paypal = Paypal.init(username, password, signature, 'http://www.example.com/return', 'http://www.example.com/cancel', true);
        var paypal = Paypal.init(username, password, signature, returnUrl, cancelUrl, true);

// Localization (OPTIONAL): https://developer.paypal.com/docs/classic/api/locale_codes/
// paypal.locale = 'SK';
// or
// paypal.locale = 'en_US';

// checkout
// requireAddress = optional, defaults to false
// paypal.pay('Invoice number', amount, 'description', 'currency', requireAddress, customData, callback);
// paypal.pay('20130001', 123.23, 'iPad', 'EUR', function(err, url) {
// or with "requireAddress": true
//         paypal.pay('20130001', 123.23, 'iPad', 'EUR', true, ['custom', 'data'], function(err, url) {
        paypal.pay(Date.now(), amount, 'Instant Payment For Product', 'USD', true, ['custom', 'data'], function(err, url) {
            if (err) {
                console.log(err);
                return;
            }

            // redirect to paypal webpage
            response.redirect(url);
        });

// result in GET method
// paypal.detail('token', 'PayerID', callback);
// or
// paypal.detail(totaljs.controller, callback);

        paypal.detail('EC-788441863R616634K', '9TM892TKTDWCE', function(err, data, invoiceNumber, price, custom_data_array) {

            // custom_data_array {String Array} - supported in +v1.6.3

            if (err) {
                console.log(err);
                return;
            }

            // data.success == {Boolean}

            if (data.success)
                console.log('DONE, PAYMENT IS COMPLETED.');
            else
                console.log('SOME PROBLEM:', data);

            /*
            data (object) =
            { TOKEN: 'EC-35S39602J3144082X',
              TIMESTAMP: '2013-01-27T08:47:50Z',
              CORRELATIONID: 'e51b76c4b3dc1',
              ACK: 'Success',
              VERSION: '52.0',
              BUILD: '4181146',
              TRANSACTIONID: '87S10228Y4778651P',
              TRANSACTIONTYPE: 'expresscheckout',
              PAYMENTTYPE: 'instant',
              ORDERTIME: '2013-01-27T08:47:49Z',
              AMT: '10.00',
              TAXAMT: '0.00',
              CURRENCYCODE: 'EUR',
              PAYMENTSTATUS: 'Pending',
              PENDINGREASON: 'multicurrency',
              REASONCODE: 'None' };
            */

        });
    }else{
        res.render('payment');
    }





};

module.exports.sendGrid = function (req, res) {

    if (req.method == "POST") {

        var from = req.body.from;
        var to = req.body.to;
        var message = req.body.message;
        var subject = req.body.subject;
        var sgId = credentials.sendGridApiKey;
        sgMail.setApiKey(sgId);
        var msg = {
            to: to,
            from: from,
            subject: subject,
            html: '<h2>!Welcome!</h2>' +
            "<p>This is the test mail from Dharmendra using SendGrid<h3><b>Your Message<b></h3>"+message+"<br>Find your attachement below</p>" +
            '<p>Thanks</p>',
        };
        sgMail.send(msg, (error, result) => {
            if (error) {
                console.log('Error occured..!!');
                console.log(error, 'Error occured..!!', result);
                res.render('sendGrid', {'message': 'Error occured..!!'});
            }
            else {
                console.log('Mail sent Successfully..!!');
                // console.log(result);
                res.render('sendGrid', {'message': 'Mail sent Successfully..!!'});
            }
        });
    } else {
        res.render('sendGrid');
    }
};