var userController = require('../controller/userController.js');
var testController = require('../controller/testController.js');
var userModel = require('../model/userModel.js');
var dataModel = require('../model/dataModel.js');
const multer = require('multer');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/images/profilePic')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
var upload = multer({
    storage: storage
});


var myLogger = function (req, res, next) {
    // console.log('Check Session',req.session.success);
    if (req.session.success) {
        next();
    } else {
        res.redirect('/user');
    }
};

var express=require('express');
var router=express.Router();

router.get('/test', function (req, res) {
    testController.testing(req, res);
}); // or; router.get('/test',testController.testRoute);

router.get('/const', function (req, res) {
    testController.constTesting(req, res);
});

router.get('/helper', function (req, res) {
    testController.helper(req, res);
});

router.get('/parameter/:id/:val', function (req, res) {
    testController.testRoute(req, res, id, req.params.val);
});

router.get('/fun', function (req, res) {
    testController.fun1(req, res);
});

router.get('/connection', function (req, res) {
    userModel.databaseConnection(req, res);
});

// router.get('/session', function (req, res) {
//     testController.sessionData('hello', 'world');
// });
router.get('/appurl', function (req, res) {
    testController.appUrl(req, res);
});



//=========================================================================================

router.get('/sendGrid', function (req, res) {
    userController.sendGrid(req, res);
});

router.post('/sendGrid', function (req, res) {
    userController.sendGrid(req, res);
});





router.get('/login', function (req, res) {
    userController.loginPage(req, res);
});
router.post('/login', function (req, res) {
    userController.loginPage(req, res);
});

router.get('/register', function (req, res) {
    userController.registerPage(req, res);
});
router.post('/register', upload.single('image'), function (req, res) {
    userController.registerPage(req, res);
});


router.use(myLogger);          //this will work as middleware;


router.get('/dashboard/:id', function (req, res) {
    userController.dashboardPage(req, res, req.params.id);
});

router.get('/sendEmail', function (req, res) {
    userController.sendEmail(req, res);
});
router.post('/sendEmail', function (req, res) {
    userController.sendEmail(req, res);
});

router.get('/sendSms', function (req, res) {
    userController.smsPage(req, res);
});
router.post('/sendSms', function (req, res) {
    userController.smsPage(req, res);
});
router.get('/logout', function (req, res) {
    req.session.success = null;
    return res.redirect('/');
});

router.get('/editDetails', function (req, res) {
    userController.editDetails(req, res);
});

router.post('/editDetails', function (req, res) {
    userController.editDetails(req, res);
});

router.get('/tableUser', function (req, res) {
    userController.dataTable(req, res);
});


router.get('/mytable', function (req, res) {
    console.log('mytable===========')
});

router.get('/table',function (req, res) {
    var data = [
        {
            name: 'Dharmendra1',
            email: 'Dharmendra1@gmail.com',
            password: 'Sharma1@123',
            gender: 'Male',
            number: '9876543211',

        },
        {
            name: 'Dharmendra2',
            email: 'Dharmendra2@gmail.com',
            password: 'Sharma2@123',
            gender: 'Male',
            number: '9876543212',

        },
        {
            name: 'Dharmendra3',
            email: 'Dharmendra3@gmail.com',
            password: 'Sharma3@123',
            gender: 'Male',
            number: '9876543213',

        }
    ];
    res.render('table');
    // res.render('table',{data: (data)});
});


router.get('/makePayment', function (req, res) {
    userController.makePayment(req, res);
});

router.post('/makePayment', function (req, res) {
    userController.makePayment(req, res);
});

router.get('/returnUrl', function (req, res) {

    console.log('====return====',req.body);
    return false;

    userController.makePayment(req, res);
});

router.get('/cancelUrl', function (req, res) {

    console.log('====cancel====',req.body);
    return false;
    userController.makePayment(req, res);
});

router.get('/', function (req, res) {
    userController.welcomePage(req, res);
});


module.exports = router;
