var adminController = require('../controller/adminController.js');
var userModel = require('../model/adminModel.js');
const multer = require('multer');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/images/profilePic')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
var upload = multer({
    storage: storage
});

var myLogger = function (req, res, next) {
    // console.log('Check Session',req.session.success);
    if (req.session.success) {
        next();
    } else {
        res.redirect('/');
    }
};


var express=require('express');
var router=express.Router();


router.get('/',(req,res)=>{
    adminController.testing(req, res);
});

router.get('/admin', function (req, res) {
    console.log('hhhhhhhhhhhhhhhhhhhhh');
    adminController.testingAdmin(req, res);
}); // or; router.get('/test',testController.testRoute);


module.exports = router;