'use strict';
var nodemailer = require('nodemailer');
var credentials = require('../../../../creds');

module.exports.testing = function (req, res) {
    res.render('admin', {data: 'Hello Dharmendra', code: 200});
};

module.exports.testingAdmin = function (req, res) {
    res.render('admin', {data: 'Hello Sharma', code: 200});
};

