module.exports = {

    socket_url:'http://localhost:3000',
    web_url:'http://localhost:3000/',

    mongodbcrd: {
        user: '',
        pass: '',
        host: '127.0.0.1',
        database: 'chatting',
        debug: process.env.MONGODB_DEBUG || false
    }


};
