var mongoose = require('mongoose');

var userschema = new mongoose.Schema({
    name: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    password: { type: String, trim: true, required: true },
    updated_at: { type: String },
    created_at: { type: String }
});

module.exports = mongoose.model('users', userschema);   // create users table in DB
