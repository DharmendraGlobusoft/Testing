var userController = require('../controller/userController');
var fileUploadController = require('../controller/fileUploadController');

var passwordHash = require('password-hash');
var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var SALT_WORK_FACTOR = 10;


//===================== SET STORAGE for file uploading ===========================

var multer = require('multer');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/uploads')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
var upload = multer({storage: storage});


//==================================file Upload routes============================


router.get('/uploadfile', function (req, res) {
    userController.fileUpload(req, res);
});

//==============================Uploading single files=============================
router.post('/uploadfile', upload.single('myFile'), (req, res, next) => {
    const file = req.file;

    if (!file) {
        const error = new Error('Please upload a file');
        error.httpStatusCode = 400;
        return next(error)
    }
    console.log('===========Uploaded====',file);
    res.send(file)

});


//===========================Uploading multiple files
router.post('/uploadmultiple', upload.array('myFiles', 12), (req, res, next) => {
    const files = req.files;
    if (!files) {
        const error = new Error('Please choose files');
        error.httpStatusCode = 400;
        return next(error)
    }

    res.send(files)

});


//============================password hashing=====================================



router.get('/password',function (req, res) {
    var pass='Sharma@123';
    var hashedPassword = passwordHash.generate(pass);
    console.log(hashedPassword);
    console.log('If password not match it will return false==========',passwordHash.verify('password123', hashedPassword));
    console.log('If password matches it will return true===========',passwordHash.verify(pass, hashedPassword));

});
//============================Showing Table=====================================


router.get('/table',function (req, res) {
    var data = [
        {
            name: 'Dharmendra1',
            email: 'Dharmendra1@gmail.com',
            password: 'Sharma1@123',
            gender: 'Male',
            number: '9876543211',

        },
        {
            name: 'Dharmendra2',
            email: 'Dharmendra2@gmail.com',
            password: 'Sharma2@123',
            gender: 'Male',
            number: '9876543212',

        },
        {
            name: 'Dharmendra3',
            email: 'Dharmendra3@gmail.com',
            password: 'Sharma3@123',
            gender: 'Male',
            number: '9876543213',

        }
    ];

    res.render('showTable',{data: (data)});
});



//=================================Chatting================================================
router.post('/chat', function (req, res) {
    // console.log(req.body);
    userController.chat(req, res);
});

router.get('/chat', function (req, res) {
    console.log(req.body);
    userController.chat(req, res);
});
// router.get('/chat', userController.chat);

router.post('/chatting', function (req, res) {
    userController.chatting(req, res);
});


router.get('/chatting', function (req, res) {
    userController.chatting(req, res);
});

router.get('/register', function (req, res) {
    userController.register(req, res);
});

router.post('/register', function (req, res) {
    userController.register(req, res);
});

router.get('/logout', function (req, res) {
    req.session.data = null;
    return res.redirect('/');
});

router.post('/login', function (req, res) {
    userController.login(req, res);
});

router.get('/*', function (req, res) {

    if (req.session.data != null) {
        return res.redirect('/chat');
    } else {
        userController.login(req, res);
    }
});

module.exports = router;
