'use strict';

var async = require('async');

var userschema = require('../../../../schemas/userschema');


module.exports.login = function (req, res) {
    if (req.method == 'POST') {
        var data = req.body || req.query;
        var userData;
        async.waterfall([
            function (callback) {

                if (req.body.username == '' || req.body.password == '') {
                    callback(null, {code: 400, message: "User name already exist!"})
                } else {
                    callback(null, data);
                }

            }, function (Data, callback) {

                userschema.findOne({username: Data.username, password: Data.password}, function (error, user) {
                    if (error) {
                        console.log("gencode-->", error);
                        callback(null, {code: 400, message: "Error occured try again..!!"});
                    } else if (user) {
                        userData = {
                            userId: user._id,
                            username: user.username,
                        };
                        callback(null, {code: 200, message: "Authentication successfully done..", userData: userData});

                    } else {
                        console.log("Invalid user", user);
                        callback(null, {code: 400, message: "User does not exist/invalid credentials"});
                    }
                })

            }
        ], function (error, result) {
            if (result) {
                // console.log('======Result============',result,'==================');
                if (result.code == 200) {

                    req.session.data = {
                        userId: result.userData.userId,
                        username: result.userData.username
                    };
                    // console.log('=========Session Data==========',req.session.data);

                    res.redirect('/chat');
                } else {
                    res.render('login', {userdata: result});
                }

            } else {
                console.log('======Error============', error, '==================');
                res.render('login', {userdata: error});
            }

        })

    } else {
        res.render('login');
    }

};

module.exports.chat = function (req, res) {
    if (req.session.data == null) {
        res.redirect('/');
    } else {
        // console.log('=========Session Data==========',req.session.data);
        res.render('chat', {username: req.session.data.username, userId: req.session.data.userId});
    }

};

module.exports.chatting = function (req, res) {
    res.render('chatting');
};

module.exports.fileUpload = function (req, res) {
    if (req.method == 'POST'){
        if (!req.files)
            res.json('No files were uploaded.');

        let sampleFile = req.files.attach_file;
        console.log(sampleFile.length);

        var file_info = [];
        var count = 0;
        sampleFile.forEach(function(ele, key) {
            ele.mv(path.resolve(`./public/assets/images/${ele.name}`), function(err) {
                if (err){
                    console.log(err);
                }else{
                    file_info.push(ele.name);
                }
                count++;
                if(sampleFile.length == count){
                    res.json({file_name: file_info });
                }
            });
        });
    }else{

        res.render('fileUpload');
    }
};

module.exports.register = function (req, res) {
    if (req.method == 'POST') {
        var data = req.body || req.query;
        async.waterfall([
                function (callback) {
                    console.log("body data-->", req.body);

                    if (req.body.name == '' || req.body.password == '' || req.body.username == '') {
                        callback(null, {code: 400, message: "User name already exist!"})
                    } else {
                        callback(null, data);
                    }
                },
                function (Data, callback) {
                    console.log("body-->", Data);
                    var code = null;
                    userschema.findOne({username: Data.username}, function (error, user) {
                        if (error) {
                            console.log("gencode-->", error)
                        } else if (user) {
                            callback(null, {code: 400, message: "User name already exist!"})
                        } else {
                            var user = new userschema({
                                name: Data.name,
                                username: Data.username,
                                password: Data.password,
                                updated_at: Math.floor(Date.now() / 1000),
                                created_at: Math.floor(Date.now() / 1000)
                            });
                            console.log("user-->", user);

                            user.save(function (error, rep) {
                                if (error) {
                                    console.log("error--save-->", err);
                                    return err;
                                } else {
                                    callback(null, {
                                        code: 200,
                                        message: "Registration successful please login to continue.."
                                    });
                                }
                            })
                        }
                    })
                }
            ],
            function (error, results) {
                if (error) {
                    console.log('=====================', error);
                    res.render('register', {data: results});
                } else {
                    console.log('=====================', results);
                    res.render('login', {data: results});
                }
            })
    } else {
        res.render('register');
    }
};


