
var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);


var bodyParser = require('body-parser');
var userRoutes = require('./app/module/user/route/userRoute.js');
app.set('views', [__dirname + '/app/module/user/view', __dirname + '/app/module/admin/view']);
app.engine('ejs', require('ejs').__express);
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use("/test", express.static(__dirname+ '/public'));
app.use('/app',express.static(__dirname + '/app'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
var session = require('express-session');
app.use(session({
    secret: 'Sharma', // session secret
    resave: true,
    saveUninitialized: true
}));

app.use('/', userRoutes);

var databaseConnection = require('./bin/dbconnection');

http.listen(3000, function() {
    console.log('listening on localhost:3000');
});

require('./socket/socketService')(io);



module.exports = app;



