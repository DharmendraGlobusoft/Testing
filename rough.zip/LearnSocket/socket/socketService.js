module.exports = function (io) {

    users = [];
    onlineUsers=[];
    io.on('connection', function (socket) {
        console.log("Socket Connected");

        console.log("sockets are connected at socket id:", socket.id);

        socket.on('setUsername', function(data) {

            var userdetails={username : data,socketId: socket.id};
            var status=0;
            if (data){

                for (var i = 0; i < onlineUsers.length; i++) {

                    var obj = onlineUsers[i];
                    if (obj.username == data) {
                        status=1;
                        onlineUsers.splice(i, 1);
                        onlineUsers.push(userdetails);
                    }
                }
            }
            if(status==0){
                onlineUsers.push(userdetails);
            }
            console.log('=========RelodData=',onlineUsers);
            //Send online user to everyone
            io.sockets.emit('userSet', {doc: onlineUsers});
        });


        socket.on('getRoutes', function (data) {
            console.log("-------------getroutes------", data);
            (new routesservices()).getroutes(function (error, response) {
                if (error) {
                    console.log("error-->", error);
                    io.to(socket.id).emit('getRoutesResponse', response);
                } else {
                    console.log("response-->", response);
                    io.to(socket.id).emit('getRoutesResponse', response);
                }
            })
        });

        socket.on('getBuses', function () {
            console.log("-------------getBuses------");
            (new busservices()).getbuses(function (error, response) {
                if (error) {
                    console.log("error-->", error);
                    io.to(socket.id).emit('getBusesResponse', response);
                } else {
                    console.log("response-->", response);
                    io.to(socket.id).emit('getBusesResponse', response);
                }
            })

        });



        socket.on('disconnect', function () {

            console.log('=====before===',onlineUsers);

            // remove the offline users

            for (var i = 0; i < onlineUsers.length; i++) {

                var obj = onlineUsers[i];
                if (obj.socketId == socket.id) {
                    onlineUsers.splice(i, 1);
                }
            }

            console.log('=====After===',onlineUsers);

            console.log("disconnected with socket connection of id:", socket.id);
            io.sockets.emit('userSet', {doc: onlineUsers});


        })
    })
};
