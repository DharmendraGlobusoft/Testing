<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 6/8/2018
 * Time: 12:52 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Manager\Models\Issue;
use App\Modules\Manager\Models\Message;
use App\Modules\Manager\Models\Notification;
use App\Modules\Manager\Models\Project;
use App\Modules\Manager\Models\Task;
use App\Modules\Manager\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class MessageController extends Controller
{

    /**
     * messagePage
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 2nd-Apr-2018
     */
    public function messagePage($sid = null, $rid = null)
    {
        $allProjectName = functionToGetProjectNames();
        $allStaffName = functionToGetStaffData();
        $allAdminName = functionToGetAdminData();
        $allManagerName = functionToGetMangerData();
        $allAdminndStaffData = array_merge(json_decode($allAdminName), json_decode($allStaffName));
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_manager')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_manager.totalNotification', count($totalNotification));

        return view('Manager::Dashboard/messages', ['userData' => json_decode($allStaffName), 'sid' => $sid, 'rid' => $rid, 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName), 'allData' => $allAdminndStaffData]);
    }

    /**
     * insertMessageData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 30th-Apr-2018
     * insertMessageData
     */
    public function insertMessageData(Request $request)
    {
        if ($request->isMethod('post')) {
            $senderName = Session::get('co_manager')['name'];
            $senderId = Session::get('co_manager')['id'];
            $receiverName = $request->input('receiverName');
            $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$receiverName]];
            $dataToFInd = ['id', 'name'];
            $getUserData = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
            $senderMessage = $request->input('senderMessage');
            $sederMessageArr[] = ['id' => (string)$senderId, 'messageId' => 1, 'posted_on' => time(), 'message' => $senderMessage];

            $array = [];
            $allIds = array_push($array, json_decode($getUserData)[0]->id, $senderId);

            $allId = implode(',', array_unique(array_map(function ($h) {
                return $h;
            }, $array)));

//            $whereToFind = ['rawQuery' => 'message_receiver_id = ? and message_sender_id=?', 'bindParams' => [json_decode($getUserData)[0]->id, $senderId]];
            $whereToFind = ['rawQuery' => 'message_sender_id in(' . $allId . ') and message_receiver_id in(' . $allId . ')'];
            $queryToFinddata = Message::getInstance()->getMessageData($whereToFind);
            if (!$queryToFinddata) {
                $notifyType = 3; //for sending message
                $type = 0;
                $insertFeedData = $this->insertNotification(Session::get('co_manager')['id'], json_decode($getUserData)[0]->id, json_decode($getUserData)[0]->id, json_decode($getUserData)[0]->name, '', $notifyType, $type);
                $dataToInsert = [
                    'message_sender_id' => Session::get('co_manager')['id'],
                    'message_receiver_id' => json_decode($getUserData)[0]->id,
                    'sender_message' => json_encode($sederMessageArr),
                    'receiver_message' => '',
                    'created_at' => time(),
                    'updated_at' => time()
                ];
                $queryToInsertMessage = Message::getInstance()->insertMessageData($dataToInsert);
                if ($queryToInsertMessage)
                    return json_encode(['status' => 200, 'message' => 'Message Send Successfully']);
                else
                    return json_encode(['status' => 400, 'message' => 'Not Sent.Please Try Again!']);
            } else {
                return json_encode(['status' => 401, 'message' => 'You Have Already Created New Message For This User. Please Check the Conversation Directly!']);
            }
        }
    }

    /**
     * messageDataAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 30th-Apr-2018
     */
    public function messageDataAjaxHandler(Request $request)
    {
        $allManagerName = functionToGetMangerData();
        $managerId = Session::get('co_manager')['id'];
        $allIds = json_decode($allManagerName);

        $allId = implode(',', array_unique(array_map(function ($h) {
            return $h->id;
        }, $allIds)));
//        $whereToFetch = ['rawQuery' => 'message_sender_id in(' . $allId . ')and message_receiver_id in(' . $allId . ')'];
        $whereToFetch = ['rawQuery' => 'message_sender_id = ? or message_receiver_id = ?', 'bindParams' => [$managerId, $managerId]];;
        $dataToFetch = ['message_id', 'message_sender_id', 'message_receiver_id', 'created_at'];
        $fetchMessageTable = Message::getInstance()->getMessageDetails($whereToFetch, $dataToFetch);
        $messageDetails=$this->messageDatatble($fetchMessageTable);
        return DataTables::of($messageDetails)->rawColumns(['details'])->make(true);
    }

    /**
     * fetchAllMessage
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 1st-May-2018
     */
    public function fetchAllMessage(Request $request)
    {
        if ($request->isMethod('post')) {
            $senderId = $request->input('senderId');
            $receiverId = $request->input('receiverId');

            $userData = $this->toFIndUser($receiverId);

            $allId[] = ['Id' => $senderId];
            $allId[] = ['Id' => $receiverId];
            $allId = json_decode(json_encode($allId));

            $allIds = implode(',', array_unique(array_map(function ($h) {
                return $h->Id;
            }, $allId)));

            $whereToFind = ['rawQuery' => 'message_sender_id in(' . $allIds . ') and message_receiver_id in(' . $allIds . ')'];
            $dataToFind = ['sender_message'];
            $queryToFetchMessage = Message::getInstance()->getMessageDetails($whereToFind, $dataToFind);

            if ($queryToFetchMessage) {

                $senderMessageDetails = array_map(function ($data) {
                    return $data->sender_message ? json_decode($data->sender_message) : [];
                }, json_decode($queryToFetchMessage));

                if (count($senderMessageDetails) > 1) {
                    $senderMessage = $senderMessageDetails[0];
                    $receiverMessage = $senderMessageDetails[1];
                    $allConversation = array_merge($senderMessage, $receiverMessage);
                } else {
                    $senderMessage = $senderMessageDetails[0];
                    $receiverMessage = [];
                    $allConversation = array_merge($senderMessage, $receiverMessage);
                }

                usort($allConversation, function ($a, $b) {
                    return $a->posted_on - $b->posted_on;
                });
                foreach ($allConversation as $k => $data) {
                    $userdetails = $this->toFIndUser($data->id);
                    $profilePic = $userdetails[0]->profile_pic ? $userdetails[0]->profile_pic : '/images/default.png';
                    $data->profile_pic = $profilePic;
                    $data->name = $userdetails[0]->name;
                    $data->role = $userdetails[0]->role;
                    $postedOn = $data->posted_on;
                }
//                $lastId = $request->input('lastId') ? $request->input('lastId') : '';
//                $latestDataArray = [];
//                $latestData = array_reverse($allConversation);
//                foreach ($latestData as $key => $val) {
//                    if ($request->input('lastId'))
//                        if ((int)$request->input('lastId') < (int)$val->messageId) {
//                            array_push($latestDataArray, $val);
//                        } else {
//                            break;
//                        }
//                }
                return json_encode([
                    'status' => 200,
                    'message' => 'All the Messages Fetched Successfully',
                    'data' => $allConversation,
                    'receiverData' => $userData[0]->profile_pic ? $userData[0]->profile_pic : '/images/default.png',
                    'id' => (string)Session::get('co_manager')['id'],
//                    'latestData' => array_reverse($latestDataArray)
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No such conversation messages are there!'
                ]);
            }
        }
    }

    public function fetchLatestMessage(Request $request)
    {
        if ($request->isMethod('post')) {
            $senderId = $request->input('senderId');
            $receiverId = $request->input('receiverId');

            $userData = $this->toFIndUser($receiverId);

            $allId[] = ['Id' => $senderId];
            $allId[] = ['Id' => $receiverId];
            $allId = json_decode(json_encode($allId));

            $allIds = implode(',', array_unique(array_map(function ($h) {
                return $h->Id;
            }, $allId)));

            $whereToFind = ['rawQuery' => 'message_sender_id in(' . $allIds . ') and message_receiver_id in(' . $allIds . ')'];
            $dataToFind = ['sender_message'];
            $queryToFetchMessage = Message::getInstance()->getMessageDetails($whereToFind, $dataToFind);

            if ($queryToFetchMessage) {

                $senderMessageDetails = array_map(function ($data) {
                    return $data->sender_message ? json_decode($data->sender_message) : [];
                }, json_decode($queryToFetchMessage));

                if (count($senderMessageDetails) > 1) {
                    $senderMessage = $senderMessageDetails[0];
                    $receiverMessage = $senderMessageDetails[1];
                    $allConversation = array_merge($senderMessage, $receiverMessage);
                } else {
                    $senderMessage = $senderMessageDetails[0];
                    $receiverMessage = [];
                    $allConversation = array_merge($senderMessage, $receiverMessage);
                }

                usort($allConversation, function ($a, $b) {
                    return $a->posted_on - $b->posted_on;
                });
//                foreach ($allConversation as $k => $data) {
//                    $userdetails = $this->toFIndUser($data->id);
//                    $profilePic = $userdetails[0]->profile_pic ? $userdetails[0]->profile_pic : '/images/default.png';
//                    $data->profile_pic = $profilePic;
//                    $data->name = $userdetails[0]->name;
//                    $data->role = $userdetails[0]->role;
//                    $postedOn = $data->posted_on;
//                }
                $lastId = $request->input('lastId') ? $request->input('lastId') : '';
                $allId = $request->input('allIds') ? $request->input('allIds') : '';

                $latestDataArray = [];
                $latestData = array_reverse($allConversation);
                foreach ($latestData as $key => $val) {
                    if ($request->input('lastId'))
                        if ((int)$request->input('lastId') < (int)$val->messageId) {
                            $userdetails = $this->toFIndUser($val->id);
                            $profilePic = $userdetails[0]->profile_pic ? $userdetails[0]->profile_pic : '/images/default.png';
                            $val->profile_pic = $profilePic;
                            $val->name = $userdetails[0]->name;
                            $val->role = $userdetails[0]->role;
                            $postedOn = $val->posted_on;
                            array_push($latestDataArray, $val);
                        } else {
                            break;
                        }
                }
//                foreach ($latestData as $key => $val) {
////                    foreach ($allId as $k => $v) {
//                        if ((int)$allId[$key] < (int)$val->messageId) {
//                            $userdetails = $this->toFIndUser($val->id);
//                            $profilePic = $userdetails[0]->profile_pic ? $userdetails[0]->profile_pic : '/images/default.png';
//                            $val->profile_pic = $profilePic;
//                            $val->name = $userdetails[0]->name;
//                            $val->role = $userdetails[0]->role;
//                            $postedOn = $val->posted_on;
//                            array_push($latestDataArray, $val);
//                        } else {
//                            break;
//                        }
////                    }
//                }
                return json_encode([
                    'status' => 200,
                    'message' => 'All the Messages Fetched Successfully',
//                    'data' => $allConversation,
                    'receiverData' => $userData[0]->profile_pic ? $userData[0]->profile_pic : '/images/default.png',
                    'id' => (string)Session::get('co_manager')['id'],
                    'latestData' => array_reverse($latestDataArray)
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No such conversation messages are there!'
                ]);
            }
        }
    }

    /**
     * toFIndUser
     * @param $id
     * @return mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 1st-May-2018
     */
    function toFIndUser($id)
    {
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFind = ['name', 'profile_pic', 'role'];
        $queryToFindUserDeatils = json_decode(User::getInstance()->getUserDetails($whereToFind, $dataToFind));
        return $queryToFindUserDeatils;
    }

    /**
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 3rd-May-2018
     */
    public function sendMessage(Request $request)
    {
        if ($request->isMethod('post')) {
            $senderId = $request->input('senderId');
            $receiverId = $request->input('receiverId');
            $userData = $this->toFIndUser($receiverId);

            $messageData = $request->input('message');
            $messageData = str_replace(' ', ' ', $messageData);

            $array = [];
            $allIds = array_push($array, $receiverId, $senderId);

            $allId = implode(',', array_unique(array_map(function ($h) {
                return $h;
            }, $array)));

            $whereToFind = ['rawQuery' => 'message_sender_id in(' . $allId . ') and message_receiver_id in(' . $allId . ')'];

//            $whereToFind = ['rawQuery' => 'message_sender_id = ? and message_receiver_id = ?', 'bindParams' => [$senderId, $receiverId]];
            $dataToFInd = ['sender_message'];
            $queryToFetchData = Message::getInstance()->getMessageDetails($whereToFind, $dataToFInd);
            $senderMessage = json_decode(json_decode($queryToFetchData)[0]->sender_message, true);

            $x = count($senderMessage);

            $notifyType = 4; //for sending message
            $type = 1;
            if ($receiverId == Session::get('co_manager')['id']) {
                $id = $senderId;
            } else {
                $id = $receiverId;
            }
            $insertFeedData = $this->insertNotification($senderId, $receiverId, $id, $userData[0]->name, '', $notifyType, $type);

            $messageToInsert = ['id' => (string)Session::get('co_manager')['id'], 'messageId' => ++$x, 'posted_on' => time(), 'message' => $messageData];
            $senderMessage[] = $messageToInsert;
            if ($messageData != '') {
                $whereToUpdate = ['rawQuery' => 'message_sender_id in(' . $allId . ') and message_receiver_id in(' . $allId . ')'];
//                $whereToUpdate = ['rawQuery' => 'message_sender_id = ? and message_receiver_id = ?', 'bindParams' => [$senderId, $receiverId]];
                $dataToUpdate = ['sender_message' => json_encode($senderMessage)];
                $queryToUpdate = Message::getInstance()->updateMessageDetails($whereToUpdate, $dataToUpdate);
                $datasss = [];
                if ($queryToUpdate) {
                    $dataAll = array_reverse(json_decode($dataToUpdate['sender_message']));
                    foreach ($dataAll as $key => $val) {
                        if ((int)$request->input('lastId') < (int)$val->messageId) {
                            $userdetails = $this->toFIndUser($val->id);
                            $profilePic = $userdetails[0]->profile_pic ? $userdetails[0]->profile_pic : '/images/default.png';
                            $val->profile_pic = $profilePic;
                            $val->name = $userdetails[0]->name;
                            $val->role = $userdetails[0]->role;
                            $postedOn = $val->posted_on;
                            array_push($datasss, $val);
                        } else {
                            break;
                        }
                    }
                    return json_encode([
                        'status' => 200,
                        'message' => 'Message Send Successfully',
                        'time' => time(),
                        'data' => array_reverse($datasss)
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Not Send.Please Try Again!',
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Please Enter Something!!',
                ]);
            }
        }
    }

    /**
     * insertNotification
     * @param $ids
     * @param $names
     * @param $projName
     * @param $notifyType
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function insertNotification($sid, $rid, $id, $name, $projName, $notifyType, $type)
    {
        $receiverId = $id;
        $senderId = Session::get('co_manager')['id'];
        $senderName = Session::get('co_manager')['name'];
        if ($notifyType === 3) {
            $senderMessage = 'You started convrsation with ' . $name . '';
//            $receiverMessage = $senderName . ' has started conversation with you.' ;
            $receiverMessage[] = ['sid' => $sid, 'rid' => $rid, 'message' => $senderName . ' has started conversation with you.'];
        } else if ($notifyType === 4) {
            $senderMessage = 'You send message to ' . $name . '';
//            $receiverMessage = $senderName . ' has sent message to you.';
            $receiverMessage[] = ['sid' => $sid, 'rid' => $rid, 'message' => $senderName . ' has sent message to you.'];
        }

        $dataToInsert = [
            'sender_id' => $senderId,
            'receiver_id' => $receiverId,
            'sender_message' => $senderMessage,
            'receiver_message' => json_encode($receiverMessage),
            'notify_type' => $notifyType,
            'notification_status' => 0,
            'created_at' => time(),
            'updated_at' => time()
        ];
        $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
    }

    public function filteringOfMessageAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        $managerId = Session::get('co_manager')['id'];

        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');

                $allIds[] = $managerId;
                $allIds[] = (int)$staffId;

                $allId = implode(',', array_unique(array_map(function ($h) {
                    return $h;
                }, $allIds)));
                $whereToFetch = ['rawQuery' => 'message_sender_id in(' . $allId . ')and message_receiver_id in(' . $allId . ')'];

                $dataToFetch = ['message_id', 'message_sender_id', 'message_receiver_id', 'created_at'];
                $fetchMessageTable = Message::getInstance()->getMessageDetails($whereToFetch, $dataToFetch);
                $messageDetails = $this->messageDatatble($fetchMessageTable);
                return DataTables::of($messageDetails)->rawColumns(['details'])->make(true);
            case 'FilertingByTime':
                if ($request->input('time') == 'today') {
                    $whereToFetch = ['rawQuery' => "created_at >= " . time() . " - 86400 and (message_sender_id = ".$managerId." or message_receiver_id = ".$managerId.")"];
                }
                if ($request->input('time') == '7 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY) and (message_sender_id = ".$managerId." or message_receiver_id = ".$managerId.")"];
                }
                if ($request->input('time') == '30 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY) and (message_sender_id = ".$managerId." or message_receiver_id = ".$managerId.")"];
                }

                $dataToFetch = ['message_id', 'message_sender_id', 'message_receiver_id', 'created_at'];
                $fetchMessageTable = Message::getInstance()->getMessageDetails($whereToFetch, $dataToFetch);

                $messageDetails=$this->messageDatatble($fetchMessageTable);
                return DataTables::of($messageDetails)->rawColumns(['details'])->make(true);
            case 'FilertingByView':
                $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY) and (message_sender_id = ".$managerId." or message_receiver_id = ".$managerId.")"];

                $dataToFetch = ['message_id', 'message_sender_id', 'message_receiver_id', 'created_at'];
                $fetchMessageTable = Message::getInstance()->getMessageDetails($whereToFetch, $dataToFetch);

                $messageDetails=$this->messageDatatble($fetchMessageTable);
                return DataTables::of($messageDetails)->rawColumns(['details'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');
                $whereToFetch = ['rawQuery' => 'message_sender_id = ? or message_receiver_id = ?', 'bindParams' => [$managerId, $managerId]];;
                $dataToFetch = ['message_id', 'message_sender_id', 'message_receiver_id', 'created_at'];
                $fetchMessageTable = Message::getInstance()->getMessageDetails($whereToFetch,$dataToFetch);

                $messageDetails = new Collection();

                foreach (json_decode($fetchMessageTable) as $k => $data) {
                    if (date("F Y", $data->created_at) == $date) {
                        $receiverId = json_decode($data->message_receiver_id);
                        if ($receiverId === Session::get('co_admin')['id']) {
                            $receiverId = json_decode($data->message_sender_id);
                            $senderId = json_decode($data->message_receiver_id);
                        } else {
                            $senderId = json_decode($data->message_sender_id);
                            $receiverId = json_decode($data->message_receiver_id);
                        }

                        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$senderId]];
                        $dataToFInd = ['name', 'role'];
                        $senderName = User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
                        $role = json_decode($senderName)[0]->role;

                        if ($role == 'A')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Admin]';
                        if ($role == 'M')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Manager]';
                        if ($role == 'S')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Staff]';


                        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$receiverId]];
                        $dataToFInd = ['name', 'role'];
                        $receiverName = User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
                        $role = json_decode($receiverName) ? json_decode($receiverName)[0]->role : '';

                        if ($role == 'A')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Admin]';
                        if ($role == 'M')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Manager]';
                        if ($role == 'S')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Staff]';

                        $startDate = date('Y-m-d', $data->created_at);

                        $dataId = $data->message_id;
                        $messageDetails->push([
                            'serialNumber' => $k + 1,
                            'sender' => $msgSenderName,
                            'receiver' => $msgReceiverName,
                            'startDate' => $startDate,
                            'details' => '<a class="custom_text_info checkViewBtn" data-toggle="modal" data-sender="' . $senderId . '" data-receiver="' . $receiverId . '" data-target="#messageModal">View Conversation</a>',
                        ]);
                    }
                }
                return DataTables::of($messageDetails)->rawColumns(['details'])->make(true);
        }
    }

    public function messageDatatble($fetchMessageTable){
        $messageDetails = new Collection();
        foreach (json_decode($fetchMessageTable) as $k => $data) {
//            $senderId = json_decode($data->message_sender_id);
            $receiverId = json_decode($data->message_receiver_id);
            if ($receiverId === Session::get('co_admin')['id']) {
                $receiverId = json_decode($data->message_sender_id);
                $senderId = json_decode($data->message_receiver_id);
            } else {
                $senderId = json_decode($data->message_sender_id);
                $receiverId = json_decode($data->message_receiver_id);
            }

            $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$senderId]];
            $dataToFInd = ['name', 'role'];
            $senderName = User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
            $role = json_decode($senderName)[0]->role;

            if ($role == 'A')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Staff]';


            $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$receiverId]];
            $dataToFInd = ['name', 'role'];
            $receiverName = User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
            $role = json_decode($receiverName) ? json_decode($receiverName)[0]->role : '';

            if ($role == 'A')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Staff]';

            $startDate = date('Y-m-d', $data->created_at);

            $dataId = $data->message_id;
            $messageDetails->push([
                'serialNumber' => $k + 1,
                'sender' => $msgSenderName,
                'receiver' => $msgReceiverName,
                'startDate' => $startDate,
                'details' => '<a class="custom_text_info checkViewBtn" data-toggle="modal" data-sender="' . $senderId . '" data-receiver="' . $receiverId . '" data-target="#messageModal">View Conversation</a>',
            ]);
        }
        return $messageDetails;
    }

}