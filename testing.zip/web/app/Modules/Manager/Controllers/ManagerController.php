<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 6/7/2018
 * Time: 3:43 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Controllers;

use App\Modules\Manager\Models\InviteLink;
use App\Modules\Manager\Models\Notification;
use App\Modules\Manager\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class ManagerController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor.
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * register
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function register(Request $request, $token)
    {
        $linkData = $this->getInviteLinkData($token);
        if ($request->isMethod('post')) {
            if (count($linkData) > 0) {
                if ($linkData[0]->email_id == $request->input('email')) {
                    $userName = $request->input('username');
                    $name = $request->input('name');
                    $emailid = $request->input('email');
                    $password = $request->input('password');
                    $cpassword = $request->input('cpassword');
                    $whereToFind = [
                        'rawQuery' => 'email = ?',
                        'bindParams' => [$emailid]
                    ];
                    $whereToFindUsername = [
                        'rawQuery' => 'username = ?',
                        'bindParams' => [$userName]
                    ];
                    $dataToFind = ['username', 'email'];
                    $checkExistEmail = User::getInstance()->getUserData($whereToFind, $dataToFind);
                    $checkExistUsername = User::getInstance()->getUserData($whereToFindUsername, $dataToFind);
                    if ($checkExistEmail) {
                        return json_encode([
                            'status' => 401,
                            'message' => 'Email-Id Already Exist,Please Try with Another Email-Id!'
                        ]);
                    } else if ($checkExistUsername) {
                        return json_encode([
                            'status' => 402,
                            'message' => 'Username Already Exist,Please choose Another Username!'
                        ]);
                    } else {
                        $statusToken = str_random(30);
                        $dataToInsert = [
                            'name' => $name,
                            'first_name' => $name,
                            'last_name' => '',
                            'username' => $userName,
                            'password' => Hash::make($password),
                            'email' => $emailid,
                            'role' => "M",
                            'account_status' => $statusToken,
                            'created_at' => time(),
                            'updated_at' => time()
                        ];
                        $insertAdminData = User::getInstance()->insertUserData($dataToInsert);
                        $deleteLink = $this->removeLinkToken($token);
                        if ($insertAdminData == true) {
                            $mailResponse = functionToSendEmail($emailid, $statusToken, $token, $this->api_url);
                            return json_encode([
                                'status' => 200,
                                'message' => 'Activation link has been Send To your Email Address!Please activate your account!'
                            ]);
                        } else {
                            return json_encode([
                                'status' => 400,
                                'message' => 'Not Registered ,Please Try Again!'
                            ]);
                        }
                    }
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Sorry! You can not change your Email-Id'
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Sorry! Link Expired.'
                ]);
            }
        }

        if ($linkData) {
            return view('Manager::Auth/register', ['email' => $linkData[0]->email_id, 'token' => $linkData[0]->token ? $linkData[0]->token : '']);
        } else {
            $data = ['status' => 400, 'message' => 'Sorry, The Link Has been Expired!!'];
            return view('Manager::Auth/accountconformation', ['data' => $data]);
        }
    }

    /**
     * getInviteLinkData
     * @param $token
     * @return mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function getInviteLinkData($token)
    {
        $whereToFind = ['rawQuery' => 'token = ?', 'bindParams' => [$token]];
        $findToken = json_decode(InviteLink::getInstance()->getInvitelinkDetails($whereToFind));
        return $findToken;
    }

    /**
     * removeLinkToken
     * @param $token
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function removeLinkToken($token)
    {
        $whereToFind = ['rawQuery' => 'token = ?', 'bindParams' => [$token]];
        $dataToUpdate = ['token' => ''];
        $updateToken = json_decode(InviteLink::getInstance()->updateInvitelinkData($whereToFind, $dataToUpdate));
    }

    /**
     * signUpVarification
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function signUpVarification(Request $request, $token)
    {
        $statusToken = $request->input('auth');
        $whereToFind = [
            'rawQuery' => 'account_status = ?',
            'bindParams' => [$statusToken]
        ];
        $queryToFindStatusToken = User::getInstance()->getUserDetails($whereToFind);
        if (json_decode($queryToFindStatusToken)) {
            $whereToUpdate = [
                'rawQuery' => 'account_status = ?',
                'bindParams' => [$statusToken]
            ];
            $dataToUpdate = ['account_status' => 'A'];
            $queryToUpdate = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
            $linkData = $this->getInviteLinkData($token);
            $data = ['status' => 200, 'message' => 'Account activated Successfully!!'];
//            return view('Manager::Auth/accountconformation', ['email' => $linkData[0]->email_id, 'token' => $linkData[0]->token])->with(['status' => 'Success', 'message' => 'Account activated Successfully!!']);
            return view('Manager::Auth/accountconformation', ['data' => $data]);
        } else {
            $linkData = $this->getInviteLinkData($token);
            $data = ['status' => 400, 'message' => 'Sorry, The Link Has been Expired!!'];
            return view('Manager::Auth/accountconformation', ['data' => $data]);
//            return view('Manager::Auth/register',['email' => $linkData[0]->email_id, 'token' => $linkData[0]->token])->with(['status' => 'Error', 'message' => 'Sorry, The Link Has been Expired!!']);
        }
    }

    /**
     * login
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function login(Request $request)
    {
        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $password = $request->input('password');
            $remember = $request->input('remember');
            $chooseRaw = 'username';
            if (strpos($email, '@') !== false) {
                $chooseRaw = 'email';
            }
            $whereToFind = ['rawQuery' => $chooseRaw . ' = ? and role = ?',
                'bindParams' => [$email, 'M']
            ];
            $findDetails = User::getInstance()->getUserData($whereToFind);
            if ($findDetails) {
                if (Hash::check($password, $findDetails->password)) {
                    if ($findDetails->account_status == 'A') {
                        if ($remember == 'on') {
                            $rememberToken = $remember;
                        } else {
                            $rememberToken = '';
                        }
                        if (Auth::attempt([$chooseRaw => $email, 'password' => $password], $rememberToken)) {
                            $whereToFind = [
                                'rawQuery' => 'id=?',
                                'bindParams' => [Auth::id()]
                            ];
                            $findUserData = User::getInstance()->getUserData($whereToFind);
                            $sessionName = 'co_manager';
                            Session::put($sessionName, (array)$findUserData);

                            $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_manager')['id'], 0]];
                            $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
                            Session::put('co_manager.totalNotification', count($totalNotification));

                            /* To store all session Ids in DB */
                            if ($findUserData->session_id == '') {
                                $sessionArray[] = $request->getSession()->getId();
                            } else {
                                $allSesssionData = json_decode($findUserData->session_id);
                                foreach ($allSesssionData as $k => $val) {
                                    if (!(file_exists(storage_path() . '/framework/sessions/' . $val))) {
                                        unset($allSesssionData[$k]);
                                    }
                                }
                                array_push($allSesssionData, $request->getSession()->getId());
                                foreach ($allSesssionData as $k => $data) {
                                    $sessionArray[] = $data;
                                }
                            }

                            $dataToUpdate = ['session_id' => json_encode($sessionArray)];
                            $whereToUpdate = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_manager')['id']]];
                            $updateQuery = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);

                            $next = null;
                            if (isset($request['next']))
                                $next = $request['next'];

                            return json_encode([
                                'status' => 200,
                                'message' => 'Welcome! You have successfully logged in!!',
                                'data' => $findUserData,
                                'next' => $next
                            ]);
                        } else {
                            return json_encode([
                                'status' => 400,
                                'message' => 'You Entered Wrong Emailid/Password!',
                                'data' => null
                            ]);
                        }

                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Account Not Activated,Please Activate your account !! Activation link has been sent to your email..!',
                            'data' => null
                        ]);
                    }
                } else {
                    return json_encode([
                        'status' => 402,
                        'message' => 'Please Enter Correct Password!',
                        'data' => null
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Your Emailid is not Registered with us!',
                    'data' => null
                ]);
            }
        }
        if (Session::get('co_manager')) {
            return redirect('/manager/dashboard');
        } else {
            return view('Manager::Auth/login');
        }
    }

    /**
     * forgotPassword
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function forgotPassword(Request $request)
    {
        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $starEmail = preg_replace_callback('/(\w)(.*?)(\w)(@.*?)$/s', function ($matches) {
                return $matches[1] . preg_replace("/\w/", "*", $matches[2]) . $matches[3] . $matches[4];
            }, $email);
            $whereToFind = ['rawQuery' => 'email = ? and role = ?',
                'bindParams' => [$email, 'M']
            ];
            $findDetails = User::getInstance()->getUserData($whereToFind);
            if ($findDetails) {
                $confirmation_code = str_random(30);
                $from = new \SendGrid\Email(null, "vandana@gmail.com");
                $subject = "Forgot Password Link";
                $to = new \SendGrid\Email(null, $email);
                $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html lang='en-US'>
<head>
    <meta charset='utf-8'>
</head>
<body>

<div>
    Plaese click on this link  <a href=" . $this->api_url . "/manager/reset-password/" . $confirmation_code . ">
    to reset your password.
</div>


</body>
</html>");
                $mail = new \SendGrid\Mail($from, $subject, $to, $content);
                $apiKey = "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";
                $sg = new \SendGrid($apiKey);
                $response = $sg->client->mail()->send()->post($mail);
                $whereToUpdate = ['rawQuery' => 'email=?', 'bindParams' => [$email]];
                $dataToUpdate = ['password_token' => $confirmation_code];
                $updateData = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                if ($updateData) {
                    return json_encode([
                        'status' => 200,
                        'message' => 'Link Has Been Sent To Your ' . $starEmail . ', Please Check.'
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Mail not Sent.Something Went Wrong!'
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 401,
                    'message' => 'Please Enter Your Registered Email-Id!',
                    'data' => null
                ]);
            }
        }
        return view('Manager::Auth/forgotpassword');
    }

    /**
     * resetPassword
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function resetPassword(Request $request)
    {
        if ($request->isMethod('post')) {
            $newPassword = $request->input('newPassword');
            $token = $request->input('token');
            $confirmPassword = Hash::make($request->input('confirmPassword'));
            $whereToFind = [
                'rawQuery' => 'password_token=?',
                'bindParams' => [$token]
            ];
            $findData = User::getInstance()->getUserData($whereToFind);
            if ($findData) {
                $getEmail = DB::table('users')->first();
                $where = [
                    'rawQuery' => 'email=?',
                    'bindParams' => [$getEmail->email]
                ];
                $checkPassword = User::getInstance()->getUserData($where);
                if (Hash::check($newPassword, $checkPassword->password)) {
                    return json_encode([
                        'status' => 401,
                        'message' => 'Password is matching with old password. Please Choose Another Password.!'
                    ]);
                } else {
                    $whereToUpdate = ['rawQuery' => 'password_token=?', 'bindParams' => [$token]];
                    $dataToUpdate = ['password' => $confirmPassword, 'password_token' => ''];
                    $updateData = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                    if ($updateData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Your password Changed successfully'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Password not updated! Please try again.'
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Link has been Expired..'
                ]);
            }
        }
        return view('Manager::Auth/resetpassword');
    }

    /**
     * checkOldPassowordExist
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function checkOldPassowordExist(Request $request)
    {
        if ($request->isMethod('post')) {
            $oldpwdData = $request->input('oldPasswordData');
            $where = [
                'rawQuery' => 'id=?',
                'bindParams' => [Session::get('co_manager')['id']]
            ];
            $checkPassword = User::getInstance()->getUserData($where);

            if (Hash::check($oldpwdData, $checkPassword->password)) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Password is matching with old password'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Entered Password is not matching with Old Password. Please try Again!'
                ]);
            }
        }
    }

    /**
     * accountSetting
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function accountSetting()
    {
        $sessionId = Session::get('co_manager')['id'];
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $whereToFind = [
            'rawQuery' => 'id=?',
            'bindParams' => [$sessionId]
        ];
        $result = User::getInstance()->getUserData($whereToFind);
        return view('Manager::Dashboard/profilesetting', ['data' => $result, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    public function checkExistEmail(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->input('data') === Session::get('co_manager')['email']) {
                return json_encode(['status' => 200, 'message' => 'Email id Not Exist']);
            } else {
                $whereToFind = ['rawQuery' => 'email = ?', 'bindParams' => [$request->input('data')]];
                $checkEmail = json_decode(User::getInstance()->getUserDetails($whereToFind));
                if (!$checkEmail) {
                    return json_encode(['status' => 200, 'message' => 'Email id Not Exist']);
                } else {
                    return json_encode(['status' => 400, 'message' => 'You Can not change your Email-ID']);
                }
            }
        }
    }

    public function checkExistUsername(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->input('data') === Session::get('co_manager')['username']) {
                return json_encode(['status' => 200, 'message' => 'Username Not Exist']);
            } else {
                $whereToFind = ['rawQuery' => 'username = ?', 'bindParams' => [$request->input('data')]];
                $checkEmail = json_decode(User::getInstance()->getUserDetails($whereToFind));
                if (!$checkEmail) {
                    return json_encode(['status' => 200, 'message' => 'Username Not Exist']);
                } else {
                    return json_encode(['status' => 400, 'message' => 'Username Already Exist! PLease Choose Another.']);
                }
            }
        }
    }

    /**
     * updateProfileAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function updateProfileAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $manager = Session::get('co_manager');
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'changePassword':
                    $currPassword = $request->input('currentPassword');
                    $newPassword = $request->input('newPassword');

                    $whereToFInd = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_manager')['id']]];
                    $checkPassword = User::getInstance()->getUserData($whereToFInd);

                    if (Hash::check($currPassword, $checkPassword->password)) {
                        if (Hash::check($newPassword, $checkPassword->password)) {
                            return json_encode(['status' => 400, 'message' => 'New Password is matching with Old password. Please Choose Another.!']);
                        } else {
                            $dataToUpdate = [
                                'password' => Hash::make($newPassword)
                            ];
                            $updateData = User::getInstance()->updateUserData($whereToFInd, $dataToUpdate);
                            if ($updateData == true) {

                                $dataToGet = ['session_id'];
                                $whereToGet = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_manager')['id']]];
                                $fetchQuery = json_decode(User::getInstance()->getUserDetails($whereToGet, $dataToGet));

                                /* Destroy all browser session data..*/
                                foreach (json_decode($fetchQuery[0]->session_id) as $k => $val) {
                                    File::delete(storage_path() . '/framework/sessions/' . $val);
                                }

                                $dataToUpdate = ['session_id' => ''];
                                $updateQuery = User::getInstance()->updateUserData($whereToGet, $dataToUpdate);

                                Session::forget('co_manager');
                                return json_encode(['status' => 200, 'message' => 'Password Changed successfully!!Please Login with New Credentials.']);
                            } else {
                                return json_encode(['status' => 400, 'message' => 'Password not Changed successfully. Please Try Again!.']);
                            }
                        }
                    } else {
                        return json_encode(['status' => 401, 'message' => 'You Entered Wrong Current Password, Please Enter your current password!']);
                    }
                    break;
                case 'updateProfilePic':
//                    if ($request->hasFile('imageFile')) {
//                        $imageName = 'manager_' . $manager['id'] . '_' . time() . '.jpg';
//                        $filePath = uploadImageToStoragePathManager(Input::file('imageFile'), '', $imageName);
//
//                        if ($filePath) {
//                            $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$manager['id']]];
//                            $dataToUpdate = ['profile_pic' => '/manageruploads/files/' . $filePath];
//
//                            $result = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
//                            Session::put('co_manager.profile_pic', '/manageruploads/files/' . $filePath);
//                            if ($result) {
//                                $deleteImage = deleteImageFromPublicPathManager($manager['profile_pic']);
//                                if ($deleteImage || $manager['profile_pic'] == null) {
//                                    Session::put('co_manager', array_merge($manager, $dataToUpdate));
//                                    return json_encode(['status' => 200, 'message' => 'your Avatar Updated successfully.', 'profilepic' => $this->api_url . '/manageruploads/files/' . $filePath]);
//                                }
//                            }
//                        } else {
//                            return json_encode(['status' => 200, 'message' => 'Sorry, there was an error uploading your file.']);
//                        }
//                    } else {
//                        return json_encode(['status' => 400, 'message' => 'Request does not have any file.']);
//                    }

                    $dataToUpdate = ['profile_pic' => $request->input('imageFile')];
                    $updateData = $this->updateData($dataToUpdate);
                    if ($updateData) {
                        Session::put('co_manager', array_merge($manager, $dataToUpdate));
                        return json_encode(['status' => 200, 'message' => 'Your Avatar Updated successfully.', 'profilepic' => $request->input('imageFile')]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Sorry, there was an error uploading your file.']);
                    }
                    break;
                case 'updateProfileInfo':
                    if ($request->input('data')) {
                        $dataToUpdate = $request->input('data');
                        $updateData = $this->updateData($dataToUpdate);
                        if ($updateData == 1) {
                            $whereToFind = [
                                'rawQuery' => 'id=?',
                                'bindParams' => [Session::get('co_manager')['id']]
                            ];
                            $findUserData = User::getInstance()->getUserData($whereToFind);
                            $sessionName = 'co_manager';
                            Session::put($sessionName, (array)$findUserData);
                            $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_manager')['id'], 0]];
                            $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
                            Session::put('co_manager.totalNotification', count($totalNotification));
                            return json_encode(['status' => 200, 'message' => 'Your Profile Details Updated Successfully!!']);
                        } else {
                            return json_encode(['status' => 400, 'message' => 'No Data Has to be Updated!!']);
                        }
                    } else {
                        return json_encode(['status' => 400, 'message' => 'No Data Has to be Updated!!']);
                    }
            }
        }
    }

    /**
     * updateData
     * @param $userData
     * @return int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function updateData($userData)
    {
        $dataToUpdate = $userData;
        $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_manager')['id']]];
        $queryToUpdate = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
        return $queryToUpdate;
    }

    /**
     * logout
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function logout()
    {
//        session::flush('co_manager');
        Session::forget('co_manager');
        return redirect('/manager/sign-in');
    }
}
