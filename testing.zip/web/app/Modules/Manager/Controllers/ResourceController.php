<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/17/2018
 * Time: 12:03 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Controllers;

use App\Modules\Manager\Models\Resource;
use App\Modules\Manager\Models\User;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class ResourceController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor..
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * resourcePage
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function resourcePage()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $resourceData = $this->allResourceDetails();
        $adminData=functionToGetAdminData();
        
        return view('Manager::Dashboard/resource', ['adminData'=>json_decode($adminData)[0]->profile_pic,'allResourceData' => $resourceData['allResourceData'], 'latestResource' => $resourceData['latestResource'], 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * @return array
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function allResourceDetails()
    {
        $managerId = Session::get('co_manager')['id'];
        $dataToFind = ['*'];
        $sortingOrder = ['col' => 'created_at', 'order' => 'DESC'];
        $whereToFInd = ['rawQuery' => "resource_privacy = '0' or find_in_set('" . $managerId . "',(substr(staff_ids,2,length(staff_ids)-2)))>0 or find_in_set('" . $managerId . "',(substr(project_ids,2,length(project_ids)-2)))>0"];
        $getAllResourceData = json_decode(Resource::getInstance()->allResourceData($whereToFInd,$sortingOrder,$dataToFind));
        $resourceDataArr = [];
        $whereToFindStaff = ['rawQuery' => 'role = ?', 'bindParams' => ['A']];
        $getUserData = json_decode(User::getInstance()->getUserDetails($whereToFindStaff));
        foreach ($getAllResourceData as $k => $data) {

            $path = $data->resource_content;
            $resourceContent = Storage::get($path);

            $bgColor = $this->extractContent($resourceContent, 'src=', '>');
            $resourceDataArr[] = [
                'id' => $data->resource_id,
                'title' => $data->resource_title,
                'imagePath' => json_decode($data->resource_image),
                'content' => $resourceContent,
                'shortImage' => $bgColor,
                'startDate' => date("F j, Y", $data->created_at),
                'pic'=>$getUserData[0]->profile_pic
            ];
        }
        $latestResource = array_slice($resourceDataArr, 0, 4, true);
        return ['allResourceData' => $resourceDataArr, 'latestResource' => $latestResource];
    }

    /**
     * @param $str
     * @param $start
     * @param $end
     * @return bool|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function extractContent($str, $start, $end)
    {
        $lastPos = 0;
        $positions = array();
        $color = array();
        $final = array();
        while (($lastPos = strpos($str, $start, $lastPos)) !== false) {
            $positions[] = $lastPos;
            $lastPos = $lastPos + strlen($start);
        }
        $newStr = $str;
        if ($positions) {
            foreach ($positions as $value) {
                $newStr = substr($str, strpos($str, $start));
                array_push($color, substr($str, $value, strpos($newStr, $end)));
            }
            $color[0] = substr($color[0], strlen('"src='));
            $color[0] = substr($color[0], 0, strpos($color[0], '"'));
            return $color[0] ? $color[0] : '/images/default.png';
        } else {
            return '/images/blog2.png';
        }
    }

    /**
     * getContents
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function getContents(Request $request)
    {
        $resId = $request->input('resourceId');
        $dataToFind = ['resource_id', 'resource_title', 'resource_content', 'resource_image', 'created_at'];
        $whereToFind = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resId]];
        $query = json_decode(Resource::getInstance()->getResourceDetails($whereToFind, $dataToFind));
        $path = $query[0]->resource_content;
        $resourceContent = Storage::get($path);
        $resourceDataArr[] = [
            'id' => $query[0]->resource_id,
            'title' => $query[0]->resource_title,
            'imagePath' => json_decode($query[0]->resource_image),
            'content' => $resourceContent,
            'date' => date('d-m-Y', $query[0]->created_at)
        ];
        return json_encode(['status' => 200, 'data' => $resourceDataArr]);
    }

    /**
     * addResourcePage
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function addResourcePage()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $allStaffManagerData=array_merge(json_decode($allStaffName),json_decode($allManagerName));
        return view('Manager::Dashboard/addresource', ['allData'=>$allStaffManagerData,'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * showMoreResources
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function showMoreResources(Request $request, $id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $resourceData = $this->allResourceDetails();
        return view('Manager::Dashboard/showMoreResource', ['latestResource' => $resourceData['latestResource'], 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * insertResourceData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function insertResourceData(Request $request)
    {
        if ($request->isMethod('post')) {
//            dd($request->all());
//            $allImageArr = [];
            $resourceTitle = $request->input('resourceTitle') ? $request->input('resourceTitle') : '';
            $resourceContent = $request->input('content');
            $id = time() . '_content.txt';
            $destinationPath = 'contentFiles/123/' . $id;
            Storage::put($destinationPath, $resourceContent);


            $resourcePrivacy = $request->input('privacyStatus');
            $allProjects = $request->input('projects');
            $allStaffs = $request->input('staffs');
            if ($resourcePrivacy == 'public') {
                $privacy = 0;
                $allProjectsData = [];
                $allAssigneedUsers = [];
            } else {
                $privacy = 1;

                if ($allProjects) {
                    $allProjectsData = array_map(function ($name) {
                        $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$name]];
                        $projectDataToFInd = ['project_id'];
                        $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);
                        return $projectId ? json_decode($projectId)[0]->project_id : '';
                    }, $allProjects);
                }


                if ($allStaffs) {
                    $allAssigneedUsers = array_map(function ($name) {
                        $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$name]];
                        $dataToFInd = ['id'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return $getUserDetails ? json_decode($getUserDetails)[0]->id : '';
                    }, $allStaffs);
                }

            }
//            foreach ($request->all() as $key => $value) {
//                if (strpos($key, 'imageFiles') === 0) {
//                    $allImageArr[] = $value;
//                }
//            }
//            $allUploadedFiles = array_map(function ($file) {
//                $response = $this->fileUpload($file);
//                return json_decode($response)->data;
//            }, $allImageArr);
            $dataToInsert = [
                'resource_title' => $resourceTitle,
                'resource_content' => $destinationPath,
                'resource_privacy' => $privacy,
//                'resource_image' => json_encode($allUploadedFiles),
                'project_ids' => $allProjects !== null ? json_encode($allProjectsData) : '',
                'staff_ids' => $allStaffs ? json_encode($allAssigneedUsers) : '',
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsertData = Resource::getInstance()->insertResourceData($dataToInsert);
            if ($queryToInsertData) {
                return json_encode(['status' => 200, 'message' => 'Blog Created successfully']);
            }
        }
    }

    /**
     * fileUpload
     * @param $file
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $fileName = date('d_m') . '_' . time() . '_' . $num . '.' . 'jpg';
            $filePath = uploadImageToStoragePath($file, '', $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'Image has been uploaded!',
                    'data' => $this->api_url . '/adminuploads/files/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

}