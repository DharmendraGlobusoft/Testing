<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 6/7/2018
 * Time: 3:43 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Controllers;

use App\Modules\Manager\Models\InviteLink;
use App\Modules\Manager\Models\Issue;
use App\Modules\Manager\Models\IssueComment;
use App\Modules\Manager\Models\Milestone;
use App\Modules\Manager\Models\Notification;
use App\Modules\Manager\Models\Project;
use App\Modules\Manager\Models\Task;
use App\Modules\Manager\Models\TaskComment;
use App\Modules\Manager\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class DashboardController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor..
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-June-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * dashboard
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 30th-Mar-2018
     */
    public function dashboard()
    {
//        $dataToFInd = ['project_name'];
//        $whereToFind = ['rawQuery' => 'project_status = ?', 'bindParams' => [1]];
//        $allProjectName = Project::getInstance()->getProjectDetails($whereToFind,$dataToFInd);
        $allProjectName = functionToGetProjectNames();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_manager')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_manager.totalNotification', count($totalNotification));
        return view('Manager::Dashboard/dashboard', ['userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * insertTaskDetails
     * @param Request $request
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 11th-Apr-2018
     */
    public function insertTaskDetails(Request $request)
    {
        if ($request->isMethod('post')) {

            $projectName = $request->input('projectName');
            $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projectName]];
            $projectDataToFInd = ['project_id'];
            $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);

            $taskName = $request->input('taskName');
            $taskDescription = $request->input('taskDesc');
            $dueDate = $request->input('dueDate');
            $dueHours = $request->input('dueHours');
            $taskPriority = $request->input('taskPriority');
            $taskAssignee = $request->input('taskAssignee');

            if ($dueDate != '' && $dueHours == '') {
                $dueHours = '12';
            }

            if ($taskAssignee) {
                $assigneedUsers = explode(',', $taskAssignee);
                $allAssigneedUsers = array_map(function ($name) {
                    $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$name]];
                    $dataToFInd = ['id'];
                    $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                    return json_decode($getUserDetails)[0]->id;
                }, $assigneedUsers);
            }


            $fileDataArr = [];
            foreach ($request->all() as $key => $value) {
                if (strpos($key, 'textFileData') === 0) {
                    // value starts with textFileData
                    $fileDataArr[] = $value;
                }
            }

            $allUploadedFiles = array_map(function ($file) {
                $response = $this->fileUpload($file);
                return json_decode($response)->data;
            }, $fileDataArr);

            $dataToInsert = [
                'project_id' => json_decode($projectId)[0]->project_id,
                'task_topic' => $taskName,
                'task_desc' => $taskDescription,
                'task_assign_to' => $taskAssignee ? json_encode($allAssigneedUsers) : "[]",
                'task_owner' => '',
                'priority' => $taskPriority,
                'task_due_date' => $dueDate,
                'task_due_hours' => $dueHours,
                'task_status' => 0,
                'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsertTask = Task::getInstance()->insertTaskData($dataToInsert);
            if ($queryToInsertTask) {
                if ($taskAssignee) {
                    $notifyType = 1; //for assigned Task
                    $type = 0;
                    $insertFeedData = $this->insertNotification($queryToInsertTask, $allAssigneedUsers, json_decode($projectId)[0]->project_id, $projectName, $notifyType, $type);
                    foreach ($assigneedUsers as $k => $val) {
                        $assignedBy = 'Manager';
                        $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$val]];
                        $dataToFInd = ['id', 'email'];
                        $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                        $sendEMail = $this->sendEmail($getUserDetails[0]->id, $queryToInsertTask, json_decode($projectId)[0]->project_id, $getUserDetails[0]->email, $taskName, $projectName, $dueDate, $assignedBy, $taskPriority);
                    }
                }
                $ids = $this->getAdminDetails();
                $notifyType = 1;
                $insertFeedData = $this->insertNotification($queryToInsertTask, $ids, json_decode($projectId)[0]->project_id, $projectName, $notifyType, '');
                return json_encode([
                    'status' => 200,
                    'message' => 'Task Details Inserted Successfully!'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Not Inserted! Please Try Again..!'
                ]);
            }
        }
    }

    public function getAdminDetails()
    {
        $allAdminDetails = functionToGetAdminData();
        $ids[] = json_decode($allAdminDetails)[0]->id;
        return $ids;
    }

    public function sendEmail($userId, $id, $pid, $email, $taskName, $projName, $dueDate, $assignedBy, $taskPriority)
    {
        $timezone = functionToTimezone(Session::get('co_manager')['id']);
        if (json_decode($timezone)[0]->timezone == null)
            date_default_timezone_set('Asia/Kolkata');
        else
            date_default_timezone_set(json_decode($timezone)[0]->timezone);
        $time = date('D,M jS,h:i A', time());
        $link = $this->api_url . '/staff/projects';
        $image = $this->api_url . '/images/logo3.png';
        $sDate = $dueDate ? date('m/d/Y', $dueDate) : 'Not Assigned';

        if ($taskPriority == 0)
            $priority = 'none';
        else if ($taskPriority == 1)
            $priority = 'low';
        else if ($taskPriority == 2)
            $priority = 'medium';
        else
            $priority = 'high';

        $projLink = $this->api_url . '/staff/projects';
        $taskLink = $this->api_url . '/staff/taskInvitation/' . $userId . '/' . $pid . '/' . $id;
        $from = new \SendGrid\Email(null, "vandana@gmail.com");
        $subject = "Assign Task";
        $to = new \SendGrid\Email(null, $email);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Task details</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$time</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    min-width:600px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td><h2>Task Details</h2></td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Project Name</b></td>
                <td style=\"padding-bottom: 10px;\">: $projName</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Task Name</b></td>
                <td style=\"padding-bottom: 10px;\">: $taskName</td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Due Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $sDate</td>
            </tr>
            
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Assigned By</b></td>
                <td style=\"padding-bottom: 10px;\">: $assignedBy</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Priority</b></td>
                <td style=\"padding-bottom: 10px;\">: $priority</td>
            </tr>
             
             

            <tr>
        <td style=\"padding-top:40px;\"><a href=$taskLink style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" >Check Details</a>
         
        </td>
      </tr>
        </table>
    </center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = "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";
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
    }

    public function sendEmailForissue($userId, $id, $pid, $email, $issueName, $projName, $dueDate, $assignedBy, $issuePriority)
    {
        $timezone = functionToTimezone(Session::get('co_manager')['id']);
        if (json_decode($timezone)[0]->timezone == null)
            date_default_timezone_set('Asia/Kolkata');
        else
            date_default_timezone_set(json_decode($timezone)[0]->timezone);
        $time = date('D,M jS,h:i A', time());
        $image = $this->api_url . '/images/logo3.png';
        $sDate = $dueDate ? date('m/d/Y', $dueDate) : 'Not Assigned';

        if ($issuePriority == 1)
            $priority = 'minor';
        else if ($issuePriority == 2)
            $priority = 'major';
        else if ($issuePriority == 3)
            $priority = 'critical';
        else
            $priority = 'none';

        $projLink = $this->api_url . '/staff/projects';
        $taskLink = $this->api_url . '/staff/issueInvitation/' . $userId . '/' . $pid . '/' . $id;

        $from = new \SendGrid\Email(null, "vandana@gmail.com");
        $subject = "Assign Issue";
        $to = new \SendGrid\Email(null, $email);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Task details</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$time</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    min-width:600px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td><h2>Issue Details</h2></td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Project Name</b></td>
                <td style=\"padding-bottom: 10px;\">: $projName</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Issue Name</b></td>
                <td style=\"padding-bottom: 10px;\">: $issueName</td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Due Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $sDate</td>
            </tr>
            
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Assigned By</b></td>
                <td style=\"padding-bottom: 10px;\">: $assignedBy</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Priority</b></td>
                <td style=\"padding-bottom: 10px;\">: $priority</td>
            </tr>
            <tr>
        <td style=\"padding-top:40px;\"><a href=$taskLink id='5'  style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" >Check Details</a>
         
        </td>
      </tr>
        </table>
       
    </center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = "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";
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
    }

    /**
     * fileUpload
     * @param Request $request
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 11th-Apr-2018
     */
    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'manageruploads/files/' . time() . $num;
//            $fileName = date('d_m') . '_' . time() . '_' . $num . '.' . $file->getClientOriginalExtension();
//            $fileName = time().'_'. $num .'_'.str_replace('`', '', $file->getClientOriginalName());
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePath($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url . '/' . $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    public function getStaffs(Request $request)
    {
        if ($request->isMethod('post')) {
            $projectName = $request->input('projectName');
            if ($projectName !== '0') {
                $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projectName]];
                $projectData = json_decode(Project::getInstance()->getProjectDetails($whereToFindProject));

                $staffDetails = json_decode($projectData[0]->staff_id);
                $allAssigneedUsers = array_map(function ($id) {
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
                    $dataToFInd = ['name', 'username'];
                    $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                    return json_decode($getUserDetails);
                }, $staffDetails);
                if ($allAssigneedUsers) {
                    return json_encode([
                        'status' => 200,
                        'message' => 'All Assigned Users!',
                        'data' => $allAssigneedUsers
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'No Assigned Users!',
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Assigned Users!',
                ]);
            }
        }
    }

    /**
     * insertIssueDetails
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 17th-Apr-2018
     */
    public function insertIssueDetails(Request $request)
    {
        if ($request->isMethod('post')) {
            $projectName = $request->input('projectName');
            $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projectName]];
            $projectDataToFInd = ['project_id', 'pending_issue_count'];
            $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);

            $issueName = $request->input('issueName');
            $issueDescription = $request->input('issueDesc');
            $dueDate = $request->input('dueDate');
            $dueHours = $request->input('dueHours');
            $issuePriority = $request->input('issuePriority');
            $issueAssignee = $request->input('issueAssignee');

            if ($dueDate != '' && $dueHours == '') {
                $dueHours = '12';
            }

            if ($issueAssignee) {
                $assigneedUsers = explode(',', $issueAssignee);
                $allAssigneedUsers = array_map(function ($name) {
                    $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$name]];
                    $dataToFInd = ['id'];
                    $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                    return json_decode($getUserDetails)[0]->id;
                }, $assigneedUsers);
            }

            $fileDataArr = [];
            foreach ($request->all() as $key => $value) {
                if (strpos($key, 'issueTextFileData') === 0) {
                    // value starts with textFileData
                    $fileDataArr[] = $value;
                }
            }

            $allUploadedFiles = array_map(function ($file) {
                $response = $this->fileUpload($file);
                return json_decode($response)->data;
            }, $fileDataArr);

            $dataToInsert = [
                'project_id' => json_decode($projectId)[0]->project_id,
                'issue_topic' => $issueName,
                'issue_desc' => $issueDescription,
                'issue_assign_to' => $issueAssignee ? json_encode($allAssigneedUsers) : "[]",
                'issue_owner' => '',
                'severity' => $issuePriority,
                'due_date' => $dueDate,
                'issue_due_hours' => $dueHours,
                'issue_status' => 0,
                'issue_attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                'created_at' => time(),
                'updated_at' => time()
            ];
            $whereToUpdate = ['rawQuery' => 'project_id = ?', 'bindParams' => [json_decode($projectId)[0]->project_id]];
            $dataToUpdate = ['pending_issue_count' => json_decode($projectId)[0]->pending_issue_count + 1];
            $queryToUpdate = Project::getInstance()->updateProjectDetails($whereToUpdate, $dataToUpdate);
            $queryToInsertIssue = Issue::getInstance()->insertIssueData($dataToInsert);

            if ($queryToInsertIssue) {
                if ($issueAssignee) {
                    $notifyType = 0; // for assigned Issue
                    $type = 0;
                    $insertFeedData = $this->insertNotification($queryToInsertIssue, $allAssigneedUsers, json_decode($projectId)[0]->project_id, $projectName, $notifyType, $type);

                    $assignedBy = 'Manager';
                    foreach ($assigneedUsers as $k => $val) {
                        $assignedBy = 'Admin';
                        $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$val]];
                        $dataToFInd = ['id', 'email'];
                        $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                        $sendEMail = $this->sendEmailForissue($getUserDetails[0]->id, $queryToInsertIssue, json_decode($projectId)[0]->project_id, $getUserDetails[0]->email, $issueName, $projectName, $dueDate, $assignedBy, $issuePriority);
                    }

                }
                $ids = $this->getAdminDetails();
                $notifyType = 0;
                $insertFeedData = $this->insertNotification($queryToInsertIssue, $ids, json_decode($projectId)[0]->project_id, $projectName, $notifyType, '');
                return json_encode([
                    'status' => 200,
                    'message' => 'Issue Details Inserted Successfully!'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Not Inserted! Please Try Again..!'
                ]);
            }
        }
    }

    /**
     * insertNotification
     * @param $ids
     * @param $names
     * @param $projName
     * @param $notifyType
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function insertNotification($id = null, $ids, $names, $projName, $notifyType, $dataType)
    {
        foreach ($ids as $k => $v) {
            $receiverId = $v;
            $senderId = Session::get('co_manager')['id'];
            $senderName = Session::get('co_manager')['name'];
            $receiverMessage = [];
            $senderMessage = '';
            if ($notifyType == 0) {
                $type = 'Issue';
                $receiverMessage[] = ['id' => $id, 'pId' => $names, 'pName' => $projName, 'message' => $senderName . ' assigned ' . $type . ' to you in ' . $projName . ' Project.'];
            } else if ($notifyType == 1) {
                $type = 'Task';
                $receiverMessage[] = ['id' => $id, 'pId' => $names, 'pName' => $projName, 'message' => $senderName . ' assigned ' . $type . ' to you in ' . $projName . ' Project.'];
            } else if ($notifyType == 10) {
                $senderMessage = 'You posted comment for ' . $projName . ' Project';
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'message' => $senderName . ' posted comment for Task in ' . $projName . '.'];
            } else if ($notifyType == 11) {
                $senderMessage = 'You posted comment for ' . $projName . ' Project';
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'message' => $senderName . ' posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 17) {
                $receiverMessage[] = ['id' => $id, 'pName' => $projName, 'message' => $senderName . ' posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 18) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 19) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 20) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 21) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 22) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 23) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 25) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            }

            $dataToInsert = [
                'sender_id' => $senderId,
                'receiver_id' => $receiverId,
                'sender_message' => $senderMessage,
                'receiver_message' => json_encode($receiverMessage),
                'notify_type' => $notifyType,
                'notification_status' => 0,
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
        }
    }

    /**
     * insertMilestoneDetails
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function insertMilestoneDetails(Request $request)
    {
        if ($request->isMethod('post')) {
            $projectName = $request->input('project_name');

            $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projectName]];
            $projectDataToFInd = ['project_id', 'staff_id'];
            $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);

            $milestoneData = $request->input('milestone');
            $startDate = $request->input('milestoneStartDate');
            $dueDate = $request->input('milestoneDueDate');
            $milestoneStatus = 0;
            $dataToInsert = [
                'project_id' => json_decode($projectId)[0]->project_id,
                'milestone' => $milestoneData,
                'start_date' => $startDate,
                'due_date' => $dueDate,
                'milestone_status' => $milestoneStatus,
                'created_at' => time(),
                'updated_at' => time()
            ];

            $queryToInsertMilestone = Milestone::getInstance()->insertMilestoneData($dataToInsert);
            if ($queryToInsertMilestone) {
                $notifyType = 17;
                $ids = array_merge($this->getAdminDetails(), json_decode(json_decode($projectId)[0]->staff_id));
                $insertFeedData = $this->insertNotification($queryToInsertMilestone, $ids, '', $projectName, $notifyType, '');

                return json_encode([
                    'status' => 200,
                    'message' => 'Milestone Details Inserted Successfully!'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Not Inserted! Please Try Again..!'
                ]);
            }
        }
    }

    /**
     * taskInfoAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function taskInfoAjaxHandler(Request $request)
    {
        $allProjectName = functionToGetProjectNames();
        $taskDetails = new Collection();
        if (count(json_decode($allProjectName)) > 0) {
            $allProjIds = array_map(function ($r) {
                return $r->project_id;
            }, json_decode($allProjectName));
            $allIds = implode(',', array_unique(array_map(function ($h) {
                return $h;
            }, $allProjIds)));

            $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ')'];
            $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date'];
            $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

            if (count(json_decode($fetchTaskTable)) > 0) {
                $taskDetails = $this->taskDatatable($fetchTaskTable, $taskDetails);
            }
        }
        return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
    }

    /**
     * issueInfoAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 17th-Apr-2018
     */
    public function issueInfoAjaxHandler(Request $request)
    {
        $allProjectName = functionToGetProjectNames();
        $issueDetails = new Collection();
        if (count(json_decode($allProjectName)) > 0) {
            $allProjIds = array_map(function ($r) {
                return $r->project_id;
            }, json_decode($allProjectName));
            $allIds = implode(',', array_unique(array_map(function ($h) {
                return $h;
            }, $allProjIds)));
            $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ')'];
            $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date'];
            $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);

            if (count(json_decode($fetchIssueTable)) > 0) {
                $issueDetails = $this->issueDatatable($fetchIssueTable, $issueDetails);
            }
        }
        return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
    }

    /**
     * milestoneDataAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-May-2018
     */
    public function milestoneDataAjaxHandler(Request $request)
    {
        $dataToFetch = ['milestone_id', 'project_id', 'milestone', 'milestone_status', 'start_date', 'due_date'];
        $fetchMilestoneTable = Milestone::getInstance()->fetchAllMilestoneData($dataToFetch);

        $milestoneDetails = new Collection();

        foreach (json_decode($fetchMilestoneTable) as $k => $data) {
            $projectId = json_decode($data->project_id);
            $whereToFindProject = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $dataToFInd = ['project_name'];
            $projectName = Project::getInstance()->getProjectDetails($whereToFindProject, $dataToFInd);

            $startDate = $data->start_date ? date('Y-m-d', $data->start_date) : '--';
            $dueDate = $data->due_date ? date('Y-m-d', $data->due_date) : '--';

            if ($data->milestone_status === 0) {
                $milestoneStatus = 'Going On';
            } else if ($data->milestone_status === 1) {
                $milestoneStatus = 'Finished';
            } else if ($data->milestone_status === null) {
                $milestoneStatus = '--';
            } else {
                $milestoneStatus = 'Overdue';
            }

//            $getAllTasks = Task::getInstance()->getTaskData($whereToFindProject);
//            $whereToFind1 = ['rawQuery' => 'task_status = ? and project_id = ?', 'bindParams' => [1, $projectId]];
//            $dataToFInd = ['task_id', 'task_status'];
//            $completedTasks = json_decode(Task::getInstance()->getTaskData($whereToFind1, $dataToFInd));
//
//            $getAllIssues = Issue::getInstance()->getIssueDetails($whereToFindProject);
//            $whereToFind1 = ['rawQuery' => 'issue_status = ? and project_id = ?', 'bindParams' => [1, $projectId]];
//            $dataToFInd = ['issue_id', 'issue_status'];
//            $completedIssue = json_decode(Issue::getInstance()->getIssueDetails($whereToFind1, $dataToFInd));
//
//            if (count($getAllTasks) === count($completedTasks) && count($getAllIssues) === count($completedIssue)) {
//                if (count($getAllTasks) === 0 && count($completedTasks) === 0 &&  count($completedIssue) == 0) {
//                    if ($startDate != '--' && $dueDate != '--') {
//                        $milestoneStatus = '--';
////                        $this->updateMilestoneStatus($milestoneId, 1);
//                    } else {
//                        $milestoneStatus = '--';
//                    }
//                }
//                else{
//                    $milestoneStatus = 'Finished';
//                }
//            } else {
//                if ($startDate != '--' && $dueDate != '--') {
//                    if ($data->due_date < time()) {
//                        $milestoneStatus = 'Overdue';
//                    } else if ($data->due_date > $data->start_date) {
//                        $milestoneStatus = 'Going On';
//                    }
//                } else {
//                    $milestoneStatus = '--';
//                }
//            }

            $milestoneId = $data->milestone_id;
            $milestoneDetails->push([
                'serialNumber' => $k + 1,
                'projectName' => '<p class="content_wrap">' . json_decode($projectName)[0]->project_name . '</p>',
                'milestone' => '<p class="content_wrap">' . $data->milestone . '</p>',
                'startDate' => $startDate,
                'dueDate' => $dueDate,
                'milestoneStatus' => '<a class="custom_text_info" style="cursor:text;">' . $milestoneStatus . '</a>',
                'milestoneData' => $data->milestone,
                'projName' => json_decode($projectName)[0]->project_name,
                'editMilestone' => '<a style="cursor: pointer;"><i class="fa fa-pencil-square-o editMilestoneData text-success" aria-hidden="true" data-toggle="modal" data-target="#editMilestone" data-id="' . $milestoneId . '"></i></a>',
            ]);
        }
        return DataTables::of($milestoneDetails)->rawColumns(['projectName', 'milestoneStatus', 'milestone', 'editMilestone'])->make(true);
    }

    /**
     * fetchDataAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 5th-May-2018
     */
    public function fetchDataAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'fetchIssueDetails':
                    $issueId = $request->input('issueId');
                    $whereToFind = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $fetchIssueData = Issue::getInstance()->getIssueDetails($whereToFind);

                    $staffId = json_decode($fetchIssueData)[0]->issue_assign_to;
                    $projectId = json_decode($fetchIssueData)[0]->project_id;
                    $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $dataToFInd = ['project_name', 'staff_id'];
                    $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

                    $staffDetails = json_decode($getProjectDetails[0]->staff_id);
                    $allAssigneedUsers = array_map(function ($id) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
                        $dataToFInd = ['username'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
                    }, $staffDetails);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['username'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
                    }, json_decode($staffId));

                    $dueDate = json_decode($fetchIssueData)[0]->due_date ? date('Y-m-d', json_decode($fetchIssueData)[0]->due_date) : '';
                    $dueHours = json_decode($fetchIssueData)[0]->issue_due_hours;

                    if (json_decode($fetchIssueData)[0]->severity == 1) {
                        $severity = 'minor';
                    } else if (json_decode($fetchIssueData)[0]->severity == 2) {
                        $severity = 'major';
                    } else if (json_decode($fetchIssueData)[0]->severity == 3) {
                        $severity = 'critical';
                    } else {
                        $severity = 'none';
                    }

                    $issueDetailsArr[] = [
                        'projectId' => json_decode($fetchIssueData)[0]->issue_id,
                        'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                        'issueName' => json_decode($fetchIssueData)[0]->issue_topic,
                        'issueDesc' => json_decode($fetchIssueData)[0]->issue_desc,
                        'dueDate' => $dueDate,
                        'durHours' => $dueHours,
                        'staffDetails' => $getAllStaffDetails,
                        'severity' => $severity,
                        'staffNames' => $allAssigneedUsers
                    ];
                    if ($fetchIssueData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $issueDetailsArr]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchTaskDetails':
                    $taskId = $request->input('taskId');
                    $whereToFind = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $fetchTaskData = Task::getInstance()->getTaskData($whereToFind);

                    $staffId = json_decode($fetchTaskData)[0]->task_assign_to;
                    $projectId = json_decode($fetchTaskData)[0]->project_id;
                    $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $dataToFInd = ['project_name', 'staff_id'];
                    $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

                    $staffDetails = json_decode($getProjectDetails[0]->staff_id);
                    $allAssigneedUsers = array_map(function ($id) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
                        $dataToFInd = ['username'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
                    }, $staffDetails);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['username'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
                    }, json_decode($staffId));

                    $dueDate = json_decode($fetchTaskData)[0]->task_due_date ? date('Y-m-d', json_decode($fetchTaskData)[0]->task_due_date) : '';
                    $dueHours = json_decode($fetchTaskData)[0]->task_due_hours;

                    if (json_decode($fetchTaskData)[0]->priority == 1) {
                        $priority = 'low';
                    } else if (json_decode($fetchTaskData)[0]->priority == 2) {
                        $priority = 'medium';
                    } else if (json_decode($fetchTaskData)[0]->priority == 3) {
                        $priority = 'high';
                    } else {
                        $priority = 'none';
                    }

                    $taskDetailsArr[] = [
                        'projectId' => json_decode($fetchTaskData)[0]->task_id,
                        'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                        'issueName' => json_decode($fetchTaskData)[0]->task_topic,
                        'issueDesc' => json_decode($fetchTaskData)[0]->task_desc,
                        'dueDate' => $dueDate,
                        'durHours' => $dueHours,
                        'staffDetails' => $getAllStaffDetails,
                        'priority' => $priority,
                        'staffNames' => $allAssigneedUsers
                    ];
                    if ($fetchTaskData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $taskDetailsArr]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchTaskAndComments':
                    $taskId = $request->input('taskId');
                    $whereToFind = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
//                    $fetchTaskData = Task::getInstance()->getTaskAndCommentData($whereToFind);
                    $fetchTaskData = Task::getInstance()->getTaskData($whereToFind);

                    $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
                    $fetchCommentData = json_decode(TaskComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
                    $commentArray = [];
                    if ($fetchCommentData) {
                        foreach ($fetchCommentData as $k => $val) {
                            $commentPostedOn = date('d F Y H:i:s', $val->comment_posted_on);
                            $commentBy = $val->comment_by;
                            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                            $dataToFInd = ['name', 'role', 'profile_pic'];
                            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                            if ($getUserDetails[0]->role == 'A') {
                                $commentBy = 'Admin';
                            } else if ($getUserDetails[0]->role == 'S') {
                                $commentBy = $getUserDetails[0]->name . '_user';
                            } else if ($getUserDetails[0]->role == 'M') {
                                $commentBy = $getUserDetails[0]->name . '_manager';
                            }
                            $commentArray[] = [
                                'task_comment_id' => $val->task_comment_id,
                                'comment' => $val->comments,
                                'commentBy' => $commentBy,
                                'commentPostedOn' => $commentPostedOn,
                                'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                                'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                            ];
                        }
                    }
                    $staffId = json_decode($fetchTaskData)[0]->task_assign_to ? json_decode($fetchTaskData)[0]->task_assign_to : '';
                    $projectId = json_decode($fetchTaskData)[0]->project_id;
                    $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $dataToFInd = ['project_name'];
                    $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['name'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
                    }, json_decode($staffId));

                    $dueDate = date('Y-m-d', json_decode($fetchTaskData)[0]->task_due_date);
                    $dueHours = json_decode($fetchTaskData)[0]->task_due_hours;

                    if (json_decode($fetchTaskData)[0]->priority == 1) {
                        $priority = 'low';
                    } else if (json_decode($fetchTaskData)[0]->priority == 2) {
                        $priority = 'medium';
                    } else {
                        $priority = 'high';
                    }

                    $allFiles = [];
                    $copyscapeFiles = json_decode(json_decode($fetchTaskData)[0]->task_submission_files);
                    if ($copyscapeFiles) {
                        foreach ($copyscapeFiles as $k => $files) {
                            $allFiles[] = ['file' => $this->api_url . $files->filePath, 'checkCopyscape' => $files->copyScapeUrl];
                        }
                    } else {
                        $allFiles[] = '';
                    }
                    $taskDetailsArr[] = [
                        'taskId' => json_decode($fetchTaskData)[0]->task_id,
                        'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                        'taskName' => json_decode($fetchTaskData)[0]->task_topic,
                        'taskDesc' => json_decode($fetchTaskData)[0]->task_desc,
                        'dueDate' => $dueDate,
                        'durHours' => $dueHours,
                        'staffDetails' => $getAllStaffDetails,
                        'priority' => $priority,
                        'taskAttachmentFiles' => $allFiles,
                    ];

                    if ($fetchTaskData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $taskDetailsArr, 'comments' => $commentArray ? $commentArray : []]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchComments':
                    $taskCommentId = $request->input('taskCommentId');
                    $whereToFind = ['rawQuery' => 'task_comment_id = ?', 'bindParams' => [$taskCommentId]];

                    $fetchCommentData = json_decode(TaskComment::getInstance()->getCommentData($whereToFind));
                    $commentArray = [];
                    if ($fetchCommentData) {
                        foreach ($fetchCommentData as $k => $val) {
                            $commentPostedOn = date('d F Y H:i:s', $val->comment_posted_on);
                            $commentBy = $val->comment_by;
                            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                            $dataToFInd = ['name', 'role', 'profile_pic'];
                            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                            if ($getUserDetails[0]->role == 'A') {
                                $commentBy = 'Admin';
                            } else if ($getUserDetails[0]->role == 'S') {
                                $commentBy = $getUserDetails[0]->name . '_user';
                            } else if ($getUserDetails[0]->role == 'M') {
                                $commentBy = $getUserDetails[0]->name . '_manager';
                            }
                            $commentArray[] = [
                                'task_comment_id' => $val->task_comment_id,
                                'comment' => $val->comments,
                                'commentBy' => $commentBy,
                                'commentPostedOn' => $commentPostedOn,
                                'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                                'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                            ];
                        }
                    }

                    if ($fetchCommentData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Comment Details', 'comments' => $commentArray ? $commentArray : []]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchIssueAndComments':
                    $issueId = $request->input('issueId');
                    $whereToFind = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $fetchIssueData = Issue::getInstance()->getIssueDetails($whereToFind);

                    $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
                    $fetchCommentData = json_decode(IssueComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
                    $commentArray = [];
                    if ($fetchCommentData) {
                        foreach ($fetchCommentData as $k => $val) {
                            $commentPostedOn = date('d F Y H:i:s', $val->comment_posted_on);
                            $commentBy = $val->comment_by;
                            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                            $dataToFInd = ['name', 'role', 'profile_pic'];
                            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                            if ($getUserDetails[0]->role == 'A') {
                                $commentBy = 'Admin';
                            } else if ($getUserDetails[0]->role == 'S') {
                                $commentBy = $getUserDetails[0]->name . '_user';
                            } else if ($getUserDetails[0]->role == 'M') {
                                $commentBy = $getUserDetails[0]->name . '_manager';
                            }
                            $commentArray[] = [
                                'issue_comment_id' => $val->issue_comment_id,
                                'comment' => $val->comments,
                                'commentBy' => $commentBy,
                                'commentPostedOn' => $commentPostedOn,
                                'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                                'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                            ];
                        }
                    }
                    $staffId = json_decode($fetchIssueData)[0]->issue_assign_to;
                    $projectId = json_decode($fetchIssueData)[0]->project_id;
                    $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $dataToFInd = ['project_name'];
                    $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['name'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
                    }, json_decode($staffId));

                    $dueDate = date('Y-m-d', json_decode($fetchIssueData)[0]->due_date);
                    $dueHours = json_decode($fetchIssueData)[0]->issue_due_hours;

                    if (json_decode($fetchIssueData)[0]->severity == 1) {
                        $severity = 'minor';
                    } else if (json_decode($fetchIssueData)[0]->severity == 2) {
                        $severity = 'major';
                    } else {
                        $severity = 'critical';
                    }

                    $issueDetailsArr[] = [
                        'issueId' => json_decode($fetchIssueData)[0]->issue_id,
                        'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                        'issueName' => json_decode($fetchIssueData)[0]->issue_topic,
                        'issueDesc' => json_decode($fetchIssueData)[0]->issue_desc,
                        'dueDate' => $dueDate,
                        'durHours' => $dueHours,
                        'staffDetails' => $getAllStaffDetails,
                        'severity' => $severity,
                        'issueAttachmentFiles' => json_decode($fetchIssueData)[0]->issue_attachment_files,
                    ];
//dd($issueDetailsArr);
                    if ($fetchIssueData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $issueDetailsArr, 'comments' => $commentArray ? $commentArray : []]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchMilestoneDetails':
                    $milestoneId = $request->input('milestoneId');
                    $whereToFind = ['rawQuery' => 'milestone_id = ?', 'bindParams' => [$milestoneId]];
                    $fetchMilestoneData = Milestone::getInstance()->getMilestoneDetails($whereToFind);

                    $projectId = json_decode($fetchMilestoneData)[0]->project_id;
                    $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $dataToFInd = ['project_name'];
                    $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

                    $dueDate = json_decode($fetchMilestoneData)[0]->due_date ? date('Y-m-d', json_decode($fetchMilestoneData)[0]->due_date) : '';
                    $startDate = json_decode($fetchMilestoneData)[0]->start_date ? date('Y-m-d', json_decode($fetchMilestoneData)[0]->start_date) : '';

                    $milestoneDetailsArr[] = [
                        'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                        'milestoneData' => json_decode($fetchMilestoneData)[0]->milestone,
                        'dueDate' => $dueDate,
                        'startDate' => $startDate,
                    ];
                    if ($fetchMilestoneData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $milestoneDetailsArr]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
                case 'fetchStaff':
                    $taskId = $request->input('taskId');
                    $whereToGet = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $findTaskData = json_decode(Task::getInstance()->getTaskData($whereToGet));
                    $staffId = json_decode($findTaskData[0]->task_assign_to);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['name', 'profile_pic'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails) : '';
                    }, $staffId);

                    if ($getAllStaffDetails) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Fetched Staff Details',
                            'data' => $getAllStaffDetails
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Fetched Staff Details',
                            'data' => null
                        ]);
                    }
                case 'fetchStaffOfIssue':
                    $issueId = $request->input('issueId');
                    $whereToGet = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $findIssueData = json_decode(Issue::getInstance()->getIssueDetails($whereToGet));
                    $staffId = json_decode($findIssueData[0]->issue_assign_to);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['name', 'profile_pic'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails) : '';
                    }, $staffId);

                    if ($getAllStaffDetails) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Fetched Issue Staff Details',
                            'data' => $getAllStaffDetails
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Fetched Isssue Staff Details',
                            'data' => null
                        ]);
                    }
            }
        }
    }

    public function updateComment(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->all()) {
                $data = [
                    'rawQuery' => 'task_comment_id = ?',
                    'bindParams' => [$request->input('taskCommentId')]
                ];
                $getCommentDetails = json_decode(TaskComment::getInstance()->getCommentData($data));

                if ($getCommentDetails[0]->comments == $request->input('comment')) {
                    return json_encode(['status' => 400, 'message' => 'No Data has to be Updated']);
                } else {
                    $dataToUpdate = [
                        'comments' => $request->input('comment') ? $request->input('comment') : $getCommentDetails->comments,
                        'comment_posted_on' => time(),
                        'updated_at' => time(),
                    ];

                    $updatedData = TaskComment::getInstance()->updateComment($data, $dataToUpdate);
                    if ($updatedData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comment Updated Successfully!.'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Updated. Please Try again.',
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Found.',
                ]);
            }
        }
    }

    public function updateIssueComment(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->all()) {
                $data = [
                    'rawQuery' => 'issue_comment_id = ?',
                    'bindParams' => [$request->input('issueCommentId')]
                ];
                $getCommentDetails = json_decode(IssueComment::getInstance()->getCommentData($data));

                if ($getCommentDetails[0]->comments == $request->input('comment')) {
                    return json_encode(['status' => 400, 'message' => 'No Data has to be Updated']);
                } else {
                    $dataToUpdate = [
                        'comments' => $request->input('comment') ? $request->input('comment') : $getCommentDetails->comments,
                        'comment_posted_on' => time(),
                        'updated_at' => time(),
                    ];

                    $updatedData = IssueComment::getInstance()->updateComment($data, $dataToUpdate);
                    if ($updatedData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comment Updated Successfully!.'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Updated. Please Try again.',
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Found.',
                ]);
            }
        }
    }

    /**
     * updateIssueData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-May-2018
     */
    public function updateIssueData(Request $request)
    {
        if ($request->isMethod('post')) {
            if (isset($request->all()['issue_assign_to']) == false) {
                $userIds = [];
            } else {
                $projectUsers = $request->input('issue_assign_to');
                $userIds = [];
                foreach ($projectUsers as $k => $val) {
                    $whereToFind = [
                        'rawQuery' => 'username=?',
                        'bindParams' => [$val]
                    ];
                    $dataToFind = ['id'];
                    $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                    $userIds[] = json_decode($findUserId) ? json_decode($findUserId)[0]->id : '';
                }
            }

            $whereToUpdate = [
                'rawQuery' => 'issue_id = ?',
                'bindParams' => [$request->input('issue_id')]
            ];

            /*..........................To send Notification.................................................*/
            $fetchData = json_decode(Issue::getInstance()->getIssueDetails($whereToUpdate));
            $issueAssignedStaffs = json_decode($fetchData[0]->issue_assign_to);
            $newStaffIds = array_diff($userIds, $issueAssignedStaffs);
            $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchData[0]->project_id]];
            $dataToFInd = ['manager_id', 'project_name'];
            $issueAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
            $adminId = $this->getAdminDetails();
            if (count($newStaffIds) > 0) {
                $notifyType = 0; //for assigned Task
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $newStaffIds, $fetchData[0]->project_id, $issueAssignedManager[0]->project_name, $notifyType, '');
                foreach ($newStaffIds as $k => $val) {
                    $assignedBy = 'Admin';
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$val]];
                    $dataToFInd = ['name', 'email'];
                    $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                    $sendEMail = $this->sendEmailForissue($val, $request->input('issue_id'), $fetchData[0]->project_id, $getUserDetails[0]->email, $fetchData[0]->issue_topic, $issueAssignedManager[0]->project_name, $fetchData[0]->due_date, $assignedBy, $fetchData[0]->severity);
                }
            }
            $msg = '';
            $topic = $request->input('issue_topic');
            $desc = $request->input('issue_desc');
            $priority = $request->input('severity');
            $dueDate = $request->input('due_date');
            $dueHours = $request->input('issue_due_hours');

            $notifyType = 23;
            $allIds = array_merge($userIds, $adminId);

            if (isset($topic)) {
                $msg = 'Issue Topic';
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $allIds, $issueAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($desc)) {
                $msg = 'Issue Description';
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $allIds, $issueAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($priority)) {
                $msg = 'Issue Priority';
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $allIds, $issueAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($dueDate)) {
                $msg = 'Issue Due Date';
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $allIds, $issueAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($dueHours)) {
                $msg = 'Issue Due Hours';
                $insertFeedData = $this->insertNotification($request->input('issue_id'), $allIds, $issueAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            /*...............................................End Notification.....................................*/

            unset($request['issue_id']);
            $update = [];
            foreach ($request->all() as $key => $input) {
                if ($key == 'issue_assign_to') {
                    $update[$key] = json_encode($userIds);
                } else {
                    $update[$key] = $input;
                }
            }
            $updatedData = Issue::getInstance()->updateIssueDetails($whereToUpdate, $update);
            if ($updatedData) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Issue Data Updated Successfully!.'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Has To Be Updated!',
                ]);
            }
        }
    }

    /**
     * updateTaskData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-May-2018
     */
    public function updateTaskData(Request $request)
    {
        if ($request->isMethod('post')) {
//            if ($request->all()) {
//                $data = [
//                    'rawQuery' => 'task_id = ?',
//                    'bindParams' => [$request->input('task_id')]
//                ];
//                $getTaskDetails = Task::getInstance()->getTaskDetails($data);
//                if ($request->input('task_assign_to')) {
//                    $projectUsers = $request->input('task_assign_to');
//                    $userIds = [];
//                    foreach ($projectUsers as $k => $val) {
//                        $whereToFind = ['rawQuery' => 'name=?', 'bindParams' => [$val]];
//                        $dataToFind = ['id'];
//                        $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
//                        $userIds[] = json_decode($findUserId) ? json_decode($findUserId)[0]->id : '';
//                    }
//                }
//
//                if ($request->input('project_name')) {
//                    $whereToFindproj = ['rawQuery' => 'project_name = ?', 'bindParams' => [$request->input('project_name')]];
//                    $dataToFInd = ['project_id'];
//                    $getProjectDetails = json_decode(Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd));
//                }
//
//                $dataToUpdate = [
//                    'project_id' => $request->input('project_name') ? $getProjectDetails[0]->project_id : $getTaskDetails->project_id,
//                    'task_topic' => $request->input('task_topic') ? $request->input('task_topic') : $getTaskDetails->task_topic,
//                    'task_desc' => $request->input('task_desc') ? $request->input('task_desc') : $getTaskDetails->task_desc,
//                    'task_due_date' => $request->input('task_due_date') ? $request->input('task_due_date') : $getTaskDetails->task_due_date,
//                    'task_due_hours' => $request->input('task_due_hour') ? $request->input('task_due_hour') : $getTaskDetails->task_due_hours,
//                    'priority' => $request->input('task_priority') != null ? $request->input('task_priority') : $getTaskDetails->priority,
//                    'task_assign_to' => $request->input('task_assign_to') ? json_encode($userIds) : "[]",
//                ];
//                $updatedData = Task::getInstance()->updateTaskDetails($data, $dataToUpdate);
//                if ($updatedData) {
//                    return json_encode([
//                        'status' => 200,
//                        'message' => 'Task Data Updated Successfully!.'
//                    ]);
//                } else {
//                    return json_encode([
//                        'status' => 400,
//                        'message' => 'No Data Has To Be Updated!.',
//                    ]);
//                }
//            } else {
//                return json_encode([
//                    'status' => 400,
//                    'message' => 'No Data Found.',
//                ]);
//            }
            if (isset($request->all()['task_assign_to']) == false) {
                $userIds = [];
            } else {
                $projectUsers = $request->input('task_assign_to');
                $userIds = [];
                foreach ($projectUsers as $k => $val) {
                    $whereToFind = [
                        'rawQuery' => 'username=?',
                        'bindParams' => [$val]
                    ];
                    $dataToFind = ['id'];
                    $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                    $userIds[] = json_decode($findUserId) ? json_decode($findUserId)[0]->id : '';
                }
            }
            $whereToUpdate = [
                'rawQuery' => 'task_id = ?',
                'bindParams' => [$request->input('task_id')]
            ];

            /*..........................To send Notification.................................................*/


            $fetchData = json_decode(Task::getInstance()->getTaskData($whereToUpdate));
            $taskAssignedStaffs = json_decode($fetchData[0]->task_assign_to);
            $newStaffIds = array_diff($userIds, $taskAssignedStaffs);
            $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchData[0]->project_id]];
            $dataToFInd = ['manager_id', 'project_name'];
            $taskAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
            $adminId = $this->getAdminDetails();
            if (count($newStaffIds) > 0) {
                $notifyType = 1; //for assigned Task
                $insertFeedData = $this->insertNotification($request->input('task_id'), $newStaffIds, $fetchData[0]->project_id, $taskAssignedManager[0]->project_name, $notifyType, '');

                foreach ($newStaffIds as $k => $val) {
                    $assignedBy = 'Admin';
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$val]];
                    $dataToFInd = ['name', 'email'];
                    $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                    $sendEMail = $this->sendEmail($val, $request->input('task_id'), $fetchData[0]->project_id, $getUserDetails[0]->email, $fetchData[0]->task_topic, $taskAssignedManager[0]->project_name, $fetchData[0]->task_due_date, $assignedBy, $fetchData[0]->priority);
                }
            }
            $msg = '';
            $topic = $request->input('task_topic');
            $desc = $request->input('task_desc');
            $priority = $request->input('priority');
            $dueDate = $request->input('task_due_date');
            $dueHours = $request->input('task_due_hours');

            $notifyType = 22;
            $allIds = array_merge($userIds, $adminId);

            if (isset($topic)) {
                $msg = 'Task Topic';
                $insertFeedData = $this->insertNotification($request->input('task_id'), $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($desc)) {
                $msg = 'Task Description';
                $insertFeedData = $this->insertNotification($request->input('task_id'), $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($priority)) {
                $msg = 'Task Priority';
                $insertFeedData = $this->insertNotification($request->input('task_id'), $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($dueDate)) {
                $msg = 'Task Due Date';
                $insertFeedData = $this->insertNotification($request->input('task_id'), $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            if (isset($dueHours)) {
                $msg = 'Task Due Hours';
                $insertFeedData = $this->insertNotification($request->input('task_id'), $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
            }
            /*...............................................End Notification.....................................*/

            unset($request['task_id']);
            $update = [];
            foreach ($request->all() as $key => $input) {
                if ($key == 'task_assign_to') {
                    $update[$key] = json_encode($userIds);
                } else {
                    $update[$key] = $input;
                }
            }
            $updatedData = Task::getInstance()->updateTaskDetails($whereToUpdate, $update);
            if ($updatedData) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Task Data Updated Successfully!.'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Has To Be Updated!',
                ]);
            }
        }
    }

    /**
     * updateMilestoneData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-May-2018
     */
    public function updateMilestoneData(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->all()) {
                $data = [
                    'rawQuery' => 'milestone_id = ?',
                    'bindParams' => [$request->input('milestone_id')]
                ];
                $getMilestoneDetails = Milestone::getInstance()->getMilestoneData($data);

                if ($request->input('project_name')) {
                    $whereToFindproj = ['rawQuery' => 'project_name = ?', 'bindParams' => [$request->input('project_name')]];
                    $dataToFInd = ['project_id'];
                    $getProjectDetails = json_decode(Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd));
                }

                /*..........................To send Notification.................................................*/
                $fetchData = json_decode(Milestone::getInstance()->getMilestoneDetails($data));
                $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchData[0]->project_id]];
                $dataToFInd = ['manager_id', 'project_name', 'staff_id'];
                $getProjDetails = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
                $adminId = $this->getAdminDetails();

                $msg = '';
                $milestone = $request->input('milestone');
                $startDate = $request->input('startDate');
                $enddate = $request->input('endDate');

                $notifyType = 25;
                $allIds = array_merge(json_decode($getProjDetails[0]->staff_id), $adminId);

                if (isset($milestone) && $milestone != $fetchData[0]->milestone) {
                    $msg = 'Milestone';
                    $insertFeedData = $this->insertNotification('', $allIds, $getProjDetails[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
                }
                if (isset($startDate) && $milestone != $fetchData[0]->start_date) {
                    $msg = 'Milestone Start Date';
                    $insertFeedData = $this->insertNotification('', $allIds, $getProjDetails[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
                }
                if (isset($enddate) && $milestone != $fetchData[0]->due_date) {
                    $msg = 'Milestone End Date';
                    $insertFeedData = $this->insertNotification('', $allIds, $getProjDetails[0]->project_name, $fetchData[0]->project_id, $notifyType, $msg);
                }
                /*...............................................End Notification.....................................*/

                $dataToUpdate = [
                    'project_id' => $request->input('project_name') ? $getProjectDetails[0]->project_id : $getMilestoneDetails->project_id,
                    'milestone' => $request->input('milestone') ? $request->input('milestone') : $getMilestoneDetails->milestone,
                    'start_date' => $request->input('startDate') ? $request->input('startDate') : $getMilestoneDetails->start_date,
                    'due_date' => $request->input('endDate') ? $request->input('endDate') : $getMilestoneDetails->due_date,
                ];

                $updatedData = Milestone::getInstance()->updateMilestoneDetails($data, $dataToUpdate);
                if ($updatedData) {
                    return json_encode([
                        'status' => 200,
                        'message' => 'Milestone Data Updated Successfully!.'
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'No Data Has to be Updated!!.',
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Found.',
                ]);
            }
        }
    }

    /**
     * insertCommentAjaxhandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 26th-May-2018
     */
    public function insertCommentAjaxhandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'insertTaskComment':
                    $taskId = $request->input('taskId');
                    $whereToFindRecipient = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $fetchQuery = json_decode(Task::getInstance()->getTaskData($whereToFindRecipient));
                    $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchQuery[0]->project_id]];
                    $getProjName = json_decode(Project::getInstance()->getProjectDetails($whereToFind));

                    $commentData = $request->input('comment');
                    $commentData = str_replace('&nbsp;', '', $commentData);
                    $commentedBy = Session::get('co_manager')['id'];

                    $fileDataArr = [];
                    foreach ($request->all() as $key => $value) {
                        if (strpos($key, 'commentFiles') === 0) {
                            $fileDataArr[] = $value;
                        }
                    }

                    $allUploadedFiles = array_map(function ($file) {
                        $response = $this->fileUpload($file);
                        return json_decode($response)->data;
                    }, $fileDataArr);

                    $dataToInsert = [
                        'task_id' => $taskId,
                        'comments' => $commentData,
                        'comment_by' => $commentedBy,
                        'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                        'comment_posted_on' => time(),
                        'created_at' => time(),
                        'updated_at' => time()
                    ];
                    $notifyType = 10; //for comment in task
                    $type = 1;
                    $insertFeedData = $this->insertNotification($taskId, json_decode($fetchQuery[0]->task_assign_to), '', $fetchQuery[0]->project_id, $notifyType, $type);
                    $queryToInsert = TaskComment::getInstance()->insertTaskCommentData($dataToInsert);
                    if ($queryToInsert) {
                        return json_encode(['status' => 200, 'message' => 'Commented Successfully', 'data' => time(), 'id' => $queryToInsert, 'file' => $allUploadedFiles]);
                    } else
                        return json_encode(['status' => 400, 'message' => 'Please Try Again']);
                case 'insertIssueComment':
                    $issueId = $request->input('issueId');
                    $whereToFindRecipient = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $fetchQuery = json_decode(Issue::getInstance()->getIssueDetails($whereToFindRecipient));
                    $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchQuery[0]->project_id]];
                    $getProjName = json_decode(Project::getInstance()->getProjectDetails($whereToFind));

                    $commentData = $request->input('comment');
                    $commentedBy = Session::get('co_manager')['id'];

                    $fileDataArr = [];
                    foreach ($request->all() as $key => $value) {
                        if (strpos($key, 'commentFiles') === 0) {
                            $fileDataArr[] = $value;
                        }
                    }

                    $allUploadedFiles = array_map(function ($file) {
                        $response = $this->fileUpload($file);
                        return json_decode($response)->data;
                    }, $fileDataArr);

                    $dataToInsert = [
                        'issue_id' => $issueId,
                        'comments' => $commentData,
                        'comment_by' => $commentedBy,
                        'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                        'comment_posted_on' => time(),
                        'created_at' => time(),
                        'updated_at' => time()
                    ];
                    $notifyType = 11; //for comment in task
                    $type = 1;
                    $insertFeedData = $this->insertNotification($issueId, json_decode($fetchQuery[0]->issue_assign_to), '', $fetchQuery[0]->project_id, $notifyType, $type);
                    $queryToInsert = IssueComment::getInstance()->insertIssueCommentData($dataToInsert);
                    if ($queryToInsert) {
                        return json_encode(['status' => 200, 'message' => 'Commented Successfully', 'data' => time(), 'id' => $queryToInsert, 'file' => $allUploadedFiles]);
                    } else
                        return json_encode(['status' => 400, 'message' => 'Please Try Again']);
            }
        }
    }

    /**
     * deleteDataAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 28th-May-2018
     */
    public function deleteDataAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'deleteTaskComment':
                    $commentId = $request->input('taskCommentId');
                    $whereData = [
                        'rawQuery' => 'task_comment_id = ?',
                        'bindParams' => [$commentId]
                    ];
                    $deleteTaskComment = TaskComment::getInstance()->deleteComment($whereData);
                    if ($deleteTaskComment == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comments Details Deleted Successfully.',
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Deleted. Please Try Again to delete the Record.',
                        ]);
                    }
                case 'deleteIssueComment':
                    $commentId = $request->input('issueCommentId');
                    $whereData = [
                        'rawQuery' => 'issue_comment_id = ?',
                        'bindParams' => [$commentId]
                    ];
                    $deleteIssueComment = IssueComment::getInstance()->deleteComment($whereData);
                    if ($deleteIssueComment == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comments Details Deleted Successfully.',
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Deleted. Please Try Again to delete the Record.',
                        ]);
                    }
                case 'deleteIssueDetails':
                    $issueId = $request->input('issueId');
                    $whereData = [
                        'rawQuery' => 'issues.issue_id = ' . $issueId
                    ];
                    $whereToUpdate = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $getProId = json_decode(Issue::getInstance()->getIssueDetails($whereToUpdate));
                    if (count($getProId) > 0) {
                        $taskAssignedStaffs = json_decode($getProId[0]->issue_assign_to);
                        $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$getProId[0]->project_id]];
                        $dataToFInd = ['manager_id', 'project_name'];
                        $taskAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
                        $adminId = $this->getAdminDetails();
                        $deleteIssue = Issue::getInstance()->deleteIssueDetails('issues', 'issue_comments', 'issues.issue_id = issue_comments.issue_id', $whereData['rawQuery']);
                        if ($deleteIssue == true) {
                            $notifyType = 21;
                            $allIds = array_merge($taskAssignedStaffs, $adminId);
                            $insertFeedData = $this->insertNotification($issueId, $allIds, $taskAssignedManager[0]->project_name, $getProId[0]->issue_topic, $notifyType, '');

                            return json_encode([
                                'status' => 200,
                                'message' => 'Issue Deleted Successfully.',
                            ]);
                        } else {
                            return json_encode([
                                'status' => 400,
                                'message' => 'Not Deleted. Please Try Again to delete the Record.',
                            ]);
                        }
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Issue Has been deleted by Admin.',
                        ]);

                    }
                case 'deleteTaskDetails':
                    $taskId = $request->input('taskId');
                    $whereData = [
                        'rawQuery' => 'tasks.task_id = ' . $taskId
                    ];
                    $whereToUpdate = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $fetchData = json_decode(Task::getInstance()->getTaskData($whereToUpdate));
                    if (count($fetchData) > 0) {

                        $taskAssignedStaffs = json_decode($fetchData[0]->task_assign_to);
                        $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchData[0]->project_id]];
                        $dataToFInd = ['manager_id', 'project_name'];
                        $taskAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
                        $adminId = $this->getAdminDetails();
                        $deleteTask = Task::getInstance()->deleteTaskDetails('tasks', 'task_comments', 'tasks.task_id = task_comments.task_id', $whereData['rawQuery']);
                        if ($deleteTask == true) {
                            $notifyType = 20;
                            $allIds = array_merge($taskAssignedStaffs, $adminId);
                            $insertFeedData = $this->insertNotification($taskId, $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->task_topic, $notifyType, '');

                            return json_encode([
                                'status' => 200,
                                'message' => 'Task Deleted Successfully.',
                            ]);
                        } else {
                            return json_encode([
                                'status' => 400,
                                'message' => 'Not Deleted. Please Try Again to delete the Record.',
                            ]);
                        }
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Task Has been Deleted by Admin.',
                        ]);
                    }
            }
        }
    }

    /**
     * updateAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 28th-May-2018
     */
    public function updateAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'updateTaskStatus':
                    $taskId = $request->input('taskId');
                    $taskStatus = $request->input('taskStatus');
                    $whereToUpdate = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $dataToUpdate = ['task_status' => $taskStatus];

                    if ($taskStatus == 0) {
                        $message = 'Pending';
                    } else {
                        $message = 'Completed';
                    }

                    $queryToUpdateStatus = Task::getInstance()->updateTaskDetails($whereToUpdate, $dataToUpdate);
                    $fetchData = json_decode(Task::getInstance()->getTaskData($whereToUpdate));
                    $taskAssignedStaffs = json_decode($fetchData[0]->task_assign_to);
                    $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$fetchData[0]->project_id]];
                    $dataToFInd = ['manager_id', 'project_name'];
                    $taskAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
                    $adminId = $this->getAdminDetails();

                    if ($queryToUpdateStatus == true) {
                        $notifyType = 18;
                        $allIds = array_merge($taskAssignedStaffs, $adminId);
                        $insertFeedData = $this->insertNotification($taskId, $allIds, $taskAssignedManager[0]->project_name, $fetchData[0]->project_id, $notifyType, $message);

                        return json_encode([
                            'status' => 200,
                            'message' => 'Task Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                case 'updateIssueStatus':
                    $issueId = $request->input('issueId');
                    $issueStatus = $request->input('issueStatus');
                    $whereToUpdate = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $dataToUpdate = ['issue_status' => $issueStatus];
                    if ($issueStatus == 0) {
                        $message = 'Pending';
                    } else {
                        $message = 'Completed';
                    }

                    $getProId = json_decode(Issue::getInstance()->getIssueDetails($whereToUpdate));
                    $taskAssignedStaffs = json_decode($getProId[0]->issue_assign_to);
                    $wherToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$getProId[0]->project_id]];
                    $dataToFInd = ['manager_id', 'project_name'];
                    $taskAssignedManager = json_decode(Project::getInstance()->getProjectDetails($wherToFind, $dataToFInd));
                    $adminId = $this->getAdminDetails();

                    $queryToUpdateStatus = Issue::getInstance()->updateIssueDetails($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateStatus == true) {
                        $dataToGet = ['rawQuery' => 'project_id = ?', 'bindParams' => [$getProId[0]->project_id]];
                        $getProjeDetails = json_decode(Project::getInstance()->getProjectDetails($dataToGet));
                        if ($issueStatus == '1') {
                            $whereToUpdate = ['rawQuery' => 'project_id = ?', 'bindParams' => [$getProjeDetails[0]->project_id]];
                            $dataToUpdate = ['pending_issue_count' => $getProjeDetails[0]->pending_issue_count - 1];
                            $queryToUpdate = Project::getInstance()->updateProjectDetails($whereToUpdate, $dataToUpdate);
                        } else {
                            $whereToUpdate = ['rawQuery' => 'project_id = ?', 'bindParams' => [$getProjeDetails[0]->project_id]];
                            $dataToUpdate = ['pending_issue_count' => $getProjeDetails[0]->pending_issue_count + 1];
                            $queryToUpdate = Project::getInstance()->updateProjectDetails($whereToUpdate, $dataToUpdate);
                        }
                        $notifyType = 19;
                        $allIds = array_merge($taskAssignedStaffs, $adminId);
                        $insertFeedData = $this->insertNotification($issueId, $allIds, $taskAssignedManager[0]->project_name, $getProId[0]->project_id, $notifyType, $message);

                        return json_encode([
                            'status' => 200,
                            'message' => 'Issue Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
            }
        }
    }

    public function taskSubmission($id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $taskId = $id;
        $whereToFind = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
        $fetchTaskData = Task::getInstance()->getTaskData($whereToFind);
        if (json_decode($fetchTaskData)) {
            $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
            $fetchCommentData = json_decode(TaskComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
            $commentArray = [];
            if ($fetchCommentData) {
                foreach ($fetchCommentData as $k => $val) {
                    $commentPostedOn = $val->comment_posted_on;
                    $commentBy = $val->comment_by;
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                    $dataToFInd = ['name', 'role', 'profile_pic'];
                    $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                    if ($getUserDetails[0]->role == 'A') {
                        $commentBy = 'Admin';
                    } else if ($getUserDetails[0]->role == 'S') {
                        $commentBy = $getUserDetails[0]->name . '_user';
                    } else if ($getUserDetails[0]->role == 'M') {
                        $commentBy = $getUserDetails[0]->name . '_manager';
                    }
                    $commentArray[] = [
                        'task_comment_id' => $val->task_comment_id,
                        'comment' => $val->comments,
                        'commentBy' => $commentBy,
                        'commentPostedOn' => $commentPostedOn,
                        'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                        'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                    ];
                }
            }
            $staffId = json_decode($fetchTaskData)[0]->task_assign_to ? json_decode($fetchTaskData)[0]->task_assign_to : '';
            $projectId = json_decode($fetchTaskData)[0]->project_id;
            $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $dataToFInd = ['project_name'];
            $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['name'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
            }, json_decode($staffId));

            $dueDate = json_decode($fetchTaskData)[0]->task_due_date ? date('m/d/Y', json_decode($fetchTaskData)[0]->task_due_date) : '';
            $dueHours = json_decode($fetchTaskData)[0]->task_due_hours;

            if (json_decode($fetchTaskData)[0]->priority == 1) {
                $priority = 'low';
            } else if (json_decode($fetchTaskData)[0]->priority == 2) {
                $priority = 'medium';
            } else {
                $priority = 'high';
            }

            $allFiles = [];
            $copyscapeFiles = json_decode(json_decode($fetchTaskData)[0]->task_submission_files);
            if ($copyscapeFiles) {
                foreach ($copyscapeFiles as $k => $files) {
                    $allFiles[] = ['file' => $files->filePath, 'checkCopyscape' => $files->copyScapeUrl];
                }
            } else {
                $allFiles[] = '';
            }

            $taskDetailsArr[] = [
                'taskId' => json_decode($fetchTaskData)[0]->task_id,
                'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                'taskName' => json_decode($fetchTaskData)[0]->task_topic,
                'taskDesc' => json_decode($fetchTaskData)[0]->task_desc,
                'dueDate' => $dueDate,
                'durHours' => $dueHours,
                'staffDetails' => $getAllStaffDetails,
                'priority' => $priority,
                'attachmentFiles' => json_decode(json_decode($fetchTaskData)[0]->attachment_files),
                'taskAttachmentFiles' => $allFiles,
                'allFiles' => json_decode(json_decode($fetchTaskData)[0]->allFiles)
            ];
            if ($fetchTaskData) {
                return view('Manager::Dashboard/tasksubmit', ['userData' => json_decode($allStaffName),
                    'managerData' => json_decode($allManagerName),
                    'projectName' => json_decode($allProjectName),
                    'data' => $taskDetailsArr,
                    'comments' => $commentArray ? json_encode($commentArray) : json_encode([])
                ]);
            } else {
                return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
            }
        } else {
            return view('Admin::Dashboard/accessDenied');
        }
    }

    public function getTaskComment(Request $request)
    {
        $taskId = $request->input('taskId');
        $whereToFind = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
        $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
        $fetchCommentData = json_decode(TaskComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
        $commentArray = [];
        if ($fetchCommentData) {
            foreach ($fetchCommentData as $k => $val) {
                $commentPostedOn = $val->comment_posted_on;
                $commentBy = $val->comment_by;
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                $dataToFInd = ['name', 'role', 'profile_pic'];
                $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                if ($getUserDetails[0]->role == 'A') {
                    $commentBy = 'Admin';
                } else if ($getUserDetails[0]->role == 'S') {
                    $commentBy = $getUserDetails[0]->name . '_user';
                } else if ($getUserDetails[0]->role == 'M') {
                    $commentBy = $getUserDetails[0]->name . '_manager';
                }
                $commentArray[] = [
                    'task_comment_id' => $val->task_comment_id,
                    'comment' => $val->comments,
                    'commentBy' => $commentBy,
                    'commentPostedOn' => $commentPostedOn,
                    'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                    'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                ];
            }
            return json_encode(['status' => 200,
                'commentData' => $commentArray ? $commentArray : []
            ]);
        } else {
            return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
        }
    }

    public function issueSubmission($id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $issueId = $id;
        $whereToFind = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
        $fetchIssueData = Issue::getInstance()->getIssueDetails($whereToFind);
        if (json_decode($fetchIssueData)) {
            $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
            $fetchCommentData = json_decode(IssueComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
            $commentArray = [];
            if ($fetchCommentData) {
                foreach ($fetchCommentData as $k => $val) {
                    $commentPostedOn = $val->comment_posted_on;
                    $commentBy = $val->comment_by;
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                    $dataToFInd = ['name', 'role', 'profile_pic'];
                    $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                    if ($getUserDetails[0]->role == 'A') {
                        $commentBy = 'Admin';
                    } else if ($getUserDetails[0]->role == 'S') {
                        $commentBy = $getUserDetails[0]->name . '_user';
                    } else if ($getUserDetails[0]->role == 'M') {
                        $commentBy = $getUserDetails[0]->name . '_manager';
                    }
                    $commentArray[] = [
                        'issue_comment_id' => $val->issue_comment_id,
                        'comment' => $val->comments,
                        'commentBy' => $commentBy,
                        'commentPostedOn' => $commentPostedOn,
                        'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                        'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                    ];
                }
            }
            $staffId = json_decode($fetchIssueData)[0]->issue_assign_to;
            $projectId = json_decode($fetchIssueData)[0]->project_id;
            $whereToFindproj = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $dataToFInd = ['project_name'];
            $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindproj, $dataToFInd);

            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['name'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
            }, json_decode($staffId));

            $dueDate = json_decode($fetchIssueData)[0]->due_date ? date('m/d/Y', json_decode($fetchIssueData)[0]->due_date) : '';
            $dueHours = json_decode($fetchIssueData)[0]->issue_due_hours;

            if (json_decode($fetchIssueData)[0]->severity == 1) {
                $severity = 'minor';
            } else if (json_decode($fetchIssueData)[0]->severity == 2) {
                $severity = 'major';
            } else {
                $severity = 'critical';
            }

            $allFiles = [];
            $copyscapeFiles = json_decode(json_decode($fetchIssueData)[0]->issue_submission);
            if ($copyscapeFiles) {
                foreach ($copyscapeFiles as $k => $files) {
                    $allFiles[] = ['file' => $files->filePath, 'checkCopyscape' => $files->copyScapeUrl];
                }
            } else {
                $allFiles[] = '';
            }

            $issueDetailsArr[] = [
                'issueId' => json_decode($fetchIssueData)[0]->issue_id,
                'projectName' => json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '',
                'issueName' => json_decode($fetchIssueData)[0]->issue_topic,
                'issueDesc' => json_decode($fetchIssueData)[0]->issue_desc,
                'dueDate' => $dueDate,
                'dueHours' => $dueHours,
                'staffDetails' => $getAllStaffDetails,
                'severity' => $severity,
                'attachmentFiles' => json_decode(json_decode($fetchIssueData)[0]->issue_attachment_files),
                'issueAttachmentFiles' => $allFiles,
                'allFiles' => json_decode(json_decode($fetchIssueData)[0]->allFiles)
            ];
            if ($fetchIssueData) {
                return view('Manager::Dashboard/issuesubmit', ['userData' => json_decode($allStaffName),
                    'managerData' => json_decode($allManagerName),
                    'projectName' => json_decode($allProjectName),
                    'data' => $issueDetailsArr,
                    'comments' => $commentArray ? json_encode($commentArray) : json_encode([])
                ]);
            } else {
                return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
            }
        } else {
            return view('Admin::Dashboard/accessDenied');
        }
    }

    public function getComment(Request $request)
    {
        $issueId = $request->input('issueId');
        $whereToFind = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
        $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
        $fetchCommentData = json_decode(IssueComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
        $commentArray = [];
        if ($fetchCommentData) {
            foreach ($fetchCommentData as $k => $val) {
                $commentPostedOn = $val->comment_posted_on;
                $commentBy = $val->comment_by;
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                $dataToFInd = ['name', 'role', 'profile_pic'];
                $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                if ($getUserDetails[0]->role == 'A') {
                    $commentBy = 'Admin';
                } else if ($getUserDetails[0]->role == 'S') {
                    $commentBy = $getUserDetails[0]->name . '_user';
                } else if ($getUserDetails[0]->role == 'M') {
                    $commentBy = $getUserDetails[0]->name . '_manager';
                }
                $commentArray[] = [
                    'issue_comment_id' => $val->issue_comment_id,
                    'comment' => $val->comments,
                    'commentBy' => $commentBy,
                    'commentPostedOn' => $commentPostedOn,
                    'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                    'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                ];
            }
            return json_encode(['status' => 200,
                'comments' => $commentArray ? $commentArray : []
            ]);
        } else {
            return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
        }
    }

    public function getAllCountInChart(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'Task':
                    $allProjectName = functionToGetProjectNames();
                    if (count(json_decode($allProjectName)) > 0) {
                        $allProjIds = array_map(function ($r) {
                            return $r->project_id;
                        }, json_decode($allProjectName));
                        $allIds = implode(',', array_unique(array_map(function ($h) {
                            return $h;
                        }, $allProjIds)));

                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and task_status = 0'];
                        $whereToFind1 = ['rawQuery' => 'project_id in(' . $allIds . ') and task_status = 1'];
                        $dataToFInd = ['task_id', 'task_status'];
                        $pendingTasks = json_decode(Task::getInstance()->getTaskData($whereToFind, $dataToFInd));
                        $completedTasks = json_decode(Task::getInstance()->getTaskData($whereToFind1, $dataToFInd));
                        if (count($pendingTasks) > 0 || count($completedTasks) > 0)
                            $allData = [count($pendingTasks), count($completedTasks)];
                        else
                            $allData = [];
                        return $allData;
                    }
                    break;
                case 'Issue':
                    $allProjectName = functionToGetProjectNames();

                    $issueDetails = new Collection();
                    if (count(json_decode($allProjectName)) > 0) {
                        $allProjIds = array_map(function ($r) {
                            return $r->project_id;
                        }, json_decode($allProjectName));
                        $allIds = implode(',', array_unique(array_map(function ($h) {
                            return $h;
                        }, $allProjIds)));
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and issue_status = 0'];
                        $whereToFind1 = ['rawQuery' => 'project_id in(' . $allIds . ') and issue_status = 1'];
                        $dataToFInd = ['issue_id', 'issue_status'];
                        $pendingIssue = json_decode(Issue::getInstance()->getIssueDetails($whereToFind, $dataToFInd));
                        $completedIssue = json_decode(Issue::getInstance()->getIssueDetails($whereToFind1, $dataToFInd));
                        if (count($pendingIssue) > 0 || count($completedIssue) > 0)
                            $allData = [count($pendingIssue), count($completedIssue)];
                        else
                            $allData = [];
                    }
                    return $allData;
                case 'Milestone':
                    $whereToFind = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [0]];
                    $whereToFind1 = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [1]];
                    $whereToFind2 = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [2]];
                    $dataToFInd = ['milestone_id', 'milestone_status'];
                    $ongoingData = json_decode(Milestone::getInstance()->getMilestoneDetails($whereToFind, $dataToFInd));
                    $finishedData = json_decode(Milestone::getInstance()->getMilestoneDetails($whereToFind1, $dataToFInd));
                    $overdueData = json_decode(Milestone::getInstance()->getMilestoneDetails($whereToFind2, $dataToFInd));
                    if (count($ongoingData) > 0 || count($finishedData) > 0 || count($overdueData) > 0)
                        $allData = [count($ongoingData), count($finishedData), count($overdueData)];
                    else
                        $allData = [];
                    return $allData;
            }
        }
    }

    public function filteringOfTaskAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');
                $allProjectName = functionToGetProjectNames();
                $taskDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));

                    $whereToFind = ['rawQuery' => 'find_in_set(' . $staffId . ',(substr(task_assign_to,2,length(task_assign_to)-2)))>0 and project_id in(' . $allIds . ')'];
                    $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date'];
                    $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchTaskTable)) > 0) {
                        $taskDetails = $this->taskDatatable($fetchTaskTable, $taskDetails);
                    }
                }
                return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
            case 'FilertingByView':
                $allProjectName = functionToGetProjectNames();
                $taskDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));

                    $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)'];
                    $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date'];
                    $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchTaskTable)) > 0) {
                        $taskDetails = $this->taskDatatable($fetchTaskTable, $taskDetails);
                    }
                }
                return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
            case 'FilertingByProject':
                $proId = $request->input('projId');
                $allProjectName = functionToGetProjectNames();
                $taskDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));

                    $whereToFind = ['rawQuery' => 'project_id = ? ', 'bindParams' => [$proId]];
                    $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date'];
                    $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchTaskTable)) > 0) {
                        $taskDetails = $this->taskDatatable($fetchTaskTable, $taskDetails);
                    }
                }
                return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
            case 'FilertingByTime':
                $allProjectName = functionToGetProjectNames();
                $taskDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));

                    if ($request->input('time') == 'today') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 1 DAY)'];
                    }
                    if ($request->input('time') == '7 days') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)'];
                    }
                    if ($request->input('time') == '30 days') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY)'];
                    }
                    $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date'];
                    $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchTaskTable)) > 0) {
                        $taskDetails = $this->taskDatatable($fetchTaskTable, $taskDetails);
                    }
                }
                return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');
                $allProjectName = functionToGetProjectNames();
                $taskDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));

                    $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ')'];
                    $dataToFetch = ['task_id', 'project_id', 'task_topic', 'task_assign_to', 'task_status', 'priority', 'task_due_date', 'created_at'];
                    $fetchTaskTable = Task::getInstance()->getTaskData($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchTaskTable)) > 0) {
                        foreach (json_decode($fetchTaskTable) as $k => $data) {
                            if (date("m Y", $data->created_at) == $date) {
                                $projectId = json_decode($data->project_id);
                                $whereToFindProject = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                                $dataToFInd = ['project_name'];
                                $projectName = Project::getInstance()->getProjectDetails($whereToFindProject, $dataToFInd);
                                $staffId = json_decode($data->task_assign_to);

                                $getAllStaffDetails = array_map(function ($staffId) {
                                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                                    $dataToFInd = ['name'];
                                    $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                                    return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
                                }, $staffId);

                                $dueDate = $data->task_due_date != "" ? date('m/d/Y', $data->task_due_date) : '--';
                                $priority = json_decode($data->priority);
                                if ($priority == 0) {
                                    $priorityName = "None";
                                } else if ($priority == 1) {
                                    $priorityName = "Low";
                                } else if ($priority == 2) {
                                    $priorityName = "Medium";
                                } else if ($priority == 3) {
                                    $priorityName = "High";
                                }

                                if ($data->task_status == 0) {
                                    $taskStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                                    $editTask = '<a class="" style="display:inline-block;margin-left: 6px;"> <i class="fa fa-square-o fa-1x taskComplete custom_text_info" title="Mark As Completed" data-toggle="popover5" data-content="" data-id="' . $data->task_id . '" aria-hidden="true"></i></a>';
                                } else if ($data->task_status == 1) {
                                    $editTask = '<a class="" style="display: inline-block;margin-left: 6px;"> <i class="fa fa-check-square taskPending custom_text_info" title="Mark As Pending" data-id="' . $data->task_id . '" aria-hidden="true"></i></a>';
                                    $taskStatus = '<a class="text-success" style="cursor: text">Completed</a>';
                                }

                                $taskId = $data->task_id;
                                $taskDetails->push([
                                    'serialNumber' => $k + 1,
                                    'projectName' => '<p class="content_wrap">' . json_decode($projectName)[0]->project_name . '</p>',
                                    'dueDate' => $dueDate,
                                    'taskName' => '<p class="content_wrap">' . $data->task_topic . '</p>',
                                    'status' => $taskStatus,
                                    'priority' => $priorityName,
                                    'staffDetails' => '<a class="custom_text_info staffListModal"  data-id="' . $taskId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">Staff List</a>',
                                    'editTask' => '<a  style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editTaskData text-success" title="Edit Task" aria-hidden="true" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#editTask" data-id="' . $taskId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteTask custom_text_danger" aria-hidden="true" title="Delete Task" data-toggle="modal" data-target="#confirmTaskModal" data-id="' . $taskId . '"></i></a>' . $editTask,
                                    'taskSubmission' => '<a href="/manager/task-submission/' . $taskId . '" class="custom_text_info viewTaskSubmission" data-id="' . $taskId . '">View </a>',
                                    'taskPrioritySort' => json_decode($data->priority),
                                    'projName' => json_decode($projectName)[0]->project_name,
                                    'taskDetails' => $data->task_topic
                                ]);
                            }
                        }
                    }
                }
                return DataTables::of($taskDetails)->rawColumns(['projectName', 'taskName', 'status', 'staffDetails', 'editTask', 'taskSubmission'])->make(true);
        }
    }

    public function taskDatatable($fetchTaskTable, $taskDetails)
    {
        foreach (json_decode($fetchTaskTable) as $k => $data) {

            $projectId = json_decode($data->project_id);
            $whereToFindProject = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $dataToFInd = ['project_name'];
            $projectName = Project::getInstance()->getProjectDetails($whereToFindProject, $dataToFInd);
            $staffId = json_decode($data->task_assign_to);

            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['name'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
            }, $staffId);

            $dueDate = $data->task_due_date != "" ? date('m/d/Y', $data->task_due_date) : '--';
            $priority = json_decode($data->priority);
            if ($priority == 0) {
                $priorityName = "None";
            } else if ($priority == 1) {
                $priorityName = "Low";
            } else if ($priority == 2) {
                $priorityName = "Medium";
            } else if ($priority == 3) {
                $priorityName = "High";
            }

            if ($data->task_status == 0) {
                $taskStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                $editTask = '<a class="" style="display:inline-block;margin-left: 6px;"> <i class="fa fa-square-o fa-1x taskComplete custom_text_info" title="Mark As Completed" data-toggle="popover5" data-content="" data-id="' . $data->task_id . '" aria-hidden="true"></i></a>';
            } else if ($data->task_status == 1) {
                $editTask = '<a class="" style="display: inline-block;margin-left: 6px;"> <i class="fa fa-check-square taskPending custom_text_info" title="Mark As Pending" data-id="' . $data->task_id . '" aria-hidden="true"></i></a>';
                $taskStatus = '<a class="text-success" style="cursor: text">Completed</a>';
            }

            $taskId = $data->task_id;
            $taskDetails->push([
                'serialNumber' => $k + 1,
                'projectName' => '<p class="content_wrap">' . json_decode($projectName)[0]->project_name . '</p>',
                'dueDate' => $dueDate,
                'taskName' => '<p class="content_wrap">' . $data->task_topic . '</p>',
                'status' => $taskStatus,
                'priority' => $priorityName,
                'staffDetails' => '<a class="custom_text_info staffListModal"  data-id="' . $taskId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">Staff List</a>',
                'editTask' => '<a  style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editTaskData text-success" title="Edit Task" aria-hidden="true" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#editTask" data-id="' . $taskId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteTask custom_text_danger" aria-hidden="true" title="Delete Task" data-toggle="modal" data-target="#confirmTaskModal" data-id="' . $taskId . '"></i></a>' . $editTask,
                'taskSubmission' => '<a href="/manager/task-submission/' . $taskId . '" class="custom_text_info viewTaskSubmission" data-id="' . $taskId . '">View </a>',
                'taskPrioritySort' => json_decode($data->priority),
                'projName' => json_decode($projectName)[0]->project_name,
                'taskDetails' => $data->task_topic
            ]);
        }
        return $taskDetails;
    }

    public function issueDatatable($fetchIssueTable, $issueDetails)
    {
        foreach (json_decode($fetchIssueTable) as $k => $data) {
            $projectId = json_decode($data->project_id);
            $whereToFindProject = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $dataToFInd = ['project_name'];
            $projectName = Project::getInstance()->getProjectDetails($whereToFindProject, $dataToFInd);

            $staffId = json_decode($data->issue_assign_to);

            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['name'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
            }, $staffId);

            $dueDate = $data->due_date ? date('m/d/Y', $data->due_date) : '--';
            $severity = json_decode($data->severity);
            if ($severity == 0) {
                $priorityName = "None";
            } else if ($severity == 1) {
                $priorityName = "Minor";
            } else if ($severity == 2) {
                $priorityName = "Major";
            } else if ($severity == 3) {
                $priorityName = "Critical";
            }

            $employeeName = '';
            if ($getAllStaffDetails) {
                foreach ($getAllStaffDetails as $v) {
                    $employeeName .= '<p>' . $v . '</p>';;
                }
            } else {
                $employeeName .= '<p>No Assigned Users.</p>';;
            }

            if ($data->issue_status == 0) {
                $issueStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                $editIssue = '<a  style="display: inline-block;margin-left: 6px;"> <i class="fa fa-square-o fa-1x custom_text_info issueComplete" title="Mark As Completed"  data-id="' . $data->issue_id . '"></i></a>';
            } else if ($data->issue_status == 1) {
                $editIssue = '<a style="display: inline-block;margin-left: 6px;"> <i class="fa fa-check-square custom_text_info issuePending" title="Mark As Pending" data-id="' . $data->issue_id . '" aria-hidden="true"></i></a>';
                $issueStatus = '<a class="text-success" style="cursor: text">Completed</a>';
            }

            $issueId = $data->issue_id;
            $issueDetails->push([
                'serialNumber' => $k + 1,
                'projectName' => '<p class="content_wrap">' . json_decode($projectName)[0]->project_name . '</p>',
                'dueDate' => $dueDate,
                'issueName' => '<p class="content_wrap">' . $data->issue_topic . '</p>',
                'severity' => $priorityName,
                'status' => $issueStatus,
                'staffDetails' => '<a class="custom_text_info staffListIssueModal" style="color:#fff;cursor: pointer;" data-id="' . $issueId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">Staff List</a>',
                'editIssue' => '<a style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editIssueData text-success" title="Edit Issue" aria-hidden="true" data-backdrop="false"  data-toggle="modal" data-target="#editIssue" data-id="' . $issueId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteIssue custom_text_danger" aria-hidden="true" title="Delete Issue" data-toggle="modal" data-target="#confirmModal" data-id="' . $issueId . '"></i></a>' . $editIssue,
                'issueSubmission' => '<a href="/manager/issue-submission/' . $issueId . '" class="custom_text_info viewIssueSubmission" data-id="' . $issueId . '">View</a>',
                'projName' => json_decode($projectName)[0]->project_name,
                'issueDetails' => $data->issue_topic
            ]);
        }
        return $issueDetails;
    }

    public function filteringOfIssueAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');

                $allProjectName = functionToGetProjectNames();
                $issueDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));
                    $whereToFind = ['rawQuery' => 'find_in_set(' . $staffId . ',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0 and project_id in(' . $allIds . ')'];
                    $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date'];
                    $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);
                    if (count(json_decode($fetchIssueTable)) > 0) {
                        $issueDetails = $this->issueDatatable($fetchIssueTable, $issueDetails);
                    }
                }
                return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
            case 'FilertingByView':
                $allProjectName = functionToGetProjectNames();
                $issueDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));
                    $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)'];
                    $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date'];
                    $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchIssueTable)) > 0) {
                        $issueDetails = $this->issueDatatable($fetchIssueTable, $issueDetails);
                    }
                }
                return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
            case 'FilertingByProject':
                $proId = $request->input('projId');
                $allProjectName = functionToGetProjectNames();
                $issueDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));
                    $whereToFind = ['rawQuery' => 'project_id = ? ', 'bindParams' => [$proId]];
                    $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date'];
                    $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchIssueTable)) > 0) {
                        $issueDetails = $this->issueDatatable($fetchIssueTable, $issueDetails);
                    }
                }
                return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
            case 'FilertingByTime':
                $allProjectName = functionToGetProjectNames();
                $issueDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));
                    if ($request->input('time') == 'today') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 1 DAY)'];
                    }
                    if ($request->input('time') == '7 days') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)'];
                    }
                    if ($request->input('time') == '30 days') {
                        $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ') and from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY)'];
                    }
                    $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date'];
                    $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchIssueTable)) > 0) {
                        $issueDetails = $this->issueDatatable($fetchIssueTable, $issueDetails);
                    }
                }
                return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');
                $allProjectName = functionToGetProjectNames();
                $issueDetails = new Collection();
                if (count(json_decode($allProjectName)) > 0) {
                    $allProjIds = array_map(function ($r) {
                        return $r->project_id;
                    }, json_decode($allProjectName));
                    $allIds = implode(',', array_unique(array_map(function ($h) {
                        return $h;
                    }, $allProjIds)));
                    $whereToFind = ['rawQuery' => 'project_id in(' . $allIds . ')'];
                    $dataToFetch = ['issue_id', 'project_id', 'issue_topic', 'issue_assign_to', 'severity', 'issue_status', 'due_date', 'created_at'];
                    $fetchIssueTable = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFetch);

                    if (count(json_decode($fetchIssueTable)) > 0) {
                        foreach (json_decode($fetchIssueTable) as $k => $data) {
                            if (date("m Y", $data->created_at) == $date) {
                                $projectId = json_decode($data->project_id);
                                $whereToFindProject = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                                $dataToFInd = ['project_name'];
                                $projectName = Project::getInstance()->getProjectDetails($whereToFindProject, $dataToFInd);

                                $staffId = json_decode($data->issue_assign_to);

                                $getAllStaffDetails = array_map(function ($staffId) {
                                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                                    $dataToFInd = ['name'];
                                    $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                                    return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->name : '';
                                }, $staffId);

                                $dueDate = $data->due_date ? date('m/d/Y', $data->due_date) : '--';
                                $severity = json_decode($data->severity);
                                if ($severity == 0) {
                                    $priorityName = "None";
                                } else if ($severity == 1) {
                                    $priorityName = "Minor";
                                } else if ($severity == 2) {
                                    $priorityName = "Major";
                                } else if ($severity == 3) {
                                    $priorityName = "Critical";
                                }

                                $employeeName = '';
                                if ($getAllStaffDetails) {
                                    foreach ($getAllStaffDetails as $v) {
                                        $employeeName .= '<p>' . $v . '</p>';;
                                    }
                                } else {
                                    $employeeName .= '<p>No Assigned Users.</p>';;
                                }

                                if ($data->issue_status == 0) {
                                    $issueStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                                    $editIssue = '<a  style="display: inline-block;margin-left: 6px;"> <i class="fa fa-square-o fa-1x custom_text_info issueComplete" title="Mark As Completed"  data-id="' . $data->issue_id . '"></i></a>';
                                } else if ($data->issue_status == 1) {
                                    $editIssue = '<a style="display: inline-block;margin-left: 6px;"> <i class="fa fa-check-square custom_text_info issuePending" title="Mark As Pending" data-id="' . $data->issue_id . '" aria-hidden="true"></i></a>';
                                    $issueStatus = '<a class="text-success" style="cursor: text">Completed</a>';
                                }

                                $issueId = $data->issue_id;
                                $issueDetails->push([
                                    'serialNumber' => $k + 1,
                                    'projectName' => '<p class="content_wrap">' . json_decode($projectName)[0]->project_name . '</p>',
                                    'dueDate' => $dueDate,
                                    'issueName' => '<p class="content_wrap">' . $data->issue_topic . '</p>',
                                    'severity' => $priorityName,
                                    'status' => $issueStatus,
                                    'staffDetails' => '<a class="custom_text_info staffListIssueModal" style="color:#fff;cursor: pointer;" data-id="' . $issueId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">Staff List</a>',
                                    'editIssue' => '<a style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editIssueData text-success" title="Edit Issue" aria-hidden="true" data-backdrop="false"  data-toggle="modal" data-target="#editIssue" data-id="' . $issueId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteIssue custom_text_danger" aria-hidden="true" title="Delete Issue" data-toggle="modal" data-target="#confirmModal" data-id="' . $issueId . '"></i></a>' . $editIssue,
                                    'issueSubmission' => '<a href="/manager/issue-submission/' . $issueId . '" class="custom_text_info viewIssueSubmission" data-id="' . $issueId . '">View</a>',
                                    'projName' => json_decode($projectName)[0]->project_name,
                                    'issueDetails' => $data->issue_topic
                                ]);
                            }
                        }
                    }
                }
                return DataTables::of($issueDetails)->rawColumns(['issueName', 'projectName', 'status', 'staffDetails', 'editIssue', 'issueSubmission'])->make(true);
        }
    }
}