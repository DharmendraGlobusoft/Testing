<?php 

return [
    'welcome' => 'Welcome, this is Manager module.'
];
