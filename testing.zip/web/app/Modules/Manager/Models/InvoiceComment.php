<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/29/2018
 * Time: 12:06 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */
namespace App\Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class InvoiceComment extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     * @used InvoiceController
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     * @used InvoiceController
     */
    protected $tableName = 'invoice_comments';

    /**
     * @return InvoiceComment|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     * @used InvoiceController
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new InvoiceComment();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     * @used InvoiceController
     */
    public function insertInvoiceCommentData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-MAy-2018
     * @used InvoiceController
     */
    public function fetchAllCommentData($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function getCommentDetails($where,$sortingOrder, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->orderby($sortingOrder['col'], $sortingOrder['order'])
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 26rd-May-2018
     * @used InvoiceController
     */
    public function updateComment($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 28th-May-2018
     * @used InvoiceController
     */
    public function deleteComment($where)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->delete();
                return $result ? $result : [];
            } catch (QueryException $e) {
                echo $e->getMessage();
            }
        } else {
            echo 'Argument not passed!';
        }
    }

}