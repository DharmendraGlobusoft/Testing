<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 4/16/2018
 * Time: 3:51 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class Issue extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     * @used DashboardController
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     * @used DashboardController
     */
    protected $tableName = 'issues';

    /**
     * @return Issue|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     * @used DashboardController
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new Issue();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     * @used DashboardController
     */
    public function insertIssueData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 17th-Apr-2018
     * @used DashboardController
     */
    public function fetchAllIssueData($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 17th-Apr-2018
     * @used DashboardController
     */
    public function getIssueDetails($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return Model|int|null|object|static
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 12th-May-2018
     * @used DashboardController
     */
    public function getIssueData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->first();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 12th-May-2018
     * @used DashboardController
     */
    public function updateIssueDetails($where, $data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : [];
            } catch (QueryException $e) {
                echo $e->getMessage();
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 30th-May-2018
     * @used DashboardController
     */
    public function deleteIssueDetails($t1, $t2, $joinCond, $whereCond)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::delete(DB::raw("delete $t1,$t2 from $t1 left join $t2 on $joinCond where $whereCond"));
                return $result ? $result : [];

            } catch (\Exception $e) {
                echo $e->getMessage();
            }
        } else {
            echo 'Argument not passed!';
        }
    }


}