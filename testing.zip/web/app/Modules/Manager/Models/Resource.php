<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/18/2018
 * Time: 1:41 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */


namespace App\Modules\Manager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class Resource extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 18th-May-2018
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 18th-May-2018
     */
    protected $tableName = 'resources';

    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new Resource();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 18th-May-2018
     * @used ResourceController
     */
    public function insertResourceData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 18th-May-2018
     * @used ResourceController
     */
    public function fetchAllResourceDetails($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function fetchAllResource($data = ['*'],$sortingOrder)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->orderby($sortingOrder['col'], $sortingOrder['order'])
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function allResourceData($where,$sortingOrder,$data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->orderby($sortingOrder['col'], $sortingOrder['order'])
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 18th-May-2018
     * @used ResourceController
     */
    public function getResourceDetails($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }
}