<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/9/2018
 * Time: 6:40 PM
 */

namespace App\Modules\Manager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class TicketReply extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 9th-May-2018
     * @used SupportTicketController
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 9th-May-2018
     * @used SupportTicketController
     */
    protected $tableName = 'ticket_replies';

    /**
     * @return TicketReply|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 9th-May-2018
     * @used SupportTicketController
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new TicketReply();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 9th-May-2018
     * @used SupportTicketController
     */
    public function insertTicketReplyData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 10th-MAy-2018
     * @used SupportTicketController
     */
    public function fetchAllTicketData($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function getTicketReplyDetails($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     * @used SupportTicketController
     */
    public function updateTIcket($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }
}