<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/4/2018
 * Time: 12:07 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Manager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class Invoice extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    protected $tableName = 'invoice_form';

    /**
     * @return Invoice|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new Invoice();
        return self::$_instance;
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 5th-May-2018
     * @used InvoiceController
     */
    public function fetchAllInvoiceData($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function getInvoiceDetails($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function updateInvoiceData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }
}