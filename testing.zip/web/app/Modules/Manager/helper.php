<?php

/**
 *    Manager Helper
 */

if (!function_exists('functionToSendEmail')) {

    function functionToSendEmail($email, $statusToken, $token, $url)
    {
        $from = new \SendGrid\Email(null, "vandana@gmail.com");
        $subject = "Account Activation Link";
        $to = new \SendGrid\Email(null, $email);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html lang='en-US'>
<head>
    <meta charset='utf-8'>
</head>
<body>
<h2>Account Activation Link</h2>

<div>
    Plaese click on this link  <a href=" . $url . "/manager/sign-up-varify/" . $token . "?auth=" . $statusToken . ">
     to activate your account.
</div>

</body>
</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = "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";
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
        return $response;
    }
}

if (!function_exists('uploadImageToStoragePathManager')) {
    /**
     * Upload image to storage path
     * @param $image
     * @param null $folderName Folder name (mainFolder_subFolder_subSubFolder)
     * @param null $fileName
     * @param int $imageWidth
     * @param int $imageHeight
     * @return bool|string
     * @author Bandana Sahu
     * @since 16th-Apr-2018
     */
    function uploadImageToStoragePathManager($image, $folderName = null, $fileName = null, $imageWidth = 1024, $imageHeight = 1024)
    {
//        $destinationFolder = 'manageruploads/files/';
        if ($folderName != '') {
            $folderNames = explode('_', $folderName);
            $folderPath = implode('/', array_map(function ($value) {
                return $value;
            }, $folderNames));
            $destinationFolder = $folderPath . '/';
        }
        $destinationPath = public_path($destinationFolder);
        if (!File::exists($destinationPath)) File::makeDirectory($destinationPath, 0777, true, true);
        $filename = ($fileName != '') ? $fileName : $folderName . '_' . time() . '.txt';

        //for file upload
        if ($image) $image->move($destinationPath, $filename);
        return $filename;

        //for image upload
//        $imageResult = Image::make($image);
//        $imageResult = Image::make($image)->resize($imageWidth, $imageHeight, function ($constraint) {
//            $constraint->aspectRatio();
//        })->save($destinationPath . $filename, imageQuality($image));
//        if ($imageResult) return $filename;
//        return false;
    }
}

if (!function_exists('imageQuality')) {
    /**
     * Get image quality for compression
     * @param $image
     * @return int
     * @since 16th-Apr-2018
     */
    function imageQuality($image)
    {
        $imageSize = filesize($image) / (1024 * 1024);
        if ($imageSize < 0.5) return 70;
        elseif ($imageSize > 0.5 && $imageSize < 1) return 60;
        elseif ($imageSize > 1 && $imageSize < 2) return 50;
        elseif ($imageSize > 2 && $imageSize < 5) return 40;
        elseif ($imageSize > 5) return 30;
        else return 50;
    }
}

if (!function_exists('deleteImageFromPublicPathManager')) {
    /**
     * Delete an image from storage path
     * @param $fileName Name of the image (Ex. user_2_1432423423.jpg)
     * @return int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function deleteImageFromPublicPathManager($fileName)
    {
        if ($fileName != '') {
            $destinationFolder = 'manageruploads/files/';
            $filePath = public_path();
            return (File::delete($filePath . '/' . $fileName));
        }
    }
}

if (!function_exists('functionToGetProjectNames')) {
    /**
     * functionToGetProjectData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetProjectNames()
    {
        $managerId = \Illuminate\Support\Facades\Session::get('co_manager')['id'];
        $dataToFInd = ['project_name','project_id'];
        $whereToFetch = ['rawQuery' => "project_status = '1' and  find_in_set('" . $managerId . "',(substr(manager_id,2,length(manager_id)-2)))>0"];
        $getAllProjectName = \App\Modules\Manager\Models\Project::getInstance()->getProjectDetails($whereToFetch,$dataToFInd);
//        $dataToFInd = ['project_name'];
//        $getAllProjectName = \App\Modules\Manager\Models\Project::getInstance()->fetchAllProjectDetails($dataToFInd);
        return $getAllProjectName;
    }
}

if (!function_exists('functionToGetProjectData')) {
    /**
     * functionToGetProjectData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetProjectData()
    {

        $dataToFInd = ['project_name'];
        $getAllProjectName = \App\Modules\Manager\Models\Project::getInstance()->fetchAllProjectDetails($dataToFInd);
        return $getAllProjectName;
    }
}

if (!function_exists('functionToGetStaffData')) {
    /**
     * functionToGetStaffData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetStaffData()
    {
        $whereToFind = ['rawQuery' => 'role = ?', 'bindParams' => ['S']];
        $dataToFInd = ['id', 'name', 'username', 'staff_rating', 'staff_feedback', 'staff_status', 'role'];
        $getUserDetails = \App\Modules\Manager\Models\User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
        return $getUserDetails;
    }
}

if (!function_exists('functionToGetMangerData')) {
    /**
     * functionToGetMangerData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetMangerData()
    {
        $whereToFindManager = ['rawQuery' => 'role = ?', 'bindParams' => ['M']];
        $dataToFInd = ['id', 'name', 'username', 'role'];
        $getManagerDetails = \App\Modules\Manager\Models\User::getInstance()->getUserDetails($whereToFindManager, $dataToFInd);
        return $getManagerDetails;
    }
}

if (!function_exists('functionToGetAdminData')) {
    /**
     * functionToGetMangerData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetAdminData()
    {
        $whereToFindAdmin = ['rawQuery' => 'role = ?', 'bindParams' => ['A']];
        $dataToFInd = ['id', 'name', 'username', 'role','profile_pic'];
        $getAdminDetails = \App\Modules\Manager\Models\User::getInstance()->getUserDetails($whereToFindAdmin, $dataToFInd);
        return $getAdminDetails;
    }
}