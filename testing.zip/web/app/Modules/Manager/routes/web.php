<?php

Route::group(['module' => 'Manager', 'middleware' => ['web'], 'namespace' => 'App\Modules\Manager\Controllers'], function () {

    Route::get('/manager/sign-up/{token}', 'ManagerController@register');
    Route::post('/manager/sign-up/{token}', 'ManagerController@register');
    Route::get('/manager/sign-up-varify/{token}', 'ManagerController@signUpVarification');


    Route::get('/manager/sign-in', 'ManagerController@login');
    Route::post('/manager/sign-in', 'ManagerController@login');

    Route::get('/manager/forgot-password', 'ManagerController@forgotPassword');
    Route::post('/manager/forgot-password', 'ManagerController@forgotPassword');

    Route::get('/manager/reset-password/{token}', 'ManagerController@resetPassword');
    Route::post('/manager/reset-password', 'ManagerController@resetPassword');

    Route::get('/manager/logout', 'ManagerController@logout');

    Route::group(['middleware' => 'CheckSession:manager'], function () {
        Route::get('/manager/dashboard', 'DashboardController@dashboard');

        Route::get('/manager/account-setting-page', 'ManagerController@accountSetting');
        Route::post('/manager/updateProfileAjaxHandler', 'ManagerController@updateProfileAjaxHandler');
        Route::post('/manager/checkOldPassowordExist', 'ManagerController@checkOldPassowordExist');
        Route::post('/manager/checkExistEmail', 'ManagerController@checkExistEmail');
        Route::post('/manager/checkExistUsername', 'ManagerController@checkExistUsername');

//        ===================================== Task ANd Issue Routes =================================
        Route::post('/manager/insertTaskDetails', 'DashboardController@insertTaskDetails');
        Route::post('/manager/insertIssueDetails', 'DashboardController@insertIssueDetails');
        Route::post('/manager/insertMilestoneDetails', 'DashboardController@insertMilestoneDetails');
        Route::get('/manager/taskInfoAjaxHandler', 'DashboardController@taskInfoAjaxHandler');
        Route::get('/manager/issueInfoAjaxHandler', 'DashboardController@issueInfoAjaxHandler');
        Route::get('/manager/milestoneDataAjaxHandler', 'DashboardController@milestoneDataAjaxHandler');
        Route::post('/manager/fetchDataAjaxHandler', 'DashboardController@fetchDataAjaxHandler');
        Route::post('/manager/updateIssueData', 'DashboardController@updateIssueData');
        Route::post('/manager/updateTaskData', 'DashboardController@updateTaskData');
        Route::post('/manager/updateMilestoneData', 'DashboardController@updateMilestoneData');
        Route::post('/manager/insertCommentAjaxhandler', 'DashboardController@insertCommentAjaxhandler');
        Route::post('/manager/deleteDataAjaxHandler', 'DashboardController@deleteDataAjaxHandler');
        Route::post('/manager/updateComment', 'DashboardController@updateComment');
        Route::post('/manager/updateIssueComment', 'DashboardController@updateIssueComment');
        Route::post('/manager/updateAjaxHandler', 'DashboardController@updateAjaxHandler');
        Route::post('/manager/getStaffs', 'DashboardController@getStaffs');
        Route::post('/manager/getTaskComment', 'DashboardController@getTaskComment');
        Route::post('/manager/getComment', 'DashboardController@getComment');
        Route::get('/manager/task-submission/{id}', 'DashboardController@taskSubmission');
        Route::get('/manager/issue-submission/{id}', 'DashboardController@issueSubmission');
        Route::post('/manager/getAllCountInChart', 'DashboardController@getAllCountInChart');
        Route::post('/manager/filteringOfTaskAjaxHandler', 'DashboardController@filteringOfTaskAjaxHandler');
        Route::post('/manager/filteringOfIssueAjaxHandler', 'DashboardController@filteringOfIssueAjaxHandler');

        //        ================================== Project Routes =============================================
        Route::get('/manager/projects-info', 'ProjectController@projectsInfo');
        Route::get('/manager/projectInfoAjaxHandler', 'ProjectController@projectInfoAjaxHandler');
        Route::post('/manager/addProjectPage', 'ProjectController@addProjectPage');
        Route::post('/manager/editProjectAjaxHandler', 'ProjectController@editProjectAjaxHandler');
        Route::post('/manager/updateProjectDetails', 'ProjectController@updateProjectDetails');
        Route::post('/manager/fetchProDataAjaxHandler', 'ProjectController@fetchProDataAjaxHandler');
        Route::get('/manager/filteringOfDataAjaxHandler', 'ProjectController@filteringOfDataAjaxHandler');

        //        ==================================== support ticket Routes =====================================
        Route::get('/manager/support-list', 'SupportTicketController@supportlist');
        Route::get('/manager/support-list/{id}', 'SupportTicketController@supportlist');
        Route::get('/manager/ticketsInfoAjaxHandler', 'SupportTicketController@ticketsInfoAjaxHandler');
        Route::post('/manager/addNewTicket', 'SupportTicketController@addNewTicket');
        Route::post('/manager/updateStatusOfTicket', 'SupportTicketController@updateStatusOfTicket');
        Route::post('/manager/fetchTicketReply', 'SupportTicketController@fetchTicketReply');
        Route::post('/manager/sendReplyForTicket', 'SupportTicketController@sendReplyForTicket');
        Route::get('/manager/view-queries', 'SupportTicketController@viewQueries');
        Route::post('/manager/filteringOfSupportAjaxHandler', 'SupportTicketController@filteringOfSupportAjaxHandler');

        //        ====================================== message page routes ===============================
        Route::get('/manager/message-page', 'MessageController@messagePage');
        Route::get('/manager/message-page/{sid}/{rid}', 'MessageController@messagePage');
        Route::get('/manager/messageDataAjaxHandler', 'MessageController@messageDataAjaxHandler');
        Route::post('/manager/insertMessageData', 'MessageController@insertMessageData');
        Route::post('/manager/fetchAllMessage', 'MessageController@fetchAllMessage');
        Route::post('/manager/fetchLatestMessage', 'MessageController@fetchLatestMessage');
        Route::post('/manager/sendMessage', 'MessageController@sendMessage');
        Route::post('/manager/filteringOfMessageAjaxHandler', 'MessageController@filteringOfMessageAjaxHandler');

        //        ===================================== staff list routes  =================================
        Route::get('/manager/staff-list-details', 'StaffListController@staffListDetails');
        Route::get('/manager/staffListInfoAjaxHandler', 'StaffListController@staffListInfoAjaxHandler');
        Route::get('/manager/allTaskOfStaffAjaxHandler', 'StaffListController@allTaskOfStaffAjaxHandler');
        Route::get('/manager/allIssueOfStaffAjaxHandler', 'StaffListController@allIssueOfStaffAjaxHandler');
        Route::get('/manager/projectTaskOfAjaxHandler', 'StaffListController@projectTaskOfAjaxHandler');
        Route::get('/manager/projectIssueOfAjaxHandler', 'StaffListController@projectIssueOfAjaxHandler');
        Route::post('/manager/updateDataAjaxHandler', 'StaffListController@updateDataAjaxHandler');
        Route::post('/manager/getProjectDetailsOfStaff', 'StaffListController@getProjectDetailsOfStaff');

        //        ========================================== Resource pages Routes  ================================

        Route::get('/manager/resource-page', 'ResourceController@resourcePage');
        Route::get('/manager/add-resource-page', 'ResourceController@addResourcePage');
        Route::get('/manager/view-resource-page/{id}', 'ResourceController@showMoreResources');
        Route::post('/manager/insertResourceData', 'ResourceController@insertResourceData');
        Route::post('/manager/getContents', 'ResourceController@getContents');
        Route::post('/manager/getMoreContents', 'ResourceController@getMoreContents');

        Route::get('/manager/feed', 'NotificationController@feedPage');
        Route::post('/manager/fetchNotificationData','NotificationController@fetchNotificationData');
        Route::post('/manager/getTotalNotiifcation','NotificationController@getTotalNotiifcation');

    });
});
