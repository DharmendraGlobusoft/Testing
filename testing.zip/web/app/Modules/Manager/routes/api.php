<?php

Route::group(['module' => 'Manager', 'middleware' => ['api'], 'namespace' => 'App\Modules\Manager\Controllers'], function() {

    Route::resource('Manager', 'ManagerController');

});
