<?php

echo trans('Manager::example.welcome');