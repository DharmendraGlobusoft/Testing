@extends('Manager::Dashboard/layouts.bodyLayout')

@section('title','StaffList || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/css/lib/datatable/editor.dataTables.min.css">
    {{--<link rel="stylesheet" href="/assets/css/ratings/star-rating.css" media="all" type="text/css"/>--}}
    {{--<script src="/assets/js/ratings/star-rating.js" type="text/javascript"></script>--}}
    <style>
        #editProjectmodal .form-control {
            display: inline-block;
        }

        /*        tabs Css*/
        .tabs {
            background: #eee;
            margin: 0 auto;
            max-width: 950px;
            overflow: hidden;
            position: relative;
        }

        .tabs__header {
            display: flex;
            justify-content: space-between;
        }

        .tabs__header li {

            list-style: none;
        }

        .tabs__header--title {
            background: #272c33;;
            color: #fff;
            cursor: pointer;
            flex: 1 0 auto;
            padding: 10px;
            position: relative;
            text-align: center;
            transition: opacity 0.3s;
        }

        .tabs__header--title::after {
            background: #E91E63;
            bottom: -1px;
            content: '';
            display: none;
            height: 4px;
            left: 50%;
            position: absolute;
            transform: translateX(-50%) scaleX(0);
            transition: transform 0.3s;
            width: 100%;
        }

        .tabs__header--title.active::after {
            transform: translateX(-50%) scaleX(1);
        }

        .tabs__underline {
            width: 50%;
            background: #3CA1EB;
            height: 4px;
            position: absolute;
            left: 0;
            top: 40px;
            transition: transform 0.5s cubic-bezier(1, -1.25, 0, 1.75);
        }

        .tabs__content {
            background: #eee;
            display: none;
            padding: 15px 20px;
        }

        .tabs__content.active {
            animation: fadeIn 1s;
            display: block;
        }

        .tabs__content.active .tabs__content--title,
        .tabs__content.active .tabs__content--text {
            animation: fadeInUp 0.3s forwards;
        }

        .tabs__content.active .tabs__content--text {
            animation-delay: 0.3s;
        }

        .tabs__content--title {
            font-family: "Lustria", serif;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .tabs__content--text {
            line-height: 1.4;
            opacity: 0;
        }

        @media only screen and (min-width: 651px) {
            .tabs__header--title:hover {
                opacity: .7;
            }

            .tabs__header--title:not(:last-of-type) {
                border-right: 1px solid #fff;
            }
        }

        @media only screen and (max-width: 650px) {
            body {
                padding: 0;
            }

            .tabs__header {
                flex-wrap: wrap;
            }

            .tabs__header--title {
                border-bottom: 1px solid #fff;
                width: 100%;
            }

            .tabs__header--title::after {
                display: block;
            }

            .tabs__underline {
                display: none;
            }
        }

        @keyframes fadeIn {
            0% {
                display: none;
                opacity: 0;
            }
            1% {
                display: block;
                opacity: 0;
            }
            100% {
                display: block;
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media only screen and (min-width: 651px) {
            .tabs__header--title:hover {
                opacity: .7;
            }

            .tabs__header--title:not(:last-of-type) {
                border-right: 1px solid #fff;
            }
        }

        @media only screen and (max-width: 650px) {
            body {
                padding: 0;
            }

            .tabs__header {
                flex-wrap: wrap;
            }

            .tabs__header--title {
                border-bottom: 1px solid #fff;
                width: 100%;
            }

            .tabs__header--title::after {
                display: block;
            }

            .tabs__underline {
                display: none;
            }
        }

        a.name .name_show {
            display: none;
        }

        a.name:hover .name_show {
            display: block;
            position: absolute;
            z-index: 999;
            background: #fff;
            width: 250px;
            word-wrap: break-all;
            color: #fff !important;
            box-shadow: 0px 0px 15px #6A6A6A;
            margin-left: -5%;
            padding: 2%;
            background-color: #333;
            border-radius: 4px;
        }

        .name_show span {
            color: #fff;
            width: 250px;
            word-break: break-all;
        }

        .ratings-icons {
            color: #fec42d;
            margin-bottom: 15px;
        }

        /*==================================================*/
        fieldset, label {
            margin: 0;
            padding: 0;
        }

        h1 {
            font-size: 1.5em;
            margin: 10px;
        }

        /****** Style Star Rating Widget *****/

        /***** CSS Magic to Highlight Stars on Hover *****/
        /**        Rating style *!*/

        .rating {
            text-align: center;
            margin-top: 0px;
            position: relative;
            width: 100%;
            float: left;
        }

        .hidden {
            opacity: 0;
        }

        .star {
            display: inline-block;
            margin: 5px;
            font-size: 15px;
            color: #c3bfbf;
            position: relative;
        }

        .star.animate {
            -webkit-animation: stretch-bounce .5s ease-in-out;
        }

        .star.hidden {
            opacity: 0;
        }

        .full:before {
            font-family: fontAwesome;
            display: inline-block;
            content: "\f005";
            position: relative;
            float: right;
            z-index: 2;
        }

        .half:before {
            font-family: fontAwesome;
            content: "\f089";
            position: absolute;
            float: left;
            z-index: 3;
        }

        .star-colour {
            color: #3ca1eb;
        }

        @-webkit-keyframes stretch-bounce {
            0% {
                -webkit-transform: scale(1);
            }
            25% {
                -webkit-transform: scale(1.5);
            }
            50% {
                -webkit-transform: scale(0.9);
            }
            75% {
                -webkit-transform: scale(1.2);
            }
            100% {
                -webkit-transform: scale(1);
            }
        }

        .selected:before {
            font-family: fontAwesome;
            display: inline-block;
            content: "\f005";
            position: absolute;
            top: 0;
            left: 0;
            -webkit-transform: scale(1);
            opacity: 1;
            z-index: 1;
        }

        .selected.pulse:before {
            -webkit-transform: scale(3);
            opacity: 0;
        }

        .selected.is-animated:before {
            transition: 1s ease-out;
        }

        .score {
            font-family: arial;
            font-size: 20px;
            color: green;
            margin-top: 20px;
            margin-left: 50px;
        }

        .score-rating {
            vertical-align: sup;
            top: -5px;
            position: relative;
            font-size: 75%;
        }

        .total {
            vertical-align: sub;
            top: 0px;
            position: relative;
            font-size: 75%;
        }

        .average {
            font-family: arial;
            font-size: 20px;
            color: indianred;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        .average .score-average {
            padding-top: 30px;
        }

        #accordion .panel {
            border: none;
            border-radius: 0;
            margin-bottom: 5px;
            box-shadow: none;
        }

        #accordion .panel-heading {
            padding: 0;
            border: none;
            border-radius: 0;
            position: relative;
        }

        #accordion .panel-title a {
            display: block;
            padding: 15px 25px;
            margin: 0;
            background: #3ca1eb;
            font-size: 15px;
            font-weight: bold;
            color: #f5f3ee;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
        }

        #accordion .panel-title a:before,
        #accordion .panel-title a.collapsed:before {
            content: "";
            width: 20px;
            height: 2px;
            background: #f6f5f3;
            position: absolute;
            top: 25px;
            right: 29px;
        }

        #accordion .panel-title a:after,
        #accordion .panel-title a.collapsed:after {
            content: "";
            width: 2px;
            height: 17px;
            background: #f8f8f8;
            position: absolute;
            bottom: 14px;
            right: 38px;
            transition: all 0.3s ease 0s;
        }

        #accordion .panel-title a:after {
            height: 0;
        }

        #accordion .panel-body {
            padding: 20px 30px;
            background: #e9e9e7;
            border: 1px solid #eae7e7;
        }


    </style>
@endsection

@section('body')
    {{--<input type="text" class="rating rating-loading" value="4" data-size="xs" title="">--}}
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Staff List</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/manager/dashboard">Dashboard</a></li>
                        <li class="active">Staff List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Staff Details</strong>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="staffListTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Staff Name</th>
                                    <th>Ratings</th>
                                    <th id="feedClass" class="feedClass">Feedback</th>
                                    <th>Project Details</th>
                                    <th>Staff Status</th>
                                    <th hidden>feedback status</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="staffProjectDetails">
        <div class="modal-dialog" style="max-width: 1000px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i> PROJECT
                        DETAILS</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="panel-group projectData" id="accordion" role="tablist" aria-multiselectable="true">

                        {{--<div class="projectData"></div>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js" type="text/javascript"
            charset="utf-8"></script>
    <script src="https://cdn.datatables.net/select/1.2.5/js/dataTables.select.min.js"></script>

    <script>
        $(document.body).on('click', '.js-tabs-title0', function () {
            let openTab0 = $(this).data('tab'),
                linePosition2 = $(this).position().left;
            $('.js-tabs-underline0').css('transform', 'translateX(' + linePosition2 + 'px)');
            $('.js-tabs-title0').removeClass('active');
            $(this).addClass('active');
            $('.js-tabs-content0').removeClass('active');
            $(openTab0).addClass('active');
        });
    </script>
    <script>
        $(function () {
            $(document.body).on("click", '.expand', function () {
                $expand1 = $(".expand").find(">:first-child");

                if ($expand1.text() == "+") {
                    $expand1.text("-");
                } else {
                    $expand1.text("+");
                }
                $expand = $(this).find(">:first-child");
                if ($expand.text() == "+") {
                    $expand.text("-");
                } else {
                    $expand.text("+");

                }
            });
        });
    </script>

    <script>

    </script>
    {{--<!-- Bandana Codes... -->==========================================================================--}}

    <script>
        $(document).ready(function () {
            let handleDatatable = function (target = 0, sortingType = "desc") {
                $('#staffListTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: '/manager/staffListInfoAjaxHandler',
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'StaffName', name: 'StaffName'},
                        {data: 'Ratings', name: 'Ratings'},
                        {data: 'Feedback', name: 'Feedback'},
                        {data: 'ProjectDetails', name: 'ProjectDetails'},
                        {data: 'status', name: 'status'},
                        {data: 'feedbackStatus', name: 'feedbackStatus', visible: false}
                    ],

                    "order": [[target, sortingType]],
                    // createdRow: function (row, data, index) {
                    //     $('td', row).eq(2).attr({
                    //         'class': 'rating rating-loading',
                    //         // 'contenteditable': data.contenteditable,
                    //         // 'data-id': data.staffId
                    //     });
                    // }
                });
            };

            handleDatatable();

            let starClicked = false;
            $('#staffListTable').on('draw.dt', function () {

                $(document.body).on('click', '.star', function () {
                    let raingNum = $(this).closest('.rating').find('.js-score').text();
                    let staffId = $(this).closest('.rating').attr('data-id');

                    $(this).children('.selected').addClass('is-animated');
                    $(this).children('.selected').addClass('pulse');

                    let target = this;

                    setTimeout(function () {
                        $(target).children('.selected').removeClass('is-animated');
                        $(target).children('.selected').removeClass('pulse');
                    }, 1000);
                    starClicked = true;
                    updateRating(staffId,raingNum);
                });

                $(document.body).on('click', '.half', function () {
                    setHalfStarState(this);

                    let raingNum = $(this).closest('.rating').find('.js-score').text();
                    let staffId = $(this).closest('.rating').attr('data-id');
                    if (starClicked == true) {
                        setHalfStarState(this)
                    }
                    $(this).closest('.rating').find('.js-score').text($(this).data('value'));

                    $(this).closest('.rating').data('vote', $(this).data('value'));
                    calculateAverage()
                    updateRating(staffId,raingNum);

                });

                $(document.body).on('click', '.full', function () {
                    setFullStarState(this);
                    let raingNum = $(this).closest('.rating').find('.js-score').text();
                    let staffId = $(this).closest('.rating').attr('data-id');
                    if (starClicked == true) {
                        setFullStarState(this)
                    }
                    $(this).closest('.rating').find('.js-score').text($(this).data('value'));

                    $(this).find('js-average').text(parseInt($(this).data('value')));

                    $(this).closest('.rating').data('vote', $(this).data('value'));
                    calculateAverage()

                    updateRating(staffId,raingNum);

                });

                // $('.half').hover(function () {
                //     if (starClicked == false) {
                //         setHalfStarState(this)
                //     }
                //
                // });
                //
                // $('.full').hover(function () {
                //     if (starClicked == false) {
                //         setFullStarState(this)
                //     }
                // })

                // });

                function updateStarState(target) {
                    $(target).parent().prevAll().addClass('animate');
                    $(target).parent().prevAll().children().addClass('star-colour');

                    $(target).parent().nextAll().removeClass('animate');
                    $(target).parent().nextAll().children().removeClass('star-colour');
                }

                function setHalfStarState(target) {
                    $(target).addClass('star-colour');
                    $(target).siblings('.full').removeClass('star-colour');
                    updateStarState(target)
                }

                function setFullStarState(target) {
                    $(target).addClass('star-colour');
                    $(target).parent().addClass('animate');
                    $(target).siblings('.half').addClass('star-colour');

                    updateStarState(target)
                }

                function calculateAverage() {
                    var average = 0

                    $('.rating').each(function () {
                        average += $(this).data('vote')
                    })

                    $('.js-average').text((average / $('.rating').length).toFixed(1))
                }
            });


            $(document.body).on('change', '.statusSelect', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateStaffStatus',
                        staffId: $(this).attr('data-id'),
                        staffStatus: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('change', '.feedbackSelect', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateStaffFeedback',
                        staffId: $(this).attr('data-id'),
                        staffFeedback: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });


            function updateRating(staffId,raingNum) {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateStaffRating',
                        staffRating: raingNum,
                        staffId: staffId,
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        }
                        // else {
                        //     toastr.error(response.message, {timeOut: 3000});
                        // }
                    }
                });
            };


            $(document.body).on('click', '.feedClass', function () {

                let elem = $(this);
                if (elem.hasClass("asc")) {
                    elem.addClass("desc").removeClass('asc');
                    handleDatatable(6, "desc");
                } else {
                    elem.addClass("asc").removeClass('desc');
                    handleDatatable(6, "asc");
                }
            });

            $(document.body).on('change', '.selectSeverity', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateIssueSeverity',
                        issueId: $(this).attr('data-id'),
                        issueSeverity: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('change', '.selectIssueStatus', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateIssueStatus',
                        issueId: $(this).attr('data-id'),
                        issueStatus: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('change', '.selectTaskStatus', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateTaskStatus',
                        taskId: $(this).attr('data-id'),
                        taskStatus: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('change', '.selectTaskPriority', function () {
                $.ajax({
                    url: "/manager/updateDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseData: 'updateTaskPriority',
                        taskId: $(this).attr('data-id'),
                        taskPriority: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            // $(document.ready).on('click', '.js-tabs-title', function () {
            $(document.body).on('click', '.tabs__header--title', function () {
                let id = $(this).parent().data('id');
                let openTab = $(this).data('tab');
                linePosition = $(this).position().left;
                $('.js-tabs-underline' + id).css('transform', 'translateX(' + linePosition + 'px)');
                $('.js-tabs-title' + id).removeClass('active'); //by siddu
                $(this).addClass('active');
                $('.js-tabs-content' + id).removeClass('active');
                $(openTab).addClass('active');
            });

            $(document.body).on('click', '.staffDetails', function () {
                $('#staffProjectDetails').attr('data-id', $(this).attr('data-id'));
                let staffId = $(this).attr('data-id');
                $.ajax({
                    url: "/manager/getProjectDetailsOfStaff",
                    type: "post",
                    dataType: "json",
                    data: {
                        staffId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        let data = '', ranInc = 1;
                        if (response.status === 200) {

                            data = '<div class="panel panel-default">' +
                                // '<div class="card-header allIssueAndTask">\n' +
                                '<div class="panel-heading allIssueAndTask" role="tab" id="headingOne">' +
                                // '<h4 data-toggle="collapse" style="cursor: pointer;" data-parent="#accordion" href="#collapse"class="panel-title expand">' +
                                // '<div class="right-arrow pull-right" style="cursor: pointer;">+</div><a>Tasks & Issues</a></h4></div>' +
                                '<h4 class="panel-title">' +
                                '<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne" class="collapsed">' +
                                'Tasks & Issues</a></h4></div>' +
                                // '<div id="collapse" class="panel-collapse collapse">' +
                                '<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">' +
                                '<div class="panel-body"><section class="tabs">' +
                                '<ul class="tabs__header">' +
                                '<li class="tabs__header--title js-tabs-title0 allTaskData active" data-tab="#tab-0">All Assigned Tasks</li>\n' +
                                '<li class="tabs__header--title js-tabs-title0 allIssueData" data-tab="#tab-1">All Assigned Issues</li>\n' +
                                '</ul>' +
                                '<div class="tabs__underline js-tabs-underline0"></div>' +
                                '<article class="tabs__content js-tabs-content0 active" id="tab-0">' +
                                '<div class="card"><div class="card-header"><strong class="card-title">All Assigned Task Details</strong></div>' +
                                '<div class="card-body">' +
                                '<table id="allTaskTable" class="table table-striped table-bordered">' +
                                '<thead><tr>' +
                                '<th>SL NO</th>\n' +
                                '<th>Project Name</th>\n' +
                                '<th>Task Name</th>\n' +
                                '<th>Due Date</th>\n' +
                                '<th>Due Hours</th>\n' +
                                '<th>Priority</th>\n' +
                                '<th>Status</th>\n' +
                                '</tr></thead></table>' +
                                '</div></div></article>' +
                                '<article class="tabs__content js-tabs-content0" id="tab-1">' +
                                '<div class="card"><div class="card-header"><strong class="card-title">Issues Details</strong></div>' +
                                '<div class="card-body table-responsive">' +
                                '<table id="allIssueTable" class="table table-striped table-bordered">' +
                                '<thead><tr>' +
                                '<th>SL NO</th>\n' +
                                '<th>Project Name</th>\n' +
                                '<th>Issue Name</th>\n' +
                                '<th>Due Date</th>\n' +
                                '<th>Due Hours</th>\n' +
                                '<th>Severity</th>\n' +
                                '<th>Staus</th>\n' +
                                '</tr></thead></table>' +
                                '</div></div></article></section></div></div></div>';
                            $.each(response.data, function (k, v) {
                                data += '<div class="panel panel-default">' +
                                    `<div class="panel-heading projectTaskandIssues " id="${staffId}" data-id="${v[0].project_id}"  role="tab">` +
                                    '<h4 class="panel-title">' +
                                    '<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseA' + v[0].project_id + '" aria-expanded="true" aria-controls="collapseA' + v[0].project_id + '" ' +
                                    'class="collapsed">Project Name : ' + v[0].project_name + '</a></h4></div>' +

                                    // '<h4 data-toggle="collapse" data-parent="#accordion" href="#collapse' + v[0].project_id + '"' +
                                    // 'class="panel-title expand"><div class="right-arrow pull-right" style="cursor: pointer;">+</div><a href="#">Project Name : ' + v[0].project_name + '</a></h4></div>' +

                                    '<div id="collapseA' + v[0].project_id + '" class="panel-collapse collapse" role="tabpanel" aria-labelledby="' + staffId + '" >' +
                                    '<div class="panel-body"><section class="tabs">' +
                                    `<ul class="tabs__header" data-id="${v[0].project_id}">` +
                                    '<li class="tabs__header--title js-tabs-title' + v[0].project_id + ' projectTaskData active" data-id="' + v[0].project_id + '" id="' + staffId + '" data-tab="#tab-' + (++ranInc) + '">Assigned Tasks</li>' +
                                    '<li class="tabs__header--title js-tabs-title' + v[0].project_id + ' projectIssueData" data-id="' + v[0].project_id + '" id="' + staffId + '" data-tab="#tab-' + (++ranInc) + '">Assigned Issues</li></ul>' +
                                    '<div class="tabs__underline js-tabs-underline' + v[0].project_id + '"></div><article class="tabs__content js-tabs-content' + v[0].project_id + ' active" id="tab-' + (--ranInc) + '"><div class="card">' +
                                    '<div class="card-header"><strong class="card-title">Assigned Task Details</strong></div><div class="card-body table-responsive">' +
                                    '<table id="projectTaskTable' + v[0].project_id + '" class="table table-striped table-bordered" width="100%">' +
                                    '<thead><tr>' +
                                    '<th>SL NO</th>' +
                                    '<th>Task Name</th>' +
                                    '<th>Start Date</th>' +
                                    '<th>End Date</th>' +
                                    '<th>Priority</th>' +
                                    '<th>Status</th></tr></thead></table>' +
                                    '</div></div></article><article class="tabs__content js-tabs-content' + v[0].project_id + '" id="tab-' + (++ranInc) + '"><div class="card"><div class="card-header">' +
                                    '<strong class="card-title"> Assigned Issues Details</strong></div><div class="card-body table-responsive">' +
                                    '<table id="projectIssueTable' + v[0].project_id + '"' +
                                    'class="table table-striped table-bordered">' +
                                    '<thead><tr>' +
                                    '<th>SL NO</th>' +
                                    '<th>Issue Name</th>' +
                                    '<th>Due Date</th>' +
                                    '<th>Due Hour</th>' +
                                    '<th>Severity</th>' +
                                    '<th>Status</th></tr>' +
                                    '</thead>' +
                                    '</table></div></div></article></section></div></div></div>';
                            });
                            $('.projectData').html('').append(data);
                            $('.allIssueAndTask,.allTaskData,.allIssueData').attr('data-id', staffId);
                        } else {
                            data = '<div class="panel panel-default">' +
                                '<div class="panel-heading allIssueAndTask" role="tab" id="headingOne">' +
                                // '<h4 data-toggle="collapse" style="cursor: pointer;" data-parent="#accordion" href="#collapse"class="panel-title expand">' +
                                // '<div class="right-arrow pull-right" style="cursor: pointer;">+</div><a>Tasks & Issues</a></h4></div>' +
                                '<h4 class="panel-title">' +
                                '<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne" class="collapsed">' +
                                'Tasks & Issues</a></h4></div>' +
                                // '<div id="collapse" class="panel-collapse collapse">' +
                                '<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">' +
                                '<div class="panel-body"><section class="tabs">' +
                                '<ul class="tabs__header">' +
                                '<li class="tabs__header--title js-tabs-title0 allTaskData active" data-tab="#tab-0">All Assigned Tasks</li>\n' +
                                '<li class="tabs__header--title js-tabs-title0 allIssueData" data-tab="#tab-1">All Assigned Issues</li>\n' +
                                '</ul>' +
                                '<div class="tabs__underline js-tabs-underline0"></div>' +
                                '<article class="tabs__content js-tabs-content0 active" id="tab-0">' +
                                '<div class="card"><div class="card-header"><strong class="card-title">All Assigned Task Details</strong></div>' +
                                '<div class="card-body">' +
                                '<table id="allTaskTable" class="table table-striped table-bordered">' +
                                '<thead><tr>' +
                                '<th>SL NO</th>\n' +
                                '<th>Project Name</th>\n' +
                                '<th>Task Name</th>\n' +
                                '<th>Due Date</th>\n' +
                                '<th>Due Hours</th>\n' +
                                '<th>Priority</th>\n' +
                                '<th>Status</th>\n' +
                                '</tr></thead></table>' +
                                '</div></div></article>' +
                                '<article class="tabs__content js-tabs-content0" id="tab-1">' +
                                '<div class="card"><div class="card-header"><strong class="card-title">Issues Details</strong></div>' +
                                '<div class="card-body table-responsive">' +
                                '<table id="allIssueTable" class="table table-striped table-bordered">' +
                                '<thead><tr>' +
                                '<th>SL NO</th>\n' +
                                '<th>Project Name</th>\n' +
                                '<th>Issue Name</th>\n' +
                                '<th>Due Date</th>\n' +
                                '<th>Due Hours</th>\n' +
                                '<th>Severity</th>\n' +
                                '<th>Staus</th>\n' +
                                '</tr></thead></table>' +
                                '</div></div></article></section></div></div></div>';
                            $('.projectData').html('').append(data);
                            $('.allIssueAndTask,.allTaskData,.allIssueData').attr('data-id', staffId);
                        }
                    }
                });
            });

            $(document.body).on('click', '.collapsed', function () {
                var cId = $(this).parent().parent().next().attr('id');
                var data = $('#accordion').find('.panel-title');
                $.each(data, function (i, v) {
                    var iid = $(v).children().attr('aria-controls');
                    var id = '#' + $(v).children().attr('aria-controls');
                    if (iid != cId) {
                        $(id).removeClass('show');
                        $(v).children().addClass('collapsed').attr('aria-expanded',false);
                    }
                });
            });

            $(document.body).on('click', '.projectTaskandIssues,.projectTaskData', function () {
                let projId = $(this).attr('data-id');
                let staffID = $(this).attr('id');
                $('#projectTaskTable' + projId).DataTable({
                    lengthMenu: [[3, 6, 9, 12, -1], [3, 6, 9, 12, "All"]],
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: '/manager/projectTaskOfAjaxHandler',
                        data: function (f) {
                            f.projectId = projId
                            f.staffId = staffID
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'taskTopic', name: 'taskTopic'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'dueHours', name: 'dueHours'},
                        {data: 'priority', name: 'priority'},
                        {data: 'status', name: 'status'}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                });
            });

            $(document.body).on('click', '.projectIssueData', function () {
                let projId = $(this).attr('data-id');
                let staffID = $(this).attr('id');
                $('#projectIssueTable' + projId).DataTable({
                    lengthMenu: [[3, 6, 9, 12, -1], [3, 6, 9, 12, "All"]],
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: '/manager/projectIssueOfAjaxHandler',
                        data: function (f) {
                            f.projectId = projId,
                                f.staffId = staffID
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'issueTopic', name: 'issueTopic'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'dueHours', name: 'dueHours'},
                        {data: 'severity', name: 'severity'},
                        {data: 'status', name: 'status'}
                    ],
                    createdRow: function (row, data, index) {
                        let issueDetails = data.issueDetails.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': issueDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                });
            });

            $(document.body).on('click', '.allIssueAndTask,.allTaskData', function () {
                let staffId = $(this).attr('data-id');
                $('#allTaskTable').DataTable({
                    lengthMenu: [[3, 6, 9, 12, -1], [3, 6, 9, 12, "All"]],
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: '/manager/allTaskOfStaffAjaxHandler',
                        data: function (f) {
                            f.staffId = staffId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'taskTopic', name: 'taskTopic'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'dueHours', name: 'dueHours'},
                        {data: 'priority', name: 'priority'},
                        {data: 'status', name: 'status'}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
                        let projName = data.projectDetails.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                });
            });

            $(document.body).on('click', '.allIssueData', function () {
                let staffId = $(this).attr('data-id');
                $('#allIssueTable').DataTable({
                    lengthMenu: [[3, 6, 9, 12, -1], [3, 6, 9, 12, "All"]],
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: '/manager/allIssueOfStaffAjaxHandler',
                        data: function (f) {
                            f.staffId = staffId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'issueTopic', name: 'issueTopic'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'dueHours', name: 'dueHours'},
                        {data: 'severity', name: 'severity'},
                        {data: 'status', name: 'status'}
                    ],
                    createdRow: function (row, data, index) {
                        let issueDetails = data.issueDetails.replace(/&amp;/g, '&');
                        let projName = data.projectDetails.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': issueDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                });
            });

        });
    </script>

@endsection

