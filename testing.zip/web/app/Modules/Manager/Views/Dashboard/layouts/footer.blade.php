{{--<script src="/managerAssets/js/vendor/jquery-2.1.4.min.js"></script>--}}
{{--<script src="/managerAssets/js/popper.min.js"></script>--}}
{{--<script src="/managerAssets/js/plugins.js"></script>--}}
{{--<script src="/managerAssets/js/lib/data-table/datatables.min.js"></script>--}}
<script src="/managerAssets/js/lib/data-table/jquery.dataTables.min.js"></script>
<script src="/managerAssets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="/managerAssets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="/managerAssets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="/managerAssets/js/lib/data-table/jszip.min.js"></script>
<script src="/managerAssets/js/lib/data-table/pdfmake.min.js"></script>
<script src="/managerAssets/js/lib/data-table/vfs_fonts.js"></script>
<script src="/managerAssets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="/managerAssets/js/lib/data-table/buttons.print.min.js"></script>
<script src="/managerAssets/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="/managerAssets/js/lib/data-table/datatables-init.js"></script>
<script src="/managerAssets/js/file_attach.js"></script>
<script src="/managerAssets/js/jquery.hotkeys.js"></script>
<script src="/managerAssets/js/bootstrap-wysiwyg.js"></script>
<script src="/managerAssets/js/toastr/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="/assets/js/main.js"></script>
<script src="/managerAssets/js/image_uploader.js" type="text/javascript"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>


<script type="text/javascript">
    $(document).ready(function () {
        $('#bootstrap-data-table-export').DataTable();
    });
</script>
<script>
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.each($('.navbar-nav li'), function () {
        if ($(this).find('a').attr('href') === window.location.pathname) {
            $(this).addClass('active').siblings().removeClass('active');
        }
    });
</script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

<script>
    $(document).ready(function () {
        $('.taskAssignee').select2({
            placeholder: "Select Your Staffs"
        });

        $('[data-toggle="popover"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Resource Page'
        });

        $('[data-toggle="popover1"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Add New Task'
        });

        $('[data-toggle="popover2"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Notifications'
        });

        $('[data-toggle="popover10"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Dashboard Page'
        });
        $('[data-toggle="popover11"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Project Page'
        });
        $('[data-toggle="popover12"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Support List'
        });
        $('[data-toggle="popover13"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Message Page'
        });
        $('[data-toggle="popover14"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Logout'
        });

        let maxLength = 80;
        $('.selectProName > option').text(function (i, text) {
            if (text.length > maxLength) {
                return text.substr(0, maxLength) + '...';
            }
        });

        function taskGraphical() {
            $.ajax({
                url: "/manager/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Task'
                },
                success: function (response) {
                    if (response.length > 0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart");
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ]
                                }],
                                labels: [
                                    "Pending",
                                    "Completed"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    } else {
                        let data = '';
                        data = '<h4 class="mb-3" >Tasks</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Task</p>\n' +
                            '<img src="/images/No_data.png" style="/*! text-align: center; */" width="120px">';
                        console.log(data);
                        $('.taskClass').html('').append(data);
                    }
                }
            });
        }

        let selectProject, taskName, taskDesc, dueDate, dueHours, taskPriority, taskAssignee,
            taskDataToInsert = {};

        $(document.body).on('change', '.selectProName', function () {
            $.ajax({
                url: "/manager/getStaffs",
                type: "post",
                dataType: "json",
                data: {
                    projectName: $(this).val()
                },
                success: function (response) {
                    let data = '';
                    if (response.status === 200) {

                        $.each(response.data, function (i, v) {
                            data += '<option value="' + v[0].username + '">' + v[0].name + '[' + v[0].username + ']' + '</option>'
                        });
                        $('.taskAssignee').html('').append(data);
                    } else {
                        $.each(response.data, function (i, v) {
                            data += '<option value="0">' + response.message + '</option>'
                        });
                        $('.taskAssignee').html('').append(data);
                    }
                }
            });
        });

        $(document.body).on('click', '.addTaskButton', function () {
            selectProject = $('.selectProName').val();
            textFileData.append('projectName', selectProject);
            taskName = $('.addTaskName').val();
            textFileData.append('taskName', taskName);
            taskDesc = $('.addTaskDesc').val();
            textFileData.append('taskDesc', taskDesc);
            dueDate = $('.taskNewDueDate').val();
            if (dueDate) {
                textFileData.append('dueDate', Date.parse(dueDate) / 1000);
            } else {
                textFileData.append('dueDate', $('.taskNewDueDate').val());
            }
            dueHours = $('.taskDueHours').val();
            textFileData.append('dueHours', dueHours);
            taskPriority = $('.addTaskPriority').val(); // 0-none,1-low,2-medium,3-high
            textFileData.append('taskPriority', taskPriority);
            taskAssignee = $('.taskAssignee').val();
            textFileData.append('taskAssignee', taskAssignee);

            let nowDate = new Date();
            let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

            if (selectProject === "0") {
                toastr.error('Please Choose Your Project');
            } else if (taskName === "") {
                toastr.error('Please Enter Your Task Name.');
            } else if ($('.taskNewDueDate').val() !== "" && Date.parse(date) / 1000 > Date.parse(dueDate) / 1000) {
                toastr.error('Due Date Should be greater than current date.');
            } else if (dueHours !== '' && dueHours < 1) {
                toastr.error('Due Hours Should be a Positive Number.');
            } else {
                $.ajax({
                    url: "/manager/insertTaskDetails",
                    type: "post",
                    dataType: "json",
                    data: textFileData,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        $(".taskSpinnerClass").css('display', 'block');
                        $(".addTaskButton,.cancelTaskBtn").attr('disabled', 'disabled');
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $(".addTaskButton,.cancelTaskBtn").attr('disabled', false);
                            $(".taskSpinnerClass").css('display', 'none');
                            $('#taskCreationmodal').modal('hide').find("input,textarea,select").val('').end();
                            $('.selectProName').val(0);
                            $('.addTaskPriority').val(0);
                            $('li.select2-selection__choice').remove();
                            $('li.form__files-item').remove();
                            $('#attachment-files').removeClass('form__files--show');
                            $('#taskTable1').DataTable().ajax.reload();
                            taskGraphical();
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            }
        });

        $(document.body).on('click', '.cancelTaskBtn,.cancelTaskButn', function () {
            $('#taskCreationmodal').modal('hide').find("input,textarea,select").val('').end();
            $('.selectProName').val(0);
            $('.addTaskPriority').val(0);
            $('li.form__files-item').remove();
            $('#attachment-files').removeClass('form__files--show');
            $('li.select2-selection__choice').remove();
        });

        setInterval(function () {
            $.ajax({
                url: "/manager/getTotalNotiifcation",
                type: "post",
                dataType: "json",
                data: '',
                success: function (response) {
                    if (response.status === 200) {
                        var data = '';
                        if (response.totalNotification > 0) {
                            data = '<button class="btn btn-secondary dropdown-toggle" type="button" id="notification"\n' +
                                'aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content="">\n' +
                                '<i class="fa fa-bell"></i>\n' +
                                '<span class="count bg-danger" style="height: 16px;\n' +
                                'width: 18px;">' + response.totalNotification + '</span>\n' +
                                '</button>';
                        } else {
                            data = '<button class="btn btn-secondary dropdown-toggle" type="button" id="notification"\n' +
                                'aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content=""\n' +
                                'style="margin-top: -8px;">\n' +
                                '<i class="fa fa-bell"></i>\n' +
                                '</button>';
                        }
                        $('.getNotifcation').html('').append(data);
                    } else {

                    }
                }
            });
        }, 10000);

    });
</script>
