<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office Blog</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>
    <meta name="author" content=""/>

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content=""/>
    <meta property="og:image" content=""/>
    <meta property="og:url" content=""/>
    <meta property="og:site_name" content=""/>
    <meta property="og:description" content=""/>
    <meta name="twitter:title" content=""/>
    <meta name="twitter:image" content=""/>
    <meta name="twitter:url" content=""/>
    <meta name="twitter:card" content=""/>
    <link rel="shortcut icon" href="/images/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Grand+Hotel" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Fira+Sans:100,200,300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <!-- Animate.css -->
    <link rel="stylesheet" href="/blog_assets/css/animate.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="/blog_assets/css/icomoon.css">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="/blog_assets/css/bootstrap.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="/blog_assets/css/magnific-popup.css">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="/blog_assets/css/flexslider.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="/blog_assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/blog_assets/css/owl.theme.default.min.css">
    <!-- Flaticons  -->
    <link rel="stylesheet" href="/blog_assets/fonts/flaticon/font/flaticon.css">
    <!-- Theme style  -->
    <link rel="stylesheet" href="/blog_assets/css/style.css">
    <!-- Modernizr JS -->
    <script src="/blog_assets/js/modernizr-2.6.2.min.js"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
    <!--<script src="js/respond.min.js"></script>-->
    <![endif]-->
    <style>
        figure {
            background: #fafafa;
            padding: 2em 0;
            /*display: block;*/
            display: contents;
        }

        .image-style-side {
            width: 100%;
        }

        h1, h2, h3 {
            color: #f6490d;
            text-align: center;
            font-family: "Lora", Georgia, serif;
            font-weight: 400;
            font-style: italic;
            font-size: 28px;
            margin-top: 25px;
            /*display: inline;*/
        }

        ul > li {
            text-align: left;
        }

        p {
            margin: 30px;
            text-align: justify;
            word-spacing: 0 !important;
        }

        .jumbotron {
            background-color: #fff !important;
            padding: 0 !important;
        }

        .jumbotron p {

            font-size: 14px !important;

        }

        .largeImageClass img {
            width: 100%;
        }

        figcaption {
            margin-top: 20px;
            color: #1e8cdd;
        }

        .sideImageClass img {
            padding: 10px;
            float: left;
        }

        .img_size {
            width: 225px;
            margin-bottom: 15px;
            height: 200px;
        }

        .date_class {
            display: block;
            font-size: 13px;
            color: gray;
            margin: 10px 0 0 0
        }

        .page {
            display: none;
        }

        .page-active {
            display: block;
        }
  .blog-wrap{
      background-color: #fff !important;
  }

        .thumbnail {

            padding: 1px !important;
        }
        /*.ck.ck-editor__main > .ck-editor__editable {*/
        /*min-height: 300px !important;*/
        /*}*/

        .side-wrap p{
            margin: 0px !important;
        }


    </style>
</head>
<body>
<div id="right-panel" class="right-panel">
    <div class="mt-3">
        <div class="animated fadeIn" style="text-align: center;">
            <aside id="colorlib-breadcrumbs">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 breadcrumbs text-center">
                            <a href="/manager/sign-in">
                            <img src="/images/logo4.png" width="30%">
                            </a>
                            {{--<h2 style="margin-top: 0;">Read Our Blogs</h2>--}}
                        </div>
                        <div class="col-md-12" style="text-align: center;">
                            <h2 style="margin-top: 0;color: #fff;">Read Our Blogs</h2>
                        </div>
                    </div>
                </div>
                {{--<div class="col-md-3 pull-right">--}}
                    {{--<a href="/manager/add-resource-page" class="btn btn-info"><i class="fa fa-plus-circle"--}}
                                                                               {{--aria-hidden="true"></i> ADD RESOURCE</a>--}}
                {{--</div>--}}
            </aside>

            <div id="colorlib-container">
                <div class="container">
                    <div class="row">
                        <div class="content">
                            <article class="blog-entry">

                                    <div class="blog-wrap">
                                        <div id="products" class="row view-group">
                                            @foreach($allResourceData as $k=>$val)
                                            <div class="item col-xs-4 col-lg-4">
                                                <div class="thumbnail card">
                                                    <div class="img-event">
                                                        {{--<a href="/admin/view-resource-page/{{$val['id']}}">--}}
                                                        <img class="group list-group-image img-fluid img_size"
                                                             src="{{$val['shortImage']}}" alt=""/>
                                                        {{--</a>--}}
                                                        <span class="date_class"><i class="icon-calendar3"></i> {{$val['startDate']}}</span>
                                                    </div>
                                                    <div class="caption card-body">
                                                        {{--<h4 class="group card-title inner list-group-item-heading">--}}
                                                            {{--Post title</h4>--}}
                                                        <h4 class="group card-title inner list-group-item-heading content_wrap" title="{{$val['title']}}">@if($val['title'] === null || $val['title'] === '')
                                                                Post Title @else {{$val['title']}} @endif</h4>
                                                        <div class="row">
                                                            <div class="col-xs-12 col-md-12">
                                                                <a class="btn btn-info" href="/manager/view-resource-page/{{$val['id']}}">View Post</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                            </article>
                        </div>
                        <aside class="sidebar">
                            <div class="side-wrap">
                                <h2 class="sidebar-heading">About Admin</h2>
                                <div class="author-img"
                                     style="background-image: url({{$adminData}});"></div>
                                <p class="aboutus-text">Cloudoffice Ltd is changing the way remote teams work by providing an
                                    on-demand, digital platform for scaling business teams that need higher levels of professionalism, security and support </p>
                                {{--<p>--}}
                                {{--<ul class="colorlib-social-icons">--}}
                                    {{--<li><a href="#"><i class="icon-twitter"></i></a></li>--}}
                                    {{--<li><a href="#"><i class="icon-facebook"></i></a></li>--}}
                                    {{--<li><a href="#"><i class="icon-linkedin"></i></a></li>--}}
                                    {{--<li><a href="#"><i class="icon-instagram"></i></a></li>--}}
                                {{--</ul>--}}
                                {{--</p>--}}
                            </div>
                            <div class="side-wrap">
                                <h2 class="sidebar-heading">Recent Post</h2>
                                @foreach($latestResource as $k1=>$val1)
                                <div class="f-entry demoClass">
                                    <a href="/manager/view-resource-page/{{$val1['id']}}">
                                    <img class="featured-img" src="{{$val1['shortImage']}}">
                                    </a>
                                    <div class="desc">
                                        <span><i class="icon-calendar3"></i> {{$val1['startDate']}}</span>
                                        <h3><a href="/manager/view-resource-page/{{$val1['id']}}">@if($val1['title'] === null || $val1['title'] === '') "Post Title" @else {{$val1['title']}} @endif</a></h3>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="icon-arrow-up2"></i></a>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<script src="/blog_assets/js/jquery.min.js"></script>
<script src="/blog_assets/js/jquery.easing.1.3.js"></script>
<script src="/blog_assets/js/bootstrap.min.js"></script>
<script src="/blog_assets/js/jquery.waypoints.min.js"></script>
<script src="/blog_assets/js/jquery.flexslider-min.js"></script>
<script src="/blog_assets/js/owl.carousel.min.js"></script>
<script src="/blog_assets/js/jquery.magnific-popup.min.js"></script>
<script src="/blog_assets/js/magnific-popup-options.js"></script>
<script src="/blog_assets/js/main.js"></script>
<script type="text/javascript" src="https://www.solodev.com/assets/pagination/jquery.twbsPagination.js"></script>
<script>

</script>
<script>
    // $(document).ready(function () {
    //     console.log('==============================');
    //     $.ajax({
    //         url: "/getContents",
    //         type: "post",
    //         dataType: "json",
    //         data: {},
    //         success: function (response) {
    //             console.log(response);
    //
    //             if (response.status === 200) {
    //                 let txt = '';
    //                 let allData = '';
    //                 $.each(response.data, function (i, v) {
    //
    //                     txt += '<div class="jumbotron page" id="page' + (i + 1) + '"><div class="container">' + v.content + '' +
    //                         '</div></div>';
    //
    //                     allData += v.shortImage + '<div class="desc">\n' +
    //                         '<span><i class="icon-calendar3"></i> January 21, 2018</span>\n' +
    //                         '<h3><a href="#">The Most Popular Leg Workout for Women</a></h3>\n' +
    //                         '</div>'
    //
    //                 });
    //                 txt += '<ul id="pagination-demo" class="pagination-lg pull-right"></ul>';
    //                 $('.content').html(txt);
    //                 $('.demoClass').html('').append(allData);
    //
    //                 $.each($('.image'), function (i, v) {
    //                     $(this).hasClass('image-style-side') ? $(this).addClass('sideImageClass') : $(this).addClass('largeImageClass');
    //                 });
    //                 $('#pagination-demo').twbsPagination({
    //                     totalPages: response.data.length,
    //                     startPage: 1,
    //
    //                     visiblePages: 5,
    //
    //                     initiateStartPageClick: true,
    //
    //                     href: false,
    //
    //                     first: 'First',
    //                     prev: 'Previous',
    //                     next: 'Next',
    //                     last: 'Last',
    //
    //                     loop: false,
    //
    //                     onPageClick: function (event, page) {
    //                         console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>');
    //                         console.log(page);
    //                         $('.page-active').removeClass('page-active');
    //                         $('#page' + page).addClass('page-active');
    //                     },
    //
    //                     paginationClass: 'pagination',
    //                     nextClass: 'next',
    //                     prevClass: 'prev',
    //                     lastClass: 'last',
    //                     firstClass: 'first',
    //                     pageClass: 'page',
    //                     activeClass: 'active',
    //                     disabledClass: 'disabled'
    //
    //                 });
    //             }
    //         }
    //     });
    //
    //     $(document.body).on('click', '.more', function () {
    //         console.log($(this).attr('data-id'));
    //         window.location.href = '/admin/show-more-resource-page/' + $(this).attr('data-id');
    //     });
    // });
</script>
</body>
</html>






























