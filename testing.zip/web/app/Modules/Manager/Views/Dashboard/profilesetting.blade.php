@extends('Manager::Dashboard/layouts.bodyLayout')

@section('title','Profile Setting || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="/assets/css/countrySelect.css">
    <style>
        /*        Image Upload CSS*/
        .avatar-upload {
            position: relative;
            max-width: 205px;
            margin: 0px auto;

        }

        .avatar-upload .avatar-edit {
            position: absolute;
            right: 0px;
            z-index: 1;
            top: 40px;
            z-index: 4;
        }

        .avatar-upload .avatar-edit input {
            display: none;
        }

        .avatar-upload .avatar-edit input + label {
            display: inline-block;
            width: 50px;
            height: 50px;
            margin-bottom: 0;
            border-radius: 100%;
            background: #3CA1EB;
            border: 1px solid transparent;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
            cursor: pointer;
            font-weight: normal;
            transition: all 0.2s ease-in-out;
            z-index: 5;
        }

        .avatar-upload .avatar-edit input + label:hover {
            background: #3CA1EB;
            border-color: #d6d6d6;
        }

        .avatar-upload .avatar-edit input + label:after {
            content: "\f040";
            font-family: 'FontAwesome';
            color: #fff;
            position: absolute;
            top: 15px;
            left: 0;
            right: 0;
            text-align: center;
            margin: auto;
        }

        .avatar-upload .avatar-preview {
            width: 200px;
            height: 200px;
            position: relative;
            border-radius: 100%;
            border: 6px solid #3CA1EB;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
            z-index: 3;
        }

        .avatar-upload .avatar-preview > div {
            width: 100%;
            height: 100%;
            border-radius: 100%;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /*      IMage Upload CSS Ends  */
        /*        tabs Css*/
        .tabs {
            background: #eee;
            margin: 0 auto;
            max-width: 950px;
            overflow: hidden;
            position: relative;
        }

        .tabs__header {
            display: flex;
            justify-content: space-between;
        }

        .tabs__header li {

            list-style: none;
        }

        .tabs__header--title {
            background: #272c33;;
            color: #fff;
            cursor: pointer;
            flex: 1 0 auto;
            padding: 10px;
            position: relative;
            text-align: center;
            transition: opacity 0.3s;
        }

        .tabs__header--title.active {
            border-bottom: 4px solid #3CA1EB;
        }

        .tabs__header--title::after {
            background: #E91E63;
            bottom: -1px;
            content: '';
            display: none;
            height: 4px;
            left: 50%;
            position: absolute;
            transform: translateX(-50%) scaleX(0);
            transition: transform 0.3s;
            width: 100%;
        }

        .tabs__header--title.active::after {
            transform: translateX(-50%) scaleX(1);
        }

        .tabs__underline {
            width: 25%;
            background: #3CA1EB;
            height: 4px;
            position: absolute;
            left: 0;
            top: 40px;
            transition: transform 0.5s cubic-bezier(1, -1.25, 0, 1.75);
        }

        .tabs__content {
            background: #eee;
            display: none;
            padding: 30px 20px;
        }

        .tabs__content.active {
            animation: fadeIn 1s;
            display: block;
        }

        .tabs__content.active .tabs__content--title,
        .tabs__content.active .tabs__content--text {
            animation: fadeInUp 0.3s forwards;
        }

        .tabs__content.active .tabs__content--text {
            animation-delay: 0.3s;
        }

        .tabs__content--title {
            font-family: "Lustria", serif;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .tabs__content--text {
            line-height: 1.4;
            opacity: 0;
        }

        @media only screen and (min-width: 651px) {
            .tabs__header--title:hover {
                opacity: .7;
            }

            .tabs__header--title:not(:last-of-type) {
                border-right: 1px solid #fff;
            }
        }

        @media only screen and (max-width: 650px) {
            body {
                padding: 0;
            }

            .tabs__header {
                flex-wrap: wrap;
            }

            .tabs__header--title {
                border-bottom: 1px solid #fff;
                width: 100%;
            }

            .tabs__header--title::after {
                display: block;
            }

            .tabs__underline {
                display: none;
            }
        }

        @keyframes fadeIn {
            0% {
                display: none;
                opacity: 0;
            }
            1% {
                display: block;
                opacity: 0;
            }
            100% {
                display: block;
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .submit-btn {
            text-align: center;
            margin: 3% 0;
        }

        .focused {
            border: solid 1px red;
        }

        .userimageresponsive{
            width: 200px;
            border-radius: 50%;
            border: 5px solid #5599f5;
        }
    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Account Settings</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/manager/dashboard">Dashboard</a></li>
                        <li class="active">Account Settings</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Account Settings Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="card-body">
                                <section class="tabs">
                                    <ul class="tabs__header">
                                        <li class="tabs__header--title js-tabs-title active" data-tab="#tab-1">Edit
                                            Personal Details
                                        </li>
                                        <li class="tabs__header--title js-tabs-title" data-tab="#tab-2">Change
                                            Password
                                        </li>
                                        <li class="tabs__header--title js-tabs-title" data-tab="#tab-3">Change Avatar
                                        </li>
                                    </ul>
                                    {{--<div class="tabs__underline js-tabs-underline"></div>--}}
                                    <article class="tabs__content js-tabs-content active" id="tab-1">
                                        <form action="">
                                            <div class="form-group col-md-6">
                                                <label for="firstName">Name:</label>
                                                <input type="text" class="form-control" id="firstName"
                                                       placeholder="Enter Name" name="firstName"
                                                       value="{{$data->name}}">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="userName">User Name:</label>
                                                <input type="text" class="form-control" id="userName"
                                                       placeholder="Enter User Name" name="userName"
                                                       value="{{$data->username}}">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="emailId">Email ID:</label>
                                                <input type="email" class="form-control" id="emailId"
                                                       placeholder="Enter Email ID" name="emailId"
                                                       value="{{$data->email}}" readonly>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Phone Number:</label>
                                                <input type="text" class="form-control" id="phoneNumber"
                                                       placeholder="Enter Phone Number" name="phoneNumber"
                                                       value="{{$data->mobile_number}}">
                                            </div>
                                            {{--<div class="form-group col-md-6">--}}
                                            {{--<label for="mPesaNumber">mPesa Number:</label>--}}
                                            {{--<input type="text" class="form-control" id="mPesaNumber"--}}
                                            {{--placeholder="Enter mPesa Number" name="mPesaNumber">--}}
                                            {{--</div>--}}
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Select Country:</label>
                                                <select id="country" name="country" class="form-control selectCountry">

                                                    <option value="{{$data->country}}"
                                                            selected>{{$data->country}}</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Select State:</label>
                                                <select name="state" id="state" class="form-control selectState">
                                                    <option value="0" >Select State</option>
                                                    {{--<option value="{{$data->state}}" selected>{{$data->state}}</option>--}}
                                                </select>
                                            </div>
                                            {{--<div class="form-group col-md-6">--}}
                                            {{--<label for="phoneNumber">Set Avaliability:</label>--}}
                                            {{--<select class="form-control">--}}
                                            {{--<option>Available</option>--}}
                                            {{--<option>Busy</option>--}}
                                            {{--</select>--}}
                                            {{--</div>--}}
                                            <div class="form-group col-md-12 submit-btn">
                                                <button type="button" class="btn btn-success updateUserDeatils"
                                                        style="padding: 6px 35px;">SUBMIT
                                                </button>
                                            </div>
                                        </form>
                                    </article>
                                    <article class="tabs__content js-tabs-content" id="tab-2">
                                        <form id="changePasswordForm" action="">
                                            <div class="col-md-6 offset-md-3">
                                                <div class="form-group">
                                                    <label for="currentPassword">Current Password:</label>
                                                    <input type="password" class="form-control" id="currentPassword"
                                                           placeholder="Enter Current Password" name="currentPassword">
                                                </div>
                                                <div class="form-group">
                                                    <label for="newpwd">New Password:</label>
                                                    <input type="password" class="form-control" id="newPassword"
                                                           placeholder="Enter New password" name="newPassword">
                                                </div>
                                                <div class="form-group">
                                                    <label for="pwd">Confirm Password:</label>
                                                    <input type="password" class="form-control" id="confirmPassword"
                                                           placeholder="Confirm password" name="confirmPassword">
                                                </div>
                                                <div class="form-group col-md-12 submit-btn">
                                                    <button type="button" class="btn btn-success changePasswordDeatils"
                                                            style="padding: 6px 35px;">SUBMIT
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </article>
                                    <article class="tabs__content js-tabs-content" id="tab-3" style="text-align: center;">
                                        <img src="@if($data->profile_pic !== ''){{$data->profile_pic}} @else '/images/degfault.png' @endif" class="image-responsive userimageresponsive">

                                        <div class="wrapper">
                                            <div class="change-icon imguploading"><a href="#" data-toggle='modal' data-target='#image-editor'><span class="change-icon-text"><i class="fa fa-pencil" aria-hidden="true"></i></span></a></div>
                                        </div>
                                        <div class="form-group col-md-12 submit-btn">
                                            <button type="button" class="btn btn-success uploadProfilePic"
                                                    style="padding: 6px 35px;">
                                                UPLOAD
                                            </button>
                                        </div>
                                    </article>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="image-editor" class="modal fade editor-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h2 class="modal-title">Edit Your Image</h2>
                    </div>
                    <div class="modal-body">
                        <div class="editor-wrapper">
                            <div class="editor-container">
                                <div class="editor">
                                    <div class="resize-container">
                                        <span class="resize-handle resize-handle-nw"></span>
                                        <span class="resize-handle resize-handle-ne"></span>
                                        <img class="resize-image" src="" alt="">
                                        <span class="resize-handle resize-handle-se"></span>
                                        <span class="resize-handle resize-handle-sw"></span>
                                    </div>
                                    <div class="overlay">
                                        <div class="overlay-inner"></div>
                                    </div>
                                    <div class="overlay overlay-preview">
                                        <div class="overlay-inner"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="upload" >
                            <form action="#"  role="form">
                                <input type="file" acccept="images/" class="form-control" id="uploaded-img" placeholder="Input field" accept="image/*">
                                <div class="upload-button" style="margin: 0 auto;">
                                    <label for="uploaded-img">
                                        <span class="label-text">Choose an Image</span><span class="upload-icon"><i class="fa fa-upload"></i></span>
                                    </label>
                                </div>
                                <!--
                                                                                    <div class="upload-button">
                                                                                        <label for="webcam-img">
                                                                                            <span class="label-text"> From Webcam</span><span class="upload-icon"><i class="fa fa-camera"></i></span>
                                                                                        </label>
                                                                                    </div>
                                -->
                                <div class="edit-button">
                                    <button class="btn form-control preview-crop">Preview</button>
                                    <button type="submit" class="js-crop btn form-control" data-dismiss="modal">upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="/assets/js/countries.js"></script>
    <script language="javascript">
        populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down

    </script>
    <script>
        function readURL1(input) {
            if (input.files && input.files[0]) {
                let reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview1').css('background-image', 'url(' + e.target.result + ')').hide().fadeIn(650);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload1").change(function () {
            readURL1(this);
        });
    </script>
    <script>
        $('.js-tabs-title').on('click', function () {
            let openTab = $(this).data('tab'),
                linePosition = $(this).position().left;
            $('.js-tabs-underline').css('transform', 'translateX(' + linePosition + 'px)');
            $('.js-tabs-title').removeClass('active');
            $(this).addClass('active');
            $('.js-tabs-content').removeClass('active');
            $(openTab).addClass('active');
        });
    </script>
    {{--<!-- Bandana Codes... -->==========================================================================--}}

    <script>
        $(document).ready(function () {
            $('#firstName').val('<?php echo $data->name ?>');
            $('#userName').val('<?php echo $data->username ?>');
            $('#emailId').val('<?php echo $data->email ?>');
            $('#phoneNumber').val('<?php echo $data->mobile_number ?>');
            if ('<?php echo $data->country ?>' === '-1' || '<?php echo $data->country ?>' === '') {
                $('.selectCountry').val('-1');
                $('.selectState').val('0');
            } else {
                $('.selectCountry').val('<?php echo $data->country ?>');
                $('.selectState').html('').append($('<option>', {
                    value: '<?php echo $data->state ?>',
                    text: '<?php echo $data->state ?>'
                }));
            }

            $('#currentPassword').val('');

            let oldPassword = '', confirmPassword = '', newPassword = '', message = '', firstName = '', userName = '',
                emailld = '',
                phoneNumber = '', selectCountry = '', selectState = '', dataToUpdate = {};


            /*function for userdetails validatin...*/
            let validateFunction = function () {
                if (!(firstName.match(/^[a-zA-Z0-9\-\s]+$/))) {
                    message = 'Please provide correct first name';
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else if (!(userName.match(/^[a-zA-Z0-9\-\s]+$/))) {
                    message = 'Please provide correct last name';
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else if (!(emailld.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                    message = 'Please provide your valid emailid';
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else if ((phoneNumber.length === 0) || (phoneNumber.length > 20) || !(phoneNumber.match(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/))) {
                    message = 'Please enter your valid phone number';
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else {
                    message = '';
                    return true;
                }
            };

            /*function for password validation...*/
            let passwordValidation = function () {
                if (!(oldPassword)) {
                    message = 'Please Enter Your Current Password.';
                    toastr.error(message, {timeOut: 3000});
                    $('#currentPassword').addClass("focused");
                    return false;
                } else if (!(newPassword.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                    message = 'Please Enter New Password which accepts numbers[0-9],letters[a-z] and a special character.';
                    $('#newPassword').addClass("focused");
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else if (!(confirmPassword.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                    message = 'Please Enter Confirm Password which accepts numbers[0-9],letters[a-z] and a special character.';
                    $('#confirmPassword').addClass("focused");
                    toastr.error(message, {timeOut: 3000});
                    return false;
                } else {
                    message = '';
                    return true;
                }
            };

            $('#currentPassword').blur(function () {
                $(this).removeClass("focused");
            });
            $('#newPassword').blur(function () {
                $(this).removeClass("focused");
            });
            $('#confirmPassword').blur(function () {
                $(this).removeClass("focused");
            });
            $('#firstName').blur(function () {
                $(this).removeClass("focused");
            });
            $('#userName').blur(function () {
                $(this).removeClass("focused");
            });
            $('#emailId').blur(function () {
                $(this).removeClass("focused");
            });
            $('#phoneNumber').blur(function () {
                $(this).removeClass("focused");
            });

            $(document.body).on('change', '#firstName', function () {
                firstName = $('#firstName').val();
                dataToUpdate.name = firstName;
            });
            $(document.body).on('change', '#userName', function () {
                userName = $('#userName').val();
                dataToUpdate.username = userName;
            });
            $(document.body).on('change', '#emailId', function () {
                emailld = $('#emailId').val();
                dataToUpdate.email = emailld;
            });
            $(document.body).on('change', '#phoneNumber', function () {
                phoneNumber = $('#phoneNumber').val();
                dataToUpdate.mobile_number = phoneNumber;
            });
            $(document.body).on('change', '.selectCountry', function () {
                selectCountry = $('.selectCountry').val();
                if (selectCountry === "-1") {
                    $('.selectState').html('').append($('<option>', {
                        value: '',
                        text: 'Select State'
                    }));
                    dataToUpdate.country = selectCountry;
                    dataToUpdate.state = $('.selectState').val();
                } else {
                    dataToUpdate.country = selectCountry;
                }
            });
            $(document.body).on('change', '.selectState', function () {
                selectState = $('.selectState').val();
                dataToUpdate.state = selectState;
            });

            function checkEmail(email) {
                let test = null;
                $.ajax({
                    async: false,
                    url: '/manager/checkExistEmail',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        data: email
                    },
                    success: function (response) {
                        if (response.status === 400) {
                            test = response.status;
                            toastr.error(response.message, {timeOut: 3000});
                        } else {
                            test = response.status;
                        }
                    }
                });
                return test;
            }

            function checkUsername(username) {
                let test = null;
                $.ajax({
                    async: false,
                    url: '/manager/checkExistUsername',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        data: username
                    },
                    success: function (response) {
                        if (response.status === 400) {
                            test = response.status;
                            toastr.error(response.message, {timeOut: 3000});
                        } else {
                            test = response.status;
                        }
                    }
                });
                return test;
            }

            /**
             * To update the userdetails
             */
            $(document.body).on('click', '.updateUserDeatils', function (e) {
                e.preventDefault();
                firstName = $('#firstName').val();
                userName = $('#userName').val();
                emailld = $('#emailId').val();
                phoneNumber = $('#phoneNumber').val();
                selectCountry = $('.selectCountry').val();
                selectState = $('.selectState').val();


                if (!(firstName.match(/^[^-\s][a-zA-Z _\s-]+$/))) {
                    message = 'Please Provide Valid Name which allow only alphabets.';
                    $('#firstName').addClass("focused").val('');
                    toastr.error(message, {timeOut: 3000});
                } else if (!(userName.match(/^[a-zA-Z0-9.\-_$*!]{3,30}$/))) {
                    message = 'Please Provide Valid User Name which doesnot accept @';
                    $('#userName').addClass("focused").val('');
                    toastr.error(message, {timeOut: 3000});
                } else if (!(emailld.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                    message = 'Please provide your valid emailid';
                    $('#emailId').addClass("focused").val('');
                    toastr.error(message, {timeOut: 3000});
                } else if ((phoneNumber.length === 0) || (phoneNumber.length > 15) || !(phoneNumber.match(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/))) {
                    message = 'Please enter your valid phone number';
                    $('#phoneNumber').addClass("focused").val('');
                    toastr.error(message, {timeOut: 3000});
                } else if (selectCountry !== "-1" && selectState === "") {
                    toastr.error('Please Select Your State', {timeOut: 3000});
                } else {
                    let checkData = checkEmail(emailld);
                    let checkUserData = checkUsername(userName);
                    if (checkData === 200 && checkUserData === 200) {
                        $.ajax({
                            url: '/manager/updateProfileAjaxHandler',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                chooseMethod: 'updateProfileInfo',
                                data: dataToUpdate
                            },
                            success: function (response) {
                                if (response.status === 200) {
                                    dataToUpdate = {};
                                    toastr.success(response.message, {timeOut: 2000});
                                } else if (response.status === 400) {
                                    toastr.error(response.message, {timeOut: 3000});
                                }
                            }
                        });
                    }
                }
            });

            $(document.body).on('focusout', '#currentPassword', function (e) {
                e.preventDefault();
                oldPassword = $(this).val();
                if (oldPassword !== '') {
                    let formData = new FormData();
                    formData.append('oldPasswordData', oldPassword);
                    $.ajax({
                        url: "/manager/checkOldPassowordExist",
                        type: "post",
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function (response) {
                            if (response.status === 400) {
                                $('#currentPassword').val('');
                                toastr.error(response.message, {timeOut: 5000});
                            }
                        }
                    });
                }
            });

            /**
             * Desc : To change password of a User.
             */
            $(document.body).on('click', '.changePasswordDeatils', function () {
                oldPassword = $('#currentPassword').val();
                newPassword = $('#newPassword').val();
                confirmPassword = $('#confirmPassword').val();

                let validationData = passwordValidation();

                if (validationData === true) {

                    if (confirmPassword !== newPassword) {
                        message = 'Please enter your confirm password same as new password!';
                        $('#confirmPassword').addClass("focused");
                        toastr.error(message, {timeOut: 3000});
                    } else if (oldPassword === '') {
                        message = 'Please enter your current password!';
                        toastr.error(message, {timeOut: 3000});
                    } else {
                        $.ajax({
                            url: '/manager/updateProfileAjaxHandler',
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                currentPassword: oldPassword,
                                newPassword: newPassword,
                                chooseMethod: 'changePassword'
                            },
                            success: function (response) {
                                if (response.status === 200) {
                                    toastr.success(response.message, {timeOut: 3000});
                                    window.setTimeout(function () {
                                        location.reload()
                                    }, 3000)
                                } else if (response.status === 400) {
                                    toastr.error(response.message, {timeOut: 3000});
                                } else if (response.status === 401) {
                                    $('#currentPassword').addClass("focused");
                                    toastr.error(response.message, {timeOut: 3000});
                                }
                            }
                        });
                    }
                }
            });

            /**
             * Desc : To update profilepic of User.
             */
            $(document.body).on('click', '.uploadProfilePic', function () {
                let imageFile = $('#imageUpload1')[0].files[0];
                let formDataFile = new FormData();
                formDataFile.append('imageFile', imageFile);
                formDataFile.append('chooseMethod', 'updateProfilePic');
                $.ajax({
                    url: '/manager/updateProfileAjaxHandler',
                    dataType: 'json',
                    type: 'post',
                    data: formDataFile,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        $('.avatar-preview').css('background-image', 'url(' + response.profilepic + ')');
                        $('.user-avatar').attr('src', response.profilepic);
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.success(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

        });
    </script>

@endsection