@extends('Manager::Dashboard/layouts.bodyLayout')

@section('title','Task Submission || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">

    {{--<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">--}}
    <style>
        .widget .card-body {
            padding: 0px;
        }

        .widget .list-group {
            margin-bottom: 0;
        }

        .widget .panel-title {
            display: inline
        }

        .widget .label-info {
            float: right;
            background-color: #5489e4;
            color: #fff;
            padding: 6px 9px;
            border-radius: 50%;
        }

        .widget li.list-group-item {
            border-radius: 0;
            border: 0;
            border-top: 1px solid #efedee;;
        }

        .widget li.list-group-item:hover {
            background-color: rgba(236, 231, 231, 0.1);
        }

        .widget .mic-info {
            color: #666666;
            font-size: 11px;
        }

        .widget .action {
            margin-top: 5px;
        }

        .widget .comment-text {
            font-size: 15px;
            word-break: break-all;
        }

        .widget .btn-block {
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .img-circle {
            border-radius: 50%;
        }

        .btn {
            padding: 5px 10px !important;
        }

        /*    Radio Button CSS*/

        .radio {
            padding-left: 20px;
        }

        .radio label {
            display: inline-block;
            position: relative;
            padding-left: 5px;
        }

        .radio label::before {
            content: "";
            display: inline-block;
            position: absolute;
            width: 17px;
            height: 17px;
            left: 0;
            margin-left: -20px;
            border: 1px solid #cccccc;
            border-radius: 50%;
            background-color: #fff;
            -webkit-transition: border 0.15s ease-in-out;
            -o-transition: border 0.15s ease-in-out;
            transition: border 0.15s ease-in-out;
        }

        .radio label::after {
            display: inline-block;
            position: absolute;
            content: " ";
            width: 11px;
            height: 11px;
            left: 3px;
            top: 3px;
            margin-left: -20px;
            border-radius: 50%;
            background-color: #555555;
            -webkit-transform: scale(0, 0);
            -ms-transform: scale(0, 0);
            -o-transform: scale(0, 0);
            transform: scale(0, 0);
            -webkit-transition: -webkit-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            -moz-transition: -moz-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            -o-transition: -o-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            transition: transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
        }

        .radio input[type="radio"] {
            opacity: 0;
        }

        .radio input[type="radio"]:focus + label::before {
            outline: thin dotted;
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px;
        }

        .radio input[type="radio"]:checked + label::after {
            -webkit-transform: scale(1, 1);
            -ms-transform: scale(1, 1);
            -o-transform: scale(1, 1);
            transform: scale(1, 1);
        }

        .radio input[type="radio"]:disabled + label {
            opacity: 0.65;
        }

        .radio input[type="radio"]:disabled + label::before {
            cursor: not-allowed;
        }

        .radio.radio-inline {
            margin-top: 0;
        }

        .radio-primary input[type="radio"] + label::after {
            background-color: #428bca !important;
        }

        .radio-primary input[type="radio"]:checked + label::before {
            border-color: #428bca;
        }

        .radio-primary input[type="radio"]:checked + label::after {
            background-color: #428bca !important;
        }

        /*    Edit Comment*/

        .accordion {
            /*    background-color: #eee;*/
            color: #444;
            cursor: pointer;
            padding: 18px;
            /*    width: 100%;*/
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        #issue_Submition_modal .panel {
            padding: 0 18px;
            margin-top: 1%;
            background-color: rgba(113, 92, 144, 0.1);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }

        .user-contact-form_field {
            margin: 0 0 8px;
            box-sizing: border-box;
        }

        .user-contact-form_field input,
        .user-contact-form_field textarea {
            font-size: 1em;
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #c1c1c1;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .user-contact-form_field textarea {
            width: 100%;
            max-width: 100%;
            min-width: 100%;
            min-height: 115px;
            margin-top: 3%;
        }

        .user-contact-form_field input:focus,
        .user-contact-form_field textarea:focus {
            border-color: #3e5e7e;
            outline: 0 solid transparent;
        }

        .user-contact-form_buttons {
            float: right;
        }

        .user-contact-form_buttons a {
            padding: 5px 10px;
            text-decoration: none;
            box-sizing: border-box;
            cursor: pointer;
        }

        .user-contact-form_buttons a.send-message {
            margin-left: 4px;
            float: left;
            background: #3e5e7e;
            border: 1px solid transparent;
            color: #fff;
        }

        .user-contact-form_buttons a.cancel-message {
            float: left;
            border: 1px solid rgba(0, 0, 0, 0.1);
            color: #fff;
            background-color: #f84d4d;
        }

        #issue_Submition_modal textarea {
            resize: none;
        }

        .form-control {
            border: 1px solid #e7e8e9;
        }

        .card {
            border: 1px solid rgba(84, 83, 83, 0.1);
        }

        .comment_align ul, ol {
            padding-left: 15px;
        }

        .comment_align ul {
            list-style-type: disc;
        }
    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Task Submission</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <a href="/manager/dashboard" style="cursor: pointer;"> <img src="/images/previous.png"
                                                                                    width="35px"></a>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card" style="margin: 0">
                        <div class="card-body" style="background: #fff;">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="row" style="margin-left: 0px;margin-right: 0px;">
                                        <div class="col-md-2">
                                            <label for="assigneeNames"
                                                   class=" form-control-label">Assignee</label>
                                        </div>
                                        <textarea id="assigneeNames" rows="1" name="name" type="text"
                                                  class="form-control col-md-10 assigneeNames"
                                                  style="word-break:break-word;" readonly>@if(count($data[0]['staffDetails']) > 0) {{implode(', ',$data[0]['staffDetails'])}} @else -- @endif</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <div class="col-lg-6" style="margin-bottom: 1rem;padding: 0;">
                                        <div class="col-lg-4">
                                            <label class="control-label" for="name">Due Date</label>
                                        </div>
                                        <input id="taskDueDate" name="name" value="@if($data[0]['dueDate'] != ""){{$data[0]['dueDate']}} @else -- @endif"
                                               class="form-control col-lg-6 taskDueDate" readonly>
                                    </div>
                                    <div class="col-lg-6" style="padding: 0">
                                        <div class="col-lg-6" style="text-align: right;
line-height: 2;">
                                            <label class="control-label" for="name">Due Hours</label>
                                        </div>
                                        <input id="taskDueHour" name="name" value="@if($data[0]['durHours'] != ""){{$data[0]['durHours']}} @else -- @endif"
                                               class="form-control col-lg-6 taskDueHour" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-2">
                                        <label for="select" class="form-control-label">Project</label>
                                    </div>
                                    <textarea id="projName" name="name" rows="1" type="text" value=""
                                              class="form-control col-md-10 projName"
                                              readonly>@if($data[0]['projectName'] != ""){{$data[0]['projectName']}} @else -- @endif</textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-2">
                                        <label class=" form-control-label"> Assigned Files</label>
                                    </div>
                                    <div class="assignedFilesData col-md-10">
                                        <p>
                                            <?php
                                            if (isset($data[0]['attachmentFiles'])){
                                            foreach ($data[0]['attachmentFiles'] as $v1){
                                            $split = explode('/', $v1);?>
                                            <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 5px"
                                               href='{{$v1}}'
                                               target="_blank" class="btn btn-info">
                                                <i class="fa fa-file-o" aria-hidden="true"></i>
                                                {{$split[6]}} <i class="fa fa-download" aria-hidden="true"></i>
                                            </a>
                                        <?php    }
                                        }else{?>
                                        <p class="text-info">
                                            No Files Has been Attached
                                        </p>
                                        <?php  }
                                        ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-2">
                                        <label class="control-label" for="name">Task Name</label>
                                    </div>
                                    <textarea id="taskName" name="name" rows="2" type="text" value=""
                                              class="form-control col-md-10 taskName"
                                              readonly>@if($data[0]['taskName'] != ""){{$data[0]['taskName']}} @else -- @endif</textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-2">
                                        <label for="textarea-input" class=" form-control-label">Task
                                            Description</label>
                                    </div>
                                    <textarea name="textarea-input" rows="9" id="textarea-input" readonly
                                              class="form-control col-md-10 taskDescription">@if($data[0]['taskDesc'] != ""){{$data[0]['taskDesc']}} @else --- @endif</textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-2">
                                        <label class=" form-control-label"> Copyscape Files</label>
                                    </div>
                                    <div class="allFilesData col-md-10">
                                        <?php
                                        if (isset($data[0]['taskAttachmentFiles'])){
                                        foreach ($data[0]['taskAttachmentFiles'] as $v1){
                                        if ($v1 != "") {
                                        $split = explode('/', $v1['file']);
                                        ?>
                                        <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 5px"
                                           href='{{$v1['file']}}'
                                           target="_blank" class="btn btn-info">
                                            <i class="fa fa-file-o" aria-hidden="true"></i>
                                            {{$split[5]}} <i class="fa fa-download" aria-hidden="true"></i>
                                        </a>
                                        <u><a style="color: purple" href='{{$v1['checkCopyscape']}}'
                                              target="_blank">
                                                Verified Url
                                            </a>
                                        </u>
                                        <?php   }else{?>
                                        <p class="text-info">
                                            No Files Has been Attached
                                        </p>
                                        <?php
                                        } }
                                        }else{?>
                                        <p class="text-info">
                                            No Files Has been Attached
                                        </p>
                                        <?php  }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-2">
                                        <label class=" form-control-label"> General Files</label>
                                    </div>
                                    <div class="allGeneralFilesData col-md-10">
                                        <?php
                                        if (isset($data[0]['allFiles'])){
                                        foreach ($data[0]['allFiles'] as $v1){
                                        $split = explode('/', $v1);?>
                                        <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 5px"
                                           href='{{$v1}}'
                                           target="_blank" class="btn btn-info">
                                            <i class="fa fa-file-o" aria-hidden="true"></i>
                                            {{$split[5]}} <i class="fa fa-download" aria-hidden="true"></i>
                                        </a>
                                        <?php    }
                                        }else{?>
                                        <p class="text-info">
                                            No Files Has been Attached
                                        </p>
                                        <?php  }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12" style="padding: 0;">
                                <div class="card widget comment_align">
                                    <div class="card-header">
                                        <i class="fa fa-commenting-o" aria-hidden="true"></i>

                                        <h5 class="panel-title">
                                            Recent Comments</h5>
                                        <span class="mesg" style="text-align:center;">(No Comments)</span>
                                        <span class="label label-info totalTaskComments"></span>
                                    </div>
                                    <div class="card-body">
                                        <div id="loaderClass" class="loaderClass hide" style="text-align: center">
                                            <img src="/images/cloud_loading.gif" style="width: 50px;">
                                        </div>
                                        <ul class="list-group appendTaskData" style="max-height: 600px;overflow: auto;">

                                        </ul>
                                        {{--<a class="btn btn-info btn-sm btn-block"--}}
                                        {{--role="button"><i class="fa fa-refresh"--}}
                                        {{--aria-hidden="true"></i>--}}
                                        {{--More</a>--}}
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12" style="border: 1px solid #dedddd;padding: 0;">
                                <div class="form-group">
                                    <div class="hero-unit">

                                        <div class="commentData" data-id="{{$data[0]['taskId']}}" id="editor"></div>
                                        <div class="btn-toolbar" data-role="editor-toolbar"
                                             data-target="#editor" style="width: 100%;">
                                            {{--<div class="btn-group">--}}
                                            {{--<a class="btn dropdown-toggle" data-toggle="dropdown"--}}
                                            {{--title="Font" ><i class="icon-font"></i><b--}}
                                            {{--class="caret"></b></a>--}}
                                            {{--<ul class="dropdown-menu" style="padding: 20px;">--}}
                                            {{--</ul>--}}
                                            {{--</div>--}}
                                            {{--<div class="btn-group">--}}
                                            {{--<a class="btn dropdown-toggle" data-toggle="dropdown"--}}
                                            {{--title="Font Size"><i--}}
                                            {{--class="icon-text-height"></i>&nbsp;<b--}}
                                            {{--class="caret"></b></a>--}}
                                            {{--<ul class="dropdown-menu">--}}
                                            {{--<li>--}}
                                            {{--<a data-edit="fontSize 5">--}}
                                            {{--<font size="5">Huge</font>--}}
                                            {{--</a>--}}
                                            {{--</li>--}}
                                            {{--<li>--}}
                                            {{--<a data-edit="fontSize 3">--}}
                                            {{--<font size="3">Normal</font>--}}
                                            {{--</a>--}}
                                            {{--</li>--}}
                                            {{--<li>--}}
                                            {{--<a data-edit="fontSize 1">--}}
                                            {{--<font size="1">Small</font>--}}
                                            {{--</a>--}}
                                            {{--</li>--}}
                                            {{--</ul>--}}
                                            {{--</div>--}}
                                            <div class="btn-group">
                                                <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i
                                                            class="icon-bold"></i></a>
                                                <a class="btn" data-edit="italic"
                                                   title="Italic (Ctrl/Cmd+I)"><i
                                                            class="icon-italic"></i></a>
                                                {{--<a class="btn" data-edit="strikethrough"--}}
                                                {{--title="Strikethrough"><i class="icon-strikethrough"></i></a>--}}
                                                <a class="btn" data-edit="underline"
                                                   title="Underline (Ctrl/Cmd+U)"><i
                                                            class="icon-underline"></i></a>
                                            </div>
                                            <div class="btn-group">
                                                <a class="btn" data-edit="insertunorderedlist" title=""
                                                   data-original-title="Bullet list"><i class="icon-list-ul"></i></a>
                                                <a class="btn" data-edit="insertorderedlist" title=""
                                                   data-original-title="Number list"><i class="icon-list-ol"></i></a>
                                                {{--<a class="btn" data-edit="outdent" title="" data-original-title="Reduce indent (Shift+Tab)"><i class="icon-indent-left"></i></a>--}}
                                                {{--<a class="btn" data-edit="indent" title="" data-original-title="Indent (Tab)"><i class="icon-indent-right"></i></a>--}}
                                            </div>
                                            {{--<div class="btn-group">--}}
                                            {{--<a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i--}}
                                            {{--class="icon-undo"></i></a>--}}
                                            {{--<a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i--}}
                                            {{--class="icon-repeat"></i></a>--}}
                                            {{--</div>--}}
                                            {{--<input type="text" data-edit="inserttext" id="voiceBtn"--}}
                                            {{--x-webkit-speech="">--}}
                                            <label for="attachmentTask" class="form__file"
                                                   style="width:5%;box-shadow: none;border: none;color: #000;">
                                                            <span class="form__file-filename" id="filename1"
                                                                  data-placeholder="Attach file"
                                                                  style="display: none;"></span>
                                                <span class="form__file-browse" style="opacity: 1;top: 10px;
right: 15px;"></span>
                                                <input type="file" name="taskCommentFile"
                                                       class="form__file-input"
                                                       id="attachmentTask">
                                            </label>


                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12" style="padding: 0;">
                                <ul class="form__files allFiles" id="attachment-filestask"></ul>
                            </div>
                            <div class="col-md-12">
                                <i class="fa fa-spinner fa-spin spinnerClass" style="position: absolute;
right: 4.5%;
top: 45%;color: #212121;display: none"></i>
                                <button class="btn btn-info comment_btn taskCommentBtn pull-right" data-id="{{$data[0]['taskId']}}">Comment
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- .animated -->
    </div>

    <div class="modal fade" id="confirmTaskCommentModal" style="z-index:9999;">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete This Comment? </p>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmTaskCmntBtn" style="padding: 8px 25px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
                {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>--}}
                {{--</div>--}}
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="/assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="/assets/js/lib/chart-js/chartjs-init.js"></script>
    <script>
        $(function () {
            function initToolbarBootstrapBindings() {
                var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'],
                    fontTarget = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts, function (idx, fontName) {
                    fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({container: 'body'});
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });

                $('[data-role=magic-overlay]').each(function () {
                    var overlay = $(this), target = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset = $('#editor').offset();
                    $('#voiceBtn').css('position', 'absolute').offset({
                        top: editorOffset.top,
                        left: editorOffset.left + $('#editor').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg = '';
                if (reason === 'unsupported-file-type') {
                    msg = "Unsupported format " + detail;
                }
                else {
                    console.log("error uploading file", reason, detail);
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings();
            $('#editor').wysiwyg({fileUploadError: showErrorAlert});
            window.prettyPrint && prettyPrint();
        });
    </script>

    {{--<!-- Bandana Codes... -->==========================================================================--}}
    <script>
        $(document).ready(function () {

            let id = window.location.href.split('/')[5];
            let allFiles = $('.allFiles');
            allFiles.empty('');
            $('.commentData').text("");
            $('.mesg').hide();

            $.ajax({
                url: "/manager/getTaskComment",
                type: "post",
                dataType: "json",
                data: {
                    taskId: id,
                },
                beforeSend: function () {
                    $("#loaderClass").show();
                },
                success: function (response) {
                    $("#loaderClass").hide();
                    if (response.status === 200) {
                        let commentData = response.commentData;
                        let data = '';
                        $('.totalTaskComments').text(commentData.length);

                        if (commentData.length > 0) {
                            $('.mesg').hide();
                            $.each(commentData, function (i, val) {
                                let name = '{{Session::get('co_manager')['name']}}';
                                if (val.commentBy.indexOf('_manager') !== -1) {
                                    data += '<li class="list-group-item commentClass' + val.task_comment_id + '"><div class="row">' +
                                        '<div class="col-xs-1 col-md-1"><img src="' + val.profilePic + '" class="img-circle img-responsive" width="65px" alt=""/>' +
                                        '<span style="color:black;font-size: 12px;margin-left: 4px;" title="' + name + '">' + name + '</span></div>' +
                                        '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                        'By: <a href="#">' + val.commentBy + '</a> on ' + getDateAndTime(val.commentPostedOn) + '</div></div>' +
                                        '<div class="comment-text" style="">' + val.comment + '</div>';
                                    if (val.attachment_files) {
                                        $.each(val.attachment_files, function (i, v) {
                                            data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                                '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[6] + '   <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                        });
                                    }
                                    data += '<div class="action">' +
                                        '<button type="button" class="btn btn-danger btn-xs deleteTaskComment" data-toggle="modal" data-target="#confirmTaskCommentModal" data-id="' + val.task_comment_id + '" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
                                        '<button type="button" class="btn btn-info btn-xs accordion editTaskComment" data-id="' + val.task_comment_id + '" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
                                        // '<div class="panel" style="max-height: 181px; display: none;">' +
                                        // '<div class="user-contact-form_field">' +
                                        // '<textarea name="message" id="commentTextarea' + val.task_comment_id + '">' + val.comment + '</textarea>\n' +
                                        // '</div>' +
                                        // '<div class="user-contact-form_buttons">' +
                                        // '<a class="cancel-message accordion cancelTaskBtn">Cancel</a>' +
                                        // '<a class="send-message accordion updateTaskComment" data-id=' + val.task_comment_id + '>Ok</a>' +
                                        // '</div></div>' +
                                        // '</div></div>' +
                                        '<div class="panel" style="max-height: 210px;display: none;">' +
                                        '<div class="user-contact-form_field"><div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">' +
                                        '<div class="form-group"><div class="hero-unit">' +
                                        '<div id="editor2" contenteditable="true" class="commentTextarea' + val.task_comment_id + ' editor2">' + val.comment + '</div>' +
                                        '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar2" data-target="#editor2" style="width: 100%;">' +
                                        '<div class="btn-group">' +
                                        '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="icon-bold"></i></a>' +
                                        '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="icon-italic"></i></a>' +
                                        '<a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>' +
                                        '</div>' +
                                        '<div class="btn-group">' +
                                        '<a class="btn" data-edit="insertunorderedlist" title=""\n' +
                                        'data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                        '<a class="btn" data-edit="insertorderedlist" title=""\n' +
                                        'data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                        '</div>' +
                                        '</div></div></div></div></div>' +
                                        '<div class="user-contact-form_buttons"><a class="cancel-message accordion cancelTaskBtn">Cancel</a>' +
                                        '<a class="send-message updateTaskComment" data-id=' + val.task_comment_id + '>Send</a></div></div>' +
                                        '</div></div>'+
                                        '</div></li>';
                                } else {
                                    data += '<li class="list-group-item commentClass' + val.task_comment_id + '"><div class="row">' +
                                        '<div class="col-xs-1 col-md-1"><img src="' + val.profilePic + '" class="img-circle img-responsive" width="65px" alt=""/>' +
                                        '<span class="custum_hide" style="color:black;font-size: 12px;margin-left: 4px;" title="' + val.commentBy + '">' + val.commentBy + '</span></div>' +
                                        '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                        'By: <a href="#">' + val.commentBy + '</a> on ' + getDateAndTime(val.commentPostedOn) + '</div></div>' +
                                        '<div class="comment-text" style="">' + val.comment + '</div>';
                                    if (val.attachment_files) {
                                        if (val.commentBy.indexOf('_user') !== -1) {
                                            $.each(val.attachment_files, function (i, v) {
                                                data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                                    '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + '   <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                            });
                                        }else{
                                            $.each(val.attachment_files, function (i, v) {
                                                data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                                    '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[6] + '   <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                            });
                                        }
                                    }
                                    data += '</div></div></li>';
                                }
                            });
                        } else {
                            $('.mesg').show();
                        }

                        $(document.body).on('click', '.editTaskComment', function () {
                            $('.editor2').wysiwyg({
                                toolbarSelector: '.editor-toolbar2'
                            });
                        });
                        $('.appendTaskData').html('').append(data).scrollTop(100000000000000000);
                    } else {
                        $('.totalTaskComments').text(0);
                    }
                }
            });

            let commentTaskData = new FormData();
            let count1 = 0;


            $('#attachmentTask').on('change', function (event) {
                var imageName = 'commentFiles' + ++count1;
                commentTaskData.append(imageName, $('input[name=taskCommentFile]')[0].files[0]);
                $('html, body').animate({
                    scrollTop: $('body').height()
                }, 800);

                var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

                // file not choosed
                if (typeof filename === 'undefined') {
                    return false;
                }


                var $file = $(this).closest('.form__file');
                $file
                    .addClass('form__file--attached')
                    .find('.form__file-filename')
                    .html(filename);

                $file
                    .find('.form__file-input')
                    .prop('disabled', true);

                // list of files
                var $files = $('#attachment-filestask');

                // show files list
                if ($files.find('li').length === 0) {
                    $files.removeClass('form__files--hide').addClass('form__files--show');
                }

                // create a new item
                var $item = $('<li/>')
                    .addClass('form__files-item')
                    .addClass('form__files-item--loading')
                    .append($('<span/>').addClass('form__files-item-link').html(filename))
                    .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                    .append($('<span/>').addClass('form__files-item-progress'))
                    .append($('<input/>').attr({
                        type: 'hidden',
                        name: 'attachments[]',
                        value: '{}'
                    }));

                $files.append($item);

                // progress bar
                $item.find('.form__files-item-progress').animate({
                    width: '100%'
                }, 2000);

                $('#attachment-filestask').trigger('contentChanged');

                setTimeout(function () {
                    $file.removeClass('form__file--attached');

                    $file
                        .find('.form__file-input')
                        .prop('disabled', false);

                    var v = $file.find('.form__file-filename').data('placeholder');
                    $file.find('.form__file-filename').html(v);
                    $file.find('.form__file-input').val('');

                    $item
                        .removeClass('form__files-item--loading')
                        .addClass('form__files-item--done');

                    $item.find('.form__files-item-link').replaceWith(function () {
                        var text = $.trim($(this).text());
                        return $('<a/>').attr({
                            href: '#',
                            target: '_blank'
                        }).addClass('form__files-item-link').html(text);
                    });

                    var _itemData = JSON.stringify({
                        id: uuidv4(),
                        // file: textFile,
                        name: filename,
                        url_view: '',
                        url_delete: ''
                    }, null, '');

                    $item
                        .find('input[type=hidden]')
                        .val(_itemData);

                    console.log('File uploaded: ', JSON.parse(_itemData));

                    $item.find('[data-file-remove=true]').on('click', function () {
                        var imageName = $(this).attr('imageName');
                        commentTaskData.delete(imageName);
                        var $removeItem = $(this).closest('.form__files-item'),
                            itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                        // ajax request
                        console.log('File deleted: ', itemData.id);

                        $removeItem.addClass('form__files-item--hide');

                        // hide files list
                        if ($files.find('li').length <= 1) {
                            $files.removeClass('form__files--show').addClass('form__files--hide');
                        }

                        $('#attachment-filestask').trigger('contentChanged');

                        setTimeout(function () {
                            $removeItem.remove();
                        }, 500);

                    });
                }, 2000);
            });
            $('#attachment-filestask').on('contentChanged', function () {
                console.log(1);
                console.log(this);
                console.log($('li', this).length);

                // $(this).each(function() {
                //   if ($(this).length <= 1) {
                //     $(this).removeClass('form__files--show').addClass('form__files--hide');
                //   }
                // });
            });

            $(document.body).on('click', '.taskCommentBtn', function () {
                let text = $('.commentData');
                if (text.html() === "") {
                    toastr.error("Please write a comment!");
                    text.focus();
                } else if (text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === " " || text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                    toastr.error("Please type a message to send!");
                } else {
                    let comment = text.html();
                    if ($(".allFiles > li").length > 0) {
                        commentTaskData.append('comment', comment);
                        commentTaskData.append('taskId', $(this).attr('data-id'));
                        commentTaskData.append('chooseMethod', 'insertTaskComment');
                        ajaxHandletData(commentTaskData, comment, text);
                    } else {
                        let formDataTask = new FormData();
                        formDataTask.append('comment', comment);
                        formDataTask.append('taskId', $(this).attr('data-id'));
                        formDataTask.append('chooseMethod', 'insertTaskComment');
                        ajaxHandletData(formDataTask, comment, text);
                    }
                }
            });

            function ajaxHandletData(formData, comment, text) {
                $.ajax({
                    url: "/manager/insertCommentAjaxhandler",
                    type: "post",
                    dataType: "json",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function () {
                        // $('.taskCommentBtn').attr('disabled', 'disabled');
                        $('.commentData').html('');
                        $('.spinnerClass').css('display','block');
                        $('.taskCommentBtn').css('opacity','0.4');
                    },
                    success: function (response) {
                        $('.spinnerClass').css('display','none');
                        $('.taskCommentBtn').css('opacity','');
                        // $('.taskCommentBtn').attr('disabled', false);
                        $('#attachment-filestask').removeClass('form__files--show').addClass('form__files--hide');
                        if (response.status === 200) {
                            $.each(response.file, function (i, v) {
                                commentTaskData.delete('commentFiles' + (i + 1));
                                count1 = 0;
                            });
                            let data = '';
                            let profilePic = '{{Session::get('co_manager')['profile_pic']}}' ? '{{Session::get('co_manager')['profile_pic']}}' : '/images/default.png';
                            let name = '{{Session::get('co_manager')['name']}}';
                            data = '<li class="list-group-item commentClass' + response.id + '"><div class="row">' +
                                '<div class="col-xs-1 col-md-1"><img src="' + profilePic + '" class="img-circle img-responsive" width="65px" alt=""/>' +
                                '<span style="color:black;font-size: 12px;margin-left: 4px;" title="' + name + '">' + name + '</span></div>' +
                                '<div class="col-xs-10 col-md-10">' +
                                '<div><div class="mic-info">By: <a href="#">' + name + '_manager</a> on ' + getDateAndTime(response.data) + '</div></div>' +
                                '<div class="comment-text" style="">' + comment.replace(/&nbsp;/g, '') + '</div>';
                            $.each(response.file, function (i, v) {
                                data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                    '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[6] + '   <i class="fa fa-download" aria-hidden="true"></i></a><p>';
                            });
                            data += '<div class="action">' +
                                '<button type="button" class="btn btn-danger btn-xs deleteTaskComment" aria-hidden="true" data-dismiss="modal" data-toggle="modal" data-target="#confirmTaskCommentModal" data-id="' + response.id + '" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
                                '<button type="button" class="btn btn-info btn-xs accordion editTaskComment" data-id="' + response.id + '"  title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
                                '<div class="panel" style="max-height: 210px;display: none;">' +
                                '<div class="user-contact-form_field"><div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">' +
                                '<div class="form-group"><div class="hero-unit">' +
                                '<div id="editor2" contenteditable="true" class="commentTextarea' + response.id + ' editor2">' + comment + '</div>' +
                                '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar1" data-target="#editor2" style="width: 100%;">' +
                                '<div class="btn-group">' +
                                '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="icon-bold"></i></a>' +
                                '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="icon-italic"></i></a>' +
                                '<a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>' +
                                '</div>' +
                                '<div class="btn-group">' +
                                '<a class="btn" data-edit="insertunorderedlist" title=""\n' +
                                'data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                '<a class="btn" data-edit="insertorderedlist" title=""\n' +
                                'data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                '</div>' +
                                '</div></div></div></div></div>' +
                                '<div class="user-contact-form_buttons"><a class="cancel-message accordion cancelTaskBtn">Cancel</a>' +
                                '<a class="send-message updateTaskComment" data-id=' + response.id + '>Send</a></div></div>' +
                                '</div></div>'+
                                '</div></li>';
                            $('.appendTaskData').append(data).scrollTop(100000000000000000);
                            $('.totalTaskComments').text($(".appendTaskData > li").length);
                            text.html("");
                            $(".allFiles").empty('');
                            $('.mesg').hide();
                        }
                    }
                });
            }

            $(document.body).on('click', '.deleteTaskComment', function () {
                $('.confirmTaskCmntBtn').attr('data-id', $(this).attr('data-id'));
            });

            $(document.body).on('click', '.confirmTaskCmntBtn', function () {
                let id = $(this).attr('data-id');
                $.ajax({
                    url: "/manager/deleteDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'deleteTaskComment',
                        taskCommentId: id
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmTaskCommentModal').modal('hide');
                            $('.commentClass' + id).remove();
                            $('.totalTaskComments').text($(".appendTaskData > li").length);
                            toastr.success(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('click', '.updateTaskComment', function (e) {
                e.preventDefault();
                let id = $(this).attr('data-id');
                let comment = $('.commentTextarea' + id);
                if (comment.html() === "") {
                    toastr.error('Please Type a message to send!');
                }else if (comment.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                    toastr.error("Please type a message to send!");
                } else {
                    let commentData = comment.html();
                    $.ajax({
                        url: "/manager/updateComment",
                        type: "post",
                        dataType: "json",
                        data: {
                            taskCommentId: $(this).attr('data-id'),
                            comment: commentData
                        },
                        success: function (response) {
                            if (response.status === 200) {
                                let data = '<div class="comment-text">' + commentData + '</div>';
                                $('.commentClass' + id).find('.comment-text').html('').append(data);
                                $('.updateTaskComment').parent().parent().removeClass('show').css('display', 'none');
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.accordion', function () {
                let obj = $('.appendTaskData');
                if (obj.find('li.list-group-item').last().attr('class') === $(this).last().parents().eq(3).attr('class')) {
                    obj.animate({scrollTop: obj.prop("scrollHeight")}, 500);
                }
                // $(this).parents('.action').find('.panel').toggle();
                // $('.appendTaskData').scrollTop(100000000000000000);
                $('.commentTextarea' + $(this).attr('data-id')).html($('.commentClass' + $(this).attr('data-id')).find('.comment-text').html());
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active');
                    $(this).next().removeClass('show').css('display', 'none');
                } else {
                    $('.accordion').removeClass('active');
                    $('.panel').removeClass('show').css('display', 'none');
                    $(this).addClass('active');
                    $(this).next().addClass('show').css('display', 'block')
                }
            });

            function getDateAndTime(getDate) {
                let date = new Date(getDate * 1000);
                let month = date.getMonth() + 1;
                let day = date.getDate();
                let hour = date.getHours();
                let min = date.getMinutes();
                let sec = date.getSeconds();

                month = (month < 10 ? "0" : "") + month;
                day = (day < 10 ? "0" : "") + day;
                hour = (hour < 10 ? "0" : "") + hour;
                min = (min < 10 ? "0" : "") + min;
                sec = (sec < 10 ? "0" : "") + sec;

                let str = date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

                return str;
            }
        });
    </script>
@endsection