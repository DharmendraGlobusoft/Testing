<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/managerAssets/css/normalize.css">
    <link rel="stylesheet" href="/managerAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/managerAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/managerAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/managerAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/managerAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/managerAssets/scss/style.css">
    <link rel="stylesheet" href="/managerAssets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .errSpan {
            float: right;
            margin-right: 6px;
            margin-top: -31px;
            position: relative;
            z-index: 2;
            color: red;
        }

        .focused {
            border: solid 1px red;
        }

        .popover1 {
            /*border: 2px dotted deepskyblue;*/
            font-size: 12px;
            text-align: center;
            font-weight: bold;
            color: dodgerblue;
        }

        /* Popover Header */
        .popover-title {
            background-color: #73AD21;
            color: #FFFFFF;
            font-size: 28px;
            text-align: center;
        }

        /* Popover Body */
        .popover-content {
            background-color: coral;
            color: #FFFFFF;
            padding: 25px;
        }

    </style>
</head>

<body class="bg-dark" style="background-image: url(/images/bg6.jpg);">
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a>
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>

            @if(Session::has('message'))
                @if(session('status')=='Success')
                    <div id="card-alert" class="card green">
                        <div class="card-content white-text">
                            <p><i class="mdi-navigation-check"></i>{{session('status')}} : {{Session::get('message')}}
                            </p>
                        </div>
                        <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>


                @endif
                @if(session('status')=='Error')
                    <div id="card-alert" class="card red">
                        <div class="card-content white-text">
                            <p><i class="mdi-navigation-check"></i>{{session('status')}} : {{Session::get('message')}}
                            </p>
                        </div>
                        <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                @endif
            @endif

            <div class="login-form">
                <form>
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Sign Up</h4>
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Name">
                        <i class="fa fa fa-exclamation-circle errSpan errName"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover1" data-content=""></i>
                    </div>
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text" name="username" id="username" class="form-control" placeholder="User Name">
                        <i class="fa fa fa-exclamation-circle errSpan errUsername"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover2" data-content=""></i>
                    </div>
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" name="email" id="email" class="form-control" placeholder="Email"
                               value="{{isset($email) ? $email : ''}}" readonly>
                        <i class="fa fa fa-exclamation-circle errSpan errEmail"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover3" data-content=""></i>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" id="password" class="form-control"
                               placeholder="Password">
                        <i class="fa fa fa-exclamation-circle errSpan errPwd"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover4" data-content=""></i>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" name="cpassword" id="cpassword" class="form-control"
                               placeholder="Confirm Password">
                        <i class="fa fa fa-exclamation-circle errSpan errCPwd"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover5" data-content=""></i>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" id="checkBox"> Agree the terms and policy
                        </label>
                    </div>
                    <button type="button" class="btn btn-primary btn-flat m-b-30 m-t-30 registerBtn"
                            style="margin: 3% 0;">Register
                    </button>

                    <div class="register-link m-t-15 text-center">
                        <p>Already have account ? <a href="/manager/sign-in"> Sign in</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>

<script src="/managerAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/managerAssets/js/popper.min.js"></script>
<script src="/managerAssets/js/plugins.js"></script>
<script src="/managerAssets/js/main.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

<script src="/managerAssets/js/toastr/toastr.min.js"></script>
<script>
    $(document).ready(function (e) {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    $(document).ready(function () {

        $('[data-toggle="popover1"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Provide Valid Name Which Accepts Only Alphabets.'
        }); $('[data-toggle="popover2"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Valid Username which accepts only special character "_".'
        }); $('[data-toggle="popover3"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please provide a valid email.'
        }); $('[data-toggle="popover4"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please provide a valid Password which accepts atleast one special character,numbers and alphabets.'
        }); $('[data-toggle="popover5"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Confirm password same as New password!'
        });


        let username, email, password, cpassword, name, status;
        let validateForm = function () {
            if (!(name.match(/^[a-zA-Z \\s]{2,20}$/))) {
                // toastr.error('<b>Please Provide Valid Name Which Accepts Only Alphabets.</b>', {timeOut: 5000});
                $('.errName').css('display', 'block');
                $('#name').addClass("focused");
                return false;
            } else if (!(username.match(/^[a-zA-Z0-9.\-_$*!]{3,30}$/))) {
                // toastr.error('<b>Please enter the valid username.</b>', {timeOut: 5000});
                $('.errUsername').css('display', 'block');
                $('#username').addClass("focused");
                return false;
            } else if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                // toastr.error('<b>Please provide a valid email.</b>', {timeOut: 5000});
                $('.errEmail').css('display', 'block');
                $('#email').addClass("focused");
                return false;
            } else if (!(password.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                // toastr.error('<b>Please provide a valid Passwors which accepts atleast one special character,numbers and alphabets.</b>', {timeOut: 5000});
                $('.errPwd').css('display', 'block');
                $('#password').addClass("focused");
                return false;
            } else if (!(cpassword.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                // toastr.error('<b>Please provide a valid Passwors which accepts atleast one special character,numbers and alphabets.</b>', {timeOut: 5000});
                $('.errCPwd').css('display', 'block');
                $('#cpassword').addClass("focused");
                return false;
            } else if (!($('#checkBox').is(":checked"))) {
                toastr.error('<b>please check the terms and condition.</b>', {timeOut: 5000});
                return false;
            } else {
                return true;
            }
        };

        $(document.body).on('keyup', '#name', function () {
            $('.errName').css('display', 'none');
        });
        $(document.body).on('keyup', '#username', function () {
            $('.errUsername').css('display', 'none');
        });
        $(document.body).on('keyup', '#email', function () {
            $('.errEmail').css('display', 'none');
        });
        $(document.body).on('keyup', '#password', function () {
            $('.errPwd').css('display', 'none');
        });
        $(document.body).on('keyup', '#cpassword', function () {
            $('.errCPwd').css('display', 'none');
        });

        $('#name,#username,#email,#password,#cpassword').blur(function () {
            $(this).removeClass("focused");
        });

        $(document.body).on('click', '.registerBtn', function (e) {
            let token = window.location.href.split('/')[5];
            name = $('#name').val();
            username = $('#username').val();
            email = $('#email').val();
            password = $('#password').val();
            cpassword = $('#cpassword').val();

            let validateData = validateForm();
            e.preventDefault();
                if (validateData === true) {
                    if (password !== cpassword) {
                        $('.errCPwd').css('display', 'block');
                        $('#cpassword').addClass("focused");
                    } else {
                        $.ajax({
                            url: "/manager/sign-up/" + token,
                            type: "post",
                            dataType: "json",
                            data: {
                                name: name,
                                username: username,
                                email: email,
                                password: password,
                                cpassword: cpassword
                            },
                            success: function (response) {
                                if (response.status === 200) {
                                    toastr.success(response.message, {timeOut: 5000});
                                    window.setTimeout(function () {
                                        window.location.href = '/manager/sign-in';
                                    }, 3000)
                                } else if (response.status === 401) {
                                    $('.errEmail').css('display', 'block');
                                    $('#email').addClass("focused").val('');
                                    toastr.error(response.message, {timeOut: 3000});
                                }else if (response.status === 402) {
                                    $('.errUsername').css('display', 'block');
                                    $('#username').addClass("focused");
                                    toastr.error(response.message, {timeOut: 3000});
                                }else {
                                    toastr.error(response.message, {timeOut: 5000});
                                }
                            }
                        });
                    }
                }
        });
    });
</script>

</html>