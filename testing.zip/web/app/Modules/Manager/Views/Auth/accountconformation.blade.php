<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office, Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="/managerAssets/css/normalize.css">
    <link rel="stylesheet" href="/managerAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/managerAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/managerAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/managerAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/managerAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/managerAssets/scss/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/managerAssets/css/index.css">
</head>
<body>

{{--<body class="bg-dark" style="background-image: url(/images/bg6.jpg);">--}}
<div id="right-panel" class="right-panel">
    <!-- Header-->
    <header id="header" class="header" style="background-color: #222;">
        <div class="header-menu">
            <div class="col-sm-7">
                <div class="header-left">
                    <img src="/images/logo4.png" width="30%">
                </div>
            </div>
            <div class="col-sm-5" style="margin-top:1%;">
                <a type="button" href="/manager/sign-in" class="btn btn-info pull-right" style="padding:5px 20px !important;">Login</a>
            </div>
        </div>
    </header>
    <div class="mt-3">
        <div class="animated fadeIn" style="text-align: center;">

            <div class="col-lg-6 offset-lg-3" style="margin-top:10%;">

                    <span id="message"></span>

            </div>
        </div>
    </div>
</div>
<script src="/managerAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/managerAssets/js/plugins.js"></script>
<script>
    let userData = $.parseJSON('<?php echo isset($data) ? json_encode($data) : []; ?>');
    if (userData.code === 200) {
        $('#message').append('<h1 style="color:green;">' + userData.message + '</h1>');
    } else {
        $('#message').append('<h1 style="color:red;">' + userData.message + '</h1>');
    }

</script>
</body>

</html>
