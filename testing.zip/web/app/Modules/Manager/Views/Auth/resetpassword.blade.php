<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/managerAssets/css/normalize.css">
    <link rel="stylesheet" href="/managerAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/managerAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/managerAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/managerAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/managerAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/managerAssets/scss/style.css">
    <link rel="stylesheet" href="/managerAssets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .errSpan {
            float: right;
            margin-right: 6px;
            margin-top: -31px;
            position: relative;
            z-index: 2;
            color: red;
        }
    </style>
</head>

<body class="bg-dark" style="background-image: url(/images/cloudbg5.png);">

<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a>
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form">
                <form>
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Reset Password</h4>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="text" name="newpassword" id="newpassword" class="form-control"
                               placeholder="New Password">
                        <i class="fa fa fa-exclamation-circle errSpan errNPwd"
                           style="font-size:25px;color:red;display: none"></i>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" name="confirmpassword" id="confirmpassword" class="form-control"
                               placeholder="Confirm Password">
                        <i class="fa fa fa-exclamation-circle errSpan errCPwd"
                           style="font-size:25px;color:red;display: none"></i>
                    </div>
                    <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30 resetPwdBtn"
                            style="margin: 3% 0;">Sign in
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="/managerAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/managerAssets/js/popper.min.js"></script>
<script src="/managerAssets/js/plugins.js"></script>
<script src="/managerAssets/js/main.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="/managerAssets/js/toastr/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    $(document).ready(function () {
        let newPassword, confirmPassword;
        let resetPwdValidation = function () {
            if (!(newPassword.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                toastr.error('<b>Please Enter valid new Password which accept atleast one special char with number.</b>', {timeOut: 2000});
                $('.errNPwd').css('display', 'block');
                return false;
            } else if (!(confirmPassword.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/))) {
                toastr.error('<b>Please Enter valid Confirm Password which accept atleast one special char with number..</b>', {timeOut: 2000});
                $('.errCPwd').css('display', 'block');
                return false;
            } else {
                return true;
            }
        };

        $(document.body).on('keyup', '#newpassword', function () {
            $('.errNPwd').css('display', 'none');
        });
        $(document.body).on('keyup', '#confirmpassword', function () {
            $('.errCPwd').css('display', 'none');
        });

        $(document.body).on('click', '.resetPwdBtn', function (e) {
            e.preventDefault();
            let token = window.location.href.split('/')[5];
            newPassword = $('#newpassword').val();
            confirmPassword = $('#confirmpassword').val();
            if (newPassword === '' && confirmPassword === '') {
                toastr.error('Please Enter Your New Password and Confirm Password', {timeOut: 3000});
                $('.errNPwd').css('display', 'block');
                $('.errCPwd').css('display', 'block');
            } else {
                let validateData = resetPwdValidation();
                if (validateData === true) {
                    if (confirmPassword !== newPassword) {
                        let message = 'Please Enter Confirm password same as New password!';
                        toastr.error(message, {timeOut: 3000});
                        $('.errCPwd').css('display', 'block');
                    } else {
                        $.ajax({
                            url: "/manager/reset-password",
                            type: "post",
                            dataType: "json",
                            data: {
                                newPassword: newPassword,
                                confirmPassword: confirmPassword,
                                token: token
                            },
                            success: function (response) {
                                if (response.status === 200) {
                                    toastr.success(response.message, {timeOut: 3000});
                                    setTimeout(function () {
                                        window.location.href = '/manager/sign-in';
                                    }, 3000);
                                } else if (response.status === 401) {
                                    $('.errNPwd').css('display', 'block');
                                    $('.errCPwd').css('display', 'block');
                                    $('#newpassword').val('');
                                    $('#confirmpassword').val('');
                                    toastr.error(response.message, {timeOut: 3000});
                                } else {
                                    toastr.error(response.message, {timeOut: 3000});
                                }
                            }
                        });
                    }
                }
            }
        });
    });
</script>
</body>

</html>