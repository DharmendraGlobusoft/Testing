<?php

Route::group(['module' => 'Admin', 'middleware' => ['web'], 'namespace' => 'App\Modules\Admin\Controllers'], function () {

    Route::post('/sendInvitationLink', 'AdminController@sendInvitationLink');

//    Route::get('/admin/register', 'AdminController@register');
//    Route::post('/admin/register', 'AdminController@register');

    Route::get('/admin/login', 'AdminController@login');
    Route::post('/admin/login', 'AdminController@login');

    Route::get('/setSessionData', 'AdminController@setSessionData');
    Route::get('/getSessionData', 'AdminController@getSessionData');

    Route::get('/admin/forgot-password', 'AdminController@forgotPassword');
    Route::post('/admin/forgot-password', 'AdminController@forgotPassword');

    Route::get('/admin/reset-password/{token}', 'AdminController@resetPassword');
    Route::post('/admin/reset-password', 'AdminController@resetPassword');

    Route::get('/admin/logout', 'AdminController@logout');

    Route::get('/cronForTaskOverdue', 'DashboardController@cronForTaskOverdue');
    Route::get('/cronForIssueOverdue', 'DashboardController@cronForIssueOverdue');

    Route::group(['middleware' => 'CheckSession:admin'], function () {

        Route::get('/admin/dashboard', 'DashboardController@dashboard');

        Route::get('/admin/account-setting-page', 'AdminController@accountSetting');
        Route::post('/updateProfileAjaxHandler', 'AdminController@updateProfileAjaxHandler');
        Route::post('/checkOldPassowordExist', 'AdminController@checkOldPassowordExist');
        Route::post('/checkExistEmail', 'AdminController@checkExistEmail');
        Route::post('/setSession','AdminController@setSession');

//        ===================================== Task ANd Issue Routes =================================
        Route::post('/insertTaskDetails', 'DashboardController@insertTaskDetails');
        Route::post('/insertIssueDetails', 'DashboardController@insertIssueDetails');
        Route::post('/insertMilestoneDetails', 'DashboardController@insertMilestoneDetails');
        Route::get('/taskInfoAjaxHandler', 'DashboardController@taskInfoAjaxHandler');
        Route::get('/issueInfoAjaxHandler', 'DashboardController@issueInfoAjaxHandler');
        Route::get('/milestoneDataAjaxHandler', 'DashboardController@milestoneDataAjaxHandler');
        Route::post('/fetchDataAjaxHandler', 'DashboardController@fetchDataAjaxHandler');
        Route::post('/updateIssueData', 'DashboardController@updateIssueData');
        Route::post('/updateTaskData', 'DashboardController@updateTaskData');
        Route::post('/updateMilestoneData', 'DashboardController@updateMilestoneData');
        Route::post('/insertCommentAjaxhandler', 'DashboardController@insertCommentAjaxhandler');
        Route::post('/deleteDataAjaxHandler', 'DashboardController@deleteDataAjaxHandler');
        Route::post('/updateComment', 'DashboardController@updateComment');
        Route::post('/updateIssueComment', 'DashboardController@updateIssueComment');
        Route::post('/updateAjaxHandler', 'DashboardController@updateAjaxHandler');
        Route::post('/getAllCountInChart', 'DashboardController@getAllCountInChart');
        Route::post('/getStaffs', 'DashboardController@getStaffs');
        Route::post('/getComment', 'DashboardController@getComment');
        Route::post('/getTaskComment', 'DashboardController@getTaskComment');
        Route::post('/checkOverdueAjaxHandler', 'DashboardController@checkOverdueAjaxHandler');
        Route::post('/filteringOfTaskAjaxHandler', 'DashboardController@filteringOfTaskAjaxHandler');
        Route::post('/filteringOfIssueAjaxHandler', 'DashboardController@filteringOfIssueAjaxHandler');
        Route::get('/admin/task-submission/{id}', 'DashboardController@taskSubmission');
        Route::get('/admin/issue-submission/{id}', 'DashboardController@issueSubmission');

//        ================================== Project Routes =============================================
        Route::get('/admin/projects-info', 'ProjectController@projectsInfo');
        Route::get('/projectInfoAjaxHandler', 'ProjectController@projectInfoAjaxHandler');
        Route::post('/addProjectPage', 'ProjectController@addProjectPage');
        Route::post('/editProjectAjaxHandler', 'ProjectController@editProjectAjaxHandler');
        Route::post('/updateProjectDetails', 'ProjectController@updateProjectDetails');
        Route::post('/fetchProDataAjaxHandler', 'ProjectController@fetchProDataAjaxHandler');
        Route::post('/deleteProjectAjaxHandler', 'ProjectController@deleteProjectAjaxHandler');
        Route::get('/filteringOfDataAjaxHandler', 'ProjectController@filteringOfDataAjaxHandler');

//        ==================================== support ticket Routes =====================================
        Route::get('/admin/support-list', 'SupportTicketController@supportlist');
        Route::get('/admin/support-list/{id}', 'SupportTicketController@supportlist');
        Route::get('/ticketsInfoAjaxHandler', 'SupportTicketController@ticketsInfoAjaxHandler');
        Route::post('/addNewTicket', 'SupportTicketController@addNewTicket');
        Route::post('/updateStatusOfTicket', 'SupportTicketController@updateStatusOfTicket');
        Route::post('/fetchTicketReply', 'SupportTicketController@fetchTicketReply');
        Route::post('/sendReplyForTicket', 'SupportTicketController@sendReplyForTicket');
        Route::get('/view-queries', 'SupportTicketController@viewQueries');
        Route::post('/filteringOfSupportAjaxHandler', 'SupportTicketController@filteringOfSupportAjaxHandler');

//        ===================================== staff list routes  =================================
        Route::get('/admin/staff-list-details', 'StaffListController@staffListDetails');
        Route::get('/rating', 'StaffListController@ratingFun');
        Route::get('/staffListInfoAjaxHandler', 'StaffListController@staffListInfoAjaxHandler');
        Route::get('/allTaskOfStaffAjaxHandler', 'StaffListController@allTaskOfStaffAjaxHandler');
        Route::get('/allIssueOfStaffAjaxHandler', 'StaffListController@allIssueOfStaffAjaxHandler');
        Route::get('/projectTaskOfAjaxHandler', 'StaffListController@projectTaskOfAjaxHandler');
        Route::get('/projectIssueOfAjaxHandler', 'StaffListController@projectIssueOfAjaxHandler');
        Route::post('/updateDataAjaxHandler', 'StaffListController@updateDataAjaxHandler');
        Route::post('/getProjectDetailsOfStaff', 'StaffListController@getProjectDetailsOfStaff');
        Route::post('/fetchUserInfo', 'StaffListController@fetchUserInfo');

//        ====================================== message page routes ===============================
        Route::get('/admin/message-page', 'MessageController@messagePage');
        Route::get('/admin/message-page/{sid}/{rid}', 'MessageController@messagePage');
        Route::get('/messageDataAjaxHandler', 'MessageController@messageDataAjaxHandler');
        Route::post('/insertMessageData', 'MessageController@insertMessageData');
        Route::post('/fetchAllMessage', 'MessageController@fetchAllMessage');
        Route::post('/fetchLatestMessage', 'MessageController@fetchLatestMessage');
        Route::post('/sendMessage', 'MessageController@sendMessage');
        Route::post('/filteringOfMessageAjaxHandler', 'MessageController@filteringOfMessageAjaxHandler');

//        ========================================= invoice routes =====================================
        Route::get('/admin/invoice', 'InvoiceController@payments');
        Route::get('/invoiceDataAjaxHandler', 'InvoiceController@invoiceDataAjaxHandler');
        Route::post('/fetchFile', 'InvoiceController@fetchFile');
        Route::post('/insertInvoiceComment', 'InvoiceController@insertInvoiceComment');
        Route::post('/fetchInvoiceData', 'InvoiceController@fetchInvoiceData');
        Route::post('/deleteInvoiceData', 'InvoiceController@deleteInvoiceData');
        Route::post('/updateInvoiceData', 'InvoiceController@updateInvoiceData');
        Route::post('/updateInvoiceComment', 'InvoiceController@updateInvoiceComment');
        Route::post('/getInvoiceComment', 'InvoiceController@getInvoiceComment');
        Route::post('/sendTransationId', 'InvoiceController@sendTransationId');
        Route::get('/admin/invoice-comment/{id}', 'InvoiceController@invoiceComment');
        Route::post('/filteringOfInvoiceAjaxHandler', 'InvoiceController@filteringOfInvoiceAjaxHandler');

//        ========================================== Resource pages Routes  ================================
        Route::get('/admin/resource-page', 'ResourceController@resourcePage');
        Route::get('/admin/add-resource-page', 'ResourceController@addResourcePage');
        Route::get('/admin/view-resource-page/{id}', 'ResourceController@showMoreResources');
        Route::post('/insertResourceData', 'ResourceController@insertResourceData');
        Route::get('/admin/edit-resource/{id}', 'ResourceController@editResource');
        Route::post('/editResourceData', 'ResourceController@editResourceData');
        Route::post('/deleteResource', 'ResourceController@deleteResource');
        Route::post('/getContents', 'ResourceController@getContents');
        Route::post('/getMoreContents', 'ResourceController@getMoreContents');


        Route::get('/admin/feed','NotificationController@feedPage');
        Route::post('/fetchNotificationData','NotificationController@fetchNotificationData');
        Route::post('/getTotalNotiifcation','NotificationController@getTotalNotiifcation');


    });

});
