<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 6/4/2018
 * Time: 6:49 PM
 * Bandana Sahu<bandanasahu@globussoft.in>
 */
namespace App\Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class InviteLink extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-June-2018
     * @used AdminController
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-June-2018
     * @used AdminController
     */
    protected $tableName = 'invite_links';

    /**
     * @return InviteLink|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-June-2018
     * @used AdminController
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new InviteLink();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-June-2018
     * @used AdminController
     */
    public function insertInvitaionData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

}