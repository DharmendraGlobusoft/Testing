<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 4/19/2018
 * Time: 5:27 PM
 */

namespace App\Modules\Admin\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class SupportTickets extends Model
{
    /**
     * @var null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     * @used SupportTicketController
     */
    protected static $_instance = null;

    /**
     * @var string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     * @used SupportTicketController
     */
    protected $tableName = 'support_tickets';

    /**
     * @return SupportTickets|null
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     * @used SupportTicketController
     */
    public static function getInstance()
    {
        if (!is_object(self::$_instance))
            self::$_instance = new SupportTickets();
        return self::$_instance;
    }

    /**
     * @param $data
     * @return array|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     * @used SupportTicketController
     */
    public function insertTicketData($data)
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->insertGetId($data);
                return $result ? $result : [];
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param array $data
     * @return \Illuminate\Support\Collection|int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     * @used SupportTicketController
     */
    public function fetchAllTicketData($data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function getTicketDetails($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->select($data)
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    /**
     * @param $where
     * @param array $data
     * @return int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     * @used SupportTicketController
     */
    public function updateTIcket($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }
}