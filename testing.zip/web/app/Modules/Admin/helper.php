<?php

/**
 *    Admin Helper
 */


if (!function_exists('uploadImageToStoragePath')) {
    /**
     * Upload image to storage path
     * @param $image
     * @param null $folderName Folder name (mainFolder_subFolder_subSubFolder)
     * @param null $fileName
     * @param int $imageWidth
     * @param int $imageHeight
     * @return bool|string
     * @author Bandana Sahu
     * @since 16th-Apr-2018
     */
    function uploadImageToStoragePath($image, $folderName = null, $fileName = null, $imageWidth = 1024, $imageHeight = 1024)
    {
//        $destinationFolder = 'adminuploads/files/';
        $destinationFolder = $folderName;
        if ($folderName != '') {
            $folderNames = explode('_', $folderName);
            $folderPath = implode('/', array_map(function ($value) {
                return $value;
            }, $folderNames));
//            $destinationFolder .= $folderPath . '/';
            $destinationFolder = $folderPath . '/';
        }
        $destinationPath = public_path($destinationFolder);
        if (!File::exists($destinationPath)) File::makeDirectory($destinationPath, 0777, true, true);
        $filename = ($fileName != '') ? $fileName : $folderName . '_' . time() . '.txt';

        //for file upload
        if($image) $image->move($destinationPath,$filename);
        return $filename;

        //for image upload
//        $imageResult = Image::make($image);
//        $imageResult = Image::make($image)->resize($imageWidth, $imageHeight, function ($constraint) {
//            $constraint->aspectRatio();
//        })->save($destinationPath . $filename, imageQuality($image));
//        if ($imageResult) return $filename;
//        return false;
    }
}

if (!function_exists('imageQuality')) {
    /**
     * Get image quality for compression
     * @param $image
     * @return int
     * @since 16th-Apr-2018
     */
    function imageQuality($image)
    {
        $imageSize = filesize($image) / (1024 * 1024);
        if ($imageSize < 0.5) return 70;
        elseif ($imageSize > 0.5 && $imageSize < 1) return 60;
        elseif ($imageSize > 1 && $imageSize < 2) return 50;
        elseif ($imageSize > 2 && $imageSize < 5) return 40;
        elseif ($imageSize > 5) return 30;
        else return 50;
    }
}

if (!function_exists('deleteImageFromStoragePath')) {
    /**
     * Delete an image from storage path
     * @param $fileName Name of the image (Ex. user_2_1432423423.jpg)
     * @return int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function deleteImageFromPublicPath($fileName)
    {
        if ($fileName != '') {
            $destinationFolder = 'adminuploads/files/';
            $filePath = public_path();
            return (File::delete($filePath . '/' . $fileName));
        }
    }
}

if (!function_exists('functionToTimezone')) {
    /**
     * Delete an image from storage path
     * @param $fileName Name of the image (Ex. user_2_1432423423.jpg)
     * @return int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToTimezone($id)
    {
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFInd = ['timezone'];
        $getUserDetails = \App\Modules\Admin\Models\User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
        return $getUserDetails;
    }
}

if (!function_exists('functionToGetProjectData')) {
    /**
     * functionToGetProjectData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetProjectData()
    {
        $dataToFInd = ['project_name','project_id'];
        $whereToFind = ['rawQuery' => 'project_status = ?', 'bindParams' => [1]];
        $getAllProjectName = \App\Modules\Admin\Models\Project::getInstance()->getProjectDetails($whereToFind, $dataToFInd);
//        $dataToFInd = ['project_name'];
//        $getAllProjectName = \App\Modules\Admin\Models\Project::getInstance()->fetchAllProjectDetails($dataToFInd);
        return $getAllProjectName;
    }
}

if (!function_exists('functionToGetStaffData')) {
    /**
     * functionToGetStaffData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetStaffData()
    {
        $whereToFind = ['rawQuery' => 'role = ?', 'bindParams' => ['S']];
        $dataToFInd = ['id','name','username','staff_rating','staff_feedback','staff_status','role'];
        $getUserDetails = \App\Modules\Admin\Models\User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
        return $getUserDetails;
    }
}

if (!function_exists('functionToGetMangerData')) {
    /**
     * functionToGetMangerData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetMangerData()
    {
        $whereToFindManager = ['rawQuery' => 'role = ?', 'bindParams' => ['M']];
        $dataToFInd = ['id','name','username','role'];
        $getManagerDetails = \App\Modules\Admin\Models\User::getInstance()->getUserDetails($whereToFindManager, $dataToFInd);
        return $getManagerDetails;
    }
}
if (!function_exists('functionToGetMangerIds')) {
    /**
     * functionToGetMangerData
     * @return \Illuminate\Support\Collection|int
     * @since 16th-Apr-2018
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     */
    function functionToGetMangerIds()
    {
        $whereToFindManager = ['rawQuery' => 'role = ?', 'bindParams' => ['M']];
        $dataToFInd = ['id'];
        $getManagerDetails = \App\Modules\Admin\Models\User::getInstance()->getUserDetailsData($whereToFindManager, $dataToFInd);
        return $getManagerDetails;
    }
}



































































