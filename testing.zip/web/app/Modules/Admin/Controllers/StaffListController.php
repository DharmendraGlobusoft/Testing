<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 4/20/2018
 * Time: 5:50 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Admin\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\Issue;
use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\Project;
use App\Modules\Admin\Models\Task;
use App\Modules\Admin\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use function PHPSTORM_META\elementType;
use Yajra\DataTables\DataTables;

class StaffListController extends Controller
{
    /**
     * staffListDetails
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 21st-Apr-2018
     */
    public function staffListDetails()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_admin.totalNotification', count($totalNotification));
        return view('Admin::Dashboard/stafflist', ['userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    public function ratingFun()
    {

        return view('Admin::Dashboard/rating');
    }

    function checkRating($child, $divClass, $rating)
    {

        $fullStar = floor($rating / 1);
        $halfStar = $rating % 1;

        if ($divClass <= $fullStar) {

            switch ($child) {
                case 0:
                    if ($divClass <= $fullStar) {
                        return 'animate';
                    } else {
                        return '';
                    }
                    break;
                case 1:
                    if ($divClass <= $fullStar) {
                        return 'star-colour';
                    } else {
                        return '';
                    }
                    break;
                case 2:
                    if ($divClass <= $fullStar) {
                        return 'star-colour';
                    } else {
                        return '';
                    }

                    break;
            }
        } else {
            if ($child == 0) {
                return '';
            } else if ($child == 1) {
                return '';
            } else if ($child == 2 && $divClass === $rating) {
                return 'star-colour';
            }
        }
    }


    /**
     * staffListInfoAjaxHandler
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 21st-Apr-2018
     */
    public function staffListInfoAjaxHandler()
    {
        $staffDetails = functionToGetStaffData();

        $staffListDetails = new Collection();

        foreach (json_decode($staffDetails) as $k => $val) {
            $staffName = $val->name;
            $rating = $val->staff_rating;
            $staffId = $val->id;
//            $halfStar = "<i class = 'fa fa-star-half-full'></i>";
//            $emptyStar = "<i class = 'fa fa-star-o'></i>";
//
//            $rating = $rating <= $maxRating ? $rating : $maxRating;
//
//            $fullStarCount = (int)$rating;
//            $halfStarCount = $rating % 1;
//            dd($halfStarCount);
//            $emptyStarCount = $maxRating - $fullStarCount - $halfStarCount;
//            dd($emptyStarCount);
//
//            $html = str_repeat($fullStar, $fullStarCount);
//            $html .= str_repeat($halfStar, $halfStarCount);
//            $html .= str_repeat($emptyStar, $emptyStarCount);
//            $html = '<div class="ratings-icons">' . $html . '</div>';
//            $data = '';
//            foreach ($maxRating as $i => $v) {
//                $data .= '<div class="star">
//
//    <span class="full" data-value=' . $v . '></span>
//    <span class="half" data-value=' . ($v / 2) . '></span>
//    <span class="selected"></span>
//
//  </div>';
//            }
//            dd($data);

            $ratingHtml = '<div class="rating" data-vote="0" data-id="' . $staffId . '">
  <div class="star hidden">
    <span class="full"data-value="0"></span>
    <span class="half"data-value="0"></span>
  </div>

  <div class="star ' . $this->checkRating(0, 1, $rating) . ' ">
    <span class="full ' . $this->checkRating(1, 1, $rating) . ' " data-value="1" </span>
    <span class="half    ' . $this->checkRating(2, 0.5, $rating) . '  " data-value="0.5"></span>
    <span class="selected"></span>
  </div>

  <div class="star ' . $this->checkRating(0, 2, $rating) . '">
    <span class="full ' . $this->checkRating(1, 2, $rating) . '" data-value="2"></span>
    <span class="half ' . $this->checkRating(2, 1.5, $rating) . '" data-value="1.5"></span>
    <span class="selected"></span>
  </div>

  <div class="star ' . $this->checkRating(0, 3, $rating) . '">
    <span class="full ' . $this->checkRating(1, 3, $rating) . '" data-value="3"></span>
    <span class="half ' . $this->checkRating(2, 2.5, $rating) . '" data-value="2.5"></span>
    <span class="selected"></span>
  </div>

  <div class="star ' . $this->checkRating(0, 4, $rating) . '">
    <span class="full ' . $this->checkRating(1, 4, $rating) . '" data-value="4"></span>
    <span class="half ' . $this->checkRating(2, 3.5, $rating) . '" data-value="3.5"></span>
    <span class="selected"></span>
  </div>

  <div class="star  ' . $this->checkRating(0, 5, $rating) . '">
    <span class="full ' . $this->checkRating(1, 5, $rating) . '" data-value="5"></span>
    <span class="half ' . $this->checkRating(2, 4.5, $rating) . '" data-value="4.5"></span>
    <span class="selected"></span>
  </div>
 <div class="score" hidden>
    <span class="score-rating js-score">' . $rating . '</span>
    <span>/</span>
    <span class="total">5</span>
  </div>
</div>';

            $status = '<option value="1" ' . ($val->staff_status == 1 ? 'selected' : '') . '>Active</option>
<option value="0" ' . ($val->staff_status == 0 ? 'selected' : '') . '>In-Active</option>';

            if ($val->staff_status == 1) {
                $staffStatus = '<a class="text-success" style="cursor: text">Active</a>';
            } else {
                $staffStatus = '<a class="custom_text_danger" style="cursor: text">In-Active</a>';
            }

            $staffFeedback = '<option value="0" ' . ($val->staff_feedback == 0 ? 'selected' : '') . '>Poor</option>
<option value="1" ' . ($val->staff_feedback == 1 ? 'selected' : '') . '>Good</option>
<option value="2" ' . ($val->staff_feedback == 2 ? 'selected' : '') . '>Average</option>
<option value="3" ' . ($val->staff_feedback == 3 ? 'selected' : '') . '>Excellent</option>';


            $staffListDetails->push([
                'serialNumber' => $k + 1,
//                'StaffName' => $staffName,
                'StaffName' => '<a class="custom_text_info staffInfo" data-toggle="modal" data-id=' . $staffId . ' data-target="#staff_personal_details">' . $staffName . '</a>',
                'Ratings' => $ratingHtml,
//                'status' => '<select class="statusSelect" data-id=' . $staffId . '>' . $status . '</select>',
                'status' => $staffStatus,
                'Feedback' => '<select class="feedbackSelect" data-id=' . $staffId . '>' . $staffFeedback . '</select>',
                'ProjectDetails' => '<a class="custom_text_info staffDetails" data-toggle="modal" data-id=' . $staffId . ' data-target="#staffProjectDetails">View Details</button>',
                'feedbackStatus' => $val->staff_feedback
//                'contenteditable' => 'true',
//                'staffId' => $staffId
            ]);
        }
        return DataTables::of($staffListDetails)->rawColumns(['StaffName', 'Ratings', 'status', 'Feedback', 'Ratings', 'ProjectDetails'])->make(true);
    }

    /**
     * allTaskOfStaffAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 24th-Apr-2018
     */
    public function allTaskOfStaffAjaxHandler(Request $request)
    {
        $staffId = $request->input('staffId');
        $dataToFind = ['task_id', 'project_id', 'task_topic', 'task_desc', 'priority', 'task_due_date', 'task_due_hours', 'task_status'];
        $whereToFind = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(task_assign_to,2,length(task_assign_to)-2)))>0"];
        $queryToFindTaskDetails = Task::getInstance()->getTaskData($whereToFind, $dataToFind);
        $allTaskDetails = new Collection();
        foreach (json_decode($queryToFindTaskDetails) as $i => $v) {
            $taskName = $v->task_topic;
            $taskDueDate = $v->task_due_date ? date('Y-m-d', $v->task_due_date) : '--';
            $taskDueHours = $v->task_due_hours ? $v->task_due_hours : '--';
            $priority = json_decode($v->priority);
            if ($priority == 0) {
                $priorityName = "None";
            } else if ($priority == 1) {
                $priorityName = "Low";
            } else if ($priority == 2) {
                $priorityName = "Medium";
            } else if ($priority == 3) {
                $priorityName = "High";
            }

            if ($v->task_status == 0) {
                $taskStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
            } else if ($v->task_status == 1) {
                $taskStatus = '<a class="text-success" style="cursor: text">Completed</a>';
            }

            $projId = $v->project_id;
            $whereToFindProjname = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projId]];
            $dataToFindProjname = ['project_name'];
            $projectname = Project::getInstance()->getProjectDetails($whereToFindProjname, $dataToFindProjname);
            $projectName = json_decode($projectname)[0]->project_name;

            $taskId = $v->task_id;
            $allTaskDetails->push([
                'serialNumber' => $i + 1,
                'projectName' => '<p class="content_wrap">' . $projectName . '</p>',
                'taskTopic' => '<p class="content_wrap">' . $taskName . '</p>',
                'dueDate' => $taskDueDate,
                'dueHours' => $taskDueHours,
                'priority' => $taskStatus,
                'status' => $priorityName,
                'taskDetails' => $taskName,
                'projectDetails' => $projectName
            ]);
        }
        return DataTables::of($allTaskDetails)->rawColumns(['taskTopic', 'projectName', 'priority', 'status'])->make(true);
    }

    public function fetchUserInfo(Request $request)
    {
        $staffId = $request->input('userId');
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
        $getUserDetails = User::getInstance()->getUserDetails($whereToFind);
        if($getUserDetails){
            return json_encode(['status'=>200,'message'=>'Fetched All the Information','data'=>$getUserDetails]);
        }else{
            return json_encode(['status'=>400,'message'=>'Not Fetched All the Information','data'=>null]);
        }
    }

    /**
     * allIssueOfStaffAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 24th-Apr-2018
     */
    public function allIssueOfStaffAjaxHandler(Request $request)
    {
        $staffId = $request->input('staffId');

        $dataToFind = ['issue_id', 'project_id', 'issue_topic', 'issue_desc', 'severity', 'due_date', 'issue_due_hours', 'issue_status'];
        $whereToFind = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0"];
        $queryToFindIssueDetails = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFind);

        $allIssueDetails = new Collection();
        foreach (json_decode($queryToFindIssueDetails) as $i => $v) {
            $issueName = $v->issue_topic;
            $issueDueDate = $v->due_date ? date('Y-m-d', $v->due_date) : '--';
            $issueDueHours = $v->issue_due_hours ? $v->issue_due_hours : '--';

            if ($v->issue_status == 0) {
                $issueStatus = '<a class="custom_text_danger" style="cursor:text;">Pending</a>';
            } else if ($v->issue_status == 1) {
                $issueStatus = '<a class="text-success" style="cursor:text;">Completed</a>';
            }

            $severity = json_decode($v->severity);
            if ($severity == 0) {
                $priorityName = "None";
            } else if ($severity == 1) {
                $priorityName = "Minor";
            } else if ($severity == 2) {
                $priorityName = "Major";
            } else if ($severity == 3) {
                $priorityName = "Critical";
            }

            $projId = $v->project_id;
            $whereToFindProjname = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projId]];
            $dataToFindProjname = ['project_name'];
            $projectname = Project::getInstance()->getProjectDetails($whereToFindProjname, $dataToFindProjname);
            $projectName = json_decode($projectname)[0]->project_name;

            $issueId = $v->issue_id;
            $allIssueDetails->push([
                'serialNumber' => $i + 1,
                'projectName' => '<p class="content_wrap">' . $projectName . '</p>',
                'issueTopic' => '<p class="content_wrap">' . $issueName . '</p>',
                'dueDate' => $issueDueDate,
                'dueHours' => $issueDueHours,
                'severity' => $priorityName,
                'status' => $issueStatus,
                'issueDetails' => $issueName,
                'projectDetails' => $projectName
            ]);
        }
        return DataTables::of($allIssueDetails)->rawColumns(['issueTopic', 'projectName', 'severity', 'status'])->make(true);
    }

    /**
     * projectTaskOfAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 25th-Apr-2018
     */
    public function projectTaskOfAjaxHandler(Request $request)
    {
        $projectId = $request->input('projectId');
        $staffId = $request->input('staffId');
        $dataToFind = ['task_id', 'task_topic', 'task_desc', 'priority', 'task_due_date', 'task_due_hours', 'task_status'];
        $whereToFind = ['rawQuery' => "project_id = $projectId and find_in_set('" . $staffId . "',(substr(task_assign_to,2,length(task_assign_to)-2)))>0"];
        $queryToFindTaskDetails = Task::getInstance()->getTaskData($whereToFind, $dataToFind);
        $projectTaskDetails = new Collection();
        if (count($queryToFindTaskDetails) > 0) {
            foreach (json_decode($queryToFindTaskDetails) as $k => $data) {

                $taskName = $data->task_topic;
                $taskDueDate = $data->task_due_date ? date('Y-m-d', $data->task_due_date) : '--';
                $taskDueHours = $data->task_due_hours ? $data->task_due_hours : '--';
                $priority = json_decode($data->priority);
                if ($priority == 0) {
                    $priorityName = "None";
                } else if ($priority == 1) {
                    $priorityName = "Low";
                } else if ($priority == 2) {
                    $priorityName = "Medium";
                } else if ($priority == 3) {
                    $priorityName = "High";
                }

                if ($data->task_status == 0) {
                    $taskStatus = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                } else if ($data->task_status == 1) {
                    $taskStatus = '<a class="text-success" style="cursor: text">Completed</a>';
                }

                $taskId = $data->task_id;
                $projectTaskDetails->push([
                    'serialNumber' => $k + 1,
                    'taskTopic' => '<p class="content_wrap">' . $taskName . '</p>',
                    'dueDate' => $taskDueDate,
                    'dueHours' => $taskDueHours,
                    'priority' => $priorityName,
                    'status' => $taskStatus,
                    'taskDetails' => $taskName
                ]);
            }
            return DataTables::of($projectTaskDetails)->rawColumns(['taskTopic', 'priority', 'status'])->make(true);
        } else {
            $projectTaskDetails = [];
            return DataTables::of($projectTaskDetails)->make(true);
        }
    }

    /**
     * projectIssueOfAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 25th-Apr-2018
     */
    public function projectIssueOfAjaxHandler(Request $request)
    {
        $projectId = $request->input('projectId');
        $staffId = $request->input('staffId');
        $dataToFind = ['issue_id', 'issue_topic', 'issue_desc', 'severity', 'due_date', 'issue_due_hours', 'issue_status'];
        $whereToFind = ['rawQuery' => "project_id = $projectId and find_in_set('" . $staffId . "',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0"];
        $queryToFindIssueDetails = Issue::getInstance()->getIssueDetails($whereToFind, $dataToFind);
        $projectIssueDetails = new Collection();
        if (count($queryToFindIssueDetails) > 0) {
            foreach (json_decode($queryToFindIssueDetails) as $k => $data) {

                $issueName = $data->issue_topic;
                $issueDueDate = $data->due_date ? date('Y-m-d', $data->due_date) : '--';
                $issueDueHours = $data->issue_due_hours ? $data->issue_due_hours : '--';
                if ($data->issue_status == 0) {
                    $issueStatus = '<a class="custom_text_danger" style="cursor:text;">Pending</a>';
                } else if ($data->issue_status == 1) {
                    $issueStatus = '<a class="text-success" style="cursor:text;">Completed</a>';
                }
                $severity = json_decode($data->severity);
                if ($severity == 0) {
                    $priorityName = "None";
                } else if ($severity == 1) {
                    $priorityName = "Minor";
                } else if ($severity == 2) {
                    $priorityName = "Major";
                } else if ($severity == 3) {
                    $priorityName = "Critical";
                }

                $issueId = $data->issue_id;
                $projectIssueDetails->push([
                    'serialNumber' => $k + 1,
                    'issueTopic' => '<p class="content_wrap">' . $issueName . '</p>',
                    'dueDate' => $issueDueDate,
                    'dueHours' => $issueDueHours,
                    'severity' => $priorityName,
                    'status' => $issueStatus,
                    'issueDetails' => $issueName
                ]);
            }
            return DataTables::of($projectIssueDetails)->rawColumns(['issueTopic', 'severity', 'status'])->make(true);
        } else {
            $projectIssueDetails = [];
            return DataTables::of($projectIssueDetails)->make(true);
        }
    }

    /**
     * updateDataAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 24th-Apr-2018
     */
    public function updateDataAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseData = $request->input('chooseData');
            switch ($chooseData) {
                case 'updateStaffStatus':
                    $staffId = $request->input('staffId');
                    $staffStatus = $request->input('staffStatus');
                    $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                    $dataToUpdate = ['staff_status' => $staffStatus];

                    $queryToUpdateStatus = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateStatus == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Staff Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateStaffFeedback':
                    $staffId = $request->input('staffId');
                    $staffFeedback = $request->input('staffFeedback');
                    $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                    $dataToUpdate = ['staff_feedback' => $staffFeedback];

                    $queryToUpdateFeedback = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateFeedback == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Staff Feedback Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Feedback Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateStaffRating':
                    $staffId = $request->input('staffId');
                    $staffRating = $request->input('staffRating');
                    $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                    $dataToUpdate = ['staff_rating' => $staffRating];

                    $queryToUpdateRating = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateRating == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Staff Rating Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Rating Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateIssueSeverity':
                    $issueId = $request->input('issueId');
                    $issueSeverity = $request->input('issueSeverity');

                    $whereToUpdate = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $dataToUpdate = ['severity' => $issueSeverity];

                    $queryToUpdateSeverity = Issue::getInstance()->updateIssueDetails($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateSeverity == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Issue Severity Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateIssueStatus':
                    $issueId = $request->input('issueId');
                    $issueStatus = $request->input('issueStatus');

                    $whereToUpdate = ['rawQuery' => 'issue_id = ?', 'bindParams' => [$issueId]];
                    $dataToUpdate = ['issue_status' => $issueStatus];

                    $queryToUpdateStatus = Issue::getInstance()->updateIssueDetails($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateStatus == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Issue Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateTaskStatus':
                    $taskId = $request->input('taskId');
                    $taskStatus = $request->input('taskStatus');
                    $whereToUpdate = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $dataToUpdate = ['task_status' => $taskStatus];

                    $queryToUpdateStatus = Task::getInstance()->updateTaskDetails($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateStatus == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Task Status Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                    break;
                case 'updateTaskPriority':
                    $taskId = $request->input('taskId');
                    $taskPriority = $request->input('taskPriority');

                    $whereToUpdate = ['rawQuery' => 'task_id = ?', 'bindParams' => [$taskId]];
                    $dataToUpdate = ['task_status' => $taskPriority];

                    $queryToUpdateStatus = Task::getInstance()->updateTaskDetails($whereToUpdate, $dataToUpdate);
                    if ($queryToUpdateStatus == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Task Priority Updated Successfully!'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Status Not Updated, Please Try Again'
                        ]);
                    }
                    break;
//                case 'updateStaffFeedback':
//                    $staffId = $request->input('staffId');
//                    $staffFeedback = $request->input('staffFeedback');
//                    $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
//                    $dataToUpdate = ['staff_feedback' => $staffFeedback];
//
//                    $queryToUpdateStatus = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
//                    if ($queryToUpdateStatus == true) {
//                        return json_encode([
//                            'status' => 200,
//                            'message' => 'Staff Feedback Updated Successfully!'
//                        ]);
//                    } else {
//                        return json_encode([
//                            'status' => 400,
//                            'message' => 'Feedback Not Updated, Please Try Again'
//                        ]);
//                    }
                default:
                    return json_encode(['status' => 400, 'message' => 'No Data Found!']);
                    break;
            }
        }
    }

    /**
     * getProjectDetailsOfStaff
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 25th-Apr-2018
     */
    public function getProjectDetailsOfStaff(Request $request)
    {
        if ($request->isMethod('post')) {
            $staffId = $request->input('staffId');
//            $whereToFind1 = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(t1.task_assign_to,2,length(t1.task_assign_to)-2)))>0"];
//            $whereToFind2 = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0"];
            $whereToFind2 = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(staff_id,2,length(staff_id)-2)))>0"];
//            $queryToFindProjectDetails = json_decode(Task::getInstance()->getProjectDetails($whereToFind1, $whereToFind2, ['project_id']));
            $queryToFindProjectDetails = json_decode(Project::getInstance()->getProjectDetails($whereToFind2, ['project_id']));
            if (count($queryToFindProjectDetails) > 0) {
                foreach ($queryToFindProjectDetails as $k => $data) {
                    $dataToFind = ['project_id', 'project_name'];
                    $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$data->project_id]];
                    $getProjectData[] = json_decode(Project::getInstance()->getProjectDetails($whereToFind, $dataToFind));
                }
                return json_encode(['status' => 200, 'message' => 'Project Data of each users', 'data' => $getProjectData]);
            } else {
                return json_encode(['status' => 400, 'message' => 'No Task Or Issue Has Been Assigned.', 'data' => null]);
            }
        }
    }
//SELECT * FROM tasks as t1 INNER JOIN  issues as i1 ON t1.task_assign_to = i1.issue_assign_to WHERE find_in_set('4',(substr(t1.task_assign_to,2,length(t1.task_assign_to)-2)))>0
//SELECT * FROM tasks as t1 INNER JOIN  issues as i1 ON t1.task_assign_to = i1.issue_assign_to WHERE find_in_set('" . $staffId . "',(substr(staff_id,2,length(staff_id)-2)))>0
}