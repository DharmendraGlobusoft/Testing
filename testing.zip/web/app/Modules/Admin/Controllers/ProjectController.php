<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 4/20/2018
 * Time: 1:00 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 * @since 20th-Apr-2018
 */

namespace App\Modules\Admin\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\Issue;
use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\Project;
use App\Modules\Admin\Models\User;
use FontLib\Table\Type\name;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class ProjectController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor.
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * addProjectPage
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 5th-Apr-2018
     */
    public function addProjectPage(Request $request)
    {
        if ($request->isMethod('post')) {
            $projId = '';
            $projectName = $request->input('projName');
            $projectStatus = $request->input('projStatus');
            $privacyStatus = $request->input('privacyStatus');
            $projectManager = $request->input('projManager') !== 'Choose Manger' ? $request->input('projManager') : '';
            $projStartDate = $request->input('projStartDate') ? $request->input('projStartDate') : null;
            $projEndDate = $request->input('projEndDate') ? $request->input('projEndDate') : null;
            $pending_issue_count = 0;
            $managerIds = [];
            if ($projectManager) {
                $whereToFind = [
                    'rawQuery' => 'username=?',
                    'bindParams' => [$projectManager]
                ];
                $dataToFind = ['id', 'email'];
                $findManagerId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                $managerIds[] = json_decode($findManagerId)[0] ? json_decode($findManagerId)[0]->id : '';
                $notifyType = 2; //foe assign Project
                $type = 0;
                $sendEMail = $this->sendEmail('', '', json_decode($findManagerId)[0]->email, $projectName, $projStartDate, $projEndDate, 'Manager');
                $insertFeedData = $this->insertNotification('', json_decode($findManagerId)[0] ? json_decode($findManagerId)[0]->id : '', $projectManager, $projectName, $notifyType, $type);
            }

            $projectUsers = $request->input('projUsers') ? $request->input('projUsers') : [];
            $userIds = [];
            if (isset($projectUsers[0])) {
                foreach ($projectUsers as $k => $val) {
                    if ($val != null) {
                        $whereToFind = [
                            'rawQuery' => 'username=?',
                            'bindParams' => [$val]
                        ];
                        $dataToFind = ['id', 'email'];
                        $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                        $userIds[] = json_decode($findUserId) ? json_decode($findUserId)[0]->id : '';
                        $notifyType = 2; //foe assign Project
                        $type = 0;
                        $insertFeedData = $this->insertNotification('', json_decode($findUserId) ? json_decode($findUserId)[0]->id : '', $val, $projectName, $notifyType, $type);
                    }
                }
            }


            $whereToFindProjName = [
                'rawQuery' => 'project_name=?',
                'bindParams' => [$projectName]
            ];
            $queryToFindProjDetails = Project::getInstance()->getProjectData($whereToFindProjName);
            if (!$queryToFindProjDetails) {
                $dataToInsert = [
                    'project_name' => $projectName,
                    'manager_id' => json_encode($managerIds),
                    'staff_id' => json_encode($userIds),
                    'pending_issue_count' => $pending_issue_count ? $pending_issue_count : 0,
                    'project_status' => $projectStatus,
                    'privacy_status' => $privacyStatus != null ? $privacyStatus : 1,
                    'start_date' => $projStartDate,
                    'end_date' => $projEndDate,
                    'created_at' => time(),
                    'updated_at' => time()
                ];
                $queryToInsertProjData = Project::getInstance()->insertProjectData($dataToInsert);
                $projId = $queryToInsertProjData;

                if ($queryToInsertProjData) {
                    $allProjectName = functionToGetProjectData();
                    if (isset($projectUsers[0])) {
                        foreach ($projectUsers as $k => $val) {
                            if ($val != null) {
                                $whereToFind = [
                                    'rawQuery' => 'username=?',
                                    'bindParams' => [$val]
                                ];
                                $dataToFind = ['id', 'email'];
                                $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                                $sendEMail = $this->sendEmail(json_decode($findUserId)[0]->id, $queryToInsertProjData, json_decode($findUserId)[0]->email, $projectName, $projStartDate, $projEndDate, 'Staff');
                            }
                        }
                    }
                    return json_encode([
                        'status' => 200,
                        'message' => 'Project Details Inserted Successfully!',
                        'data' => $allProjectName
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Not Inserted! Please Try Again..!'
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Project Name Already Exist! Please Choose Another..!'
                ]);
            }
        }
    }

    public function sendEmail($id, $pid, $email, $projName, $startDate, $endDate, $type)
    {
        $timezone = functionToTimezone(Session::get('co_admin')['id']);
        if (json_decode($timezone)[0]->timezone == null)
            date_default_timezone_set('Asia/Kolkata');
        else
            date_default_timezone_set(json_decode($timezone)[0]->timezone);
        $time = date('D,M jS,h:i A', time());
        if ($type == 'Manager') {
            $link = $this->api_url . '/manager/projects-info?next=projects-info';
        } else {
            $link = $this->api_url . '/staff/projectInvitation/' . $id . '/' . $pid;
        }
        $image = $this->api_url . '/images/logo3.png';
        $sDate = $startDate ? date('m/d/Y', $startDate) : 'Not Assigned';
        $eDate = $endDate ? date('m/d/Y', $endDate) : 'Not Assigned';


        $from = new \SendGrid\Email(null, env('sendgrid_emailid'));
        $subject = "Admin added $projName to you!";
        $to = new \SendGrid\Email(null, $email);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Project details</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$time</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    min-width:600px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td><h2>Project Details</h2></td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Project</b></td>
                <td style=\"padding-bottom: 10px;\">: $projName</td>
            </tr>
              <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Start Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $sDate</td>
            </tr>
              <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>End Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $eDate</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Company</b> </td>
                <td style=\"padding-bottom: 10px;\">: Cloud Office Pvt Ltd.</td>
            </tr>
            <tr>
        <td style=\"padding-top:40px;\"><a href=$link style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" >Check Details</a>
         
        </td>
      </tr>
        </table>
    </center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = env('sendgrid_api_key');
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
    }

    /**
     * insertNotification
     * @param $ids
     * @param $names
     * @param $projName
     * @param $notifyType
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 5th-May-2018
     */
    public function insertNotification($id, $ids, $names, $projName, $notifyType, $dataType)
    {
        $receiverId = $ids;
        $senderId = Session::get('co_admin')['id'];
        $senderMessage = '';
        if ($notifyType == 0) {
            $type = 'Issue';
            $senderMessage = 'Admin Assigned the ' . $type . ' to ' . $names . ' in ' . $projName . ' Project';
            $receiverMessage = 'Admin has assigned one ' . $type . ' to you in ' . $projName . ' Project';
        } else if ($notifyType == 1) {
            $type = 'Task';
            $senderMessage = 'Admin Assigned the ' . $type . ' to ' . $names . ' in ' . $projName . ' Project';
            $receiverMessage = 'Admin has assigned one ' . $type . ' to you in ' . $projName . ' Project';
        } else if ($notifyType == 2) {
            $senderMessage = 'You welcomes ' . $names . ' to join project ' . $projName;
            $receiverMessage[] = ['id' => $id, 'pName' => $projName, 'message' => 'Admin welcomes you to join project ' . $projName . '.'];
        } else if ($notifyType == 24) {
            $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
        } else if ($notifyType == 26) {
            $receiverMessage[] = ['id' => $id, 'pName' => $projName, 'msg' => $dataType, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
        }

        $dataToInsert = [
            'sender_id' => $senderId,
            'receiver_id' => $receiverId,
            'sender_message' => $senderMessage,
            'receiver_message' => json_encode($receiverMessage),
            'notify_type' => $notifyType,
            'notification_status' => 0,
            'created_at' => time(),
            'updated_at' => time()
        ];
        $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
    }

    /**
     * updateProjectDetails
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 10th-Apr-2018
     */
    public function updateProjectDetails(Request $request)
    {
        if ($request->isMethod('post')) {
            if (isset($request->all()['staff_id']) == false) {
                $userIds = [];
            } else {
                $projectUsers = $request->input('staff_id');
                $userIds = [];
                foreach ($projectUsers as $k => $val) {
                    $whereToFind = [
                        'rawQuery' => 'username=?',
                        'bindParams' => [$val]
                    ];
                    $dataToFind = ['id'];
                    $findUserId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                    $userIds[] = json_decode($findUserId) ? json_decode($findUserId)[0]->id : '';
                }
            }

            $managerIds = [];
            if ($request->input('manager_id')) {
                $projectManager = $request->input('manager_id');
                $managerIds = [];
                $whereToFind = [
                    'rawQuery' => 'username=?',
                    'bindParams' => [$projectManager]
                ];
                $dataToFind = ['id'];
                $findManagerId = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                $managerIds[] = json_decode($findManagerId) ? json_decode($findManagerId)[0]->id : '';
            }
            $whereToUpdate = [
                'rawQuery' => 'project_id = ?',
                'bindParams' => [$request->input('project_id')]
            ];

            /*..........................To send Notification.................................................*/

            $dataToFInd = ['manager_id', 'project_name', 'staff_id', 'privacy_status', 'start_date', 'end_date'];
            $projectData = json_decode(Project::getInstance()->getProjectDetails($whereToUpdate, $dataToFInd));
            $projectAssignedStaff = json_decode($projectData[0]->staff_id);
            $newStaffIds = array_diff($userIds, $projectAssignedStaff);
            if (count($newStaffIds) > 0) {
                foreach ($newStaffIds as $k => $v) {
                    $notifyType = 2; //for assigned Task
                    $insertFeedData = $this->insertNotification('', $v, '', $projectData[0]->project_name, $notifyType, '');

                    $whereToFind = [
                        'rawQuery' => 'id=?',
                        'bindParams' => [$v]
                    ];
                    $dataToFind = ['name', 'email'];
                    $findUserEmail = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                    $sendEMail = $this->sendEmail($v, $request['project_id'], json_decode($findUserEmail)[0]->email, $projectData[0]->project_name, $projectData[0]->start_date, $projectData[0]->end_date, 'Staff');
                }
            }
            $newManagerIds = array_diff($managerIds, json_decode($projectData[0]->manager_id));
            if (count($newManagerIds) > 0) {
                foreach ($newManagerIds as $k => $v) {
                    $notifyType = 2; //for assigned Task
                    $insertFeedData = $this->insertNotification('', $v, '', $projectData[0]->project_name, $notifyType, '');

                    $whereToFind = ['rawQuery' => 'id=?', 'bindParams' => [$v]];
                    $dataToFind = ['name', 'email'];
                    $findUserEmail = User::getInstance()->getUserDetails($whereToFind, $dataToFind);
                    $sendEMail = $this->sendEmail('', '', json_decode($findUserEmail)[0]->email, $projectData[0]->project_name, $projectData[0]->start_date, $projectData[0]->end_date, 'Manager');
                }
            }
            $msg = '';
            $pName = $request->input('project_name');
            $managerId = $request->input('manager_id');
            $pStatus = $request->input('project_status');
            $privacyStatus = $request->input('privacy_status');
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');

            $notifyType = 24;
            $allIds = array_merge($userIds, json_decode($projectData[0]->manager_id));
            foreach ($allIds as $k => $val) {
                if (isset($pName)) {
                    $msg = 'Project Name';
                    $insertFeedData = $this->insertNotification($request->input('project_id'), $val, $projectData[0]->project_name, '', $notifyType, $msg);
                }
//            if (isset($managerId)) {
//                $msg = 'Manger';
//                $insertFeedData = $this->insertNotification($request->input('project_id'), $allIds, $projectData[0]->project_name, '', $notifyType, $msg);
//            }
                if (isset($pStatus)) {
                    $msg = 'Project Status';
                    $insertFeedData = $this->insertNotification($request->input('project_id'), $val, $projectData[0]->project_name, '', $notifyType, $msg);
                }
                if (isset($privacyStatus) && $request->input('privacy_status') != $projectData[0]->privacy_status) {
                    $msg = 'Project Privacy Status';
                    $insertFeedData = $this->insertNotification($request->input('project_id'), $val, $projectData[0]->project_name, '', $notifyType, $msg);
                }
                if (isset($startDate)) {
                    $msg = 'Start Date';
                    $insertFeedData = $this->insertNotification($request->input('project_id'), $val, $projectData[0]->project_name, '', $notifyType, $msg);
                }
                if (isset($endDate)) {
                    $msg = 'End Date';
                    $insertFeedData = $this->insertNotification($request->input('project_id'), $val, $projectData[0]->project_name, '', $notifyType, $msg);
                }
            }
            /*...............................................End Notification.....................................*/


            unset($request['project_id']);
            $update = [];
            foreach ($request->all() as $key => $input) {
                if ($key == 'staff_id') {
                    $update[$key] = json_encode($userIds);
                } else if ($key == 'manager_id') {
                    $update[$key] = json_encode($managerIds);
                } else {
                    $update[$key] = $input;
                }
            }
            $updatedData = Project::getInstance()->updateProjectDetails($whereToUpdate, $update);
            if ($updatedData) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Project Data Updated Successfully!.'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Has To Be Updated!',
                ]);
            }
        }
    }

    /**
     * projectsInfo
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 6th-Apr-2018
     */
    public function projectsInfo()
    {
        $whereToFind = ['rawQuery' => 'role = ? and staff_status = ?', 'bindParams' => ['S', '1']];
        $dataToFInd = ['id', 'name', 'username', 'staff_rating', 'staff_feedback', 'staff_status', 'role'];
//        $getUserDetails = \App\Modules\Admin\Models\User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
        $allStaffName = \App\Modules\Admin\Models\User::getInstance()->getUserDetails($whereToFind, $dataToFInd);
        $allProjectName = functionToGetProjectData();
        $allStaff = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_admin.totalNotification', count($totalNotification));
        return view('Admin::Dashboard/projects', ['userData' => json_decode($allStaffName), 'staffData' => json_decode($allStaff), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * projectInfoAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 6th-Apr-2018
     */
    public function projectInfoAjaxHandler(Request $request)
    {
        $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date'];
        $fetchProjectTable = Project::getInstance()->fetchAllProjectDetails($dataToFetch);

        $projectDetails=$this->projectDatatable($fetchProjectTable);
        return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
    }

    public function filteringOfDataAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');
                $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date'];
                $whereToFetch = ['rawQuery' => "find_in_set('" . $staffId . "',(substr(staff_id,2,length(staff_id)-2)))>0"];
                $fetchProjectTable = Project::getInstance()->getProjectDetails($whereToFetch, $dataToFetch);

                $projectDetails=$this->projectDatatable($fetchProjectTable);
                return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
            case 'FilertingByView':
                $staffId = $request->input('staffId');
                $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date'];
                $whereToFetch = ['rawQuery' => "created_at > " . time() . " - 604800"];
                $fetchProjectTable = Project::getInstance()->getProjectDetails($whereToFetch, $dataToFetch);

                $projectDetails=$this->projectDatatable($fetchProjectTable);
                return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
            case 'FilertingByProject':
                $proName = $request->input('projName');
                $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date'];
                $whereToFetch = ['rawQuery' => 'project_name = ? ', 'bindParams' => [$proName]];
                $fetchProjectTable = Project::getInstance()->getProjectDetails($whereToFetch, $dataToFetch);

                $projectDetails=$this->projectDatatable($fetchProjectTable);
                return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
            case 'FilertingByTime':

                $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date'];

                if ($request->input('time') == 'today') {
                    $whereToFetch = ['rawQuery' => "created_at >= " . time() . " - 86400"];
//                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) = CURDATE()"];
                }
                if ($request->input('time') == '7 days') {
                    $whereToFetch = ['rawQuery' => "created_at > " . time() . " - 604800"];
                }
                if ($request->input('time') == '30 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY)"];
                }
                $fetchProjectTable = Project::getInstance()->getProjectDetails($whereToFetch, $dataToFetch);
                $projectDetails=$this->projectDatatable($fetchProjectTable);
                return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');

                $dataToFetch = ['project_id', 'project_name', 'manager_id', 'staff_id', 'project_status', 'pending_issue_count', 'start_date', 'end_date', 'created_at'];
                $fetchProjectTable = Project::getInstance()->fetchAllProjectDetails($dataToFetch);

                $projectDetails = new Collection();

                foreach (json_decode($fetchProjectTable) as $k => $data) {
                    $count=0;
                    if (date("F Y", $data->created_at) == $date) {
                        $managerId = json_decode($data->manager_id);
                        $staffId = json_decode($data->staff_id);

                        $getAllManagerDetails = array_map(function ($managerId) {
                            $whereToFindManager = ['rawQuery' => 'id = ?', 'bindParams' => [$managerId]];
                            $dataToFInd = ['name'];
                            $getManagerDetails = User::getInstance()->getUserDetails($whereToFindManager, $dataToFInd);
                            return json_decode($getManagerDetails) ? json_decode($getManagerDetails)[0]->name : '--';
                        }, $managerId);

                        $startDate = $data->start_date != "" ? date('m/d/Y', $data->start_date) : '--';
                        $endDate = $data->end_date != "" ? date('m/d/Y', $data->end_date) : '--';

                        $issueDetails = '';
                        $projName = $data->project_name;
                        $whereToGet = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projName]];
                        $dataToGet = ['project_id'];
                        $findProjId = Project::getInstance()->getProjectDetails($whereToGet, $dataToGet);

                        if ($data->project_status == '0') {
                            $projStatus = '<a class="custom_text_danger" style="cursor:text;">In-Active</a>';
                        } else {
                            $projStatus = '<a class="text-success" style="cursor:text;">Active</a>';
                        }

                        $whereToGetIssueData = ['rawQuery' => 'project_id = ?', 'bindParams' => [json_decode($findProjId)[0]->project_id]];
                        $dataToGetIssueData = ['issue_id', 'issue_topic'];
                        $fetchIssueDetails = Issue::getInstance()->getIssueDetails($whereToGetIssueData, $dataToGetIssueData);

                        $dataId = $data->project_id;
                        $projectDetails->push([
                            'serialNumber' => $k + 1,
                            'projectId' => $dataId,
                            'projectName' => '<p class="content_wrap" >' . $data->project_name . '</p>',
                            'projectStatus' => $projStatus,
                            'startDate' => $startDate,
                            'endDate' => $endDate,
                            'manager' => $getAllManagerDetails ? $getAllManagerDetails[0] : '--',
                            'staffDetails' => '<a class="custom_text_info staffListModal" data-id="' . $dataId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">View Staff</a>',
                            'pendingIssues' => '<a class="custom_text_danger issueListModal" data-toggle="modal" data-id=' . $dataId . ' data-target="#issuelist_modal"> View Issues</a>',
                            'action' => '<a  style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editProjectData text-success" title="Edit Project" aria-hidden="true" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#editProjectmodal" data-id="' . $dataId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteProject custom_text_danger" aria-hidden="true" title="Delete Project" data-toggle="modal" data-target="#confirmProjectModal" data-id="' . $dataId . '"></i></a>',
                            'totalPendingIssues' => $data->pending_issue_count,
                            'projName' => $data->project_name
                        ]);
                    }
                }
                return DataTables::of($projectDetails)->rawColumns(['projectName', 'projectStatus', 'staffDetails', 'pendingIssues', 'action'])->make(true);
        }
    }

    public function projectDatatable($fetchProjectTable){
        $projectDetails = new Collection();
        foreach (json_decode($fetchProjectTable) as $k => $data) {
            $managerId = json_decode($data->manager_id);
            $staffId = json_decode($data->staff_id);

            $getAllManagerDetails = array_map(function ($managerId) {
                $whereToFindManager = ['rawQuery' => 'id = ?', 'bindParams' => [$managerId]];
                $dataToFInd = ['name'];
                $getManagerDetails = User::getInstance()->getUserDetails($whereToFindManager, $dataToFInd);
                return json_decode($getManagerDetails) ? json_decode($getManagerDetails)[0]->name : '--';
            }, $managerId);

            $startDate = $data->start_date != "" ? date('m/d/Y', $data->start_date) : '--';
            $endDate = $data->end_date != "" ? date('m/d/Y', $data->end_date) : '--';

            $issueDetails = '';
            $projName = $data->project_name;
            $whereToGet = ['rawQuery' => 'project_name = ?', 'bindParams' => [$projName]];
            $dataToGet = ['project_id'];
            $findProjId = Project::getInstance()->getProjectDetails($whereToGet, $dataToGet);

            if ($data->project_status == '0') {
                $projStatus = '<a class="custom_text_danger" style="cursor:text;">In-Active</a>';
            } else {
                $projStatus = '<a class="text-success" style="cursor:text;">Active</a>';
            }

            $whereToGetIssueData = ['rawQuery' => 'project_id = ?', 'bindParams' => [json_decode($findProjId)[0]->project_id]];
            $dataToGetIssueData = ['issue_id', 'issue_topic'];
            $fetchIssueDetails = Issue::getInstance()->getIssueDetails($whereToGetIssueData, $dataToGetIssueData);

            $dataId = $data->project_id;
            $projectDetails->push([
                'serialNumber' => $k + 1,
                'projectId' => $dataId,
                'projectName' => '<p class="content_wrap" >' . $data->project_name . '</p>',
                'projectStatus' => $projStatus,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'manager' => $getAllManagerDetails ? $getAllManagerDetails[0] : '--',
                'staffDetails' => '<a class="custom_text_info staffListModal" data-id="' . $dataId . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">View Staff</a>',
                'pendingIssues' => '<a class="custom_text_danger issueListModal" data-toggle="modal" data-id=' . $dataId . ' data-target="#issuelist_modal"> View Issues</a>',
                'action' => '<a  style="display: inline-block;"><i style="cursor: pointer;" class="fa fa-pencil-square-o editProjectData text-success" title="Edit Project" aria-hidden="true" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#editProjectmodal" data-id="' . $dataId . '"></i>
                                    </a> <a  style="display: inline-block;"><i class="fa fa-trash-o deleteProject custom_text_danger" aria-hidden="true" title="Delete Project" data-toggle="modal" data-target="#confirmProjectModal" data-id="' . $dataId . '"></i></a>',
                'totalPendingIssues' => $data->pending_issue_count,
                'projName' => $data->project_name
            ]);
        }
        return $projectDetails;
    }

    /**
     * editProjectAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-Apr-2018
     */
    public function editProjectAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $projectId = $request->input('projectId');
            $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $fetchProjectData = Project::getInstance()->getProjectData($whereToFind);

            $managerId = json_decode($fetchProjectData->manager_id);
            $staffId = json_decode($fetchProjectData->staff_id);

            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['username'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
            }, $staffId);

            $getAllManagerDetails = array_map(function ($managerId) {
                $whereToFindManager = ['rawQuery' => 'id = ?', 'bindParams' => [$managerId]];
                $dataToFInd = ['username'];
                $getManagerDetails = User::getInstance()->getUserDetails($whereToFindManager, $dataToFInd);
                return json_decode($getManagerDetails) ? json_decode($getManagerDetails)[0]->username : '';
            }, $managerId);

            $startDate = $fetchProjectData->start_date ? date('Y-m-d', $fetchProjectData->start_date) : '';
            $endDate = $fetchProjectData->end_date ? date('Y-m-d', $fetchProjectData->end_date) : '';

            $projectDetailsArr[] = [
                'projectId' => $fetchProjectData->project_id,
                'projectName' => $fetchProjectData->project_name,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'manager' => $getAllManagerDetails ? $getAllManagerDetails[0] : '',
                'staffDetails' => $getAllStaffDetails,
                'staffId' => $staffId,
                'projectStatus' => $fetchProjectData->project_status == 1 ? 'Active' : 'In-Active',
                'privacyStatus' => $fetchProjectData->privacy_status == 1 ? 'Public' : 'Private'
            ];
            if ($fetchProjectData) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Fetched Project Details',
                    'data' => $projectDetailsArr
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Not Fetched the Data.Please Try Again.',
                    'data' => null
                ]);
            }
        }
    }

    public function fetchProDataAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'fetchStaff':
                    $projectId = $request->input('projectId');
                    $whereToGet = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $findProjData = json_decode(Project::getInstance()->getProjectDetails($whereToGet));
                    $staffDetails = json_decode($findProjData[0]->staff_id);

                    $getAllStaffDetails = array_map(function ($staffId) {
                        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                        $dataToFInd = ['name', 'profile_pic'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return json_decode($getUserDetails) ? json_decode($getUserDetails) : '';
                    }, $staffDetails);
                    if ($getAllStaffDetails) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Fetched Staff Details',
                            'data' => $getAllStaffDetails
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Fetched Staff Details',
                            'data' => null
                        ]);
                    }
                case 'fetchIssue':
                    $projectId = $request->input('projectId');
                    $whereToGet = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                    $findProjData = json_decode(Project::getInstance()->getProjectDetails($whereToGet));

                    $whereToGetIssueData = ['rawQuery' => 'project_id = ? and issue_status = ?', 'bindParams' => [$findProjData[0]->project_id, 0]];
                    $dataToGetIssueData = ['issue_id', 'issue_topic'];
                    $fetchIssueDetails = Issue::getInstance()->getIssueDetails($whereToGetIssueData, $dataToGetIssueData);
                    if (count(json_decode($fetchIssueDetails)) > 0) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Fetched Issues Details',
                            'data' => $fetchIssueDetails
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Fetched Issue Details',
                            'data' => null
                        ]);
                    }
            }
        }
    }

    public function deleteProjectAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $projectId = $request->input('projectId');
            $whereData = [
                'rawQuery' => 'projects.project_id = ' . $projectId
            ];

            $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
            $fetchData = json_decode(Project::getInstance()->getProjectDetails($whereToFind));
            if (count($fetchData) > 0) {
                $projectAssignedStaffs = json_decode($fetchData[0]->staff_id);
                $ProjectAssignedManager = json_decode($fetchData[0]->manager_id);

                $deleteTask = Project::getInstance()->deleteProjectDetails('projects', 'tasks', 'issues', 'milestones', 'projects.project_id = tasks.project_id', 'projects.project_id = issues.project_id', 'projects.project_id = milestones.project_id', $whereData['rawQuery']);
                if ($deleteTask == true) {
                    $notifyType = 26;
                    $allIds = array_merge($projectAssignedStaffs, $ProjectAssignedManager);

                    foreach ($allIds as $k => $val) {
                        $insertFeedData = $this->insertNotification($projectId, $val, '', $fetchData[0]->project_name, $notifyType, '');
                    }
                    return json_encode([
                        'status' => 200,
                        'message' => 'Project Deleted Successfully.',
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Not Deleted. Please Try Again to delete the Record.',
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Project Has been deleted by Manager.',
                ]);
            }
        }
    }

}