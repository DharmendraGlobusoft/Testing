<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 4/20/2018
 * Time: 12:48 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 * @since 20th-Apr-2018
 */

namespace App\Modules\Admin\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\SupportTickets;
use App\Modules\Admin\Models\TicketReply;
use App\Modules\Admin\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class SupportTicketController extends Controller
{
    /**
     * supportlist
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 2nd-Apr-2018
     */
    public function supportlist($id = null)
    {
        if ($id != null) {
            $whereToFind = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$id]];
            $findQuery = json_decode(SupportTickets::getInstance()->getTicketDetails($whereToFind));
            if (count($findQuery) == 0) {
                return view('Admin::Dashboard/accessDenied');
            }
        }
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $allData = array_merge(json_decode($allStaffName), json_decode($allManagerName));
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_admin.totalNotification', count($totalNotification));
        return view('Admin::Dashboard/supportlist', ['data' => $allData, 'id' => $id, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * addNewTicket
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function addNewTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketRaisedBy = $request->input('ticketRaisedBy');
            $ticketReceipient = $request->input('ticketReciepient');
            $subject = $request->input('subject');
            $ticketDesc = $request->input('ticketDesc');

            $dataToFindId = ['id', 'name'];
            $whereToFindRaisedBy = ['rawQuery' => 'username = ?', 'bindParams' => [$ticketRaisedBy]];
            $whereToFindReceipient = ['rawQuery' => 'username = ?', 'bindParams' => [$ticketReceipient]];
            $tktRaisedBy = User::getInstance()->getUserDetails($whereToFindRaisedBy, $dataToFindId);
            $tktReceipient = User::getInstance()->getUserDetails($whereToFindReceipient, $dataToFindId);

            $notifyType = 5; //for raising ticket
            $type = 0;
            $insertFeedData = $this->insertNotification('', json_decode($tktReceipient)[0]->id, json_decode($tktReceipient)[0]->name, '', $notifyType, $type);

            $dataToInsert = [
                'ticket_raised_by' => Session::get('co_admin')['id'],
                'ticket_reciepient' => json_decode($tktReceipient)[0]->id,
                'ticket_subject' => $subject,
                'ticket_description' => $ticketDesc,
                'ticket_status' => 1, // 1-open and 0-closed
                'ticket_queried_at' => time(),
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsert = SupportTickets::getInstance()->insertTicketData($dataToInsert);
            if ($queryToInsert) {
                return json_encode(['status' => 200, 'message' => 'Ticket Data Inserted Successfully!']);
            } else
                return json_encode(['status' => 400, 'message' => 'Not Inserted! Please Try Again']);
        }
    }

    /**
     * ticketsInfoAjaxHandler
     * @param Request $request
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function ticketsInfoAjaxHandler(Request $request)
    {
        $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at'];
        $fetchTicketTable = SupportTickets::getInstance()->fetchAllTicketData($dataToFetch);

        $ticketDetails = $this->ticketDatatble($fetchTicketTable);
        return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
    }

    /**
     * updateStatusOfTicket
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    public function updateStatusOfTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $ticketStatus = $request->input('ticketStatus');
            $whereToUpdate = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$ticketId]];
            $dataToUpdate = ['ticket_status' => $ticketStatus];

            $queryToUpdateStatus = SupportTickets::getInstance()->updateTIcket($whereToUpdate, $dataToUpdate);
            if ($queryToUpdateStatus == true) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Staff Status Updated Successfully!!'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Status Not Updated, Please Try Again'
                ]);
            }
        }
    }

    /**
     * fetchTicketReply
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    public function fetchTicketReply(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $whereToFetch = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$ticketId]];
            $dataToFetch = ['ticket_status', 'ticket_subject', 'ticket_description', 'ticket_raised_by', 'ticket_queried_at'];
            $queryToFetchData = json_decode(SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch));

            $ticketRaiseBy = $queryToFetchData[0]->ticket_raised_by;
            $queryToFindUserDeatils = $this->toFIndUser($ticketRaiseBy);

            $dataTOFetchReplies = ['replies', 'replied_by', 'reply_posted_on'];
            $getAllReplies = json_decode(TicketReply::getInstance()->getTicketReplyDetails($whereToFetch, $dataTOFetchReplies));
            usort($getAllReplies, function ($a, $b) {
                return $b->reply_posted_on - $a->reply_posted_on;
            });

            $ticketReplyDetails = array_map(function ($data) {
                $repliedBy = $data->replied_by;
                $userData = $this->toFIndUser($repliedBy);
                if ($data->replied_by == Session::get('co_admin')['id']) {
                    $repledBy = 'Admin';
                } else if ($userData[0]->role == 'M') {
                    $repledBy = $userData[0]->name . '_manager';
                } else {
                    $repledBy = $userData[0]->name . '_user';
                }
                return [
                    'replies' => $data->replies,
                    'replied_by' => $repledBy,
                    'reply_posted_on' => $data->reply_posted_on,
                    'profilePic' => $userData[0]->profile_pic ? $userData[0]->profile_pic : '/images/default.png'
                ];
            }, $getAllReplies);

            if ($queryToFindUserDeatils[0]->role == 'A') {
                $name = 'Admin';
            } else if ($queryToFindUserDeatils[0]->role == 'M') {
                $name = $queryToFindUserDeatils[0]->name . '_Manager';
            } else {
                $name = $queryToFindUserDeatils[0]->name . '_User';
            }
            $allTIcketData[] = [
                'ticket_description' => $queryToFetchData[0]->ticket_description,
                'ticket_subject' => $queryToFetchData[0]->ticket_subject,
                'ticket_status' => $queryToFetchData[0]->ticket_status,
                'ticket_queried_at' => $queryToFetchData[0]->ticket_queried_at,
                'name' => $name,
                'profile_pic' => $queryToFindUserDeatils[0]->profile_pic ? $queryToFindUserDeatils[0]->profile_pic : 'http://dummyimage.com/60',
            ];
            return json_encode(['status' => 200, 'message' => 'all data', 'data' => $allTIcketData, 'allTicketReplies' => $ticketReplyDetails]);
        }
    }

    /**
     * toFIndUser
     * @param $id
     * @return mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    function toFIndUser($id)
    {
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFind = ['name', 'profile_pic', 'role'];
        $queryToFindUserDeatils = json_decode(User::getInstance()->getUserDetails($whereToFind, $dataToFind));
        return $queryToFindUserDeatils;
    }

    /**
     * sendReplyForTicket
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    public function sendReplyForTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $whereToFindRecipient = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$ticketId]];
            $fetchQuery = json_decode(SupportTickets::getInstance()->getTicketDetails($whereToFindRecipient));

            $ticketReply = $request->input('ticketReply');
            $repliedBy = Session::get('co_admin')['id'];

            $dataToInsert = [
                'ticket_id' => $ticketId,
                'replies' => $ticketReply,
                'replied_by' => $repliedBy,
                'reply_posted_on' => time(),
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsert = TicketReply::getInstance()->insertTicketReplyData($dataToInsert);

            $notifyType = 6; //for sent ticket reply
            $type = 1;
            if ($fetchQuery[0]->ticket_reciepient === Session::get('co_admin')['id']) {
                $id = $fetchQuery[0]->ticket_raised_by;
            } else {
                $id = $fetchQuery[0]->ticket_reciepient;
            }
            $insertFeedData = $this->insertNotification($ticketId, $id, '', '', $notifyType, $type);

            if ($queryToInsert) {
                return json_encode(['status' => 200, 'message' => 'Support Ticket Replied Successfully', 'data' => time()]);
            } else
                return json_encode(['status' => 400, 'message' => 'Please Try Again']);
        }
    }

    /**
     * insertNotification
     * @param $ids
     * @param $names
     * @param $projName
     * @param $notifyType
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function insertNotification($ticketId = null, $id, $name, $projName, $notifyType, $type)
    {
        $receiverId = $id;
        $senderId = Session::get('co_admin')['id'];
        if ($notifyType === 5) {
            $senderMessage = 'You raised one ticket for ' . $name . '';
//            $receiverMessage = 'Admin Raised one Ticket for ' . $name . '.';
            $receiverMessage[] = ['id' => $ticketId, 'message' => 'Admin Raised one Ticket for ' . $name . '.'];
        } else if ($notifyType === 6) {
            $senderMessage = 'You replied on ticket.';
            $receiverMessage[] = ['id' => $ticketId, 'message' => 'Admin has replied on your ticket.'];
        }

        $dataToInsert = [
            'sender_id' => $senderId,
            'receiver_id' => $receiverId,
            'sender_message' => $senderMessage,
            'receiver_message' => json_encode($receiverMessage),
            'notify_type' => $notifyType,
            'notification_status' => 0,
            'created_at' => time(),
            'updated_at' => time()
        ];
        $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
    }

    public function filteringOfSupportAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');
                $whereToFetch = ['rawQuery' => 'ticket_raised_by = ? or ticket_reciepient = ?', 'bindParams' => [$staffId, $staffId]];

                $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at'];
                $fetchTicketTable = SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch);

                $ticketDetails = $this->ticketDatatble($fetchTicketTable);
                return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
            case 'FilertingByTime':
                if ($request->input('time') == 'today') {
                    $whereToFetch = ['rawQuery' => "created_at >= " . time() . " - 86400"];
                }
                if ($request->input('time') == '7 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)"];
                }
                if ($request->input('time') == '30 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY)"];
                }
                $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at'];
                $fetchTicketTable = SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch);

                $ticketDetails = $this->ticketDatatble($fetchTicketTable);
                return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
            case 'FilertingByView':
                $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)"];
                $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at', 'created_at'];
                $fetchTicketTable = SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch);

                $ticketDetails = $this->ticketDatatble($fetchTicketTable);
                return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');

                $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at', 'created_at'];
                $fetchTicketTable = SupportTickets::getInstance()->fetchAllTicketData($dataToFetch);

                $ticketDetails = new Collection();

                foreach (json_decode($fetchTicketTable) as $k => $data) {
                    if (date("F Y", $data->created_at) == $date) {
                        $whereToFindReceipient = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_reciepient]];
                        $whereToFindRaisedBy = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_raised_by]];
                        $dataToFInd = ['name', 'role'];
                        $receipientName = json_decode(User::getInstance()->getUserDetails($whereToFindReceipient, $dataToFInd));
                        $raisedBy = json_decode(User::getInstance()->getUserDetails($whereToFindRaisedBy, $dataToFInd));

                        if ($receipientName[0]->role == 'A') {
                            $receiverName = 'Admin';
                        } else if ($receipientName[0]->role == 'M') {
                            $receiverName = $receipientName[0]->name . '_Manager';
                        } else {
                            $receiverName = $receipientName[0]->name . '_Staff';
                        }

                        if ($raisedBy[0]->role == "A") {
                            $dataRaisedBy = 'Admin';
                        } else if ($raisedBy[0]->role == "M") {
                            $dataRaisedBy = $raisedBy[0]->name . '_Manager';
                        } else {
                            $dataRaisedBy = $raisedBy[0]->name . '_Staff';
                        }


                        $queriedAt = date('Y-m-d', $data->ticket_queried_at);

                        $status = '<option value="1" ' . ($data->ticket_status == 1 ? 'selected' : '') . '>Open</option><option value="0" ' . ($data->ticket_status == 0 ? 'selected' : '') . '>Closed</option>';


                        $ticketDetails->push([
                            'ticketId' => $data->ticket_id,
                            'ticketRaisedBy' => $dataRaisedBy,
                            'supportPersonal' => $receiverName,
                            'subject' => '<p class="content_wrap">' . $data->ticket_subject . '</p>',
                            'queried_at' => $queriedAt,
                            'status' => '<select class="statusSelect" data-id =' . $data->ticket_id . ' >' . $status . '</select>',
                            'description' => '<a class="custom_text_info staffListModal"  data-id="' . $data->ticket_id . '" data-val="' . $data->ticket_description . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">View</a>',
                            'tckSubject' => $data->ticket_subject,
                            'viewQuery' => '<div class="test"><a class="custom_text_danger viewQueryBtn checkClass' . $data->ticket_id . '" data-toggle="modal" data-target="#editStaffDetails"  data-id="' . $data->ticket_id . '" >Reply</a></div>',
                        ]);
                    }
                }
                return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
        }
    }

    public function ticketDatatble($fetchTicketTable)
    {
        $ticketDetails = new Collection();
        foreach (json_decode($fetchTicketTable) as $k => $data) {

            $whereToFindReceipient = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_reciepient]];
            $whereToFindRaisedBy = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_raised_by]];
            $dataToFInd = ['name', 'role'];
            $receipientName = json_decode(User::getInstance()->getUserDetails($whereToFindReceipient, $dataToFInd));
            $raisedBy = json_decode(User::getInstance()->getUserDetails($whereToFindRaisedBy, $dataToFInd));

            if ($receipientName[0]->role == 'A') {
                $receiverName = 'Admin';
            } else if ($receipientName[0]->role == 'M') {
                $receiverName = $receipientName[0]->name . '_Manager';
            } else {
                $receiverName = $receipientName[0]->name . '_Staff';
            }

            if ($raisedBy[0]->role == "A") {
                $dataRaisedBy = 'Admin';
            } else if ($raisedBy[0]->role == "M") {
                $dataRaisedBy = $raisedBy[0]->name . '_Manager';
            } else {
                $dataRaisedBy = $raisedBy[0]->name . '_Staff';
            }


            $queriedAt = date('Y-m-d', $data->ticket_queried_at);

            $status = '<option value="1" ' . ($data->ticket_status == 1 ? 'selected' : '') . '>Open</option><option value="0" ' . ($data->ticket_status == 0 ? 'selected' : '') . '>Closed</option>';


            $ticketDetails->push([
                'ticketId' => $data->ticket_id,
                'ticketRaisedBy' => $dataRaisedBy,
                'supportPersonal' => $receiverName,
                'subject' => '<p class="content_wrap">' . $data->ticket_subject . '</p>',
                'queried_at' => $queriedAt,
                'status' => '<select class="statusSelect" data-id =' . $data->ticket_id . ' >' . $status . '</select>',
                'description' => '<a class="custom_text_info staffListModal"  data-id="' . $data->ticket_id . '" data-val="' . $data->ticket_description . '" data-toggle="modal" data-target="#stafflist_modal" data-placement="left left-top">View</a>',
                'tckSubject' => $data->ticket_subject,
                'viewQuery' => '<div class="test"><a class="custom_text_danger viewQueryBtn checkClass' . $data->ticket_id . '" data-toggle="modal" data-target="#editStaffDetails"  data-id="' . $data->ticket_id . '" >Reply</a></div>',
            ]);
        }
        return $ticketDetails;
    }
}