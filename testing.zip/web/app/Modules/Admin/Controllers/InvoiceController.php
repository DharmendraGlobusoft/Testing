<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/4/2018
 * Time: 12:06 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Admin\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\Invoice;
use App\Modules\Admin\Models\InvoiceComment;
use App\Modules\Admin\Models\Issue;
use App\Modules\Admin\Models\Message;
use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\Project;
use App\Modules\Admin\Models\Task;
use App\Modules\Admin\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class InvoiceController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor.
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * payments
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 2nd-Apr-2018
     */
    public function payments()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_admin.totalNotification', count($totalNotification));
        return view('Admin::Dashboard/payments', ['userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * invoiceDataAjaxHandler
     * @return mixed
     * @throws \Exception
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 2nd-May-2018
     */
    public function invoiceDataAjaxHandler()
    {
        $dataToFetch = ['invoice_id', 'invoice_number', 'sender', 'receiver', 'payment_by', 'invoice_status', 'attachment', 'start_date', 'due_amount'];
        $fetchInvoiceTable = Invoice::getInstance()->fetchAllInvoiceData($dataToFetch);

        $invoiceDetails = $this->invoiceDatatble($fetchInvoiceTable);
        return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails', 'status'])->make(true);
    }

    public function filteringOfInvoiceAjaxHandler(Request $request)
    {
        $chooseMethod = $request->input('chooseMethod');
        switch ($chooseMethod) {
            case 'FilertingByStaff':
                $staffId = $request->input('staffId');
                $whereToFetch = ['rawQuery' => 'sender = ? ', 'bindParams' => [$staffId]];

                $dataToFetch = ['invoice_id', 'invoice_number', 'due_amount', 'sender', 'receiver', 'payment_by', 'attachment', 'start_date', 'invoice_status'];
                $fetchInvoiceTable = Invoice::getInstance()->getInvoiceDetails($whereToFetch, $dataToFetch);

                $invoiceDetails = $this->invoiceDatatble($fetchInvoiceTable);
                return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails', 'status'])->make(true);
            case 'FilertingByTime':
                if ($request->input('time') == 'today') {
                    $whereToFetch = ['rawQuery' => "created_at >= " . time() . " - 86400"];
                }
                if ($request->input('time') == '7 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)"];
                }
                if ($request->input('time') == '30 days') {
                    $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 30 DAY)"];
                }
                $dataToFetch = ['invoice_id', 'invoice_number', 'sender', 'due_amount', 'receiver', 'payment_by', 'attachment', 'start_date', 'invoice_status'];
                $fetchInvoiceTable = Invoice::getInstance()->getInvoiceDetails($whereToFetch, $dataToFetch);

                $invoiceDetails = $this->invoiceDatatble($fetchInvoiceTable);
                return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails', 'status'])->make(true);
            case 'FilertingByView':
                $whereToFetch = ['rawQuery' => "from_unixtime(created_at) >= DATE_SUB(now(), INTERVAL 7 DAY)"];
                $dataToFetch = ['invoice_id', 'invoice_number', 'sender', 'due_amount', 'receiver', 'payment_by', 'attachment', 'start_date', 'invoice_status'];
                $fetchInvoiceTable = Invoice::getInstance()->getInvoiceDetails($whereToFetch, $dataToFetch);

                $invoiceDetails = $this->invoiceDatatble($fetchInvoiceTable);
                return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails', 'status'])->make(true);
            case 'FilertingByMonth':

                $date = $request->input('mnthValue');

                $dataToFetch = ['invoice_id', 'invoice_number', 'due_amount', 'sender', 'receiver', 'payment_by', 'attachment', 'invoice_status', 'start_date'];
                $fetchInvoiceTable = Invoice::getInstance()->fetchAllInvoiceData($dataToFetch);

                $invoiceDetails = new Collection();

                foreach (json_decode($fetchInvoiceTable) as $k => $data) {
                    if (date("F Y", $data->start_date) == $date) {
                        $invoiceNumber = $data->invoice_number;
                        $invoiceSenderId = $data->sender;
                        $invoiceReceiverId = $data->receiver;
                        $whereToFindS = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceSenderId]];
                        $whereToFindR = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceReceiverId]];
                        $dataToFInd = ['name', 'role'];
                        $senderName = User::getInstance()->getUserDetails($whereToFindS, $dataToFInd);
                        $receiverName = User::getInstance()->getUserDetails($whereToFindR, $dataToFInd);

                        $role = json_decode($senderName) ? json_decode($senderName)[0]->role : '';

                        if ($role == 'A')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Admin]';
                        if ($role == 'M')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Manager]';
                        if ($role == 'S')
                            $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Staff]';

                        $role = json_decode($receiverName) ? json_decode($receiverName)[0]->role : '';

                        if ($role == 'A')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Admin]';
                        if ($role == 'M')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Manager]';
                        if ($role == 'S')
                            $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Staff]';

                        $startDate = date('Y-m-d', $data->start_date);
                        $payBy = $data->payment_by. '-' . $data->due_amount;
                        $dataId = $data->invoice_id;
                        $invoiceFile = json_decode($data->attachment);
                        $invoiceFile = array_map(function ($h) {
                            return $this->api_url . $h;
                        }, $invoiceFile);
                        $invoiceFile = json_encode($invoiceFile);

                        if ($data->invoice_status == 0) {
                            $status = '<p class="custom_text_danger">Unpaid</p>';
                        } else {
                            $status = '<p class="text-success">Paid</p>';
                        }

                        $invoiceDetails->push([
                            'serialNumber' => $k + 1,
                            'inviceNumber' => $invoiceNumber,
                            'sender' => $msgSenderName,
                            'receiver' => $msgReceiverName,
                            'startDate' => $startDate,
                            'paymentBy' => $payBy,
                            'status' => $status,
                            'attachFile' => '<a class="custom_text_info attachmentBtn" data-id="' . $dataId . '"><span class="fa fa-download"></span>Paymentdetails.pdf</a>',
                            'viewDetails' => '<a href="/admin/invoice-comment/' . $dataId . '" class="custom_text_danger viewInvoiceDetails" data-id="' . $dataId . '" >View Details</a>',
                        ]);
                    }
                }
                return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails', 'status'])->make(true);
        }
    }

    public function invoiceDatatble($fetchInvoiceTable)
    {
        $invoiceDetails = new Collection();

        foreach (json_decode($fetchInvoiceTable) as $k => $data) {
            $invoiceNumber = $data->invoice_number;
            $invoiceSenderId = $data->sender;
            $invoiceReceiverId = $data->receiver;
            $whereToFindS = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceSenderId]];
            $whereToFindR = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceReceiverId]];
            $dataToFInd = ['name', 'role'];
            $senderName = User::getInstance()->getUserDetails($whereToFindS, $dataToFInd);
            $receiverName = User::getInstance()->getUserDetails($whereToFindR, $dataToFInd);

            $role = json_decode($senderName) ? json_decode($senderName)[0]->role : '';

            if ($role == 'A')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Staff]';

            $role = json_decode($receiverName) ? json_decode($receiverName)[0]->role : '';

            if ($role == 'A')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Staff]';

            $startDate = date('Y-m-d', $data->start_date);
            $payBy = $data->payment_by . '-' . $data->due_amount;
            $dataId = $data->invoice_id;
            $invoiceFile = json_decode($data->attachment);
            $invoiceFile = array_map(function ($h) {
                return $this->api_url . $h;
            }, $invoiceFile);
            $invoiceFile = json_encode($invoiceFile);

            if ($data->invoice_status == 0) {
                $status = '<p class="custom_text_danger">Unpaid</p>';
            } else {
                $status = '<p class="text-success">Paid</p>';
            }

            $invoiceDetails->push([
                'serialNumber' => $k + 1,
                'inviceNumber' => $invoiceNumber,
                'sender' => $msgSenderName,
                'receiver' => $msgReceiverName,
                'startDate' => $startDate,
                'paymentBy' => $payBy,
                'status' => $status,
                'attachFile' => '<a class="custom_text_info attachmentBtn" data-id="' . $dataId . '"><span class="fa fa-download"></span>Paymentdetails.pdf</a>',
                'viewDetails' => '<a href="/admin/invoice-comment/' . $dataId . '" class="custom_text_danger viewInvoiceDetails" data-id="' . $dataId . '" >View Details</a>',
            ]);
        }
        return $invoiceDetails;
    }

    /**
     * fetchFile
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 2nd-May-2018
     */
    public function fetchFile(Request $request)
    {
        if ($request->isMethod('post')) {
            $invoiceId = $request->input('invoiceId');
            $dataToFind = ['attachment'];
            $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
            $query = Invoice::getInstance()->getInvoiceDetails($whereToFind, $dataToFind);
            $invoiceFile = json_decode(json_decode($query)[0]->attachment);
            $invoiceFile = array_map(function ($h) {
                return $this->api_url . $h;
            }, $invoiceFile);
            return json_encode(['status' => 200, 'data' => $invoiceFile]);
        }
    }

    /**
     * insertInvoiceComment
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     */
    public function insertInvoiceComment(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'insertInvoiceComment':
                    $invoiceId = $request->input('invoiceId');

                    $whereToFindRecipient = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
                    $fetchQuery = json_decode(Invoice::getInstance()->getInvoiceDetails($whereToFindRecipient));
                    $commentData = $request->input('comment');
                    $commentedBy = Session::get('co_admin')['id'];

                    $fileDataArr = [];
                    foreach ($request->all() as $key => $value) {
                        if (strpos($key, 'commentFiles') === 0) {
                            $fileDataArr[] = $value;
                        }
                    }

                    $allUploadedFiles = array_map(function ($file) {
                        $response = $this->fileUpload($file);
                        return json_decode($response)->data;
                    }, $fileDataArr);

                    $dataToInsert = [
                        'invoice_id' => $invoiceId,
                        'comments' => $commentData,
                        'comment_by' => $commentedBy,
                        'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                        'comment_posted_on' => time(),
                        'created_at' => time(),
                        'updated_at' => time()
                    ];
                    $notifyType = 7; //for comment in invoice
                    $type = 1;
                    $insertFeedData = $this->insertNotification($invoiceId, $fetchQuery[0]->sender, '', '', $notifyType, $type);
                    $queryToInsert = InvoiceComment::getInstance()->insertInvoiceCommentData($dataToInsert);
                    if ($queryToInsert) {
                        return json_encode(['status' => 200, 'message' => 'Commented Successfully', 'data' => time(), 'id' => $queryToInsert, 'file' => $allUploadedFiles]);
                    } else
                        return json_encode(['status' => 400, 'message' => 'Please Try Again']);
            }
        }
    }

    /**
     * insertNotification
     * @param $ids
     * @param $names
     * @param $projName
     * @param $notifyType
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 16th-Apr-2018
     */
    public function insertNotification($invoiceId = null, $id, $name, $projName, $notifyType, $type)
    {
        $receiverId = $id;
        $senderId = Session::get('co_admin')['id'];
        if ($notifyType === 7) {
            $senderMessage = 'You comments on invoice module.';
//            $receiverMessage = 'Admin posted comment for Invoice.';
            $receiverMessage[] = ['id' => $invoiceId, 'message' => 'Admin posted comment for Invoice.'];
        } else if ($notifyType === 8) {
            $senderMessage = 'You comments on invoice module.';
            $receiverMessage[] = ['id' => $invoiceId, 'message' => 'Admin has successsfully Paid and The Transaction id is ' . $name . '.'];
        } else if ($notifyType === 9) {
            $senderMessage = 'You comments on invoice module.';
//            $receiverMessage = 'Admin Makes your Invoice status as ' . $name . '.';
            $receiverMessage[] = ['id' => $invoiceId, 'message' => 'Admin Makes your Invoice status as ' . $name . '.'];
        }

        $dataToInsert = [
            'sender_id' => $senderId,
            'receiver_id' => $receiverId,
            'sender_message' => $senderMessage,
            'receiver_message' => json_encode($receiverMessage),
            'notify_type' => $notifyType,
            'notification_status' => 0,
            'created_at' => time(),
            'updated_at' => time()
        ];
        $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
        return $queryToInsert;
    }

    /**
     * fileUpload
     * @param Request $request
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 11th-Apr-2018
     */
    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'adminuploads/files/' . time() . $num;
//            $fileName = date('d_m') . '_' . time() . '_' . $num . '.' . $file->getClientOriginalExtension();
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePath($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url . '/' . $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    /**
     * fetchInvoiceData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     */
    public function fetchInvoiceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'fetchInvoiceAndComments':
                    $invoiceId = $request->input('invoiceId');
                    $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
                    $fetchInvoiceData = Invoice::getInstance()->getInvoiceDetails($whereToFind);

                    $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
                    $fetchCommentData = json_decode(InvoiceComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
                    $commentArray = [];
                    if ($fetchCommentData) {
                        foreach ($fetchCommentData as $k => $val) {
                            $commentPostedOn = date('d F Y H:i:s', $val->comment_posted_on);
                            $commentBy = $val->comment_by;
                            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                            $dataToFInd = ['name', 'role', 'profile_pic'];
                            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                            if ($getUserDetails[0]->role == 'A') {
                                $commentBy = 'Admin';
                            } else if ($getUserDetails[0]->role == 'S') {
                                $commentBy = $getUserDetails[0]->name . '_user';
                            } else if ($getUserDetails[0]->role == 'M') {
                                $commentBy = $getUserDetails[0]->name . '_manager';
                            }
                            $commentArray[] = [
                                'invoice_comment_id' => $val->invoice_comment_id,
                                'comment' => $val->comments,
                                'commentBy' => $commentBy,
                                'commentPostedOn' => $commentPostedOn,
                                'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                                'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                            ];
                        }
                    }

                    $dueAmmount = json_decode($fetchInvoiceData)[0]->due_amount;
                    $date = date('Y-m-d', json_decode($fetchInvoiceData)[0]->start_date);
                    $getPaymentIds = $this->getUserdata(json_decode($fetchInvoiceData)[0]->sender, json_decode($fetchInvoiceData)[0]->payment_by);

                    $InvoiceDetailsArr[] = [
                        'dueAmount' => $dueAmmount,
                        'dueDate' => $date,
                        'paymentBy' => json_decode($fetchInvoiceData)[0]->payment_by,
                        'paymentId' => $getPaymentIds,
                        'invoiceStatus' => json_decode($fetchInvoiceData)[0]->invoice_status
                    ];

                    if ($fetchInvoiceData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $InvoiceDetailsArr, 'comments' => $commentArray ? $commentArray : []]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
                    }
            }
        }
    }

    /**
     * invoiceComment
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-June-2018
     */
    public function invoiceComment($id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $invoiceId = $id;
        $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
        $fetchInvoiceData = Invoice::getInstance()->getInvoiceDetails($whereToFind);
        if (json_decode($fetchInvoiceData)) {
            $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
            $fetchCommentData = json_decode(InvoiceComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
            $commentArray = [];
            if ($fetchCommentData) {
                foreach ($fetchCommentData as $k => $val) {
                    $commentPostedOn = $val->comment_posted_on;
                    $commentBy = $val->comment_by;
                    $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                    $dataToFInd = ['name', 'role', 'profile_pic'];
                    $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                    if ($getUserDetails[0]->role == 'A') {
                        $commentBy = 'Admin';
                    } else if ($getUserDetails[0]->role == 'S') {
                        $commentBy = $getUserDetails[0]->name . '_user';
                    } else if ($getUserDetails[0]->role == 'M') {
                        $commentBy = $getUserDetails[0]->name . '_manager';
                    }
                    $commentArray[] = [
                        'invoice_comment_id' => $val->invoice_comment_id,
                        'comment' => $val->comments,
                        'commentBy' => $commentBy,
                        'commentPostedOn' => $commentPostedOn,
                        'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                        'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                    ];
                }
            }

            $dueAmmount = json_decode($fetchInvoiceData)[0]->due_amount;
            $date = date('Y-m-d', json_decode($fetchInvoiceData)[0]->start_date);
            $getPaymentIds = $this->getUserdata(json_decode($fetchInvoiceData)[0]->sender, json_decode($fetchInvoiceData)[0]->payment_by);

            $InvoiceDetailsArr[] = [
                'invoiceId' => $id,
                'dueAmount' => $dueAmmount,
                'dueDate' => $date,
                'paymentBy' => json_decode($fetchInvoiceData)[0]->payment_by,
                'paymentId' => $getPaymentIds,
                'invoiceStatus' => json_decode($fetchInvoiceData)[0]->invoice_status,
                'message' => json_decode($fetchInvoiceData)[0]->message,
                'subject' => json_decode($fetchInvoiceData)[0]->subject,
                'enddate' => date('Y-m-d', json_decode($fetchInvoiceData)[0]->end_date)
            ];

            if ($fetchInvoiceData) {
                return view('Admin::Dashboard/invoiceComment', ['userData' => json_decode($allStaffName),
                    'managerData' => json_decode($allManagerName),
                    'projectName' => json_decode($allProjectName),
                    'data' => json_encode($InvoiceDetailsArr),
                    'comments' => $commentArray ? json_encode($commentArray) : json_encode([])
                ]);
            } else {
                return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
            }
        } else {
            return view('Admin::Dashboard/accessDenied');
        }
    }

    /**
     * getInvoiceComment
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-June-2018
     */
    public function getInvoiceComment(Request $request)
    {
        $invoiceId = $request->input('invoiceId');
        $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
        $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
        $fetchCommentData = json_decode(InvoiceComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
        $commentArray = [];
        if ($fetchCommentData) {
            foreach ($fetchCommentData as $k => $val) {
                $commentPostedOn = $val->comment_posted_on;
                $commentBy = $val->comment_by;
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                $dataToFInd = ['name', 'role', 'profile_pic'];
                $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                if ($getUserDetails[0]->role == 'A') {
                    $commentBy = 'Admin';
                } else if ($getUserDetails[0]->role == 'S') {
                    $commentBy = $getUserDetails[0]->name . '_user';
                } else if ($getUserDetails[0]->role == 'M') {
                    $commentBy = $getUserDetails[0]->name . '_manager';
                }
                $commentArray[] = [
                    'invoice_comment_id' => $val->invoice_comment_id,
                    'comment' => $val->comments,
                    'commentBy' => $commentBy,
                    'commentPostedOn' => $commentPostedOn,
                    'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                    'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                ];
            }
            return json_encode(['status' => 200,
                'comments' => $commentArray ? $commentArray : []
            ]);
        } else {
            return json_encode(['status' => 400, 'message' => 'Not Fetched the Data.Please Try Again.', 'data' => null]);
        }
    }

    /**
     * getUserdata
     * @param $id
     * @param $type
     * @return mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     */
    public function getUserdata($id, $type)
    {
        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFInd = ['name', 'role', 'profile_pic', 'paypalEmail', 'mPesaNumber'];
        $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
        if ($type == 'mPesa') {
            return $getUserDetails[0]->mPesaNumber;
        } else
            return $getUserDetails[0]->paypalEmail;
    }

    /**
     * deleteInvoiceData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     */
    public function deleteInvoiceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'deleteInvoiceComment':
                    $commentId = $request->input('invoiceCommentId');
                    $whereData = [
                        'rawQuery' => 'invoice_comment_id = ?',
                        'bindParams' => [$commentId]
                    ];
                    $deleteInvoiceComment = InvoiceComment::getInstance()->deleteComment($whereData);
                    if ($deleteInvoiceComment == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comments Details Deleted Successfully.',
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Deleted. Please Try Again to delete the Record.',
                        ]);
                    }
            }
        }
    }

    /**
     * updateInvoiceData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-May-2018
     */
    public function updateInvoiceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $invoiceId = $request->input('invoiceId');
            $whereData = [
                'rawQuery' => 'invoice_id = ?',
                'bindParams' => [$invoiceId]
            ];
            $dataToUpdate = ['invoice_status' => $request->input('invoiceStatus') == "paid" ? 1 : 0];
            $fetchQuery = json_decode(Invoice::getInstance()->getInvoiceDetails($whereData));
            $updateQuery = Invoice::getInstance()->updateInvoiceData($whereData, $dataToUpdate);
            $notifyType = 9;
            $type = 0;
            $insertFeedData = $this->insertNotification($invoiceId, $fetchQuery[0]->sender, $request->input('invoiceStatus'), '', $notifyType, $type);
            if ($updateQuery == true) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Invoice Status Updated Successfully.',
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Not Updated. Please Try Again to update the Record.',
                ]);
            }
        }
    }

    /**
     * updateInvoiceComment
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-June-2018
     */
    public function updateInvoiceComment(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->all()) {
                $data = [
                    'rawQuery' => 'invoice_comment_id = ?',
                    'bindParams' => [$request->input('invoiceCommentId')]
                ];
                $getCommentDetails = json_decode(InvoiceComment::getInstance()->getCommentData($data));

                if ($getCommentDetails[0]->comments == $request->input('comment')) {
                    return json_encode(['status' => 400, 'message' => 'No Data has to be Updated']);
                } else {
                    $dataToUpdate = [
                        'comments' => $request->input('comment') ? $request->input('comment') : $getCommentDetails->comments,
                        'comment_posted_on' => time(),
                        'updated_at' => time(),
                    ];

                    $updatedData = InvoiceComment::getInstance()->updateComment($data, $dataToUpdate);
                    if ($updatedData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comment Updated Successfully!.'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Updated. Please Try again.',
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Found.',
                ]);
            }
        }
    }

    /**
     * sendTransationId
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-July-2018
     */
    public function sendTransationId(Request $request)
    {
        if ($request->isMethod('post')) {
            $notifyType = 8;
            $type = 0;
            $invoiceId = $request->input('invoiceId');
            $transactionId = $request->input('transationId');

            $whereToFindRecipient = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
            $fetchQuery = json_decode(Invoice::getInstance()->getInvoiceDetails($whereToFindRecipient));

            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$fetchQuery[0]->sender]];
            $dataToFInd = ['name', 'email', 'paypalEmail', 'mPesaNumber'];
            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
            $receiverDate = date('m/d/Y', $fetchQuery[0]->created_at);

            if ($fetchQuery[0]->payment_by == 'mPesa')
                $payBy = $fetchQuery[0]->payment_by . ' [' . $getUserDetails[0]->mPesaNumber == '' ? $getUserDetails[0]->mPesaNumber : '[Not Given' . ']';
            else
                $payBy = $fetchQuery[0]->payment_by . ' [' . $getUserDetails[0]->paypalEmail == '' ? $getUserDetails[0]->paypalEmail : '[Not Given' . ']';

            $insertFeedData = $this->insertNotification($invoiceId, $fetchQuery[0]->sender, $transactionId, '', $notifyType, $type);
            $sendEmailForInvoice = $this->sendEmail($invoiceId, $fetchQuery[0]->sender, $getUserDetails[0]->email, $fetchQuery[0]->invoice_number, $getUserDetails[0]->name, $receiverDate, $payBy, $transactionId, $fetchQuery[0]->due_amount);
            if ($insertFeedData) {
                return json_encode(['status' => 200, 'message' => 'Transaction Id sent to Sender Successfully']);
            }
        }
    }

    /**
     * sendEmail
     * @param $id
     * @param $email
     * @param $invoiceNum
     * @param $senderName
     * @param $date
     * @param $paymentBy
     * @param $transactionId
     * @param $amount
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 7th-August-2018
     */
    public function sendEmail($id, $userId, $email, $invoiceNum, $senderName, $date, $paymentBy, $transactionId, $amount)
    {
        $timezone = functionToTimezone(Session::get('co_admin')['id']);
        if (json_decode($timezone)[0]->timezone == null)
            date_default_timezone_set('Asia/Kolkata');
        else
            date_default_timezone_set(json_decode($timezone)[0]->timezone);
        $time = date('D,M jS,h:i A', time());
//        $link = $this->api_url . '/staff/invoice-comment/' . $id;
        $link = $this->api_url . '/staff/invoicePaid/' . $userId . '/' . $id;
        $image = $this->api_url . '/images/logo3.png';


        $from = new \SendGrid\Email(null, env('sendgrid_emailid'));
        $subject = "Invoice Paid By Client";
        $to = new \SendGrid\Email(null, $email);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Invoice Paid By Client</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$time</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    min-width:600px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td><h2>Invoice Paid By Client</h2></td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Invoice Number</b></td>
                <td style=\"padding-bottom: 10px;\">: $invoiceNum</td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Sender</b></td>
                <td style=\"padding-bottom: 10px;\">: $senderName</td>
            </tr>
            
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Received Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $date</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Payment Method</b></td>
                <td style=\"padding-bottom: 10px;\">: $paymentBy</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Transaction ID</b> </td>
                <td style=\"padding-bottom: 10px;\">: $transactionId</td>
            </tr>
              <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Amount Paid</b></td>
                <td style=\"padding-bottom: 10px;\">: $amount</td>
            </tr>
             

            <tr>
        <td style=\"padding-top:40px;\"><a href=$link style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" >Check Details</a>
         
        </td>
      </tr>
        </table>
    </center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = "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";
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
    }


}