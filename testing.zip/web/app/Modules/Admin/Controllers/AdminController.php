<?php


/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 3/23/2018
 * Time: 1:28 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 * @since 23-Mar-2018
 */

namespace App\Modules\Admin\Controllers;

use App\Modules\Admin\Models\InviteLink;
use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor.
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * register
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function register(Request $request)
    {
        if ($request->isMethod('post')) {
            $userName = $request->input('username');
            $name = $request->input('name');
            $emailid = $request->input('email');
            $password = $request->input('password');

            $whereToFind = ['rawQuery' => 'email = ?',
                'bindParams' => [$emailid]
            ];
            $dataToFind = ['username', 'email'];
            $findDetails = User::getInstance()->getUserData($whereToFind, $dataToFind);
            if ($findDetails) {
                return json_encode([
                    'status' => 400,
                    'message' => 'Emailid Already Exist,Please Try with Another Emailid!'
                ]);
            } else {
                $dataToInsert = [
                    'name' => $name,
                    'username' => $userName,
                    'password' => Hash::make($password),
                    'email' => $emailid,
                    'role' => "A",
                    'created_at' => time(),
                    'updated_at' => time()
                ];
                $insertAdminData = User::getInstance()->insertUserData($dataToInsert);
                if ($insertAdminData == true) {
                    return json_encode([
                        'status' => 200,
                        'message' => 'Registered Successfully!'
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Not Registered ,Please Try Again!'
                    ]);
                }
            }
        }
        return view('Admin::Auth/register');
    }

    /**
     * login
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function login(Request $request)
    {
        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $password = $request->input('password');
            $remember = $request->input('remember');
            $chooseRaw = 'username';
            if (strpos($email, '@') !== false) {
                $chooseRaw = 'email';
            }
            $whereToFind = ['rawQuery' => $chooseRaw . ' = ? and role = ?',
                'bindParams' => [$email, "A"]
            ];
            $findDetails = User::getInstance()->getUserData($whereToFind);
            if ($findDetails) {
                if (Hash::check($password, $findDetails->password)) {
                    if ($remember == 'on') {
                        $rememberToken = $remember;
                    } else {
                        $rememberToken = '';
                    }
                    if (Auth::attempt([$chooseRaw => $email, 'password' => $password], $rememberToken)) {
                        $whereToFind = [
                            'rawQuery' => 'id=?',
                            'bindParams' => [Auth::id()]
                        ];
                        $findUserData = User::getInstance()->getUserData($whereToFind);
                        $sessionName = 'co_admin';
                        Session::put($sessionName, (array)$findUserData);

                        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
                        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
                        Session::put('co_admin.totalNotification', count($totalNotification));

                        /* To store all session Ids in DB */
                        if ($findUserData->session_id == '') {
                            $sessionArray[] = $request->getSession()->getId();
                        } else {
                            $allSesssionData = json_decode($findUserData->session_id);
                            foreach ($allSesssionData as $k => $val) {
                                if (!(file_exists(storage_path() . '/framework/sessions/' . $val))) {
                                    unset($allSesssionData[$k]);
                                }
                            }
                            array_push($allSesssionData, $request->getSession()->getId());
                            foreach ($allSesssionData as $k => $data) {
                                $sessionArray[] = $data;
                            }
                        }

                        $dataToUpdate = ['session_id' => json_encode($sessionArray), 'timezone' => $request->input('timezone')];
                        $whereToUpdate = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_admin')['id']]];
                        $updateQuery = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);

                        $next = null;
                        if (isset($request['next']))
                            $next = $request['next'];

                        return json_encode([
                            'status' => 200,
                            'message' => 'Welcome! You have successfully logged in!!',
                            'data' => $findUserData,
                            'next' => $next
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'You Entered Wrong Emailid/Password!',
                            'data' => null
                        ]);
                    }
                } else {
                    return json_encode([
                        'status' => 402,
                        'message' => 'Please Enter Correct Password!',
                        'data' => null
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Your Emailid is not Registered with us!!',
                    'data' => null
                ]);
            }
        }
        if (Session::get('co_admin')) {
            return redirect('/admin/dashboard');
        } else {
            return view('Admin::Auth/login');
        }
    }

    /**
     * forgotPassword
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function forgotPassword(Request $request)
    {
        if ($request->isMethod('post')) {
            $email = $request->input('email');
            $starEmail = preg_replace_callback('/(\w)(.*?)(\w)(@.*?)$/s', function ($matches) {
                return $matches[1] . preg_replace("/\w/", "*", $matches[2]) . $matches[3] . $matches[4];
            }, $email);
            $whereToFind = ['rawQuery' => 'email = ?',
                'bindParams' => [$email]
            ];
            $findDetails = User::getInstance()->getUserData($whereToFind);
            if ($findDetails) {
                $confirmation_code = str_random(30);
                $from = new \SendGrid\Email(null, env('sendgrid_emailid'));
                $subject = "Forgot Password Link";
                $to = new \SendGrid\Email(null, $email);
                $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html lang='en-US'>
<head>
    <meta charset='utf-8'>
</head>
<body>
<h2>Forgot Password Link</h2>

<div>
    Plaese click on this link  <a href=" . $this->api_url . "/admin/reset-password/" . $confirmation_code . ">
     to reset your password.
</div>

</body>
</html>");
                $mail = new \SendGrid\Mail($from, $subject, $to, $content);
//                $apiKey = "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";
                $apiKey = env('sendgrid_api_key');
                $sg = new \SendGrid($apiKey);
                $response = $sg->client->mail()->send()->post($mail);
                $whereToUpdate = ['rawQuery' => 'email=?', 'bindParams' => [$email]];
                $dataToUpdate = ['password_token' => $confirmation_code];
                $updateData = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                if ($updateData) {
                    return json_encode([
                        'status' => 200,
                        'message' => 'Link Has Been Sent To Your ' . $starEmail . ', Please Check.'
                    ]);
                } else {
                    return json_encode([
                        'status' => 400,
                        'message' => 'Mail not Sent.Something Went Wrong!'
                    ]);
                }
            } else {
                return json_encode([
                    'status' => 401,
                    'message' => 'Please Enter Your Registered Emailid!',
                    'data' => null
                ]);
            }
        }
        return view('Admin::Auth/forgotpassword');
    }

    /**
     * resetPassword
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public
    function resetPassword(Request $request)
    {
        if ($request->isMethod('post')) {
            $newPassword = $request->input('newPassword');
            $token = $request->input('token');
            $confirmPassword = Hash::make($request->input('confirmPassword'));
            $whereToFind = [
                'rawQuery' => 'password_token=?',
                'bindParams' => [$token]
            ];
            $findData = User::getInstance()->getUserData($whereToFind);
            if ($findData) {
                $getEmail = DB::table('users')->first();
                $where = [
                    'rawQuery' => 'email=?',
                    'bindParams' => [$getEmail->email]
                ];
                $checkPassword = User::getInstance()->getUserData($where);
                if (Hash::check($newPassword, $checkPassword->password)) {
                    return json_encode([
                        'status' => 401,
                        'message' => 'Password is matching with old password. Please Choose Another Password.!'
                    ]);
                } else {
                    $whereToUpdate = ['rawQuery' => 'password_token=?', 'bindParams' => [$token]];
                    $dataToUpdate = ['password' => $confirmPassword, 'password_token' => ''];
                    $updateData = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
                    if ($updateData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Your password Changed successfully'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Password not updated! Please try again.'
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Link has been Expired..'
                ]);
            }
        }
        return view('Admin::Auth/resetpassword');
    }

    /**
     * sendInvitationLink
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 6th-May-2018
     */
    public
    function sendInvitationLink(Request $request)
    {
        if ($request->isMethod('post')) {
            $confirmation_code = str_random(30);
            $email = $request->input('email');
            $whereToFind = [
                'rawQuery' => 'email = ?',
                'bindParams' => [$email]
            ];
            $dataToFind = ['username', 'email'];
            $checkExistEmail = User::getInstance()->getUserData($whereToFind, $dataToFind);
            if ($checkExistEmail) {
                return json_encode([
                    'status' => 401,
                    'message' => 'Email-Id Already Exist,Please Try with Another Email-Id!'
                ]);
            } else {
                $name = explode('@', $email)[0];
                $timezone = functionToTimezone(Session::get('co_admin')['id']);
                if (json_decode($timezone)[0]->timezone == null)
                    date_default_timezone_set('Asia/Kolkata');
                else
                    date_default_timezone_set(json_decode($timezone)[0]->timezone);
                $time = date('D,M jS,h:i A', time());
                $image = $this->api_url . '/images/logo3.png';
                $portfolioType = $request->input('type');
                if ($portfolioType === '2') {
                    $link = '<a href=' . $this->api_url . '/staff/sign-up/' . $confirmation_code . '';
                    $btnName = 'Click Here to Join as Staff';
                } else {
                    $link = '<a href=' . $this->api_url . '/manager/sign-up/' . $confirmation_code . '';
                    $btnName = 'Join as Manager';
                }
                $from = new \SendGrid\Email(null, env('sendgrid_emailid'));
                $subject = "Invitation Link";
                $to = new \SendGrid\Email(null, $email);
                $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
  <title>Welcome Mail</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
  <center>
    <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
      <tr>
        <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
        <td align=\"right\" style=\"font-size: 13px;\">$time</td>
      </tr>
    </table>
    <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    max-width:650px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;
                  line-height: 1.5rem;\">

      <tr>
        <td style=\"padding-top:20px;
                   padding-bottom:10px;\">Hi $name,</td>
      </tr>
      <tr style=\"padding-top:5px;padding-bottom:20px;\">
        <td style=\"padding-bottom: 10px;\">Welcome to cloud office.<br>

Please confirm this email within 24 Hours. <br>

By confirming it means you are in compliance with our terms and conditions.</td>
      </tr>
       
      <tr style=\"padding-top:40px;padding-bottom:0px;\">
        <td>Sincerely,</td>
      </tr>
      <tr><td>Cloud office management.</td></tr>
       <tr>
        <td style=\"padding-top:40px;\"><a name=$link style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" >$btnName</a>
         
        </td>
      </tr>
    </table>
  </center>
</body>

</html>");
                $mail = new \SendGrid\Mail($from, $subject, $to, $content);
                $apiKey = env('sendgrid_api_key');
                $sg = new \SendGrid($apiKey);
                $response = $sg->client->mail()->send()->post($mail);
                if ($response) {
                    $dataToInsert = [
                        'email_id' => $email,
                        'project_name' => $request->input('project'),
                        'portfolio' => $request->input('type'),
                        'token' => $confirmation_code,
                        'created_at' => time(),
                        'updated_at' => time()
                    ];
                    $queryToInsertData = InviteLink::getInstance()->insertInvitaionData($dataToInsert);
                    if ($queryToInsertData == true)
                        return json_encode(['status' => 200, 'message' => 'Invitation Link Send Successfully']);
                } else
                    return json_encode(['status' => 400, 'message' => 'Not Send,Please Try again!!']);
            }
        }
    }

    /**
     * staffSignup
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 4th-May-2018
     */
    public
    function staffSignup()
    {
        return view('Staff::register');
    }

    /**
     * accountSetting
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-Mar-2018
     */
    public function accountSetting()
    {
        if (Session::get('co_admin')) {
            $allProjectName = functionToGetProjectData();
            $allStaffName = functionToGetStaffData();
            $allManagerName = functionToGetMangerData();
            $whereToFind = [
                'rawQuery' => 'id=?',
                'bindParams' => [Session::get('co_admin')['id']]
            ];
            $result = User::getInstance()->getUserData($whereToFind);
            return view('Admin::Dashboard/profilesetting', ['data' => $result, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
        } else {
            return view('Admin::Auth/login');
        }
    }

    public function checkExistEmail(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->input('data') === Session::get('co_admin')['email']) {
                return json_encode(['status' => 200, 'message' => 'Email id Not Exist']);
            } else {
                $whereToFind = ['rawQuery' => 'email = ?', 'bindParams' => [$request->input('data')]];
                $checkEmail = json_decode(User::getInstance()->getUserDetails($whereToFind));
                if (!$checkEmail) {
                    return json_encode(['status' => 200, 'message' => 'Email id Not Exist']);
                } else {
                    return json_encode(['status' => 400, 'message' => 'This Email Id Already Exist!!Please Choose Another']);
                }
            }
        }
    }

    /**
     * updateProfileAjaxHandler
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-Mar-2018
     */
    public function updateProfileAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $admin = Session::get('co_admin');
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'changePassword':
                    $currPassword = $request->input('currentPassword');
                    $newPassword = $request->input('newPassword');

                    $whereToFInd = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_admin')['id']]];
                    $checkPassword = User::getInstance()->getUserData($whereToFInd);

                    if (Hash::check($currPassword, $checkPassword->password)) {
                        if (Hash::check($newPassword, $checkPassword->password)) {
                            return json_encode(['status' => 400, 'message' => 'New Password is matching with Old password. Please Choose Another.!']);
                        } else {
                            $dataToUpdate = [
                                'password' => Hash::make($newPassword)
                            ];
                            $updateData = User::getInstance()->updateUserData($whereToFInd, $dataToUpdate);
                            if ($updateData == true) {

                                $dataToGet = ['session_id'];
                                $whereToGet = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_admin')['id']]];
                                $fetchQuery = json_decode(User::getInstance()->getUserDetails($whereToGet, $dataToGet));

                                /* Destroy all browser session data..*/
                                foreach (json_decode($fetchQuery[0]->session_id) as $k => $val) {
                                    File::delete(storage_path() . '/framework/sessions/' . $val);
                                }

                                $dataToUpdate = ['session_id' => ''];
                                $updateQuery = User::getInstance()->updateUserData($whereToGet, $dataToUpdate);
                                Session::forget('co_admin');

                                return json_encode(['status' => 200, 'message' => 'Password Changed successfully!!Please Login with New Credentials.']);
                            } else {
                                return json_encode(['status' => 400, 'message' => 'Password not Changed successfully. Please Try Again!.']);
                            }
                        }
                    } else {
                        return json_encode(['status' => 401, 'message' => 'You Entered Wrong Current Password, Please Enter your current password!']);
                    }
                    break;
                case 'updateProfilePic':
//                    if ($request->hasFile('imageFile')) {
//                        $imageName = 'admin_' . $admin['id'] . '_' . time() . '.jpg';
//                        $filePath = uploadImageToStoragePath(Input::file('imageFile'), '', $imageName);
//
//                        if ($filePath) {
//                            $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [$admin['id']]];
//                            $dataToUpdate = ['profile_pic' => '/adminuploads/files/' . $filePath];
//
//                            $result = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
//                            Session::put('co_admin.profile_pic', '/adminuploads/files/' . $filePath);
//                            if ($result) {
//                                $deleteImage = deleteImageFromPublicPath($admin['profile_pic']);
//                                if ($deleteImage || $admin['profile_pic'] == null) {
//                                    Session::put('co_admin', array_merge($admin, $dataToUpdate));
//                                    return json_encode(['status' => 200, 'message' => 'Your Avatar Updated successfully.', 'profilepic' => $this->api_url . '/adminuploads/files/' . $filePath]);
//                                }
//                            }
//                        } else {
//                            return json_encode(['status' => 200, 'message' => 'Sorry, there was an error uploading your file.']);
//                        }

                    $dataToUpdate = ['profile_pic' => $request->input('imageFile')];
                    $updateData = $this->updateData($dataToUpdate);
                    if ($updateData) {
                        Session::put('co_admin', array_merge($admin, $dataToUpdate));
                        return json_encode(['status' => 200, 'message' => 'Your Avatar Updated successfully.', 'profilepic' => $request->input('imageFile')]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Sorry, there was an error uploading your file.']);
                    }
//                    } else {
//                        return json_encode(['status' => 400, 'message' => 'Request does not have any file.']);
//                    }
                    break;
                case 'updateProfileInfo':
                    if ($request->input('data')) {
                        $dataToUpdate = $request->input('data');
                        $updateData = $this->updateData($dataToUpdate);
                        if ($updateData) {
                            return json_encode(['status' => 200, 'message' => 'Your Profile Details Updated successfully!!']);
                        } else {
                            return json_encode(['status' => 400, 'message' => 'Not Updated,Please Try Again!!']);
                        }
                    } else {
                        return json_encode(['status' => 400, 'message' => 'No Data Has to be Updated!!']);
                    }
                case 'saveCopyscapeCreds':
                    if ($request->isMethod('post')) {
                        $webConfigPath = base_path() . '/config/copyscapeCreds.php';

                        $fileContent = "<?php
            return [
                'copyscape_username'=>'" . $request->all()['username'] . "',
                'copyscape_api_key'=>'" . $request->all()['apiKey'] . "'
            ];";
                        file_put_contents($webConfigPath, $fileContent);
                        return json_encode(['status' => 200, 'message' => 'Successfully Credential Saved!']);
                    }
            }
        }
    }

    /**
     * updateData
     * @param $userData
     * @return int
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 6th-May-2018
     */
    public
    function updateData($userData)
    {
        $dataToUpdate = $userData;
        $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_admin')['id']]];
        $queryToUpdate = User::getInstance()->updateUserData($whereToUpdate, $dataToUpdate);
        return $queryToUpdate;
    }

    /**
     * checkOldPassowordExist
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 29th-Mar-2018
     */
    public
    function checkOldPassowordExist(Request $request)
    {
        if ($request->isMethod('post')) {
            $oldpwdData = $request->input('oldPasswordData');
            $where = [
                'rawQuery' => 'id=?',
                'bindParams' => [Session::get('co_admin')['id']]
            ];
            $checkPassword = User::getInstance()->getUserData($where);

            if (Hash::check($oldpwdData, $checkPassword->password)) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Password is matching with old password'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Entered Current Password is not matching with Old Password!'
                ]);
            }
        }
    }

    public function setSession(Request $request)
    {
        if ($request->isMethod('post')) {
            if (Session::get('co_admin.checkModal') == null) {
                $sessionSata = 1;
            } else if (Session::get('co_admin.checkModal') == 1) {
                $sessionSata = 0;
            } else {
                $sessionSata = 1;
            }
            Session::put('co_admin.checkModal', $sessionSata);
            Session::save();
            return json_encode(['status' => 200, 'data' => Session::get('co_admin.checkModal')]);
//            dd(Session::get('co_admin.checkModal'));
        }
    }

    /**
     * logout
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 25th-Mar-2018
     */
    public
    function logout()
    {
        Session::forget('co_admin');
        return redirect('/admin/login');
    }
}
