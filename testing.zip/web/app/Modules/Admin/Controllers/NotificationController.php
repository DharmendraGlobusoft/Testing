<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/10/2018
 * Time: 6:58 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Admin\Controllers;

use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class NotificationController extends Controller
{
    public function feedPage()
    {
        ini_set('memory_limit', '-1');
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();

        $dataToFetch = ['t1.notification_id', 't1.receiver_message', 't1.created_at', 't1.notify_type', 't2.name', 't2.role', 't2.profile_pic'];
        $whereToFetch = ['rawQuery' => 'receiver_id = ?', 'bindParams' => [Session::get('co_admin')['id']]];
        $sortingOrder = ['col' => 'created_at', 'order' => 'Desc'];
        $skip = 0;
        $limit = 15;
        $allFeedData = json_decode(Notification::getInstance()->fetchFeedData($sortingOrder, $whereToFetch, $dataToFetch, $skip, $limit));
        foreach ($allFeedData as $k => $val) {
            if ($val->role == 'M') {
                $val->name = $val->name . '[Manager]';
            } else if ($val->role == 'S') {
                $val->name = $val->name . '[Staff]';
            } else {
                $val->name = 'Admin';
            }
        }
        $dataToUpdate = ['notification_status' => '1'];
        $updateFeedStatus = Notification::getInstance()->updateNotificationDetails($whereToFetch, $dataToUpdate);

        $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
        $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
        Session::put('co_admin.totalNotification', count($totalNotification));
        return view('Admin::Dashboard/feed', ['allFeed' => $allFeedData, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    public function fetchNotificationData(Request $request)
    {
        if ($request->isMethod('post')) {
            $skip = $request->input('skip');
            $limit = $request->input('limit');
            $dataToFetch = ['t1.notification_id', 't1.receiver_message', 't1.created_at', 't1.notify_type', 't2.name', 't2.role', 't2.profile_pic'];
            $whereToFetch = ['rawQuery' => 'receiver_id = ?', 'bindParams' => [Session::get('co_admin')['id']]];
            $sortingOrder = ['col' => 'created_at', 'order' => 'Desc'];
            $allFeedData = json_decode(Notification::getInstance()->fetchFeedData($sortingOrder, $whereToFetch, $dataToFetch, $skip, $limit));
            foreach ($allFeedData as $k => $val) {
                if ($val->role == 'M') {
                    $val->name = $val->name . '[Manager]';
                } else if ($val->role == 'S') {
                    $val->name = $val->name . '[Staff]';
                } else {
                    $val->name = 'Admin';
                }
            }
            if ($allFeedData) {
                return json_encode(['status' => 200, 'data' => $allFeedData]);
            }
        }
    }

    public function getTotalNotiifcation(Request $request)
    {
        if ($request->isMethod('post')) {
            $whereToFetch = ['rawQuery' => 'receiver_id = ? and notification_status=?', 'bindParams' => [Session::get('co_admin')['id'], 0]];
            $totalNotification = json_decode(Notification::getInstance()->getNotificationDetails($whereToFetch));
            Session::put('co_admin.totalNotification', count($totalNotification));
            return json_encode(['status' => 200, 'totalNotification' => count($totalNotification)]);
        }
    }
}