<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/17/2018
 * Time: 12:03 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Admin\Controllers;

use App\Modules\Admin\Models\Notification;
use App\Modules\Admin\Models\Project;
use App\Modules\Admin\Models\Resource;
use App\Modules\Admin\Models\User;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class ResourceController extends Controller
{
    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor..
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * resourcePage
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function resourcePage()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $resourceData = $this->allResourceDetails();
        return view('Admin::Dashboard/resource', ['allResourceData' => $resourceData['allResourceData'], 'latestResource' => $resourceData['latestResource'], 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * @return array
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function allResourceDetails()
    {
        $dataToFind = ['*'];
        $sortingOrder = ['col' => 'created_at', 'order' => 'DESC'];
        $getAllResourceData = json_decode(Resource::getInstance()->fetchAllResource($dataToFind, $sortingOrder));

        $resourceDataArr = [];
        foreach ($getAllResourceData as $k => $data) {

            $path = $data->resource_content;
            $resourceContent = Storage::get($path);

            $bgColor = $this->extractContent($resourceContent, 'src=', '>');
            $resourceDataArr[] = [
                'id' => $data->resource_id,
                'title' => $data->resource_title,
                'imagePath' => json_decode($data->resource_image),
                'content' => $resourceContent,
                'shortImage' => $bgColor,
                'attach_files' => json_decode($data->attachment_files),
                'startDate' => date("F j, Y", $data->created_at)
            ];
        }
        $latestResource = array_slice($resourceDataArr, 0, 4, true);
        return ['allResourceData' => $resourceDataArr, 'latestResource' => $latestResource];
    }

    /**
     * @param $str
     * @param $start
     * @param $end
     * @return bool|string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-Apr-2018
     */
    public function extractContent($str, $start, $end)
    {
        $lastPos = 0;
        $positions = array();
        $color = array();
        $final = array();
        while (($lastPos = strpos($str, $start, $lastPos)) !== false) {
            $positions[] = $lastPos;
            $lastPos = $lastPos + strlen($start);
        }
        $newStr = $str;
        if ($positions) {
            foreach ($positions as $value) {
                $newStr = substr($str, strpos($str, $start));
                array_push($color, substr($str, $value, strpos($newStr, $end)));
            }
            $color[0] = substr($color[0], strlen('"src='));
            $color[0] = substr($color[0], 0, strpos($color[0], '"'));
            return $color[0] ? $color[0] : '/images/default.png';
        } else {
            return '/images/blog2.png';
        }
    }

    /**
     * getContents
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function getContents(Request $request)
    {
        $resId = $request->input('resourceId');
        $allData = $this->getContentsById($resId);
//        $dataToFind = ['resource_id', 'resource_title', 'resource_content', 'resource_image', 'created_at'];
//        $whereToFind = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resId]];
//        $query = json_decode(Resource::getInstance()->getResourceDetails($whereToFind, $dataToFind));
//        $path = $query[0]->resource_content;
//        $resourceContent = Storage::get($path);
//        $resourceDataArr[] = [
//            'id' => $query[0]->resource_id,
//            'title' => $query[0]->resource_title,
//            'imagePath' => json_decode($query[0]->resource_image),
//            'content' => $resourceContent,
//            'date' => date('d-m-Y', $query[0]->created_at)
//        ];
        return json_encode(['status' => 200, 'data' => $allData]);
    }

    function getContentsById($id)
    {
        $resId = $id;
        $dataToFind = ['resource_id', 'resource_title', 'resource_content', 'resource_image','attachment_files', 'created_at'];
        $whereToFind = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resId]];
        $query = json_decode(Resource::getInstance()->getResourceDetails($whereToFind, $dataToFind));
        $path = $query[0]->resource_content;
        $resourceContent = Storage::get($path);
        $resourceDataArr[] = [
            'id' => $query[0]->resource_id,
            'title' => $query[0]->resource_title,
            'imagePath' => json_decode($query[0]->resource_image),
            'content' => $resourceContent,
            'date' => date('d-m-Y', $query[0]->created_at),
            'attach_files' => json_decode($query[0]->attachment_files),
        ];
//        return json_encode(['status' => 200, 'data' => $resourceDataArr]);
        return $resourceDataArr;
    }

    /**
     * addResourcePage
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function addResourcePage()
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $allStaffManagerData = array_merge(json_decode($allStaffName), json_decode($allManagerName));
        return view('Admin::Dashboard/addresource', ['allData' => $allStaffManagerData, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * showMoreResources
     * @param Request $request
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function showMoreResources(Request $request, $id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $resourceData = $this->allResourceDetails();
        $allData = $this->getContentsById($id);
        return view('Admin::Dashboard/showMoreResource', ['data'=>$allData,'latestResource' => $resourceData['latestResource'], 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * insertResourceData
     * @param Request $request
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function insertResourceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $resourceTitle = $request->input('resourceTitle') ? $request->input('resourceTitle') : '';
            $catName = $request->input('categoryName') ? $request->input('categoryName') : '';
            $resourceContent = $request->input('content');
            $id = time() . '_content.txt';
            $destinationPath = 'contentFiles/123/' . $id;
            Storage::put($destinationPath, $resourceContent);


            $resourcePrivacy = $request->input('privacyStatus');
            $allProjects = $request->input('projects');
            $allStaffs = $request->input('staffs');
            if ($resourcePrivacy == 'public') {
                $privacy = 0;
                $allProjectsData = [];
                $allAssigneedUsers = [];
            } else {
                $privacy = 1;
                if ($allProjects) {
                    $allProjects = explode(',', $request->input('projects'));
                    $allProjectsData = array_map(function ($name) {
                        $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$name]];
                        $projectDataToFInd = ['project_id'];
                        $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);
                        return $projectId ? json_decode($projectId)[0]->project_id : '';
                    }, $allProjects);
                }

                if ($allStaffs) {
                    $allStaffs = explode(',', $request->input('staffs'));
                    $allAssigneedUsers = array_map(function ($name) {
                        $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$name]];
                        $dataToFInd = ['id'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return $getUserDetails ? json_decode($getUserDetails)[0]->id : '';
                    }, $allStaffs);


                }
            }

            $fileDataArr = [];
            foreach ($request->all() as $key => $value) {
                if (strpos($key, 'resourseFileData') === 0) {
                    $fileDataArr[] = $value;
                }
            }

            $allUploadedFiles = array_map(function ($file) {
                $response = $this->fileUpload($file);
                return json_decode($response)->data;
            }, $fileDataArr);


            $dataToInsert = [
                'resource_title' => $resourceTitle,
                'resource_content' => $destinationPath,
                'resource_privacy' => $privacy,
                'category_name' => $catName,
                'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                'project_ids' => $allProjects !== null ? json_encode($allProjectsData) : '',
                'staff_ids' => $allStaffs ? json_encode($allAssigneedUsers) : '',
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsertData = Resource::getInstance()->insertResourceData($dataToInsert);
            if ($queryToInsertData) {
                $allIds=array_merge(json_decode(functionToGetStaffData()),json_decode(functionToGetMangerData()));
                foreach ($allIds as $k=>$v){
                    $allIdData[]=$v->id;
                }
                $notifyType = 30; //for creating Resouce
                $insertFeedData = $this->insertNotification($queryToInsertData, $allIdData, '', '', $notifyType, '');

                if ($allStaffs) {
                    $notifyType = 30; //for creating Resouce
                    $insertFeedData = $this->insertNotification($queryToInsertData, $allAssigneedUsers, '', '', $notifyType, '');
                }


                return json_encode(['status' => 200, 'message' => 'Blog Created successfully']);
            }
        }
    }

    public function editResourceData(Request $request)
    {
        if ($request->isMethod('post')) {
//            dd($request->all());
            $resourceTitle = $request->input('resourceTitle') ? $request->input('resourceTitle') : '';
            $resourceContent = $request->input('content');
            $id = time() . '_content.txt';
            $destinationPath = 'contentFiles/123/' . $id;
            Storage::put($destinationPath, $resourceContent);


            $resourcePrivacy = $request->input('privacyStatus');
            $allProjects = $request->input('projects');
            $allStaffs = $request->input('staffs');
            if ($resourcePrivacy == 'public') {
                $privacy = 0;
                $allProjectsData = [];
                $allAssigneedUsers = [];
            } else {
                $privacy = 1;

                if ($allProjects) {
                    $allProjectsData = array_map(function ($name) {
                        $whereToFindProject = ['rawQuery' => 'project_name = ?', 'bindParams' => [$name]];
                        $projectDataToFInd = ['project_id'];
                        $projectId = Project::getInstance()->getProjectDetails($whereToFindProject, $projectDataToFInd);
                        return $projectId ? json_decode($projectId)[0]->project_id : '';
                    }, $allProjects);
                }


                if ($allStaffs) {
                    $allAssigneedUsers = array_map(function ($name) {
                        $whereToFindStaff = ['rawQuery' => 'username = ?', 'bindParams' => [$name]];
                        $dataToFInd = ['id'];
                        $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                        return $getUserDetails ? json_decode($getUserDetails)[0]->id : '';
                    }, $allStaffs);
                }

            }

            $whereToUpdate = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$request->input('id')]];
            $dataToUpdate = [
                'resource_title' => $resourceTitle,
                'resource_content' => $destinationPath,
                'resource_privacy' => $privacy,
                'project_ids' => $allProjects !== null ? json_encode($allProjectsData) : '',
                'staff_ids' => $allStaffs ? json_encode($allAssigneedUsers) : '',
                'updated_at' => time()
            ];
            $queryToUpdateData = Resource::getInstance()->updateResource($whereToUpdate, $dataToUpdate);
            if ($queryToUpdateData) {
                return json_encode(['status' => 200, 'message' => 'Blog Updated successfully']);
            }
        }
    }

    public function deleteResource(Request $request)
    {
        if ($request->isMethod('post')) {
            $id = $request->input('id');
            $whereToDelete = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$id]];
            $deleteQuery = Resource::getInstance()->deleteResourceDetails($whereToDelete);
            if ($deleteQuery) {
                return json_encode(['status' => 200, 'message' => 'Resource Deleted Successfully!']);
            } else {
                return json_encode(['status' => 400, 'message' => 'Resource Not Deleted , Please Try Again!']);
            }
        }
    }

    public function editResource(Request $request, $id)
    {
        $resouceId = $id;
        $dataToFind = ['resource_id', 'resource_title', 'resource_content', 'resource_privacy', 'project_ids', 'staff_ids'];
        $whereToFind = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resouceId]];
        $query = json_decode(Resource::getInstance()->getResourceDetails($whereToFind, $dataToFind));
        $path = $query[0]->resource_content;
        $resourceContent = Storage::get($path);

        $staffId = json_decode($query[0]->staff_ids);
        $projectId = json_decode($query[0]->project_ids);
        if ($staffId) {
            $getAllStaffDetails = array_map(function ($staffId) {
                $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$staffId]];
                $dataToFInd = ['name', 'username', 'role'];
                $getUserDetails = User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd);
                return json_decode($getUserDetails) ? json_decode($getUserDetails)[0]->username : '';
            }, $staffId);
        }
        if ($projectId) {
            $getAllProjectDetails = array_map(function ($projectId) {
                $whereToFindPro = ['rawQuery' => 'project_id = ?', 'bindParams' => [$projectId]];
                $dataToFInd = ['project_name'];
                $getProjectDetails = Project::getInstance()->getProjectDetails($whereToFindPro, $dataToFInd);
                return json_decode($getProjectDetails) ? json_decode($getProjectDetails)[0]->project_name : '';
            }, $projectId);
        }

        $resourceDataArr = [
            'id' => $query[0]->resource_id,
            'title' => $query[0]->resource_title,
            'resourcePrivacy' => $query[0]->resource_privacy === 0 ? 'Public' : 'Private',
            'projectIds' => $projectId ? $getAllProjectDetails : '',
            'staffIds' => $staffId ? $getAllStaffDetails : ''
        ];
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $allStaffManagerData = array_merge(json_decode($allStaffName), json_decode($allManagerName));

        return view('Admin::Dashboard/resourceEditor', ['content' => $resourceContent, 'resourceData' => json_encode($resourceDataArr), 'allData' => $allStaffManagerData, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * fileUpload
     * @param $file
     * @return string
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 19th-May-2018
     */
    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'adminuploads/files/' . time() . $num;
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePath($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url . '/' . $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    public function insertNotification($id = null, $ids, $names, $projName, $notifyType, $dataType)
    {
        foreach ($ids as $k => $v) {
            $receiverId = $v;
            $senderId = Session::get('co_admin')['id'];
            $senderMessage = '';
            $receiverMessage = [];
            if ($notifyType == 0) {
                $type = 'Issue';
                $receiverMessage[] = ['id' => $id, 'pId' => $names, 'pName' => $projName, 'message' => 'Admin assigned ' . $type . ' to you in ' . $projName . ' Project.'];
            } else if ($notifyType == 1) {
                $type = 'Task';
                $receiverMessage[] = ['id' => $id, 'pId' => $names, 'pName' => $projName, 'message' => 'Admin assigned ' . $type . ' to you in ' . $projName . ' Project.'];
            } else if ($notifyType == 10) {
                $senderMessage = 'You posted comment for ' . $projName . ' Project';
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'message' => 'Admin posted comment for Task in ' . $projName . '.'];
            } else if ($notifyType == 11) {
                $senderMessage = 'You posted comment for ' . $projName . ' Project';
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 17) {
                $receiverMessage[] = ['id' => $id, 'pName' => $projName, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            } else if ($notifyType == 18) {
                $receiverMessage[] = ['id' => $id, 'pId' => $projName, 'msg' => $dataType, 'pName' => $names, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            }  else if ($notifyType == 30) {
                $receiverMessage[] = ['id' => $id, 'pId' => $names, 'msg' => $dataType, 'pName' => $projName, 'message' => 'Admin posted comment for Issue in ' . $projName . '.'];
            }

            $dataToInsert = [
                'sender_id' => $senderId,
                'receiver_id' => $receiverId,
                'sender_message' => $senderMessage,
                'receiver_message' => json_encode($receiverMessage),
                'notify_type' => $notifyType,
                'notification_status' => 0,
                'created_at' => time(),
                'updated_at' => time()
            ];
            $whereToFind = ['rawQuery' => 'receiver_id = ?', 'bindParams' => [$senderId]];
            $queryToFind = json_decode(Notification::getInstance()->getNotificationDetails($whereToFind));
            if (count($queryToFind) > 25) {
                $sortingOrder = ['col' => 'created_at', 'order' => 'Desc'];
                $limit = 1;
                $queryTodelete = Notification::getInstance()->deleteNotification($whereToFind, $sortingOrder, $limit);
                $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
            } else {
                $queryToInsert = Notification::getInstance()->insertNotificationData($dataToInsert);
            }

        }
    }

}