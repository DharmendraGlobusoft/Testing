<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur || UI Developer">
    <meta name="author" content="Bandana Sahu || Web Developer">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/assets/css/normalize.css">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/css/themify-icons.css">
    <link rel="stylesheet" href="/assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/assets/scss/style.css">
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .errSpan {
            float: right;
            margin-right: 6px;
            margin-top: -31px;
            position: relative;
            z-index: 2;
            color: red;
        }

        .focused {
            border: solid 1px red;
        }

        .popover1 {
            /*border: 2px dotted deepskyblue;*/
            font-size: 12px;
            text-align: center;
            font-weight: bold;
            color: dodgerblue;
        }


    </style>
</head>

<body class="bg-dark" style="background-image: url(/images/cloudbg5.png);">

<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a>
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form">
                <form>
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Login</h4>
                    <div class="form-group">
                        <label>Email-Id/Username</label>
                        <input type="text" name="email" id="email" class="form-control" placeholder="Email">
                        <i class="fa fa fa-exclamation-circle errSpan errEmail"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover1"
                           data-content=""></i>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" id="password" class="form-control"
                               placeholder="Password">
                        <i class="fa fa fa-exclamation-circle errSpan errPassword"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover2"
                           data-content=""></i>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="remember" id="remember"> Remember Me
                        </label>
                        <label class="pull-right">
                            <a href="/admin/forgot-password">Forgotten Password?</a>
                        </label>
                    </div>
                    <i class="fa fa-spinner fa-spin spinnerClass" style="position: absolute;
margin-top: 2.5%;
margin-left: 15%;color: #212121;display: none"></i>
                    <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30 loginBtn"
                            style="margin: 3% 0;">Sign in
                    </button>

                    {{--<div class="register-link m-t-15 text-center">--}}
                    {{--<p>Don't have account ? <a href="/admin/register" style="color:#0e94f6;"> Sign Up Here</a></p>--}}
                    {{--</div>--}}
                </form>
            </div>
        </div>
    </div>
</div>


<script src="/assets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/assets/js/popper.min.js"></script>
<script src="/assets/js/plugins.js"></script>
<script src="/assets/js/main.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

<script src="/assets/js/toastr/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>
<script>
    $(document).ready(function () {
        window.history.pushState(null, "", window.location.href);
        window.onpopstate = function () {
            window.history.pushState(null, "", window.location.href);
        };

        var tz = jstz.determine(); // Determines the time zone of the browser client
        var timezone = tz.name();
        console.log('Your timezone is: ' + timezone);

        $('[data-toggle="popover1"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Your Valid Email Id Or Username.'
        });

        $('[data-toggle="popover2"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Your Valid Password which accepts alphabets,numbers and a special character.'
        });

        $('[data-toggle="popover3"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Valid Password which accepts alphabets,numbers and a special character.'
        });

        let emailid, password, remember;
        let loginValidateForm = function () {
            if (!(password.match(/^(?=.*[0-9])(?=.*[!@#$%^&()*])[a-zA-Z0-9!@#$%^&()*]{6,16}$/))) {
                // toastr.error('<b>Please Enter Valid Password which accepts alphabets,numbers and a special charcter.</b>', {timeOut: 2000});
                $('.errPassword').css('display', 'block').removeAttr('data-toggle').attr('data-toggle', 'popover3');
                $('#password').addClass("focused");
                return false;
            } else {
                return true;
            }
        };

        $(document.body).on('keyup', '#email', function () {
            $('.errEmail').css('display', 'none');
        });
        $(document.body).on('keyup', '#password', function () {
            $('.errPassword').css('display', 'none');
        });
        $('#email').blur(function () {
            $(this).removeClass("focused");
        });
        $('#password').blur(function () {
            $(this).removeClass("focused");
        });


        $(document.body).on('click', '.loginBtn', function (e) {
            e.preventDefault();
            emailid = $('#email').val();
            password = $('#password').val();
            if ($('#remember').prop('checked') === true) {
                remember = 'on';
            } else {
                remember = 'off';
            }
            if (emailid === '' && password === '') {
                // toastr.error('Please Enter Your Emailid and Password', {timeOut: 3000});
                $('.errEmail,.errPassword').css('display', 'block');
                $('#email,#password').addClass("focused");
            } else {
                let validateData = loginValidateForm();
                if (validateData === true) {
                    $.ajax({
                        url: "/admin/login",
                        type: "post",
                        dataType: "json",
                        data: {
                            email: emailid,
                            password: password,
                            remember: remember,
                            timezone: timezone,
                            next: location.href.split('?')[1]
                        },
                        beforeSend: function () {
                            $('.spinnerClass').css('display', 'block');
                            $('.loginBtn').css('opacity', '0.2');
                        },
                        success: function (response) {
                            $('.spinnerClass').css('display', 'none');
                            $('.loginBtn').css('opacity', '');
                            if (response.status === 200) {
                                if (response['next'] != null)
                                    window.location.href = '/admin/' + response['next'].split('=')[1];
                                else
                                    window.location.href = '/admin/dashboard';
                            } else if (response.status === 401) {
                                $('.errEmail').css('display', 'block');
                                $('#email').addClass("focused").val('');
                            } else if (response.status === 402) {
                                $('.errPassword').css('display', 'block');
                                $('#password').addClass("focused").val('');
                            } else if (response.status === 403) {
                                window.location.reload(true);
                            } else {
                                $('.errEmail,.errPassword').css('display', 'block');
                                $('#email,#password').addClass("focused");
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            }
        });
    });
</script>
</body>

</html>