<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/assets/css/normalize.css">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/css/themify-icons.css">
    <link rel="stylesheet" href="/assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/assets/scss/style.css">
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .errSpan {
            float: right;
            margin-right: 6px;
            margin-top: -31px;
            position: relative;
            z-index: 2;
            color: red;
        }

        .focused {
            border: solid 1px red;
        }
    </style>
</head>

<body class="bg-dark" style="background-image: url(/images/cloudbg5.png);">
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a href="/admin/login">
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form">
                <form>
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Forgot Password</h4>
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" id="email" class="form-control" placeholder="Email">
                        <i class="fa fa fa-exclamation-circle errSpan errorEmail"
                           style="font-size:25px;color:red;display: none" aria-hidden="true" data-toggle="popover1" data-content=""></i>
                    </div>
                    <button type="button" class="btn btn-primary btn-flat m-b-15 submitBtn">Submit</button>

                </form>
            </div>
        </div>
    </div>
</div>
<script src="/assets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/assets/js/popper.min.js"></script>
<script src="/assets/js/plugins.js"></script>
<script src="/assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<script src="/assets/js/toastr/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    $(document).ready(function () {

        $('[data-toggle="popover1"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Please Enter Your Valid Email-Id.'
        });

        var emailid;
        var forgotPwdValidateForm = function () {
            if (!(emailid.match(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i))) {
                $('#email').addClass("focused");
                // toastr.error('<b>Please provide a valid email.</b>', {timeOut: 2000});
                $('.errorEmail').css('display', 'block');
                return false;
            } else {
                return true;
            }
        };

        $('#email').blur(function () {
            $(this).removeClass("focused");
        });

        $(document.body).on('keyup', '#email', function () {
            $('.errorEmail').css('display', 'none');
        });

        $(document.body).on('click', '.submitBtn', function (e) {
            e.preventDefault();
            emailid = $('#email').val();
            if (emailid === '') {
                $('.errorEmail').css('display', 'block');
                $('#email').addClass("focused");
                // toastr.error('Please Enter Your Emailid', {timeOut: 3000});
            } else {
                let validateData = forgotPwdValidateForm();
                if (validateData === true) {
                    $.ajax({
                        url: "/admin/forgot-password",
                        type: "post",
                        dataType: "json",
                        data: {
                            email: emailid
                        },
                        success: function (response) {
                            if (response.status === 200) {
                                toastr.success(response.message, {timeOut: 3000});
                            }else if (response.status === 401) {
                                $('.errorEmail').css('display', 'block');
                                $('#email').addClass("focused").val('');
                                toastr.error(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            }
        });
    });
</script>
</body>
</html>