<!DOCTYPE html>
<!--suppress CssUnusedSymbol, JSUnresolvedLibraryURL -->
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Krajee JQuery Plugins - &copy; Kartik</title>
    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">

    {{--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">--}}
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/assets/css/ratings/star-rating.css" media="all" type="text/css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    {{--<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>--}}

    <script src="/assets/js/ratings/star-rating.js" type="text/javascript"></script>
<body>
{{--<div class="container">--}}
    {{--<div class="page-header">--}}
        {{--<h2>Bootstrap Star Rating Examples--}}
            {{--<small>&copy; Kartik Visweswaran, Krajee.com</small>--}}
        {{--</h2>--}}
    {{--</div>--}}
    {{--<form>--}}
        {{--<div class="page-header">--}}
            {{--<h3>Glyphicon Star LTR</h3>--}}
        {{--</div>--}}

        <input type="text" class="rating rating-loading" value="3" data-size="xs" title="">


    {{--</form>--}}
{{--</div>--}}
</body>
<script>
    $(document).ready(function () {
        $('.rating').rating({
            filledStar: '<i class="fa fa-star"></i>',
            emptyStar: '<i class="fa fa-star-o"></i>'
        });


        $('.rating,.kv-fa').on(
            'change', function () {
                alert('====');
                console.log('Rating selected: ' + $(this).val());
            });
    });
</script>
</html>


