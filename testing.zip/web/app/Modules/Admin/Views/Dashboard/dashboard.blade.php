@extends('Admin::Dashboard/layouts.bodyLayout')

@section('title','Dashboard || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">

    {{--<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">--}}
    <style>
        .name_show p {
            color: #fff;
        }

        .modal_xsm {
            min-height: 200px;
        }

        .loaderClass {
            position: absolute;
            left: 45%;
            top: 25%;
            max-height: 200px;
        }

        a.name .name_show {
            display: none;
        }

        a.name:hover .name_show {
            display: block;
            position: absolute;
            z-index: 999;
            background: #fff;
            min-width: 5%;
            color: #fff !important;
            box-shadow: 0px 0px 15px #6A6A6A;
            margin-left: -5%;
            padding: 2%;
            background-color: #333;
            border-radius: 4px;
        }

        #addNewissue .form-control {
            display: inline-block;
        }

        #addNewMilestone .form-control {
            display: inline-block;
        }

        #editIssue .form-control {
            display: inline-block;
        }

        #editTask .form-control {
            display: inline-block;
        }

        #editMilestone .form-control {
            display: inline-block;
        }

        .widget .card-body {
            padding: 0px;
        }

        .widget .list-group {
            margin-bottom: 0;
        }

        .widget .panel-title {
            display: inline
        }

        .widget .label-info {
            float: right;
            background-color: #5489e4;
            color: #fff;
            padding: 6px 9px;
            border-radius: 50%;
        }

        .widget li.list-group-item {
            border-radius: 0;
            border: 0;
            border-top: 1px solid #ddd;
        }

        .widget li.list-group-item:hover {
            background-color: rgba(86, 61, 124, .1);
        }

        .widget .mic-info {
            color: #666666;
            font-size: 11px;
        }

        .widget .action {
            margin-top: 5px;
        }

        .widget .comment-text {
            font-size: 15px;
        }

        .widget .btn-block {
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .img-circle {
            border-radius: 50%;
        }

        .btn {
            padding: 5px 10px !important;
        }

        /*i {*/
        /*color: #fff;*/
        /*}*/

        textarea {
            /*resize: none;*/
            outline: none;
            width: 394px;
            font-family: tahoma;
            background: #f9f9f9;
        }

        textarea:focus {
            background: #fff;
        }

        input[type="submit"] {
            width: 100%;
            padding: 5px 0px;
            font-weight: bold;
            margin-top: -6px;
        }

        .content {
            width: 100%;
        }

        .comments {
            width: 80%;
            margin: 30px auto;
        }

        .insert-text {
            position: relative;
        }

        .insert-text .loading {
            position: absolute;
            bottom: -25px;
            display: none;
        }

        .insert-text .total-comment {
            position: absolute;
            bottom: -25px;
            right: 0px;
        }

        .insert-text .total-comment:before {
            content: "Total comment: ";
            font-weight: bold;
        }

        .list-comments {
            margin-top: 30px;
            border: 1px solid #ccc;
            background: #f0f0f0;
        }

        .list-comments > div {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }

        .list-comments > div:last-child {
            border-bottom: none;
        }

        .editor {
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .editor-header {
            border-bottom: 1px solid #ccc;
        }

        .editor-header a {
            display: inline-block;
            padding: 10px;
            color: #666;
        }

        .editor-header a:hover {
            color: #000;
        }

        .editor-content {
            padding: 10px;
            outline: none;
            min-height: 80px;
            background: #f9f9f9;
            border-radius: 0px 0px 5px 5px;
        }

        .editor-content:focus {
            background: #fff;
        }

        #stafflist_modal .list-group-item {
            padding: 10px 0 0 0;
            border: none;
        }

        .img-circle {

            border-radius: 50%;
        }

        .staff_list {
            border-bottom: 1px solid #d4d2d2 !important;
            padding: 6px 15px !important;
            margin: 0px;
            font-size: 15px;
        }

        /* Staff List CSS*/

        .custom_tooltip {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
        }

        .custom_tooltip .tooltiptext {
            visibility: hidden;
            width: auto;
            background-color: #3ca1eb;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            top: 70%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .custom_tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent #3ca1eb transparent;
        }

        .custom_tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        .tooltiptext.swing:before,
        .tooltiptext.swing:after {
            transform: translate3d(0, 30px, 0) rotate3d(0, 0, 1, 60deg);
            transform-origin: 0 0;
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:after {
            transform: translate3d(0, 60px, 0);
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:hover:before,
        .tooltiptext.swing:hover:after {
            opacity: 1;
            transform: translate3d(0, 0, 0) rotate3d(1, 1, 1, 0deg);
        }

        /*        Scoll bar CSS*/

        #boxscroll {
            height: 400px;
            overflow-y: auto;
        }

        /*
        }
                #boxscroll  a{
                    overflow-x: hidden ;
                    width: 100%;
                }
        */

        .nicescroll-cursors {
            background-color: rgba(70, 166, 248, 0.8) !important;
        }

        /*        Staff details modal css*/

        .details {
            list-style-type: none;
            border: 1px solid #eee;
            margin: 0;
            padding: 0;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            background: #3c4451;
            border-radius: 5px;
        }

        .details:hover {
            box-shadow: 0 8px 12px 0 rgba(0, 0, 0, 0.2)
        }

        .details .header {
            font-size: 20px;
            padding: 15px;
            color: #fff;
            background: #db3b5e;
        }

        .details li {

            padding: 18px 20px;
            color: #fff;
        }

        .details .grey {
            background-color: #e94633;
            font-size: 20px;
            color: #fff;
        }

        .staff_img_section {
            background: #fff;
            text-align: center;
        }

        .staff_img {
            width: 150px;
            border-radius: 50%;
            border: 4px solid #3ca1eb;
        }

        /*        Custom select */
        select.soflow,
        select.soflow-color {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            -webkit-border-radius: 3px;
            /*  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);*/
            -webkit-padding-end: 20px;
            -webkit-padding-start: 2px;
            -webkit-user-select: none;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            border: 1px solid #D4D1D1;
            color: #555;
            font-size: inherit;
            /*  margin: 20px;*/
            overflow: hidden;
            padding: 5px 10px;
            text-overflow: ellipsis;
            white-space: nowrap;
            /*  width: 300px;*/
        }

        select.soflow-color {
            color: #fff;
            background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#779126, #779126 40%, #779126);
            background-color: #779126;
            -webkit-border-radius: 20px;
            -moz-border-radius: 20px;
            border-radius: 20px;
            padding-left: 15px;
        }

        select.form-control:not([size]):not([multiple]) {
            height: calc(2rem + 2px);
        }

        body {
            font-size: 14px;
        }

        /*        Month select */
        .monthly-wrp {
            padding: 1em;
            top: 6px;
            z-index: 1000;
            border-radius: 3px;
            background-color: #2C3E50;
            top: 90% !important;
            left: 36% !important;
        }

        .monthly-wrp:before {
            content: "";
            border-bottom: 6px solid #2C3E50;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            position: absolute;
            top: -6px;
            left: 6px;
            z-index: 1002;
        }

        .monthly-wrp .years {
            margin-bottom: 0.8em;
            text-align: center;
        }

        .monthly-wrp .years select {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            border: 0;
            border-radius: 3px;
            width: 100%;
            height: 30px;
            -webkit-appearance: button;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            background-color: #f6f7f5 !important;
        }

        .monthly-wrp .years select:focus {
            outline: none;
        }

        .monthly-wrp table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        .monthly-wrp td {
            padding: 1px;
        }

        .monthly-wrp table button {
            width: 100%;
            border: none;
            background-color: #3ca1eb;
            color: #FFFFFF;
            font-size: 14px;
            padding: 0.4em;
            cursor: pointer;
            border-radius: 3px;
        }

        .monthly-wrp table button:hover {
            background-color: #3ca1eb;
        }

        .monthly-wrp table button:focus {
            outline: none;
        }

        .monthly-wrp table {
            width: auto !important;
        }

        /*        Month select */
        .monthly-wrp1 {
            padding: 1em;
            top: 6px;
            z-index: 1000;
            border-radius: 3px;
            background-color: #2C3E50;
            top: 90% !important;
            left: 36% !important;
        }

        .monthly-wrp1:before {
            content: "";
            border-bottom: 6px solid #2C3E50;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            position: absolute;
            top: -6px;
            left: 6px;
            z-index: 1002;
        }

        .monthly-wrp1 .years {
            margin-bottom: 0.8em;
            text-align: center;
        }

        .monthly-wrp1 .years select {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            border: 0;
            border-radius: 3px;
            width: 100%;
            height: 30px;
            -webkit-appearance: button;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            background-color: #f6f7f5 !important;
        }

        .monthly-wrp1 .years select:focus {
            outline: none;
        }

        .monthly-wrp1 table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        .monthly-wrp1 td {
            padding: 1px;
        }

        .monthly-wrp1 table button {
            width: 100%;
            border: none;
            background-color: #3ca1eb;
            color: #FFFFFF;
            font-size: 14px;
            padding: 0.4em;
            cursor: pointer;
            border-radius: 3px;
        }

        .monthly-wrp1 table button:hover {
            background-color: #3ca1eb;
        }

        .monthly-wrp1 table button:focus {
            outline: none;
        }

        .monthly-wrp1 table {
            width: auto !important;
        }

        #filter-panel {
            transition: height 200ms ease-out;
        }

        /*        Month select */

        .ui-widget-header {
            border: 0px solid #aaa !important;
            background: #fff !important;
            color: #222222 !important;
            font-weight: bold !important;
        }

        .ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {

            border: 1px solid #0000004d !important;
            background: #3ca1eb !important;
            font-weight: normal !important;
            color: #fff !important;

        }

    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Dashboard</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right"></ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Overview</strong>
                        </div>
                        <div class="card-body">

                            <div class="col-lg-4 taskClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Tasks</h4>
                                <canvas id="doughutChart"></canvas>
                            </div>
                            <div class="col-lg-4 issueClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Overview of Issues</h4>
                                <canvas id="doughutChart1"></canvas>
                            </div>
                            <div class="col-lg-4 milestoneClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Milestones</h4>
                                <canvas id="doughutChart2"></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">All Tasks</strong>
                            <button type="button" class="btn btn-info filterdealy pull-right" data-toggle="collapse"
                                    data-target="#filter-panel" style="padding: 4px 10px;margin-bottom: 15px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>
                            <div class="row">
                                <div id="filter-panel" class="collapse filter-panel">
                                    <div class="panel panel-default">
                                        <div class="panel-body" id="list">
                                            <form class="form" role="form">
                                                <div class="form-group col-xs-2 col-md-2 ">
                                                    <label class="control-label" for="pref-perpage">Time</label>
                                                    <select id="pref-perpage" class="form-control soflow filterByTime">
                                                        <option value="0">All Time</option>
                                                        <option value="1">Today</option>
                                                        <option value="2">Last 7 days</option>
                                                        <option value="3">Last 30 days</option>
                                                    </select>
                                                </div> <!-- form group [rows] -->

                                                <div class="form-group col-xs-2 col-md-2">
                                                    <label class="control-label" for="pref-perpage">Month</label>
                                                    <input class="soflow form-control filterByMonthndYear" type="text"
                                                           id="selection"
                                                           value="{{date('M Y')}}" style="font-size: inherit;">
                                                </div>
                                                <div class="form-group col-xs-4 col-md-4">
                                                    <label class="control-label" for="pref-search">Project</label>
                                                    <select id="pref-search"
                                                            class="form-control soflow filterByProject">
                                                        <option value="0">All</option>
                                                        @foreach($projectName as $K=>$val)
                                                            <option value="{{$val->project_id}}">{{$val->project_name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div><!-- form group [search] -->
                                                <div class="form-group col-xs-2 col-md-2">
                                                    <label class="control-label" for="pref-orderby">Staff</label>
                                                    <select id="pref-orderby "
                                                            class="form-control soflow filterByStaff">
                                                        <option value="0">All</option>
                                                        @foreach($userData as $i=>$v)
                                                            <option value="{{$v->id}}">{{$v->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                {{--<div class="form-group col-xs-2 col-md-2">--}}
                                                {{--<label class="control-label" for="pref-orderby">View</label>--}}
                                                {{--<select id="pref-orderby" class="form-control soflow filterByView">--}}
                                                {{--<option value="0">All</option>--}}
                                                {{--<option value="1">Latest Task(Last 7 Days)</option>--}}
                                                {{--</select>--}}
                                                {{--</div>--}}
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="taskTable1" class="table table-striped table-bordered taskTable">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    {{--<th>Id</th>--}}
                                    <th>Tasks</th>
                                    <th>Projects</th>
                                    <th class="taskPrioritySort">Priority</th>
                                    <th>Staff</th>
                                    <th>Status</th>
                                    <th>Due Date</th>
                                    <th>Task Submission</th>
                                    <th>Action</th>
                                    <th hidden>Task Priority Sort</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">All Issues</strong>
                            <button class="btn btn-info pull-right" data-toggle="modal" data-target="#addNewissue">
                                <i class="fa fa-plus-circle" aria-hidden="true"></i> Add New Issue
                            </button>
                            <button type="button" class="btn btn-info pull-right" data-toggle="collapse"
                                    data-target="#filter-panel-issue" style="padding: 4px 10px;margin: 0px 5px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>Filters
                            </button>
                            <div class="row">
                                <div id="filter-panel-issue" class="collapse filter-panel">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <form class="form" role="form">
                                                <div class="form-group col-xs-2 col-md-2 ">
                                                    <label class="control-label" for="pref-perpage">Time</label>
                                                    <select id="pref-perpage"
                                                            class="form-control soflow filterByTimeInIssue">
                                                        <option value="0">All Time</option>
                                                        <option value="1">Today</option>
                                                        <option value="2">Last 7 days</option>
                                                        <option value="3">Last 30 days</option>
                                                    </select>
                                                </div> <!-- form group [rows] -->

                                                <div class="form-group col-xs-2 col-md-2">
                                                    <label class="control-label" for="pref-perpage">Month</label>
                                                    <input class="soflow form-control filterByMonthndYear" type="text"
                                                           id="selection1"
                                                           value="{{date('M Y')}}" style="font-size: inherit;">
                                                </div>
                                                <div class="form-group col-xs-5 col-md-5">
                                                    <label class="control-label" for="pref-search">Project</label>
                                                    <select id="pref-search"
                                                            class="form-control soflow filterByProjectInIssue">
                                                        <option value="0">All</option>

                                                        @foreach($projectName as $K=>$val)
                                                            <option value="{{$val->project_id}}">{{$val->project_name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div><!-- form group [search] -->
                                                <div class="form-group col-xs-3 col-md-3">
                                                    <label class="control-label" for="pref-orderby">Staff</label>
                                                    <select id="pref-orderby "
                                                            class="form-control soflow filterByStaffInIssue">
                                                        <option value="0">All</option>
                                                        @foreach($userData as $i=>$v)
                                                            <option value="{{$v->id}}">{{$v->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                {{--<div class="form-group col-xs-2 col-md-2">--}}
                                                {{--<label class="control-label" for="pref-orderby">View</label>--}}
                                                {{--<select id="pref-orderby"--}}
                                                {{--class="form-control soflow filterByViewInIssue">--}}
                                                {{--<option value="0">All</option>--}}
                                                {{--<option value="1">Latest Issue(Last 7 Days)</option>--}}
                                                {{--</select>--}}
                                                {{--</div>--}}
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="issueTable1" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Issues</th>
                                    <th>Projects</th>
                                    <th>Severity</th>
                                    <th>Staffs</th>
                                    <th>Status</th>
                                    <th>Due Date</th>
                                    <th>Issue Submission</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Milestones</strong>
                            <button class="btn btn-info pull-right" data-toggle="modal"
                                    data-target="#addNewMilestone"><i class="fa fa-plus-circle" aria-hidden="true"></i>
                                Add New Milestone
                            </button>
                        </div>
                        <div class="card-body table-responsive">
                            <table id="milestoneTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Projects</th>
                                    <th>Milestone</th>
                                    <th>Start Date</th>
                                    <th>Due Date</th>
                                    <th>Milestone Status</th>
                                    <th>Edit</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addNewissue">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">
                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-plus-circle"></i>&nbsp;Add
                        New
                        Issue</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Select Project</label>
                            </div>

                            <select name="select" id="Select" class="form-control form-control col-md-9 projectName">
                                <option value="0">Please select</option>
                                @foreach($projectName as $k=>$val)
                                    <option value="{{$val->project_name}}"
                                            title="{{$val->project_name}}">{{$val->project_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Issue Name</label>
                            </div>
                            <input id="issueName" name="name" type="text" placeholder="Issue name"
                                   class="form-control col-md-9 issueName">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Issue Description</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="10" placeholder="Description..."
                                      class="form-control col-md-9 issueDesc"></textarea>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Due Date</label>
                            <input id="issueDueDate" name="name" type="date" placeholder="Your name"
                                   class="form-control col-md-4 issueDueDate" style="margin-left: -4px;">

                            <label class="col-md-2 control-label" style="text-align: right;" for="name">Due
                                Hours</label>
                            <input id="issueDueHours" min="1" name="name" type="number" placeholder="Hours"
                                   class="form-control col-md-2 issueDueHours">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Severity</label>
                            </div>
                            <select name="select" id="Select" class="form-control form-control col-md-3 issuePriority">
                                <option value="0">None</option>
                                <option value="1">Minor</option>
                                <option value="2">Major</option>
                                <option value="3">Critical</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Assignee</label>
                            </div>
                            <select class="assigneedUsers form-control" name="userDataInput[]"
                                    multiple="multiple">
                                {{--@foreach($userData as $k=>$val)--}}
                                {{--<option value="{{$val->name}}">{{$val->name}}</option>--}}
                                {{--@endforeach--}}
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">

                            <label for="issueAttachment" class="form__file">
                                <span class="form__file-filename" id="filename" data-placeholder="Attach file">Attach file</span>
                                <span class="form__file-browse">Browse</span>
                                <input type="file" name="issueUploadfile" class="form__file-input attachment"
                                       id="issueAttachment">

                            </label>
                            <ul class="form__files" id="attachment-files1"></ul>
                        </div>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin:4% 0;">
                        <button class="btn btn-success addIssueButton" style="padding: 6px 10px;">Add Issue</button>
                        <button type="button" class="btn btn-danger cancelIssueBtn" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addNewMilestone">
        <div class="modal-dialog" style="max-width: 730px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">
                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-plus-circle"></i>&nbsp;Add
                        New
                        Milestone</h4>
                    <button type="button" class="close cancelMilestoneBtn" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Select Project</label>
                            </div>

                            <select name="select" id="Select" class="form-control form-control col-md-9 projName">
                                <option value="0">Please select</option>
                                @foreach($projectName as $k=>$val)
                                    <option value="{{$val->project_name}}"
                                            title="{{$val->project_name}}">{{$val->project_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Milestone</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="2" placeholder="Milestone..."
                                      class="form-control col-md-9 milestoneTextarea"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Start Date</label>
                            <input id="issueDueDate" name="name" type="date" placeholder="Start Date"
                                   class="form-control col-md-3 milestoneStartDate"
                                   style="margin-left: -4px;padding: 5px 0px;">

                            <label style="text-align: right;" class="col-md-2 control-label" for="name">Due Date</label>
                            <input id="issueDueHours" name="name" type="date" placeholder="Due Date"
                                   class="form-control col-md-3 milestoneDueDate" style="padding: 5px 0px;">
                        </div>
                    </div>

                    <div class="col-lg-12" style="text-align: center;margin:4% 0;">
                        <button class="btn btn-success addMilestoneButton" style="padding: 6px 10px;">Add Milestone
                        </button>
                        <button type="button" class="btn btn-danger cancelMilestoneBtn" data-dismiss="modal">Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editIssue" style="background: rgba(73, 74, 71, 0.8) none repeat scroll 0% 0%;">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">
                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Edit Issue
                    </h4>
                    <button type="button" class="close closeEditIssueBtn" id="closeBtnId" data-dismiss="modal">&times;
                    </button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Select Project</label>
                            </div>

                            <input name="select" id="Select"
                                   class="form-control form-control col-md-9 editProjectName" value="" readonly>
                            {{--<option value="0">Please select</option>--}}
                            {{--                                @foreach($projectName as $k=>$val)--}}
                            {{--                                    <option value="{{$val->project_name}}" title="{{$val->project_name}}">{{$val->project_name}}</option>--}}
                            {{--@endforeach--}}
                            {{--</input>--}}
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Issue Name</label>
                            </div>
                            <input id="issueName" name="name" type="text" placeholder="Issue name"
                                   class="form-control col-md-9 editIssueName">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Issue Description</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="2" placeholder="Description..."
                                      class="form-control col-md-9 editIssueDesc"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Due Date</label>
                            <input id="issueDueDate" name="name" type="date" placeholder="Your name"
                                   class="form-control col-md-4 editIssueDueDate" style="margin-left: -4px;">

                            <label class="col-md-2 control-label" style="text-align: right;" for="name">Due
                                Hours</label>
                            <input id="issueDueHours" name="name" type="number" placeholder="Hours"
                                   class="form-control col-md-2 editIssueDueHours">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Severity</label>
                            </div>
                            <select name="select" id="Select"
                                    class="form-control form-control col-md-3 editIssuePriority">
                                <option value="0">None</option>
                                <option value="1">Minor</option>
                                <option value="2">Major</option>
                                <option value="3">Critical</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Assignee</label>
                            </div>
                            <select class="editAssigneedUsers form-control" name="userDataInput[]"
                                    multiple="multiple">
                                @foreach($userData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    {{--<div class="col-md-12">--}}
                    {{--<div class="form-group">--}}
                    {{--<label for="editIssueAttachment" class="form__file">--}}
                    {{--<span class="form__file-filename" id="filename" data-placeholder="Attach file">Attach file</span>--}}
                    {{--<span class="form__file-browse">Browse</span>--}}
                    {{--<input type="file" name="editIssueUploadfile" class="form__file-input attachment"--}}
                    {{--id="editIssueAttachment">--}}

                    {{--</label>--}}
                    {{--<ul class="form__files" id="attachment-files2"></ul>--}}
                    {{--</div>--}}
                    {{--</div>--}}
                    <div class="col-lg-12" style="text-align: center;margin:4% 0;">
                        <button class="btn btn-success updateIssueButton" data-backdrop="static" data-keyboard="false"
                                style="padding: 6px 10px;">Update Issue
                        </button>
                        <button type="button" class="btn btn-danger closeEditIssueBtn" data-dismiss="modal">Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editTask">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Edit
                        Task</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Select Project</label>
                            </div>

                            <input name="select" id="Select" data-placeholder="Please select"
                                   class="form-control form-control col-md-9 selectTaskProjName" readonly>


                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Task Name</label>
                            </div>
                            <input id="name" name="name" type="text" placeholder="Task name"
                                   class="form-control col-md-9 taskName">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Task Description</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="2"
                                      placeholder="Description..."
                                      class="form-control col-md-9 taskDesc"></textarea>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Due Date</label>
                            <input id="name" name="name" type="date" placeholder="Your name"
                                   class="form-control col-md-4 dueDate" style="margin: -4px;">

                            <label style="text-align: right;" class="col-md-2 control-label" for="name">Due
                                Hours</label>
                            <input id="name" name="name" min="1" type="number" placeholder="Hours"
                                   class="form-control col-md-2 dueHours">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Priority</label>
                            </div>
                            <select name="select" id="Select"
                                    class="form-control form-control col-md-3 taskPriority">
                                <option value="0">None</option>
                                <option value="1">Low</option>
                                <option value="2">Medium</option>
                                <option value="3">High</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Assignee</label>
                            </div>
                            <select class="userDataClass form-control" name="userDataInput[]"
                                    multiple="multiple">
                                @foreach($userData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12" style="text-align: center;margin:4% 0;">

                        <button class="btn btn-success updateTaskBtn" style="padding: 6px 10px;">Update Task</button>
                        <button type="button" class="btn btn-danger editTaskClose" data-dismiss="modal">Cancel</button>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editMilestone">
        <div class="modal-dialog" style="max-width: 730px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Edit
                        Milestone</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label for="select" class=" form-control-label">Select Project</label>
                            </div>

                            <input name="select" id="Select" data-placeholder="Please select"
                                   class="form-control form-control col-md-9 selectProjName" readonly>


                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Milestone</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="2" placeholder="Milestone..."
                                      class="form-control col-md-9 milestoneEditTextarea"></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Start Date</label>
                            <input id="issueDueDate" name="name" type="date" placeholder="Start Date"
                                   class="form-control col-md-3 editMilestoneStartDate"
                                   style="margin-left: -4px;padding: 5px 0px;">

                            <label style="text-align: right;" class="col-md-2 control-label" for="name">Due Date</label>
                            <input id="issueDueHours" name="name" type="date" placeholder="Due Date"
                                   class="form-control col-md-3 editMilestoneEndDate" style="padding: 5px 0px;">
                        </div>
                    </div>

                    <div class="col-lg-12" style="text-align: center;margin:4% 0;">

                        <button class="btn btn-success updateMilestoneBtn" style="padding: 6px 10px;">Update Milestone
                        </button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmModal">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete The Issue? </p>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmOkBtn" style="padding: 8px 25px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmTaskModal">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete The Task? </p>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmTaskBtn" style="padding: 8px 25px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
                {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>--}}
                {{--</div>--}}
            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmMilestoneModal">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete The Task? </p>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmMilestoneBtn" style="padding: 8px 25px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
                {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>--}}
                {{--</div>--}}
            </div>
        </div>
    </div>

    <div class="modal fade" id="stafflist_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="true">
        <div class="modal-dialog modal-sm" role="document" style="max-width: 425px;">
            <div class="modal-content modal_xsm" style="border: none;">
                <div class="modal-header" style="background-color: #3ab3d4;">
                    <h5 class="modal-title" id="exampleModalLabel" style="color: #fff;">Staff List</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body text-center p-lg"
                     style="padding: 0;max-height: 400px;overflow: auto;margin-bottom: 10px;">
                    <div class="loaderClass show">
                        <img src="/images/cloud_loading.gif" style="width: 50px;">
                    </div>
                    <div class="col-md-12" style="padding: 0;">
                        <ul class="list-group" style="text-align: left;">
                            <li class="list-group-item staff_list"><img src="images/admin1.jpg" class="img-circle"
                                                                        width="40px">
                                Siddu Venkatapur
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="/assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="/assets/js/lib/chart-js/chartjs-init.js"></script>
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
    <script src="/assets/js/jquery.mtz.monthpicker.js"></script>
    <script>
        $(function () {
            function initToolbarBootstrapBindings() {
                var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'],
                    fontTarget = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts, function (idx, fontName) {
                    fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({container: 'body'});
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });

                $('[data-role=magic-overlay]').each(function () {
                    var overlay = $(this), target = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset = $('#editor').offset();
                    $('#voiceBtn').css('position', 'absolute').offset({
                        top: editorOffset.top,
                        left: editorOffset.left + $('#editor').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg = '';
                if (reason === 'unsupported-file-type') {
                    msg = "Unsupported format " + detail;
                }
                else {
                    console.log("error uploading file", reason, detail);
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings();
            $('#editor').wysiwyg({fileUploadError: showErrorAlert});
            window.prettyPrint && prettyPrint();
        });
    </script>
    <script>
        $(function () {
            function initToolbarBootstrapBindings1() {
                var fonts1 = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'],
                    fontTarget1 = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts1, function (idx, fontName) {
                    fontTarget1.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({container: 'body'});
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });

                $('[data-role=magic-overlay]').each(function () {
                    var overlay1 = $(this), target1 = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target1.offset()).width(target1.outerWidth()).height(target1.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset1 = $('#editor1').offset();
                    $('#voiceBtn1').css('position', 'absolute').offset({
                        top: editorOffset1.top,
                        left: editorOffset1.left + $('#editor1').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn1').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg1 = '';
                if (reason === 'unsupported-file-type') {
                    msg1 = "Unsupported format " + detail;
                }
                else {
                    console.log("error uploading file", reason, detail);
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings1();
            $('#editor1').wysiwyg({fileUploadError: showErrorAlert});
            window.prettyPrint && prettyPrint();
        });
    </script>
    {{--<!-- Bandana Codes... -->==========================================================================--}}
    <script>
        // function padToTwo(number) {
        //     if (number <= 9999) {
        //         number = ("0" + number).slice(-2);
        //     }
        //     return number;
        // }
        //
        // (function ($) {
        //     $.fn.monthly = function (options) {
        //         var months = options.months || [
        //                 "January",
        //                 "February",
        //                 "March",
        //                 "April",
        //                 "May",
        //                 "June",
        //                 "July",
        //                 "August",
        //                 "September",
        //                 "October",
        //                 "November",
        //                 "December"
        //             ],
        //             Monthly = function (el) {
        //                 this._el = $(el);
        //                 this._init();
        //                 this._render();
        //                 this._renderYears();
        //                 this._renderMonths();
        //                 this._bind();
        //             };
        //
        //         Monthly.prototype = {
        //             _init: function () {
        //                 this._el.html(months[0] + " " + options.years[0]);
        //             },
        //
        //             _render: function () {
        //                 var linkPosition = this._el.offset(),
        //                     cssOptions = {
        //                         display: "none",
        //                         position: "absolute",
        //                         top:
        //                         linkPosition.top + this._el.height() + (options.topOffset || 0),
        //                         left: linkPosition.left
        //                     };
        //                 this._container = $('<div class="monthly-wrp">')
        //                     .css(cssOptions)
        //                     .appendTo($("body"));
        //             },
        //
        //             _bind: function () {
        //                 var self = this;
        //                 this._el.on("click", $.proxy(this._show, this));
        //                 $(document).on("click", $.proxy(this._hide, this));
        //                 this._yearsSelect.on("click", function (e) {
        //                     e.stopPropagation();
        //                 });
        //                 this._container.on("click", "button", $.proxy(this._selectMonth, this));
        //             },
        //
        //             _show: function (e) {
        //                 e.preventDefault();
        //                 e.stopPropagation();
        //                 this._container.css("display", "inline-block");
        //             },
        //
        //             _hide: function () {
        //                 this._container.css("display", "none");
        //             },
        //
        //             _selectMonth: function (e) {
        //                 var monthIndex = $(e.target).data("value"),
        //                     month = months[monthIndex],
        //                     year = this._yearsSelect.val();
        //                 this._el.html(month + " " + year);
        //                 if (options.onMonthSelect) {
        //                     options.onMonthSelect(monthIndex, month, year);
        //                 }
        //             },
        //
        //             _renderYears: function () {
        //                 var markup = $.map(options.years, function (year) {
        //                     return "<option>" + year + "</option>";
        //                 });
        //                 var yearsWrap = $('<div class="years">').appendTo(this._container);
        //                 this._yearsSelect = $("<select class='currentYear'>")
        //                     .html(markup.join(""))
        //                     .appendTo(yearsWrap);
        //                 var curntyear = new Date().getFullYear();
        //                 $('.currentYear :selected').text(curntyear);
        //             },
        //
        //             _renderMonths: function () {
        //                 var markup = ["<table>", "<tr>"];
        //                 $.each(months, function (i, month) {
        //                     if (i > 0 && i % 4 === 0) {
        //                         markup.push("</tr>");
        //                         markup.push("<tr>");
        //                     }
        //                     markup.push(
        //                         '<td><button data-value="' + i + '">' + month + "</button></td>"
        //                     );
        //                 });
        //                 markup.push("</tr>");
        //                 markup.push("</table>");
        //                 this._container.append(markup.join(""));
        //             }
        //         };
        //
        //         return this.each(function () {
        //             return new Monthly(this);
        //         });
        //     };
        // })(jQuery);
        //
        // let data = [];
        // var upperLimit = new Date().getFullYear() + 20;
        // for (var v = 2000; v < upperLimit; v++) {
        //     data.push(v);
        //     var year = new Date().getFullYear();
        //     console.log('==================', year);
        //     $('.currentYear :selected').text(year);
        // }
        //
        //
        // $(function () {
        //     $("#selection").monthly({
        //         years: data,
        //         topOffset: 28,
        //         onMonthSelect: function (mi, m, y) {
        //             mi = padToTwo(mi);
        //             $("#selection").val(m + " " + y);
        //             $("#monthly").val(y + "-" + mi);
        //             console.log('=================', $("#selection").val());
        //             $('#taskTable1').DataTable({
        //                 lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
        //                 processing: true,
        //                 serverSide: true,
        //                 destroy: true,
        //                 ajax: {
        //                     url: '/filteringOfTaskAjaxHandler',
        //                     method: 'post',
        //                     data: function (f) {
        //                         f.chooseMethod = 'FilertingByMonth';
        //                         f.mnthValue = $("#selection").val();
        //                     }
        //                 },
        //                 columns: [
        //                     {data: 'serialNumber', name: 'serialNumber'},
        //                     {data: 'taskName', name: 'taskName'},
        //                     {data: 'projectName', name: 'projectName'},
        //                     {data: 'priority', name: 'priority'},
        //                     {data: 'staffDetails', name: 'staffDetails'},
        //                     {data: 'status', name: 'status'},
        //                     {data: 'dueDate', name: 'dueDate'},
        //                     {data: 'taskSubmission', name: 'taskSubmission'},
        //                     {data: 'editTask', name: 'editTask'},
        //                     {data: 'taskPrioritySort', name: 'taskPrioritySort', visible: false}
        //                 ],
        //                 createdRow: function (row, data, index) {
        //                     let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
        //                     let projName = data.projName.replace(/&amp;/g, '&');
        //                     $('td', row).eq(6).attr({
        //                         'class': 'text-center'
        //                     });
        //                     $('td', row).eq(2).attr({
        //                         'data-tooltip': projName,
        //                         'style': 'word-break: break-all'
        //                     });
        //                     $('td', row).eq(1).attr({
        //                         'data-tooltip': taskDetails,
        //                         'style': 'word-break: break-all'
        //                     });
        //                 },
        //                 "order": [[0, 'desc']]
        //             });
        //         }
        //     });
        //
        // });



        let taskTableData = function (val) {
            $('#taskTable1').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                destroy: true,
                ajax: {
                    url: '/filteringOfTaskAjaxHandler',
                    method: 'post',
                    data: function (f) {
                        f.chooseMethod = 'FilertingByMonth';
                        f.mnthValue = val;
                    }
                },
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'taskName', name: 'taskName'},
                    {data: 'projectName', name: 'projectName'},
                    {data: 'priority', name: 'priority'},
                    {data: 'staffDetails', name: 'staffDetails'},
                    {data: 'status', name: 'status'},
                    {data: 'dueDate', name: 'dueDate'},
                    {data: 'taskSubmission', name: 'taskSubmission'},
                    {data: 'editTask', name: 'editTask'},
                    {data: 'taskPrioritySort', name: 'taskPrioritySort', visible: false}
                ],
                createdRow: function (row, data, index) {
                    let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(6).attr({
                        'class': 'text-center'
                    });
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': taskDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });
        };

        let issueTableData = function (val) {
            $('#issueTable1').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                destroy: true,
                ajax: {
                    url: '/filteringOfIssueAjaxHandler',
                    method: 'post',
                    data: function (f) {
                        f.chooseMethod = 'FilertingByMonth';
                        f.mnthValue = val;
                    }
                },
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'issueName', name: 'issueName'},
                    {data: 'projectName', name: 'projectName'},
                    {data: 'severity', name: 'severity'},
                    {data: 'staffDetails', name: 'staffDetails'},
                    {data: 'status', name: 'status'},
                    {data: 'dueDate', name: 'dueDate'},
                    {data: 'issueSubmission', name: 'issueSubmission'},
                    {data: 'editIssue', name: 'editIssue'},
                ],
                createdRow: function (row, data, index) {
                    let issueDetails = data.issueDetails.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(6).attr({
                        'class': 'text-center'
                    });
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': issueDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });
        };

        $('#selection1').monthpicker({
            pattern: 'mm yyyy',
            selectedYear: 2015,
            startYear: 1900,
            finalYear: 2212,
        });

        $('#selection').monthpicker({
            pattern: 'mm yyyy',
            selectedYear: 2015,
            startYear: 1900,
            finalYear: 2212,
        });

        $('#selection').monthpicker().bind('monthpicker-click-month', function (e, month) {
            var val = $("#selection").val();
            taskTableData(val)
        }).bind('monthpicker-change-year', function (e, year) {
            var val = $("#selection").val();
            // alert(year)
            // taskTableData(val)
        })

        $('#selection1').monthpicker().bind('monthpicker-click-month', function (e, month) {
            var val = $("#selection1").val();
            console.log(val);
            issueTableData(val)
        }).bind('monthpicker-change-year', function (e, year) {
            var val = $("#selection").val();
            // alert(year)
            // taskTableData(val)
        })

    </script>

    {{--<script>--}}
        {{--function padToTwo1(number) {--}}
            {{--if (number <= 9999) {--}}
                {{--number = ("0" + number).slice(-2);--}}
            {{--}--}}
            {{--return number;--}}
        {{--}--}}

        {{--(function ($) {--}}
            {{--$.fn.monthly1 = function (options) {--}}
                {{--var months = options.months || [--}}
                        {{--"January",--}}
                        {{--"February",--}}
                        {{--"March",--}}
                        {{--"April",--}}
                        {{--"May",--}}
                        {{--"June",--}}
                        {{--"July",--}}
                        {{--"August",--}}
                        {{--"September",--}}
                        {{--"October",--}}
                        {{--"November",--}}
                        {{--"December"--}}
                    {{--],--}}
                    {{--Monthly1 = function (el) {--}}
                        {{--this._el = $(el);--}}
                        {{--this._init();--}}
                        {{--this._render();--}}
                        {{--this._renderYears();--}}
                        {{--this._renderMonths();--}}
                        {{--this._bind();--}}
                    {{--};--}}

                {{--Monthly1.prototype = {--}}
                    {{--_init: function () {--}}
                        {{--this._el.html(months[0] + " " + options.years[0]);--}}
                    {{--},--}}

                    {{--_render: function () {--}}
                        {{--var linkPosition = this._el.offset(),--}}
                            {{--cssOptions = {--}}
                                {{--display: "none",--}}
                                {{--position: "absolute",--}}
                                {{--top:--}}
                                {{--linkPosition.top + this._el.height() + (options.topOffset || 0),--}}
                                {{--left: linkPosition.left--}}
                            {{--};--}}
                        {{--this._container = $('<div class="monthly-wrp1">')--}}
                            {{--.css(cssOptions)--}}
                            {{--.appendTo($("body"));--}}
                    {{--},--}}

                    {{--_bind: function () {--}}
                        {{--var self = this;--}}
                        {{--this._el.on("click", $.proxy(this._show, this));--}}
                        {{--$(document).on("click", $.proxy(this._hide, this));--}}
                        {{--this._yearsSelect.on("click", function (e) {--}}
                            {{--e.stopPropagation();--}}
                        {{--});--}}
                        {{--this._container.on("click", "button", $.proxy(this._selectMonth, this));--}}
                    {{--},--}}

                    {{--_show: function (e) {--}}
                        {{--e.preventDefault();--}}
                        {{--e.stopPropagation();--}}
                        {{--this._container.css("display", "inline-block");--}}
                    {{--},--}}

                    {{--_hide: function () {--}}
                        {{--this._container.css("display", "none");--}}
                    {{--},--}}

                    {{--_selectMonth: function (e) {--}}
                        {{--var monthIndex = $(e.target).data("value"),--}}
                            {{--month = months[monthIndex],--}}
                            {{--year = this._yearsSelect.val();--}}
                        {{--this._el.html(month + " " + year);--}}
                        {{--if (options.onMonthSelect) {--}}
                            {{--options.onMonthSelect(monthIndex, month, year);--}}
                        {{--}--}}
                    {{--},--}}

                    {{--_renderYears: function () {--}}
                        {{--var markup = $.map(options.years, function (year) {--}}
                            {{--return "<option>" + year + "</option>";--}}
                        {{--});--}}
                        {{--var yearsWrap = $('<div class="years">').appendTo(this._container);--}}
                        {{--this._yearsSelect = $("<select class='currentYear'>")--}}
                            {{--.html(markup.join(""))--}}
                            {{--.appendTo(yearsWrap);--}}
                        {{--var curntyear = new Date().getFullYear();--}}
                        {{--$('.currentYear :selected').text(curntyear);--}}
                    {{--},--}}

                    {{--_renderMonths: function () {--}}
                        {{--var markup = ["<table>", "<tr>"];--}}
                        {{--$.each(months, function (i, month) {--}}
                            {{--if (i > 0 && i % 4 === 0) {--}}
                                {{--markup.push("</tr>");--}}
                                {{--markup.push("<tr>");--}}
                            {{--}--}}
                            {{--markup.push(--}}
                                {{--'<td><button data-value="' + i + '">' + month + "</button></td>"--}}
                            {{--);--}}
                        {{--});--}}
                        {{--markup.push("</tr>");--}}
                        {{--markup.push("</table>");--}}
                        {{--this._container.append(markup.join(""));--}}
                    {{--}--}}
                {{--};--}}

                {{--return this.each(function () {--}}
                    {{--return new Monthly1(this);--}}
                {{--});--}}
            {{--};--}}
        {{--})(jQuery);--}}

        {{--let data1 = [];--}}
        {{--for (var v = 2000; v < 2099; v++) {--}}
            {{--data1.push(v);--}}
        {{--}--}}

        {{--$(function () {--}}
            {{--$("#selection1").monthly({--}}
                {{--years: data1,--}}
                {{--topOffset: 28,--}}
                {{--onMonthSelect: function (mi, m, y) {--}}
                    {{--mi = padToTwo1(mi);--}}
                    {{--$("#selection1").val(m + " " + y);--}}
                    {{--$("#monthly").val(y + "-" + mi);--}}
                    {{--console.log('=================', $("#selection1").val());--}}
                    {{--$('#taskTable1').DataTable({--}}
                        {{--lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],--}}
                        {{--processing: true,--}}
                        {{--serverSide: true,--}}
                        {{--destroy: true,--}}
                        {{--ajax: {--}}
                            {{--url: '/filteringOfTaskAjaxHandler',--}}
                            {{--method: 'post',--}}
                            {{--data: function (f) {--}}
                                {{--f.chooseMethod = 'FilertingByMonth';--}}
                                {{--f.mnthValue = $("#selection1").val();--}}
                            {{--}--}}
                        {{--},--}}
                        {{--columns: [--}}
                            {{--{data: 'serialNumber', name: 'serialNumber'},--}}
                            {{--{data: 'taskName', name: 'taskName'},--}}
                            {{--{data: 'projectName', name: 'projectName'},--}}
                            {{--{data: 'priority', name: 'priority'},--}}
                            {{--{data: 'staffDetails', name: 'staffDetails'},--}}
                            {{--{data: 'status', name: 'status'},--}}
                            {{--{data: 'dueDate', name: 'dueDate'},--}}
                            {{--{data: 'taskSubmission', name: 'taskSubmission'},--}}
                            {{--{data: 'editTask', name: 'editTask'},--}}
                            {{--{data: 'taskPrioritySort', name: 'taskPrioritySort', visible: false}--}}
                        {{--],--}}
                        {{--createdRow: function (row, data, index) {--}}
                            {{--let taskDetails = data.taskDetails.replace(/&amp;/g, '&');--}}
                            {{--let projName = data.projName.replace(/&amp;/g, '&');--}}
                            {{--$('td', row).eq(6).attr({--}}
                                {{--'class': 'text-center'--}}
                            {{--});--}}
                            {{--$('td', row).eq(2).attr({--}}
                                {{--'data-tooltip': projName,--}}
                                {{--'style': 'word-break: break-all'--}}
                            {{--});--}}
                            {{--$('td', row).eq(1).attr({--}}
                                {{--'data-tooltip': taskDetails,--}}
                                {{--'style': 'word-break: break-all'--}}
                            {{--});--}}
                        {{--},--}}
                        {{--"order": [[0, 'desc']]--}}
                    {{--});--}}
                {{--}--}}
            {{--});--}}
        {{--});--}}

    {{--</script>--}}
    <script>

        var sessionData = `{{Session::get('co_admin.checkModal')}}`;
        if (parseInt(sessionData) === 1) {
            $('body').toggleClass('open');
        }

        taskGraphical();
        issueGraphical();
        milestoneGraphical();

        /* Function for Task Graphical Represtation */
        function taskGraphical() {
            $.ajax({
                url: "/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Task'
                },
                success: function (response) {
                    if (response.length > 0) {
                        let myChart;
                        let data = response;
                        if (myChart) {
                            myChart.destroy();
                        }
                        var ctx = document.getElementById("doughutChart");
                        ctx.height = 150;
                        myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ]
                                }],
                                labels: [
                                    "Pending",
                                    "Completed"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    } else {
                        console.log('No data');
                        let data = '';
                        data = '<h4 class="mb-3" >Tasks</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Task </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        console.log(data);
                        $('.taskClass').html('').append(data);
                    }
                }
            });
        }

        /* Function for Issue Graphical Represtation */
        function issueGraphical() {
            $.ajax({
                url: "/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Issue'
                },
                success: function (response) {
                    if (response.length > 0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart1");
                        ctx.height = 150;
                        var myChart;
                        if (myChart) myChart.destroy();
                        myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"

                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"

                                    ]

                                }],
                                labels: [
                                    "Pending",
                                    "Completed"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    } else {
                        let data = '';
                        data = '<h4 class="mb-3" >Overview of Issues</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Issue </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        console.log(data);
                        $('.issueClass').html('').append(data);
                    }
                }
            });
        }

        /* Function for Milestone Graphical Represtation */
        function milestoneGraphical() {
            $.ajax({
                url: "/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Milestone'
                },
                success: function (response) {
                    if (response.length > 0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart2");
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)",
                                        "rgba(50,205,50)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)",
                                        "rgba(50,205,50)"
                                    ]
                                }],
                                labels: [
                                    "On Going",
                                    "Finished",
                                    "Overdue"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    } else {
                        let data = '';
                        data = '<h4 class="mb-3" >Milestones</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Milestone </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        console.log(data);
                        $('.milestoneClass').html('').append(data);
                    }
                }
            });
        }

        $(document).ready(function () {

            toastr.info('Welcome To Dashboard Page!', {timeOut: 5000});
            let maxLength = 80;
            $('.projectName > option').text(function (i, text) {
                if (text.length > maxLength) {
                    return text.substr(0, maxLength) + '...';
                }
            });
            $('.selectTaskProjName > option').text(function (i, text) {
                if (text.length > maxLength) {
                    return text.substr(0, maxLength) + '...';
                }
            });
            $('.editProjectName > option').text(function (i, text) {
                if (text.length > maxLength) {
                    return text.substr(0, maxLength) + '...';
                }
            });
            $('.projName > option').text(function (i, text) {
                if (text.length > maxLength) {
                    return text.substr(0, maxLength) + '...';
                }
            });
            $('.selectProjName > option').text(function (i, text) {
                if (text.length > maxLength) {
                    return text.substr(0, maxLength) + '...';
                }
            });

            let issueTextFileData = new FormData();
            let commentTaskData = new FormData();
            let commentIssueData = new FormData();
            let count = 0;
            let count1 = 0;
            let count2 = 0;

            $('#issueAttachment').on('change', function (event) {
                var imageName = 'issueTextFileData' + ++count;
                issueTextFileData.append(imageName, $('input[name=issueUploadfile]')[0].files[0]);


                var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

                // file not choosed
                if (typeof filename === 'undefined') {
                    return false;
                }


                var $file = $(this).closest('.form__file');
                $file
                    .addClass('form__file--attached')
                    .find('.form__file-filename')
                    .html(filename);

                $file
                    .find('.form__file-input')
                    .prop('disabled', true);

                // list of files
                var $files = $('#attachment-files1');

                // show files list
                if ($files.find('li').length === 0) {
                    $files.removeClass('form__files--hide').addClass('form__files--show');
                }

                // create a new item
                var $item = $('<li/>')
                    .addClass('form__files-item')
                    .addClass('form__files-item--loading')
                    .append($('<span/>').addClass('form__files-item-link').html(filename))
                    .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                    .append($('<span/>').addClass('form__files-item-progress'))
                    .append($('<input/>').attr({
                        type: 'hidden',
                        name: 'attachments[]',
                        value: '{}'
                    }));

                $files.append($item);

                // progress bar
                $item.find('.form__files-item-progress').animate({
                    width: '100%'
                }, 2000);

                $('#attachment-files1').trigger('contentChanged');

                setTimeout(function () {
                    $file.removeClass('form__file--attached');

                    $file
                        .find('.form__file-input')
                        .prop('disabled', false);

                    var v = $file.find('.form__file-filename').data('placeholder');
                    $file.find('.form__file-filename').html(v);
                    $file.find('.form__file-input').val('');

                    $item
                        .removeClass('form__files-item--loading')
                        .addClass('form__files-item--done');

                    $item.find('.form__files-item-link').replaceWith(function () {
                        var text = $.trim($(this).text());
                        return $('<a/>').attr({
                            href: '#',
                            target: '_blank'
                        }).addClass('form__files-item-link').html(text);
                    });

                    var _itemData = JSON.stringify({
                        id: uuidv4(),
                        // file: textFile,
                        name: filename,
                        url_view: '',
                        url_delete: ''
                    }, null, '');

                    $item
                        .find('input[type=hidden]')
                        .val(_itemData);

                    console.log('File uploaded: ', JSON.parse(_itemData));

                    $item.find('[data-file-remove=true]').on('click', function () {
                        var imageName = $(this).attr('imageName');
                        issueTextFileData.delete(imageName);
                        var $removeItem = $(this).closest('.form__files-item'),
                            itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                        // ajax request
                        console.log('File deleted: ', itemData.id);

                        $removeItem.addClass('form__files-item--hide');

                        // hide files list
                        if ($files.find('li').length <= 1) {
                            $files.removeClass('form__files--show').addClass('form__files--hide');
                        }

                        $('#attachment-files1').trigger('contentChanged');

                        setTimeout(function () {
                            $removeItem.remove();
                        }, 500);

                    });
                }, 2000);
            });
            $('#attachment-files1').on('contentChanged', function () {
                if ($(this).find('li').length === 0) {
                    $('#attachment-files').removeClass('form__files--show');
                } else {
                    $('#attachment-files').addClass('form__files--hide');
                }
                console.log(1);
                console.log(this);
                console.log($('li', this).length);

                // $(this).each(function() {
                //   if ($(this).length <= 1) {
                //     $(this).removeClass('form__files--show').addClass('form__files--hide');
                //   }
                // });
            });

            $('.assigneedUsers').select2({
                placeholder: "Select Your Staffs"
            });
            $('.editAssigneedUsers').select2({
                placeholder: "Select Your Staffs"
            });
            $('.userDataClass').select2({
                placeholder: "Select Your Staffs"
            });

            /* --------------------------------------------- Filteration In Task---------------------------------------------------*/

            $(document.body).on('change', '.filterByStaff', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleTaskDatatable();
                } else {
                    taskTabledata('/filteringOfTaskAjaxHandler', 'FilertingByStaff', '', staffId, '');
                }
            });

            $(document.body).on('change', '.filterByProject', function () {
                console.log($(this).val());
                let projId = $(this).val();
                if (projId == 0) {
                    handleTaskDatatable();
                } else {
                    taskTabledata('/filteringOfTaskAjaxHandler', 'FilertingByProject', '', '', projId);
                }
            });

            $(document.body).on('change', '.filterByView', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleTaskDatatable();
                } else {
                    taskTabledata('/filteringOfTaskAjaxHandler', 'FilertingByView', '', staffId, '');
                }
            });

            $(document.body).on('change', '.filterByTime', function () {
                console.log($(this).val());
                let timeVal = $(this).val();
                if (timeVal == 0) {
                    handleTaskDatatable();
                } else if (timeVal == 1) {
                    filterByTime('today');
                } else if (timeVal == 2) {
                    filterByTime('7 days');
                } else if (timeVal == 3) {
                    filterByTime('30 days');
                }
            });

            function filterByTime(val) {
                taskTabledata('/filteringOfTaskAjaxHandler', 'FilertingByTime', val, '', '');
            }

            function taskTabledata(url, FilertingByTime, val, staffId, projId) {
                $('#taskTable1').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: url,
                        method: 'post',
                        data: function (f) {
                            f.chooseMethod = FilertingByTime;
                            f.time = val;
                            f.staffId = staffId;
                            f.projId = projId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'taskName', name: 'taskName'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'priority', name: 'priority'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'status', name: 'status'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'taskSubmission', name: 'taskSubmission'},
                        {data: 'editTask', name: 'editTask'},
                        {data: 'taskPrioritySort', name: 'taskPrioritySort', visible: false}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(6).attr({
                            'class': 'text-center'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            }

            /* --------------------------------------------- Filteration In Issue---------------------------------------------------*/

            function issueTabledata(url, FilertingByTime, val, staffId, projId) {
                $('#issueTable1').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: '/filteringOfIssueAjaxHandler',
                        method: 'post',
                        data: function (f) {
                            f.chooseMethod = FilertingByTime;
                            f.time = val;
                            f.staffId = staffId;
                            f.projId = projId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'issueName', name: 'issueName'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'severity', name: 'severity'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'status', name: 'status'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'issueSubmission', name: 'issueSubmission'},
                        {data: 'editIssue', name: 'editIssue'},
                    ],
                    createdRow: function (row, data, index) {
                        let issueDetails = data.issueDetails.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(6).attr({
                            'class': 'text-center'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': issueDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            }

            $(document.body).on('change', '.filterByStaffInIssue', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleIssueDatatable();
                } else {
                    issueTabledata('/filteringOfIssueAjaxHandler', 'FilertingByStaff', '', staffId, '');
                }
            });

            $(document.body).on('change', '.filterByProjectInIssue', function () {
                console.log($(this).val());
                let projId = $(this).val();
                if (projId == 0) {
                    handleIssueDatatable();
                } else {
                    issueTabledata('/filteringOfIssueAjaxHandler', 'FilertingByProject', '', '', projId);
                }
            });

            $(document.body).on('change', '.filterByViewInIssue', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleIssueDatatable();
                } else {
                    issueTabledata('/filteringOfIssueAjaxHandler', 'FilertingByView', '', staffId, '');
                }
            });

            $(document.body).on('change', '.filterByTimeInIssue', function () {
                console.log($(this).val());
                let timeVal = $(this).val();
                if (timeVal == 0) {
                    handleIssueDatatable();
                } else if (timeVal == 1) {
                    filterByTimeInIssue('today');
                } else if (timeVal == 2) {
                    filterByTimeInIssue('7 days');
                } else if (timeVal == 3) {
                    filterByTimeInIssue('30 days');
                }
            });

            function filterByTimeInIssue(val) {
                issueTabledata('/filteringOfIssueAjaxHandler', 'FilertingByTime', val, '', '');
            }

            /* ---------------------------------------------- Issue Codes----------------------------------------------*/

            let selectProject, issueName, issueDesc, dueDate, dueHours, issuePriority, issueAssignee;

            /* Add New Issue*/
            $(document.body).on('click', '.addIssueButton', function () {
                selectProject = $('.projectName').val();
                issueTextFileData.append('projectName', selectProject);
                issueName = $('.issueName').val();
                issueTextFileData.append('issueName', issueName);
                issueDesc = $('.issueDesc').val();
                issueTextFileData.append('issueDesc', issueDesc);


                dueDate = $('.issueDueDate').val();

                var d = new Date();
                var n = d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
                console.log(n);
                var time3 = dueDate + ' ' + n;

                var dateString = time3;
                dateString = dateString.split(' ').join('T');
                var date1 = new Date(dateString.slice(0, -1));
                date1 = date1.getTime() / 1000;
                console.log('<br />' + date1);

                if (dueDate) {
                    // issueTextFileData.append('dueDate', Date.parse(dueDate) / 1000);
                    issueTextFileData.append('dueDate', date1);
                } else {
                    issueTextFileData.append('dueDate', $('.issueDueDate').val());
                }

                dueHours = $('.issueDueHours').val();
                issueTextFileData.append('dueHours', dueHours);
                issuePriority = $('.issuePriority').val(); // 0-major,1-minor,2-critical
                issueTextFileData.append('issuePriority', issuePriority);
                issueAssignee = $('.assigneedUsers').val();
                issueTextFileData.append('issueAssignee', issueAssignee);

                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

                if (selectProject === "0") {
                    toastr.error('Please Choose Your Project');
                } else if (issueName.trim() === "") {
                    toastr.error('Please Enter Your Issue Name.');
                } else if ($('.issueDueDate').val() !== "" && Date.parse(date) / 1000 > Date.parse(dueDate) / 1000) {
                    toastr.error('Due Date Should be greater than current date.');
                } else if (dueHours !== '' && dueHours < 1) {
                    toastr.error('Due Hours Should be a Positive Number.');
                }
                else {
                    $.ajax({
                        url: "/insertIssueDetails",
                        type: "post",
                        dataType: "json",
                        data: issueTextFileData,
                        contentType: false,
                        processData: false,
                        beforeSend: function () {
                            $(".addIssueButton,.cancelIssueBtn").attr('disabled', 'disabled');
                        },
                        success: function (response) {
                            if (response.status === 200) {
                                $(".addIssueButton,.cancelIssueBtn").attr('disabled', false);
                                $('#addNewissue').modal("hide").find("input,textarea,select").val('').end();
                                $('.projectName').val(0);
                                $('.issuePriority').val(0);
                                $('li.select2-selection__choice').remove();
                                $('li.form__files-item').remove();
                                $('#attachment-files').removeClass('form__files--show');
                                $('#issueTable1').DataTable().ajax.reload();
                                issueGraphical();
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            /* Cancel Issue Button */
            $(document.body).on('click', '.cancelIssueBtn', function () {
                $('#addNewissue').modal('hide').find("input,textarea,select").val('').end();
                $('.projectName').val(0);
                $('.issuePriority').val(0);
                $('li.select2-selection__choice').remove();
                $('li.form__files-item').remove();
                $('#attachment-files').removeClass('form__files--show');
            });

            $(document.body).on('change', '.projectName', function () {
                $.ajax({
                    url: "/getStaffs",
                    type: "post",
                    dataType: "json",
                    data: {
                        projectName: $(this).val()
                    },
                    success: function (response) {
                        let data = '';
                        if (response.status === 200) {

                            $.each(response.data, function (i, v) {
                                data += '<option value="' + v[0].username + '">' + v[0].name + '[' + v[0].username + ']' + '</option>'
                            });
                            $('.assigneedUsers').html('').append(data);
                        } else {
                            $.each(response.data, function (i, v) {
                                data += '<option value="0">' + response.message + '</option>'
                            });
                            $('.assigneedUsers').html('').append(data);
                        }
                    }
                });
            });

            let handleIssueDatatable = function (target = 0, sortingType = "desc") {
                $('#issueTable1').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: '/issueInfoAjaxHandler',
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'issueName', name: 'issueName'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'severity', name: 'severity'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'status', name: 'status'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'issueSubmission', name: 'issueSubmission'},
                        {data: 'editIssue', name: 'editIssue'},
                    ],
                    createdRow: function (row, data, index) {
                        let issueDetails = data.issueDetails.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(6).attr({
                            'class': 'text-center'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': issueDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            };
            handleIssueDatatable();

            $(document.body).on('click', '.editIssueData', function () {
                $('.updateIssueButton').attr('data-id', $(this).attr('data-id'));
                $.ajax({
                    url: "/fetchDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'fetchIssueDetails',
                        issueId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        let data = '';
                        if (response.status === 200) {
                            $.each(response.data[0].staffNames, function (i, v) {
                                data += '<option value="' + v + '">' + v + '</option>'
                            });
                            $('.editAssigneedUsers').html('').append(data);
                            $('.editProjectName').val(response.data[0].projectName);
                            $('.editIssueName').val(response.data[0].issueName);
                            $('.editIssueDesc').val(response.data[0].issueDesc);
                            $('.editIssueDueDate').val(response.data[0].dueDate);
                            $('.editIssueDueHours').val(response.data[0].durHours);
                            $('.editAssigneedUsers ').val(response.data[0].staffDetails).trigger('change');
                            if (response.data[0].severity === 'minor')
                                $('.editIssuePriority').val(1);
                            else if (response.data[0].severity === 'major')
                                $('.editIssuePriority').val(2);
                            else if (response.data[0].severity === 'critical')
                                $('.editIssuePriority').val(3);
                            else
                                $('.editIssuePriority').val(0);
                        } else {
                            $.each(response.data[0].staffNames, function (i, v) {
                                data += '<option value="0">No Staffs</option>'
                            });
                            $('.editAssigneedUsers').html('').append(data);
                        }
                    }
                });
            });

            let updateProName, updateIssueSeverity, updateIssueName, updateIssueDesc, updateDueDate, updateDueHours,
                updateAssignee, issueDataToUpdate = {};

            $(document.body).on('change', '.editProjectName', function () {
                updateProName = $(this).val();
                issueDataToUpdate.project_name = updateProName;
            });
            $(document.body).on('change', '.editIssueName', function () {
                updateIssueName = $(this).val();
                issueDataToUpdate.issue_topic = updateIssueName;
            });
            $(document.body).on('change', '.editIssueDesc', function () {
                updateIssueDesc = $(this).val();
                issueDataToUpdate.issue_desc = updateIssueDesc;
            });
            $(document.body).on('change', '.editIssueDueDate', function () {
                updateDueDate = $(this).val();

                var d = new Date();
                var n = d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
                var time4 = updateDueDate + ' ' + n;

                var dateString = time4;
                dateString = dateString.split(' ').join('T');
                var date1 = new Date(dateString.slice(0, -1));
                date1 = date1.getTime() / 1000;
                console.log('<br />' + date1);

                if (updateDueDate) {
                    // issueDataToUpdate.due_date = Date.parse(updateDueDate) / 1000;
                    issueDataToUpdate.due_date = date1;
                    issueDataToUpdate.issue_due_hours = '12';
                } else {
                    issueDataToUpdate.due_date = updateDueDate;
                    issueDataToUpdate.issue_due_hours = '';
                }
            });
            $(document.body).on('change', '.editIssueDueHours', function () {
                updateDueHours = $(this).val();
                if (updateDueHours === '' && updateDueDate !== '') {
                    issueDataToUpdate.issue_due_hours = '12';
                } else {
                    issueDataToUpdate.issue_due_hours = updateDueHours;
                }
            });
            $(document.body).on('change', 'select.editAssigneedUsers', function () {
                updateAssignee = $(this).val();
                if (updateAssignee.length === 0) {
                    issueDataToUpdate.issue_assign_to = '';
                } else {
                    issueDataToUpdate.issue_assign_to = updateAssignee;
                }
            });
            $(document.body).on('change', 'select.editIssuePriority', function () {
                updateIssueSeverity = parseInt($(this).val());
                issueDataToUpdate.severity = updateIssueSeverity;
            });

            $(document.body).on('click', '.updateIssueButton', function () {
                let stratDate = Date.parse($('.editIssueDueDate').val()) / 1000;
                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

                if (updateProName === "") {
                    toastr.error('Please Enter Your Project Name');
                } else if (updateIssueName === "") {
                    toastr.error('Please Enter Your Issue Name');
                } else if (Date.parse(updateDueDate) / 1000 === stratDate && Date.parse(date) / 1000 > stratDate) {
                    toastr.error('Due Date Should be greater than current date.');
                } else {
                    issueDataToUpdate.issue_id = $(this).attr('data-id');
                    $.ajax({
                        url: "/updateIssueData",
                        type: "post",
                        dataType: "json",
                        data: issueDataToUpdate,
                        success: function (response) {
                            if (response.status === 200) {
                                issueDataToUpdate = {};
                                $('#editIssue').modal('hide');
                                $('#issueTable1').DataTable().ajax.reload();
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                $('#editIssue').modal('hide');
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.closeEditIssueBtn', function () {
                issueDataToUpdate = {};
            });

            $(document.body).on('click', '.deleteIssue', function () {
                $('.confirmOkBtn').attr('data-id', $(this).attr('data-id'));
            });

            $('.confirmOkBtn').click(function () {
                $.ajax({
                    url: "/deleteDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'deleteIssueDetails',
                        issueId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmModal').modal('hide');
                            $('#issueTable1').DataTable().ajax.reload();
                            issueGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            $('#confirmModal').modal('hide');
                            $('#issueTable1').DataTable().ajax.reload();
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('click', '.issueComplete', function () {
                $.ajax({
                    url: "/updateAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'updateIssueStatus',
                        issueId: $(this).attr('data-id'),
                        issueStatus: 1
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#issueTable1').DataTable().ajax.reload();
                            issueGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('click', '.issuePending', function () {
                $.ajax({
                    url: "/updateAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'updateIssueStatus',
                        issueId: $(this).attr('data-id'),
                        issueStatus: 0
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#issueTable1').DataTable().ajax.reload();
                            issueGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            /*--------------------------------------- Milestone Codes ----------------------------------------*/

            let selectProjectName, milestone, milestoneStartDate, milestoneDueDate, milestoneDataToInsert = {};

            $(document.body).on('click', '.addMilestoneButton', function () {

                selectProjectName = $('.projName').val();
                milestoneDataToInsert.project_name = selectProjectName;
                milestone = $('.milestoneTextarea').val();
                milestoneDataToInsert.milestone = milestone;

                milestoneStartDate = $('.milestoneStartDate').val();
                if (milestoneStartDate) {
                    milestoneDataToInsert.milestoneStartDate = Date.parse(milestoneStartDate) / 1000;
                } else {
                    milestoneDataToInsert.milestoneStartDate = milestoneStartDate;
                }

                milestoneDueDate = $('.milestoneDueDate').val();
                if (milestoneDueDate) {
                    milestoneDataToInsert.milestoneDueDate = Date.parse(milestoneDueDate) / 1000;
                } else {
                    milestoneDataToInsert.milestoneDueDate = milestoneDueDate;
                }

                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

                if (selectProjectName === "0") {
                    toastr.error('Please Choose Your Project');
                } else if (milestone.trim() === "") {
                    toastr.error('Please Enter Milestone.');
                } else if ($('.milestoneStartDate').val() !== "" && $('.milestoneDueDate').val() === "") {
                    toastr.error('Please Choose Your Due Date.');
                } else if ($('.milestoneStartDate').val() === "" && $('.milestoneDueDate').val() !== "") {
                    toastr.error('Please Choose Your Start Date.');
                } else if ($('.milestoneStartDate').val() !== "" && Date.parse(date) / 1000 > Date.parse(milestoneStartDate) / 1000) {
                    toastr.error('Start Date Should be greater than current date.');
                } else if ($('.milestoneDueDate').val() !== "" && Date.parse(milestoneDueDate) / 1000 < Date.parse(milestoneStartDate) / 1000) {
                    toastr.error('Please Choose Your Due Date which should be greater than Start Date.');
                } else {
                    $.ajax({
                        url: "/insertMilestoneDetails",
                        type: "post",
                        dataType: "json",
                        data: milestoneDataToInsert,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#addNewMilestone').modal('hide').find("input[type=date],input,textarea,select").val('').end();
                                $('.projName').val(0);
                                $('#milestoneTable').DataTable().ajax.reload();
                                milestoneGraphical();
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.cancelMilestoneBtn', function () {
                $('#addNewMilestone').modal('hide').find("input[type=date],input,textarea,select").val('').end();
                $('.projName').val(0);
            });

            $('#milestoneTable').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                ajax: '/milestoneDataAjaxHandler',
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'projectName', name: 'projectName'},
                    {data: 'milestone', name: 'milestone'},
                    {data: 'startDate', name: 'startDate'},
                    {data: 'dueDate', name: 'dueDate'},
                    {data: 'milestoneStatus', name: 'milestoneStatus'},
                    {data: 'editMilestone', name: 'editMilestone'}
                ],
                createdRow: function (row, data, index) {
                    $('td', row).eq(1).attr({
                        'data-tooltip': data.projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(2).attr({
                        'data-tooltip': data.milestoneData,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });

            $(document.body).on('click', '.editMilestoneData', function () {
                $('.updateMilestoneBtn').attr('data-id', $(this).attr('data-id'));
                $.ajax({
                    url: "/fetchDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'fetchMilestoneDetails',
                        milestoneId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('.selectProjName').val(response.data[0].projectName);
                            $('.milestoneEditTextarea').val(response.data[0].milestoneData);
                            $('.editMilestoneStartDate').val(response.data[0].startDate);
                            $('.editMilestoneEndDate').val(response.data[0].dueDate);
                        }
                    }
                });
            });

            let updateProjectName, updateMilestone, updateStartDate, updateEnddate, milestoneDataToUpdate = {};

            $(document.body).on('change', '.selectProjName', function () {
                updateProjectName = $(this).val();
                milestoneDataToUpdate.project_name = updateProName;
            });
            $(document.body).on('change', '.milestoneEditTextarea', function () {
                updateMilestone = $(this).val();
                milestoneDataToUpdate.milestone = updateMilestone;
            });
            $(document.body).on('change', '.editMilestoneStartDate', function () {
                updateStartDate = $(this).val();
                if (updateStartDate) {
                    milestoneDataToUpdate.startDate = Date.parse(updateStartDate) / 1000;
                } else {
                    milestoneDataToUpdate.startDate = updateStartDate;
                }
            });
            $(document.body).on('change', '.editMilestoneEndDate', function () {
                updateEnddate = $(this).val();
                if (updateEnddate) {
                    milestoneDataToUpdate.endDate = Date.parse(updateEnddate) / 1000;
                } else {
                    milestoneDataToUpdate.endDate = updateEnddate;
                }
            });

            $(document.body).on('click', '.updateMilestoneBtn', function () {
                let startDate = Date.parse($('.editMilestoneStartDate').val()) / 1000;
                let endDate = Date.parse($('.editMilestoneEndDate').val()) / 1000;
                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

                if (updateProjectName === "") {
                    toastr.error('Please Enter Your Project Name');
                } else if (updateMilestone === "") {
                    toastr.error('Please Enter Milestone');
                } else if ($('.editMilestoneStartDate').val() !== "" && $('.editMilestoneEndDate').val() === "") {
                    toastr.error('Please Choose Your Due Date.');
                } else if ($('.editMilestoneStartDate').val() === "" && $('.editMilestoneEndDate').val() !== "") {
                    toastr.error('Please Choose Your Start Date.');
                } else if (Date.parse(updateStartDate) / 1000 === startDate && Date.parse(date) / 1000 > startDate) {
                    toastr.error('Start Date Should be greater than current date.');
                } else if ($('.editMilestoneEndDate').val() !== "" && endDate < startDate) {
                    toastr.error('Please Choose Your Due Date which should be greater than Start Date.');
                } else {
                    milestoneDataToUpdate.milestone_id = $(this).attr('data-id');
                    $.ajax({
                        url: "/updateMilestoneData",
                        type: "post",
                        dataType: "json",
                        data: milestoneDataToUpdate,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#editMilestone').modal("hide");
                                milestoneDataToUpdate = {};
                                $('#milestoneTable').DataTable().ajax.reload();
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.deleteMilestone', function () {
                $('.confirmMilestoneBtn').attr('data-id', $(this).attr('data-id'));
            });

            $('.confirmMilestoneBtn').click(function () {
                $.ajax({
                    url: "/deleteDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'deleteMilestoneDetails',
                        milestoneId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmMilestoneModal').modal('hide');
                            $('#milestoneTable').DataTable().ajax.reload();
                            milestoneGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            $('#confirmMilestoneModal').modal('hide');
                            $('#milestoneTable').DataTable().ajax.reload();
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            /* -------------------------------------- Task Codes --------------------------------------------------- */

            let handleTaskDatatable = function (target = 0, sortingType = "desc") {
                $('#taskTable1').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: '/taskInfoAjaxHandler',
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        // {data: 'taskId', name: 'taskId'},
                        {data: 'taskName', name: 'taskName'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'priority', name: 'priority'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'status', name: 'status'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'taskSubmission', name: 'taskSubmission'},
                        {data: 'editTask', name: 'editTask'},
                        {data: 'taskPrioritySort', name: 'taskPrioritySort', visible: false}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.taskDetails.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(6).attr({
                            'class': 'text-center'
                        });
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[target, sortingType]]
                });
            };

            handleTaskDatatable();

            $(document.body).on('click', '.taskPrioritySort', function () {
                let elem = $(this);
                if (elem.hasClass("asc")) {
                    elem.addClass("desc").removeClass('asc');
                    handleTaskDatatable(9, "desc");
                } else {
                    elem.addClass("asc").removeClass('desc');
                    handleTaskDatatable(9, "asc");
                }
            });

            let updateProjName, updateTaskPriority, updateTaskName, updateTaskDesc, updateTaskDueDate,
                updateTaskDueHours,
                updateTaskAssignee, taskDataToUpdate = {};

            $(document.body).on('change', '.selectTaskProjName', function () {
                updateProjName = $(this).val();
                taskDataToUpdate.project_name = updateProjName;
            });
            $(document.body).on('change', '.taskName', function () {
                updateTaskName = $(this).val();
                taskDataToUpdate.task_topic = updateTaskName;
            });
            $(document.body).on('change', '.taskDesc', function () {
                updateTaskDesc = $(this).val();
                taskDataToUpdate.task_desc = updateTaskDesc;
            });
            $(document.body).on('change', '.dueDate', function () {
                updateTaskDueDate = $(this).val();

                var d = new Date();
                var n = d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
                var time2 = updateTaskDueDate + ' ' + n;

                var dateString = time2;
                dateString = dateString.split(' ').join('T');
                var date1 = new Date(dateString.slice(0, -1));
                date1 = date1.getTime() / 1000;
                console.log('<br />' + date1);

                if (updateTaskDueDate) {
                    // taskDataToUpdate.task_due_date = Date.parse(updateTaskDueDate) / 1000;
                    taskDataToUpdate.task_due_date = date1;
                    taskDataToUpdate.task_due_hours = '12';
                } else {
                    taskDataToUpdate.task_due_date = updateTaskDueDate;
                    taskDataToUpdate.task_due_hours = '';
                }
            });
            $(document.body).on('change', '.dueHours', function () {
                updateTaskDueHours = $(this).val();
                if (updateTaskDueHours === '' && updateTaskDueDate !== '') {
                    taskDataToUpdate.task_due_hours = '12';
                } else {
                    taskDataToUpdate.task_due_hours = updateTaskDueHours;
                }
            });
            $(document.body).on('change', 'select.userDataClass', function () {
                updateTaskAssignee = $(this).val();
                // taskDataToUpdate.task_assign_to = updateTaskAssignee;
                if (updateTaskAssignee.length === 0) {
                    taskDataToUpdate.task_assign_to = '';
                } else {
                    taskDataToUpdate.task_assign_to = updateTaskAssignee;
                }
            });
            $(document.body).on('change', 'select.taskPriority', function () {
                updateTaskPriority = parseInt($(this).val());
                taskDataToUpdate.priority = updateTaskPriority;
            });

            $(document.body).on('click', '.updateTaskBtn', function (e) {
                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();
                let stratDate = Date.parse($('.dueDate').val()) / 1000;


                if (updateProjName === "") {
                    toastr.error('Please Enter Your Project Name');
                } else if (updateTaskName === "") {
                    toastr.error('Please Enter Your Task Topic');
                } else if (Date.parse(updateTaskDueDate) / 1000 === stratDate && Date.parse(date) / 1000 > stratDate) {
                    toastr.error('Due Date Should be greater than current date.');
                } else {
                    taskDataToUpdate.task_id = $(this).attr('data-id');
                    $.ajax({
                        url: "/updateTaskData",
                        type: "post",
                        dataType: "json",
                        data: taskDataToUpdate,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#editTask').modal('hide');
                                taskDataToUpdate = {};
                                $('#taskTable1').DataTable().ajax.reload();
                                toastr.success(response.message, {timeOut: 3000})
                            } else {
                                $('#editTask').modal('hide');
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.editTaskClose', function () {
                taskDataToUpdate = {};
            });

            $(document.body).on('click', '.editTaskData', function () {
                $('.updateTaskBtn').attr('data-id', $(this).attr('data-id'));
                $.ajax({
                    url: "/fetchDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'fetchTaskDetails',
                        taskId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        let data = '';
                        if (response.status === 200) {
                            console.log(response.data);
                            $.each(response.data[0].staffNames, function (i, v) {
                                data += '<option value="' + v + '">' + v + '</option>'
                            });
                            $('.userDataClass').html('').append(data);

                            $('.selectTaskProjName').val(response.data[0].projectName);
                            $('.taskName').val(response.data[0].issueName);
                            $('.taskDesc').val(response.data[0].issueDesc);
                            $('.dueDate').val(response.data[0].dueDate);
                            $('.dueHours').val(response.data[0].durHours);
                            $('.userDataClass').val(response.data[0].staffDetails).trigger('change');
                            if (response.data[0].priority === 'low')
                                $('.taskPriority').val(1);
                            else if (response.data[0].priority === 'medium')
                                $('.taskPriority').val(2);
                            else if (response.data[0].priority === 'high')
                                $('.taskPriority').val(3);
                            else
                                $('.taskPriority').val(0);
                        } else {
                            $.each(response.data[0].staffNames, function (i, v) {
                                data += '<option value="0">No Staffs</option>'
                            });
                            $('.userDataClass').html('').append(data);
                        }
                    }
                });
            });

            $(document.body).on('click', '.deleteTask', function () {
                $('.confirmTaskBtn').attr('data-id', $(this).attr('data-id'));
            });

            $('.confirmTaskBtn').click(function () {
                $.ajax({
                    url: "/deleteDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'deleteTaskDetails',
                        taskId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmTaskModal').modal('hide');
                            $('#taskTable1').DataTable().ajax.reload();
                            taskGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            $('#confirmTaskModal').modal('hide');
                            $('#taskTable1').DataTable().ajax.reload();
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('click', '.taskComplete', function () {
                $.ajax({
                    url: "/updateAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'updateTaskStatus',
                        taskId: $(this).attr('data-id'),
                        taskStatus: 1
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#taskTable1').DataTable().ajax.reload();
                            taskGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('click', '.taskPending', function () {
                $.ajax({
                    url: "/updateAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'updateTaskStatus',
                        taskId: $(this).attr('data-id'),
                        taskStatus: 0
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#taskTable1').DataTable().ajax.reload();
                            taskGraphical();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('click', '.staffListModal', function () {
                $.ajax({
                    url: "/fetchDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: "fetchStaff",
                        taskId: $(this).attr('data-id')
                    },
                    beforeSend: function () {
                        $('.list-group').html('');
                        $('.loaderClass').addClass('show').removeClass('hide');
                    },
                    success: function (response) {
                        $('.loaderClass').addClass('hide').removeClass('show');
                        let data = '';
                        if (response.status === 200) {
                            $.each(response.data, function (i, v) {
                                let pic = v[0].profile_pic === null ? '/images/default.png' : v[0].profile_pic;
                                data += '<li class="list-group-item staff_list" style="font-size: 17px;"><img src="' + pic + '" class="img-circle" width="40px" style="margin-right: 10px;">' + v[0].name + '</li>'
                            });
                            $('.list-group').html('').append(data);
                        } else {
                            data = '<h5 style="text-align: center;padding: 50px;">No Staffs are there!</h5>';
                            $('.list-group').html('').append(data);
                        }
                    }
                });
            });

            $(document.body).on('click', '.staffListIssueModal', function () {
                $.ajax({
                    url: "/fetchDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: "fetchStaffOfIssue",
                        issueId: $(this).attr('data-id')
                    },
                    beforeSend: function () {
                        $('.list-group').html('');
                        $('.loaderClass').addClass('show').removeClass('hide');
                    },
                    success: function (response) {
                        $('.loaderClass').addClass('hide').removeClass('show');
                        let data = '';
                        if (response.status === 200) {
                            $.each(response.data, function (i, v) {
                                let pic = v[0].profile_pic === null ? '/images/default.png' : v[0].profile_pic;
                                data += '<li class="list-group-item staff_list" style="font-size: 17px;"><img src="' + pic + '" class="img-circle" width="40px" style="margin-right: 10px;">' + v[0].name + '</li>'
                            });
                            $('.list-group').html('').append(data);
                        } else {
                            data = '<h5 style="text-align: center;padding: 50px;">No Staffs are there!</h5>';
                            $('.list-group').html('').append(data);
                        }
                    }
                });
            });

        });
    </script>
@endsection