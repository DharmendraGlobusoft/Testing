@extends('Admin::Dashboard/layouts.bodyLayout')

@section('title','Add Resource-Page || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet">
    <style>
        body {
            padding-right: 0px !important;
        }

        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        #addResource .form-control {
            display: inline-block;
        }

        .activity-stream {
            list-style-type: none;
            margin: 2em 3em;
            padding: 0;
            border-left: 1px solid #ccc;
            padding-left: 1.5em;
        }

        .activity-stream li {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li textarea {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li .icon {
            height: 60px;
            width: 60px;
            padding: 4px 4px;
            color: #fff;
            box-sizing: border-box;
            display: block;
            background: #53b2ea;
            position: absolute;
            left: -4.5em;
            top: .5em;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .activity-stream li:before,
        .activity-stream li:after {
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: transparent;
            border-left: 0;
        }

        .activity-stream li:before {
            top: 1em;
            left: -8px;
            /* If 1px darken stroke slightly */
            border-right-color: #aaa;
            border-width: 7px;
        }

        .activity-stream li:after {
            top: 1em;
            left: -7px;
            border-right-color: white;
            border-width: 7px;
        }

        /*   Resource CSS    */

        .lib-panel {
            margin-bottom: 20Px;
        }

        .lib-panel img {
            width: 100%;
            background-color: transparent;
        }

        .lib-panel .row,
        .lib-panel .col-md-6 {
            padding: 5px;
            background-color: #FFFFFF;
        }

        .lib-panel .lib-row {
            padding: 0 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header {
            background-color: #FFFFFF;
            font-size: 20px;
            padding: 10px 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header .lib-header-seperator {
            height: 2px;
            width: 26px;
            background-color: #d9d9d9;
            margin: 7px 0 7px 0;
        }

        .lib-panel .lib-row.lib-desc {
            position: relative;
            height: 100%;
            display: block;
            font-size: 13px;
        }

        .lib-panel .lib-row.lib-desc a {
            position: absolute;
            width: 100%;
            bottom: 10px;
            left: 20px;
        }

        .row-margin-bottom {
            margin: 15px;
        }

        .box-shadow {
            -webkit-box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
            box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
        }

        .no-padding {
            padding: 0;
        }

        /*   Resources CSS  Ends*/

        /*        Radio Css*/

        .buying-selling.active {
            background: #3ca1eb;
        }

        .buying-selling {
            width: 130px;
            padding: 10px;
            position: relative;
        }

        .buying-selling-word {
            font-size: 15px;
            font-weight: 600;
            margin-left: 22px;
        }

        .radio-dot:before,
        .radio-dot:after {
            content: "";
            display: block;
            position: absolute;
            background: #fff;
            border-radius: 100%;
        }

        .radio-dot:before {
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            top: 10px;
            left: 16px;
        }

        .radio-dot:after {
            width: 12px;
            height: 12px;
            border-radius: 100%;
            top: 14px;
            left: 20px;
        }

        .buying-selling.active .buying-selling-word {
            color: #fff;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active .radio-dot:before {
            background: #fff;
            border-color: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:before {
            border-color: #adadad;
        }

        .buying-selling.active:hover .radio-dot:before {
            border-color: #3ca1eb;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active:hover .radio-dot:after {
            background: #3ca1eb;
        }

        @media (max-width: 400px) {
            .mobile-br {
                display: none;
            }

            .buying-selling {
                width: 49%;
                padding: 10px;
                position: relative;
            }
        }

        .popover.bottom .arrow {
            left: 14%;
        }

        .ck.ck-editor__editable_inline {
            min-height: 300px !important;
            padding: 0px 25px !important;
        }

        figure {
            margin: 60px 0 !important;

        }

        /*.ck-content .image > img{*/

        /*padding: 60px 0 !important;*/
        /*}*/
    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Resources|News Board </h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="#">Admin</a></li>
                        <li class="active">Resources List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header" style="background:rgb(60, 161, 235);color: #ffff;">
                            <h4 style="display: inline-block">Add New Resource</h4>
                        </div>
                        <div class="card-body" style="background: #dddbdb;">
                            <div class="row">
                                <form>
                                    {{csrf_field()}}
                                    <div class="col-md-12">
                                        <div class="form-group ">
                                    <textarea name="content" required class="form-control"
                                              id="editor"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="resourseAttachment" class="form__file">
                                                <span class="form__file-filename" id="filename"
                                                      data-placeholder="Attach file">Attach file</span>
                                                <span class="form__file-browse">Browse</span>
                                                <input type="file" name="resourseUploadFile" class="form__file-input"
                                                       id="resourseAttachment">
                                            </label>
                                            <ul class="form__files" id="resouseAttachment-files"></ul>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="col col-md-2">
                                                <label class="control-label" for="name">Resource Title</label>
                                            </div>
                                            <input id="resourceTitle" name="name" type="text"
                                                   placeholder="Resource Title"
                                                   class="form-control col-md-10 resourceTitle">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="col col-md-2">
                                                <label class="control-label" for="name">Category Name</label>
                                            </div>
                                            <input id="category" name="name" type="text"
                                                   placeholder="Category Name"
                                                   class="form-control col-md-10 categoryName">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="col-md-2 control-label" for="name">Privacy</label>
                                                <div class="buying-selling-group" id="buying-selling-group"
                                                     data-toggle="buttons"
                                                     style="display: inline-block;">
                                                    <label class="btn btn-default buying-selling">
                                                        <input type="radio" name="options" id="publicBtn"
                                                               autocomplete="off">
                                                        <span class="radio-dot"></span>
                                                        <span class="buying-selling-word">Public</span>
                                                    </label>

                                                    <label class="btn btn-default buying-selling"
                                                           data-target="#PrivateUser"
                                                           data-toggle="modal">
                                                        <input type="radio" name="options" id="privateBtn"
                                                               autocomplete="off">
                                                        <span class="radio-dot"></span>
                                                        <span class="buying-selling-word">Private</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" style="text-align: center;margin-top:2%;">
                                            <button class="btn btn-success uploadResource" style="padding: 8px 25px;">
                                                Upload
                                            </button>
                                            <a href="/admin/resource-page" class="btn btn-danger cancelButton"
                                               style="padding: 8px 25px;">Cancel</a>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="PrivateUser" role="dialog">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header" style="background-color:#4285ea;color: #fff;">
                    <h4 class="modal-title">Private Mode</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form action="" role="form">
                        <div class="form-group">
                            <label for="user" class="col-md-4">Project Name</label>
                            {{--<select data-placeholder="Choose a Projects..." multiple class="standardSelect"--}}
                            {{--class="form-control col-md-8">--}}
                            {{--<option value=""></option>--}}
                            {{--<option value="Project #1">Project #1</option>--}}
                            {{--<option value="Project #2">Project #2</option>--}}
                            {{--<option value="Project #3">Project #3</option>--}}
                            {{--<option value="Project #4">Project #4</option>--}}
                            {{--<option value="Project #5">Project #5</option>--}}
                            {{--<option value="Project #6">Project #6</option>--}}
                            {{--<option value="Project #7">Project #7</option>--}}
                            {{--</select>--}}

                            <select class="selectProject form-control" name="userDataInput[]"
                                    multiple="multiple">
                                @foreach($projectName as $k=>$val)
                                    <option value="{{$val->project_name}}">{{$val->project_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-md-4">User Name</label>
                            {{--<select data-placeholder="Choose a User..." multiple class="standardSelect"--}}
                            {{--class="form-control col-md-8">--}}
                            {{--<option value=""></option>--}}
                            {{--<option value="User #1">User #1</option>--}}
                            {{--<option value="User #2">User #2</option>--}}
                            {{--<option value="User #3">User #3</option>--}}
                            {{--<option value="User #4">User #4</option>--}}
                            {{--<option value="User #5">User #5</option>--}}
                            {{--<option value="User #6">User #6</option>--}}
                            {{--<option value="User #7">User #7</option>--}}
                            {{--</select>--}}
                            <select class="selectUsers form-control" name="userDataInput[]"
                                    multiple="multiple">
                                @foreach($allData as $k=>$val)
                                    <option value="{{$val->username}}">@if($val->role === 'M') {{$val->name}}
                                        [Manager] @else {{$val->name}}[Staff] @endif</option>
                                @endforeach
                            </select>

                        </div>
                        <div style="text-align: center;">
                            <button type="button" class="btn btn-primary btn-sm privacyModalSubmit">Submit</button>
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="/assets/js/jquery.imageuploader.js"></script>
    <script>
        $('button[data-toggle=popover]').popover({
            html: true,
            //trigger: "click",
            content: function (e) {
                return $('#popover_content_wrapper').html();
            }
        });
    </script>

    {{--CK Editor--}}
    <script src="https://cdn.ckeditor.com/ckeditor5/11.0.1/classic/ckeditor.js"></script>
    <script>
        let theEditor;
        ClassicEditor
            .create(document.querySelector('#editor'), {
                ckfinder: {
                    uploadUrl: '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files&responseType=json'
                }
            })
            .then(editor => {
                theEditor = editor;
                console.log('Editor was initialized');
            })
            .catch(error => {
                console.error(error);
            });


    </script>

    <script>
        $('.selectProject').select2({
            placeholder: "Select Your Projects"
        });
        $('.selectUsers').select2({
            placeholder: "Select Your Staffs"
        });

        let resourseFileData = new FormData();
        let count1 = 0;

        $('#resourseAttachment').on('change', function (event) {
            var imageName = 'resourseFileData' + ++count1;
            resourseFileData.append(imageName, $('input[name=resourseUploadFile]')[0].files[0]);


            var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

            // file not choosed
            if (typeof filename === 'undefined') {
                return false;
            }


            var $file = $(this).closest('.form__file');
            $file
                .addClass('form__file--attached')
                .find('.form__file-filename')
                .html(filename);

            $file
                .find('.form__file-input')
                .prop('disabled', true);

            // list of files
            var $files = $('#resouseAttachment-files');

            // show files list
            if ($files.find('li').length === 0) {
                $files.removeClass('form__files--hide').addClass('form__files--show');
            }

            // create a new item
            var $item = $('<li/>')
                .addClass('form__files-item')
                .addClass('form__files-item--loading')
                .append($('<span/>').addClass('form__files-item-link').html(filename))
                .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                .append($('<span/>').addClass('form__files-item-progress'))
                .append($('<input/>').attr({
                    type: 'hidden',
                    name: 'attachments[]',
                    value: '{}'
                }));

            $files.append($item);

            // progress bar
            $item.find('.form__files-item-progress').animate({
                width: '100%'
            }, 2000);

            $('#resouseAttachment-files').trigger('contentChanged');

            setTimeout(function () {
                $file.removeClass('form__file--attached');

                $file
                    .find('.form__file-input')
                    .prop('disabled', false);

                var v = $file.find('.form__file-filename').data('placeholder');
                $file.find('.form__file-filename').html(v);
                $file.find('.form__file-input').val('');

                $item
                    .removeClass('form__files-item--loading')
                    .addClass('form__files-item--done');

                $item.find('.form__files-item-link').replaceWith(function () {
                    var text = $.trim($(this).text());
                    return $('<a/>').attr({
                        href: '#',
                        target: '_blank'
                    }).addClass('form__files-item-link').html(text);
                });

                var _itemData = JSON.stringify({
                    id: uuidv4(),
                    // file: textFile,
                    name: filename,
                    url_view: '',
                    url_delete: ''
                }, null, '');

                $item
                    .find('input[type=hidden]')
                    .val(_itemData);

                console.log('File uploaded: ', JSON.parse(_itemData));

                $item.find('[data-file-remove=true]').on('click', function () {
                    var imageName = $(this).attr('imageName');
                    resourseFileData.delete(imageName);
                    var $removeItem = $(this).closest('.form__files-item'),
                        itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                    // ajax request
                    console.log('File deleted: ', itemData.id);

                    $removeItem.addClass('form__files-item--hide');

                    // hide files list
                    if ($files.find('li').length <= 1) {
                        $files.removeClass('form__files--show').addClass('form__files--hide');
                    }

                    $('#resouseAttachment-files').trigger('contentChanged');

                    setTimeout(function () {
                        $removeItem.remove();
                    }, 500);

                });
            }, 2000);
        });
        $('#resouseAttachment-files').on('contentChanged', function () {
            if ($(this).find('li').length === 0) {
                $('#resouseAttachment-files').removeClass('form__files--show');
            } else {
                $('#resouseAttachment-files').addClass('form__files--hide');
            }
            console.log(1);
            console.log(this);
            console.log($('li', this).length);

            // $(this).each(function() {
            //   if ($(this).length <= 1) {
            //     $(this).removeClass('form__files--show').addClass('form__files--hide');
            //   }
            // });
        });

        let projectNames, staffNames;

        $(document.body).on('click', '.privacyModalSubmit', function () {
            projectNames = $('.selectProject').val();
            staffNames = $('.selectUsers').val();
            if (projectNames === null && staffNames === null) {
                toastr.error('Please Choose atleast one field.');
            } else {
                $('#PrivateUser').modal('hide');
            }
        });

        let privacyStatus = '', privacyData = '';
        $(document.body).on('click', '.uploadResource', function () {
            let content = theEditor.getData();
            let title = $('.resourceTitle').val();
            let catName = $('.categoryName').val();


            if ($('#publicBtn').prop('checked') === true) {
                privacyStatus = 'public'; // 0-public
                $('.select2-selection__choice').remove();
            } else if ($('#privateBtn').prop('checked') === true) {
                privacyStatus = 'private'; // 1-private
            }

            resourseFileData.append('content', content);
            resourseFileData.append('resourceTitle',title);
            resourseFileData.append('projects', projectNames);
            resourseFileData.append('staffs', staffNames);
            resourseFileData.append('privacyStatus', privacyStatus);
            resourseFileData.append('categoryName', catName);

            if ($('#publicBtn').prop('checked') === false && $('#privateBtn').prop('checked') === false) {
                toastr.error('Please Choose Your Privacy.');
            } else {
                $.ajax({
                    url: "/insertResourceData",
                    type: "post",
                    dataType: "json",
                    data: resourseFileData,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        toastr.success(response.message, {timeOut: 3000});
                        setTimeout(function () {
                            window.location.href = '/admin/resource-page';
                        }, 3000);
                    }
                });
            }
        });
    </script>
@endsection