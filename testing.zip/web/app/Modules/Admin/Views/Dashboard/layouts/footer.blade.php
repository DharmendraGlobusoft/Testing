{{--<script src="/assets/js/vendor/jquery-2.1.4.min.js"></script>--}}
{{--<script src="/assets/js/popper.min.js"></script>--}}


<!-- Data Table   -->
{{--<script src="/assets/js/lib/data-table/datatables.min.js"></script>--}}
<script src="/assets/js/main.js"></script>
<script src="/assets/js/lib/data-table/jquery.dataTables.min.js"></script>
<script src="/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="/assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="/assets/js/lib/data-table/jszip.min.js"></script>
<script src="/assets/js/lib/data-table/pdfmake.min.js"></script>
<script src="/assets/js/lib/data-table/vfs_fonts.js"></script>
<script src="/assets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="/assets/js/lib/data-table/buttons.print.min.js"></script>
<script src="/assets/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="/assets/js/lib/data-table/datatables-init.js"></script>
<script src="/assets/js/lib/chosen/chosen.jquery.min.js"></script>
<script src="/assets/js/file_attach.js"></script>
<script src="/assets/js/toastr/toastr.min.js"></script>
<script src="/assets/js/jquery.hotkeys.js"></script>
<script src="/assets/js/bootstrap-wysiwyg.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="/assets/js/bootstrap-popover-x.js"></script>
<script src="/assets/js/plugins.js"></script>
<script src="/assets/js/jquery.nicescroll.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js'></script>
<script src="/assets/js/datepicker_js.js"></script>
<script src="/assets/js/image_uploader.js" type="text/javascript"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>
{{--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/locale/af.js"></script>--}}

{{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>--}}
{{--<script src="/assets/js/main.js"></script>--}}


<script type="text/javascript">

    $(document).ready(function () {
        $('#bootstrap-data-table-export').DataTable();
    });

</script>
<script>
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-right";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicates = true
    });
</script>
<script>
    $.each($('.navbar-nav li'), function () {
        if ($(this).find('a').attr('href') === window.location.pathname) {
            $(this).addClass('active').siblings().removeClass('active');
        }
    });
</script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    $(document).ready(function () {
        $('.user-area').click(function () {
            $(this).addClass('show');
            $(this).find('.user-menu').addClass('show');
        })
    });
</script>

<script>
    $(document).ready(function () {
        $('.taskAssignee').select2({
            placeholder: "Select Your Staffs"
        });

        $('[data-toggle="popover"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Resource Page'
        });

        $('[data-toggle="popover1"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Add New Task'
        });

        $('[data-toggle="popover2"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Notifications'
        });
        $('[data-toggle="popover3"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Send Invitation'
        });

        $('[data-toggle="popover10"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Dashboard Page'
        });
        $('[data-toggle="popover11"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Project Page'
        });
        $('[data-toggle="popover12"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Staff List'
        });
        $('[data-toggle="popover13"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Invoice/Payment Page'
        });
        $('[data-toggle="popover14"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Support List'
        });
        $('[data-toggle="popover15"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Messages'
        });
        $('[data-toggle="popover16"]').popover({
            placement: 'bottom',
            trigger: 'hover',
            html: true,
            content: 'Logout'
        });

        // $(document.body).on("mouseover", ".issueComplete", function () {
        //     $(this).popover({
        //         placement: 'bottom',
        //         trigger: 'hover',
        //         html: true,
        //         content: 'On Click of this, Task will be marked As Completed'
        //     });
        // });

        let selectProject, taskName, taskDesc, dueDate, dueHours, taskPriority, taskAssignee,
            taskDataToInsert = {};

        $(document.body).on('change', '.selectProName', function () {
            $.ajax({
                url: "/getStaffs",
                type: "post",
                dataType: "json",
                data: {
                    projectName: $(this).val()
                },
                success: function (response) {
                    let data = '';
                    if (response.status === 200) {

                        $.each(response.data, function (i, v) {
                            data += '<option value="' + v[0].username + '">' + v[0].name + '[' + v[0].username + ']' + '</option>'
                        });
                        $('.taskAssignee').html('').append(data);
                    } else {
                        $.each(response.data, function (i, v) {
                            data += '<option value="0">' + response.message + '</option>'
                        });
                        $('.taskAssignee').html('').append(data);
                    }
                }
            });
            // }
        });

        let maxLength = 80;
        $('.selectProName > option').text(function (i, text) {
            if (text.length > maxLength) {
                return text.substr(0, maxLength) + '...';
            }
        });

        $(document.body).on('click', '.addTaskButton', function () {
            selectProject = $('.selectProName').val();
            textFileData.append('projectName', selectProject);
            taskName = $('.addTaskName').val();
            textFileData.append('taskName', taskName);
            taskDesc = $('.addTaskDesc').val();
            textFileData.append('taskDesc', taskDesc);
            dueDate = $('.taskNewDueDate').val();


            var d = new Date();
            console.log(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
            var n = d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
            console.log(n);
            var time1 = dueDate + ' ' + n;
            var dateString = time1;
            dateString = dateString.split(' ').join('T');
            console.log(dateString);
            // var date1 = new Date(dateString.slice(0, -1));
            var date1 = new Date(dateString);
            date1 = date1.getTime() / 1000;
            console.log('<br />' + date1);

            if (dueDate) {
                // textFileData.append('dueDate', Date.parse(dueDate) / 1000);
                // textFileData.append('dueDate', date1.getTime()/1000);
                textFileData.append('dueDate', date1);
            } else {
                textFileData.append('dueDate', $('.taskNewDueDate').val());
            }
            dueHours = $('.taskDueHours').val();
            textFileData.append('dueHours', dueHours);
            taskPriority = $('.addTaskPriority').val(); // 0-none,1-low,2-medium,3-high
            textFileData.append('taskPriority', taskPriority);
            taskAssignee = $('.taskAssignee').val();
            textFileData.append('taskAssignee', taskAssignee);

            let nowDate = new Date();
            let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

            if (selectProject === "0") {
                toastr.error('Please Choose Your Project');
            } else if (taskName.trim() === "") {
                toastr.error('Please Enter Your Task Name.');
            } else if ($('.taskNewDueDate').val() !== "" && Date.parse(date) / 1000 > Date.parse(dueDate) / 1000) {
                toastr.error('Due Date Should be greater than current date.');
            } else if (dueHours !== '' && dueHours < 1) {
                toastr.error('Due Hours Should be a Positive Number.');
            } else {
                $.ajax({
                    url: "/insertTaskDetails",
                    type: "post",
                    dataType: "json",
                    data: textFileData,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        $(".taskSpinnerClass").css('display', 'block');
                        $(".addTaskButton,.cancelTaskBtn").attr('disabled', 'disabled');
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $(".addTaskButton,.cancelTaskBtn").attr('disabled', false);
                            $(".taskSpinnerClass").css('display', 'none');
                            $('#taskCreationmodal').modal('hide').find("input,textarea,select").val('').end();
                            $('.selectProName').val(0);
                            $('.addTaskPriority').val(0);
                            $('li.select2-selection__choice').remove();
                            $('li.form__files-item').remove();
                            $('#attachment-files').removeClass('form__files--show');
                            taskGraphical();
                            $('#taskTable1').DataTable().ajax.reload();
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            }
        });

        $(document.body).on('click', '.cancelTaskBtn,.cancelTaskButn', function () {
            $('#taskCreationmodal').modal('hide').find("input,textarea,select").val('').end();
            $('.selectProName').val(0);
            $('.addTaskPriority').val(0);
            $('li.form__files-item').remove();
            $('#attachment-files').removeClass('form__files--show');
            $('li.select2-selection__choice').remove();
        });

        $(document.body).on('click', '.cancelInviteBtn', function () {
            $('#invitation_link').modal('hide').find("input[name=name],input[name=email],select").val('').end();
            $('.selectPortfolio').val(0);
            $('#email').removeClass("focused");
        });

        function taskGraphical() {
            $.ajax({
                url: "/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Task'
                },
                success: function (response) {
                    if (response.length > 0) {
                        let myChart;
                        let data = response;
                        if (myChart) {
                            myChart.destroy();
                        }
                        var ctx = document.getElementById("doughutChart");
                        ctx.height = 150;
                        myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ]
                                }],
                                labels: [
                                    "Pending",
                                    "Completed"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    } else {
                        console.log('No data');
                        let data = '';
                        data = '<h4 class="mb-3" >Tasks</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Task </p>\n' +
                            '<img src="/images/No_data.png" style="/*! text-align: center; */" width="120px">';
                        console.log(data);
                        $('.taskClass').html('').append(data);
                    }
                }
            });
        }

        $(document.body).on('click', '.inviteBtn', function () {
            let emailID = $('#email').val();
            let projName = $('.inviteProjName').val();
            let selectType = $('.selectPortfolio').val();
            if (!(emailID.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                toastr.error('<b>Please provide a valid email.</b>', {timeOut: 2000});
            } else if (selectType === "0") {
                toastr.error('<b>Please Select Portfolio.</b>', {timeOut: 2000});
            } else {
                $.ajax({
                    url: "/sendInvitationLink",
                    type: "post",
                    dataType: "json",
                    data: {
                        email: emailID,
                        project: projName,
                        type: selectType
                    },
                    beforeSend: function () {
                        $(".spinnerClass").css('display', 'block');
                        $(".inviteBtn").attr('disabled', 'disabled');
                    },
                    success: function (response) {
                        $(".spinnerClass").css('display', 'none');
                        $(".inviteBtn").attr('disabled', false);
                        if (response.status === 200) {
                            $('#invitation_link').modal('hide').find("input[name=name],input[name=email],select").val('').end();
                            $('.selectPortfolio').val(0);
                            toastr.success(response.message, {timeOut: 3000});
                        } else if (response.status === 401) {
                            $('#email').addClass("focused").val('');
                            toastr.error(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            }
        });

        setInterval(function () {
            $.ajax({
                url: "/getTotalNotiifcation",
                type: "post",
                dataType: "json",
                data: '',
                success: function (response) {
                    if (response.status === 200) {
                        var data = '';
                        if (response.totalNotification > 0) {
                            data = '<button class="btn btn-secondary dropdown-toggle" type="button" id="notification"\n' +
                                'aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content="">\n' +
                                '<i class="fa fa-bell"></i>\n' +
                                '<span class="count bg-danger" style="height: 16px;\n' +
                                'width: 18px;">' + response.totalNotification + '</span>\n' +
                                '</button>';
                        } else {
                            data = '<button class="btn btn-secondary dropdown-toggle" type="button" id="notification"\n' +
                                'aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content=""\n' +
                                'style="margin-top: -8px;">\n' +
                                '<i class="fa fa-bell"></i>\n' +
                                '</button>';
                        }
                        $('.getNotifcation').html('').append(data);
                    } else {

                    }
                }
            });
        }, 10000);

        // setInterval(function () {
        //     var hour = new Date().getHours();
        //     if (hour >= 10 && hour < 18) {
        //         $.ajax({
        //             url: "/checkOverdueAjaxHandler",
        //             type: "post",
        //             dataType: "json",
        //             data: {
        //                 chooseMethod: "overdueIssues",
        //             },
        //             beforeSend: function () {
        //             },
        //             success: function (response) {
        //                 if (response.status === 200) {
        //
        //                 } else {
        //
        //                 }
        //             }
        //         });
        //     }
        // }, 1000 * 60 * 60);
    });
</script>
