<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">


<head>
    @include('Admin::Dashboard/layouts.header')
    <title>@yield('title')</title>
    @yield('pageCSS')
</head>

<body style="padding-right: 0px !important;">
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu"
                    aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="/admin/dashboard"><img src="/images/logo4.png" alt="Logo"></a>
            <a class="navbar-brand hidden" href="/admin/dashboard"><img src="/images/favicon.png" alt="Logo"></a>
        </div>

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li>
                    <a href="/admin/dashboard" class="dashboardPage"> <i class="menu-icon fa fa-dashboard"
                                                                         aria-hidden="true" data-toggle="popover10"
                                                                         data-content=""></i>Dashboard
                    </a>
                </li>

                <li>
                    <a href="/admin/projects-info"> <i class="menu-icon fa fa-file-text" aria-hidden="true"
                                                       data-toggle="popover11" data-content=""></i>Projects </a>
                </li>
                <li>
                    <a href="/admin/staff-list-details"> <i class="menu-icon fa fa-users" aria-hidden="true"
                                                            data-toggle="popover12" data-content=""></i>Staff List</a>
                </li>
                <li>
                    <a href="/admin/invoice"> <i class="menu-icon fa fa-money" aria-hidden="true"
                                                 data-toggle="popover13" data-content=""></i>Invoices/Payment </a>
                </li>
                <li>
                    <a href="/admin/support-list"> <i class="menu-icon fa fa-users" aria-hidden="true"
                                                      data-toggle="popover14" data-content=""></i>Support List</a>
                </li>
                <li>
                    <a href="/admin/message-page"> <i class="menu-icon fa fa-commenting-o" aria-hidden="true"
                                                      data-toggle="popover15" data-content=""></i>Messages</a>
                </li>
                <li>
                    <a href="/admin/logout"> <i class="menu-icon fa fa-sign-out" aria-hidden="true"
                                                data-toggle="popover16" data-content=""></i>Logout </a>
                </li>

            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>
</aside>
<div id="right-panel" class="right-panel">
    <header id="header" class="header">
        <div class="header-menu">

            <div class="col-sm-7">
                <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                <div class="header-left">

                    <a href="/admin/feed">
                        <div class="dropdown for-notification getNotifcation">

                            @if(Session::get('co_admin')['totalNotification'] > 0)
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="notification"
                                        aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content="">
                                    <i class="fa fa-bell"></i>
                                    <span class="count bg-danger" style="height: 16px;
width: 18px;">{{Session::get('co_admin')['totalNotification']}}</span>
                                </button>
                            @else
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="notification"
                                        aria-haspopup="true" aria-hidden="true" data-toggle="popover2" data-content=""
                                        style="margin-top: -8px;">
                                    <i class="fa fa-bell"></i>
                                </button>
                            @endif

                        </div>
                    </a>
                    <a data-toggle="modal" data-target="#taskCreationmodal"
                       style="cursor: pointer;font-size:20px;padding: 0px 10px;"><i class="fa fa-plus-square-o"
                                                                                  aria-hidden="true"
                                                                                  data-toggle="popover1"
                                                                                  data-content=""></i></a>
                    <a href="/admin/resource-page" style="cursor: pointer;font-size:20px;padding: 0px 10px;"><i
                                class="fa fa-info-circle" aria-hidden="true" data-toggle="popover" data-content=""></i></a>
                    <a data-toggle="modal" data-target="#invitation_link"
                       style="cursor: pointer;font-size:20px;padding: 0px 10px;"><i class="fa fa-paper-plane-o"
                                                                                  aria-hidden="true"
                                                                                  data-toggle="popover3"
                                                                                  data-content=""></i>
                    </a>
                </div>
            </div>

            <div class="col-sm-5">
                <div class="user-area dropdown float-right">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false">
                        <img class="user-avatar rounded-circle" @if(Session::get('co_admin')['profile_pic'])
                        src="{{Session::get('co_admin')['profile_pic']}}" @else src="/images/default.png"
                             @endif alt="User Avatar">
                    </a>

                    <div class="user-menu dropdown-menu" style="left: 0 !important;">
                        {{--<div class="user-menu dropdown-menu" style=" border-radius: 0;--}}
                        {{--transform: none !important;">--}}
                        {{--<a class="nav-link" href="#"><i class="fa fa- user"></i>My Profile</a>--}}

                        {{--<a class="nav-link" href="#"><i class="fa fa- user"></i>Notifications <span--}}
                        {{--class="count">13</span></a>--}}

                        <a class="nav-link" href="/admin/account-setting-page"><i class="fa fa -cog"></i>Settings</a>

                        <a class="nav-link" href="/admin/logout"><i class="fa fa-power -off"></i>Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    @yield('body')
</div>
<div class="modal fade" id="taskCreationmodal">
    <div class="modal-dialog" style="max-width: 700px;">
        <div class="modal-content" style="border:5px solid #3ca1eb;">

            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-plus-circle"></i>&nbsp;Create
                    New
                    Task</h4>
                <button type="button" class="close cancelTaskButn" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            {{--<form enctype="multipart/form-data" action="/insertTaskDetails" type="post">--}}
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col col-md-3">
                            <label for="select" class=" form-control-label">Select Project</label>
                        </div>

                        <select name="select" id="Select" data-placeholder="Please select"
                                class="form-control form-control col-md-9 selectProName">
                            <option style="max-height:50px;overflow: auto;" value="0">Please select</option>
                            @foreach($projectName as $k=>$val)
                                <option value="{{$val->project_name}}"
                                        title="{{$val->project_name}}">{{$val->project_name}}</option>
                            @endforeach
                        </select>

                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col col-md-3">
                            <label class="control-label" for="name">Task Name</label>
                        </div>
                        <input id="name" name="name" type="text" placeholder="Task name"
                               class="form-control col-md-9 addTaskName">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col-md-3">
                            <label for="textarea-input" class=" form-control-label">Task Description</label>
                        </div>

                        <textarea name="textarea-input" id="textarea-input" rows="10"
                                  placeholder="Description..."
                                  class="form-control col-md-9 addTaskDesc"></textarea>
                    </div>
                </div>

                {{--<input type="text" name="uploadFileData" id="uploadFileData" value="">--}}

                <div class="col-md-12">
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="name">Due Date</label>
                        <input id="name" name="name" type="date" placeholder="Your name"
                               class="form-control col-md-4 taskNewDueDate" style="margin-left: -4px;">
                        <label class="col-md-2 control-label" for="name" style="text-align: right;">Due Hours</label>
                        <input id="name" name="name" type="number" min="1" placeholder="Hours"
                               class="form-control col-md-2 taskDueHours">
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col col-md-3">
                            <label for="select" class=" form-control-label">Priority</label>
                        </div>
                        <select name="select" id="Select"
                                class="form-control form-control col-md-3 addTaskPriority">
                            <option value="0" selected>None</option>
                            <option value="1">Low</option>
                            <option value="2">Medium</option>
                            <option value="3">High</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col col-md-3">
                            <label for="select" class=" form-control-label">Assignee</label>
                        </div>
                        <select class="taskAssignee form-control" name="userDataInput[]"
                                multiple="multiple">
                            {{--@foreach($userData as $k=>$val)--}}
                            {{--<option value="{{$val->name}}">{{$val->name}}</option>--}}
                            {{--@endforeach--}}
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="attachment" class="form__file">
                            <span class="form__file-filename" id="filename"
                                  data-placeholder="Attach file">Attach file</span>
                            <span class="form__file-browse">Browse</span>
                            <input type="file" name="uploadFile" class="form__file-input attachment"
                                   id="attachment">
                        </label>
                        <ul class="form__files" id="attachment-files"></ul>
                    </div>
                </div>

                <div class="col-lg-12" style="text-align: center;margin:4% 0;">

                    <button class="btn btn-success addTaskButton" style="padding: 6px 10px;">Add Task</button>
                    <button type="button" class="btn btn-danger cancelTaskBtn" data-dismiss="modal">Cancel</button>
                    <i style="font-size: 20px;display:none" class="fa fa-spinner fa-spin taskSpinnerClass"></i>
                </div>
            </div>
            {{--</form>--}}

        </div>
    </div>
</div>
<div class="modal fade" id="invitation_link">
    <div class="modal-dialog" style="max-width: 700px;">
        <div class="modal-content" style="border:5px solid #3ca1eb;">

            <!-- Modal Header -->
            <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-paper-plane-o"></i> Send
                    invitation link</h4>
                {{--<button type="button" class="close" data-dismiss="modal">&times;</button>--}}
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="col-md-12">
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="col col-md-3">
                            <label class="control-label" for="name">Email</label>
                        </div>
                        <input id="email" name="email" type="email" placeholder="Email" class="form-control col-md-9">
                    </div>
                </div>
                {{--<div class="col-md-12">--}}
                {{--<div class="form-group">--}}
                {{--<div class="col col-md-3">--}}
                {{--<label class="control-label" for="name">project name</label>--}}
                {{--</div>--}}
                {{--<input id="projectName" name="name" type="email" placeholder="Project Name" class="form-control col-md-9 inviteProjName">--}}
                {{--</div>--}}
                {{--</div>--}}
                <div class="form-group">
                    <div class="col-md-12">
                        <div class="col col-md-3">
                            <label for="select" class=" form-control-label">Portfolio</label>
                        </div>

                        <select name="select" class="form-control form-control col-md-9 selectPortfolio">
                            <option value="0">Please select</option>
                            <option value="1">Manager</option>
                            <option value="2">Staff</option>

                        </select>
                    </div>

                </div>

                <div class="col-lg-12" style="text-align: center;margin:4% 0;">

                    <button class="btn btn-success inviteBtn">Invite</button>

                    <button type="button" class="btn btn-danger cancelInviteBtn" data-dismiss="modal">Cancel</button>
                    <i style="font-size: 20px;display:none" class="fa fa-spinner fa-spin spinnerClass"></i>
                </div>
            </div>
        </div>
    </div>
</div>
@include('Admin::Dashboard/layouts.footer')
@yield('scripts')
</body>

</html>

