<meta charset="utf-8">

<meta name="csrf-token" content="{{ csrf_token() }}">


<meta http-equiv="X-UA-Compatible" content="IE=edge">
{{--<title>Cloud Office</title>--}}
<meta name="author" content="Siddu Venkatapur || UI Developer">
<meta name="author" content="Bandana Sahu || Web Developer">
<meta name="description" content="Cloud office, Project Management Software">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="apple-touch-icon" href="apple-icon.png">
<link rel="shortcut icon" href="/images/favicon.png">
<link rel="stylesheet" href="/assets/css/normalize.css">
<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/css/themify-icons.css">
<link rel="stylesheet" href="/assets/css/flag-icon.min.css">
<link rel="stylesheet" href="/assets/css/cs-skin-elastic.css">
<link rel="stylesheet" href="/assets/css/lib/datatable/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="/assets/scss/style.css">
<link rel="stylesheet" href="/assets/css/lib/chosen/chosen.min.css">
<link rel="stylesheet" href="/assets/css/file_attach.css">
<link rel="stylesheet" href="/assets/css/styles.imageuploader.css">
<link rel="stylesheet" href="/assets/css/index.css" media="screen" title="" charset="utf-8">
<link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
{{--<link href='https://fonts.googleapis.com/css?family=Roboto:400,600,700,800' rel='stylesheet' type='text/css'>--}}
<link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="/assets/css/image_uploaderstyle.css">
<link rel="stylesheet" href="/assets/css/bootstrap-popover-x.css" type="text/css">
<link rel='stylesheet prefetch'
      href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.standalone.min.css'>
<link href="/assets/css/datepicker_style.css" rel="stylesheet" type="text/css">

{{--<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>--}}

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>


{{--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">--}}

<style>

    body {

        font-size: 13px;
    }

    table {
        width: 100% !important;
    }

    .side-area .user-avatar {
        margin: 20px 10px;
        width: 80px;
    }

    .side-area {
        text-align: center;
    }

    .side-area .dropdown-toggle::after {
        display: none;
    }

    #editProjectmodal .form-control {
        display: inline-block;
    }

    #addNewproject .form-control {
        display: inline-block;
    }

    .select2-container {
        width: 420px !important;
    }

    /* Popover */
    .popover {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        font-weight: bold;
        color: #FFFFFF;
    }

    .popover1 {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        font-weight: bold;
        color: dodgerblue;
    }

    .popover2 {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        font-weight: bold;
        color: dodgerblue;
    }

    .popover5 {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        /*font-weight: bold;*/
        color: dodgerblue;
    }

    /* Popover Header */
    .popover-title {
        background-color: #73AD21;
        color: #FFFFFF;
        font-size: 28px;
        text-align: center;
    }

    /* Popover Body */
    .popover-content {
        background-color: coral;
        color: #FFFFFF;
        padding: 25px;
    }

    /* Popover Arrow */
    .arrow {
        border-right-color: red !important;
    }

    td {
        word-break: break-word;
        vertical-align: top;
    }

    label {
        line-height: 2rem;
    }

    /*Data Table CSS*/

    .table-bordered td, .table-bordered th {
        border: none;
    }

    .table-bordered tbody tr {
        border-top: 1px solid #eae9e9;
    }

    .table-striped tbody tr:nth-of-type(2n+1) {
        background-color: rgba(242, 240, 240, 0.1);
    }

    .table thead th {

        border-bottom: 1px solid #eae9e9;
    }

    .table-bordered {
        border: 1px solid #eaeaea;
    }

    .table td, .table th {
        border-top: 1px solid #ededed !important;
    }

    .card {
        border: 1px solid rgba(84, 83, 83, 0.1);
    }

    .card-header {
        border-bottom: 1px solid rgba(132, 131, 131, 0.1);
    }

    .table th {
        color: #525252;
        font-size: 15px;
    }

    .page-item.disabled .page-link {
        border-color: #e9e9ea;
    }

    .page-link {
        border-color: #e9e9ea;
    }

    .table thead th {
        border-bottom: 1px solid #e4e1e1;
        border-top: none !important;
    }

    .custom_text_info {
        color: rgb(17, 103, 167) !important;
        cursor: pointer;
    }

    .custom_text_danger {
        color: rgb(251, 86, 86) !important;
        cursor: pointer;
    }

    .btn-info {
        color: #fff;
        background-color: #3ca1eb;
        border-color: #3ca1eb;
        padding: 4px 6px;
        border-radius: 3px;
        font-size: 15px;
    }

    .btn-info:hover {
        color: #fff;
        background-color: #1e8cdd;
        border-color: #1e8cdd;
    }

    .btn-success {
        color: #fff;
        background-color: #55ad69;
        border-color: #55ad69;
        padding: 4px 7px;
        border-radius: 3px !important;
        font-size: 14px;
    }

    .btn-success:hover {
        color: #fff;
        background-color: #39a852;
        border-color: #39a852;
    }

    .content_wrap {
        white-space: nowrap;
        width: 120px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .comment_wrap {
        white-space: nowrap;
        width: 50px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    table p {
        font-size: 13px;
        color: #212529;

    }

    .btn-danger {
        color: #fff;
        background-color: #fe4a5c;
        border-color: #fe4a5c;
        padding: 4px 7px;
        border-radius: 3px !important;
        font-size: 14px;
    }

    .btn-danger:hover {
        color: #fff;
        background-color: #fe4a5c;
        border-color: #fe4a5c;
    }

    .select2-container--default .select2-search--inline .select2-search__field {
        background: transparent;
        border: none;
        outline: 0;
        box-shadow: none;
        -webkit-appearance: textfield;
        width: auto !important;
    }

    .lodder-btn {
        font-size: 24px;
        display: inline-block;
        position: absolute;
        padding: 0px;
        color: #0b50c6;
        top: 35px;
    }

    [data-tooltip] {
        position: relative;
        cursor: pointer;
        white-space: pre-wrap;
    }

    [data-tooltip]:before,
    [data-tooltip]:after {
        visibility: hidden;
        -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        opacity: 0;
        pointer-events: none;
        z-index: 99999999 !important;
    }

    [data-tooltip]:before {
        position: absolute;
        top: 70%;
        left: 50%;
        margin-bottom: 5px;
        margin-left: -80px;
        padding: 7px;
        min-width: 200px;
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        border-radius: 3px;
        background-color: #3ca1eb;
        background-color: #3ca1eb;
        color: #fff;
        content: attr(data-tooltip);
        text-align: center;
        font-size: 14px;
        line-height: 1.2;
        /*box-shadow: 0px 0px 10px #0b0b0b;*/
        /*    border: 1px solid #7e7b7b;*/
    }

    [data-tooltip]:after {
        position: absolute;
        top: 63%;
        left: 50%;
        margin-left: -5px;
        width: 0;
        border-bottom: 5px solid #3ca1eb;
        /*border-top: 5px solid #3ca1eb;*/
        border-right: 5px solid transparent;
        border-left: 5px solid transparent;
        content: " ";
        font-size: 0;
        line-height: 0;
        /*    border: 1px solid #333;*/
        /*    box-shadow: 0px 0px 10px #6A6A6A;*/
    }

    [data-tooltip]:hover:before,
    [data-tooltip]:hover:after {
        visibility: visible;
        -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=100);
        opacity: 1;
        /*    z-index: 99999999 !important;*/
    }

    .comment_btn {
        /*position: absolute;*/
        /*bottom: 3px;*/
        /*right: 1%;*/
        cursor: pointer;
        padding: 4px 8px !important;
        font-size: 13px;
        margin-top: 10px;
    }

    .loader_icon {
        font-size: 19px;
        position: absolute;
        right: 0;
    }

    /* Staff List CSS*/

    .custom_tooltip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }

    .custom_tooltip .tooltiptext {
        visibility: hidden;
        width: auto;
        background-color: #3ca1eb;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px;
        position: absolute;
        z-index: 1;
        top: 70%;
        left: 50%;
        margin-left: -60px;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .custom_tooltip .tooltiptext::after {
        content: "";
        position: absolute;
        bottom: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: transparent transparent #3ca1eb transparent;
    }

    .custom_tooltip:hover .tooltiptext {
        visibility: visible;
        opacity: 1;
    }

    .custum_hide {
        display: inline-block;
        width: 50px;
        white-space: nowrap;
        overflow: hidden !important;
        text-overflow: ellipsis;
    }

    .feed_msg{
        font-size: .94rem;
        color: #4a89dc;
        text-decoration: none;
        font-weight: 400;
        line-height: 1.629rem;
    }
    .feed_msg1{
        font-size: .94rem;
        color: #E95656;
        text-decoration: none;
        font-weight: 400;
        line-height: 1.629rem;
    }

    .focused {
        border: solid 1px red;
    }

    .fa-bars{
        color: #fff !important;
    }

</style>