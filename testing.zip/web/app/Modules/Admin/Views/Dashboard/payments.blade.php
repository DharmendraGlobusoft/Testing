@extends('Admin::Dashboard/layouts.bodyLayout')

@section('title','Invoice/Payments || Cloud Office')

@section('pageCSS')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
    <style>

        .widget .card-body {
            padding: 0px;
        }

        .widget .list-group {
            margin-bottom: 0;
        }

        .widget .panel-title {
            display: inline
        }

        .widget .label-info {
            float: right;
            background-color: #5489e4;
            color: #fff;
            padding: 6px 9px;
            border-radius: 50%;
        }

        .widget li.list-group-item {
            border-radius: 0;
            border: 0;
            border-top: 1px solid #ddd;
        }

        .widget li.list-group-item:hover {
            background-color: rgba(86, 61, 124, .1);
        }

        .widget .mic-info {
            color: #666666;
            font-size: 11px;
        }

        .widget .action {
            margin-top: 5px;
        }

        .widget .comment-text {
            font-size: 14px;
        }

        .widget .btn-block {
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .img-circle {
            border-radius: 50%;
        }

        .btn {
            padding: 5px 10px !important;
        }

        /* Staff List CSS*/

        .custom_tooltip {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
        }

        .custom_tooltip .tooltiptext {
            visibility: hidden;
            width: auto;
            background-color: #3ca1eb;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            top: 70%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .custom_tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent #3ca1eb transparent;
        }

        .custom_tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        .tooltiptext.swing:before,
        .tooltiptext.swing:after {
            transform: translate3d(0, 30px, 0) rotate3d(0, 0, 1, 60deg);
            transform-origin: 0 0;
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:after {
            transform: translate3d(0, 60px, 0);
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:hover:before,
        .tooltiptext.swing:hover:after {
            opacity: 1;
            transform: translate3d(0, 0, 0) rotate3d(1, 1, 1, 0deg);
        }

        /*        Scoll bar CSS*/

        #boxscroll {
            height: 400px;
            overflow-y: auto;
        }

        /*
        }
                #boxscroll  a{
                    overflow-x: hidden ;
                    width: 100%;
                }
        */

        .nicescroll-cursors {
            background-color: rgba(70, 166, 248, 0.8) !important;
        }

        /*        Staff details modal css*/

        .details {
            list-style-type: none;
            border: 1px solid #eee;
            margin: 0;
            padding: 0;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            background: #3c4451;
            border-radius: 5px;
        }

        .details:hover {
            box-shadow: 0 8px 12px 0 rgba(0, 0, 0, 0.2)
        }

        .details .header {
            font-size: 20px;
            padding: 15px;
            color: #fff;
            background: #db3b5e;
        }

        .details li {

            padding: 18px 20px;
            color: #fff;
        }

        .details .grey {
            background-color: #e94633;
            font-size: 20px;
            color: #fff;
        }

        .staff_img_section {
            background: #fff;
            text-align: center;
        }

        .staff_img {
            width: 150px;
            border-radius: 50%;
            border: 4px solid #3ca1eb;
        }

        /*        Custom select */
        select.soflow,
        select.soflow-color {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            -webkit-border-radius: 3px;
            /*  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);*/
            -webkit-padding-end: 20px;
            -webkit-padding-start: 2px;
            -webkit-user-select: none;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            border: 1px solid #D4D1D1;
            color: #555;
            font-size: inherit;
            /*  margin: 20px;*/
            overflow: hidden;
            padding: 5px 10px;
            text-overflow: ellipsis;
            white-space: nowrap;
            /*  width: 300px;*/
        }

        select.soflow-color {
            color: #fff;
            background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#779126, #779126 40%, #779126);
            background-color: #779126;
            -webkit-border-radius: 20px;
            -moz-border-radius: 20px;
            border-radius: 20px;
            padding-left: 15px;
        }

        select.form-control:not([size]):not([multiple]) {
            height: calc(2rem + 2px);
        }

        body {
            font-size: 14px;
        }

        /*        Month select */
        .monthly-wrp {
            padding: 1em;
            top: 6px;
            z-index: 1000;
            border-radius: 3px;
            background-color: #2C3E50;
            top: 40% !important;
            left: 36% !important;
        }

        .monthly-wrp:before {
            content: "";
            border-bottom: 6px solid #2C3E50;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            position: absolute;
            top: -6px;
            left: 6px;
            z-index: 1002;
        }

        .monthly-wrp .years {
            margin-bottom: 0.8em;
            text-align: center;
        }

        .monthly-wrp .years select {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            border: 0;
            border-radius: 3px;
            width: 100%;
            height: 30px;
            -webkit-appearance: button;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            background-color: #f6f7f5 !important;
        }

        .monthly-wrp .years select:focus {
            outline: none;
        }

        .monthly-wrp table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        .monthly-wrp td {
            padding: 1px;
        }

        .monthly-wrp table button {
            width: 100%;
            border: none;
            background-color: #3ca1eb;
            color: #FFFFFF;
            font-size: 14px;
            padding: 0.4em;
            cursor: pointer;
            border-radius: 3px;
        }

        .monthly-wrp table button:hover {
            background-color: #3ca1eb;
        }

        .monthly-wrp table button:focus {
            outline: none;
        }

        .monthly-wrp table {
            width: auto !important;
        }

    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Invoice/Payment</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/admin/dashboard">Dashboard</a></li>
                        <li class="active">Invoice/Payment</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <button type="button" class="btn btn-info" data-toggle="collapse"
                                    data-target="#filter-panel" style="padding: 4px 10px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>
                            <div id="filter-panel" class="collapse filter-panel" style="margin-top: 15px;">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <form class="form" role="form">
                                            <div class="form-group col-xs-2 col-md-2 ">
                                                <label class="control-label" for="pref-perpage">Time</label>
                                                <select id="pref-perpage" class="form-control soflow filterByTime">
                                                    <option value="0">All Time</option>
                                                    <option value="1">Today</option>
                                                    <option value="2">Last 7 days</option>
                                                    <option value="3">Last 30 days</option>
                                                </select>
                                            </div> <!-- form group [rows] -->

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-perpage">Month</label>
                                                <input class="soflow form-control filterByMonthndYear" type="text"
                                                       id="selection"
                                                       value="{{date('M Y')}}" style="font-size: inherit;">
                                            </div>

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-orderby">Staff</label>
                                                <select id="pref-orderby " class="form-control soflow filterByStaff">
                                                    <option value="0">All</option>
                                                    @foreach($userData as $i=>$v)
                                                        <option value="{{$v->id}}">{{$v->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-orderby">View</label>
                                                <select id="pref-orderby" class="form-control soflow filterByView">
                                                    <option value="0">All</option>
                                                    <option value="1">Latest Tickets(Last 7 Days)</option>
                                                </select>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="invoiceTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Number</th>
                                    <th>Sender</th>
                                    <th>Recipient</th>
                                    <th>Received Date</th>
                                    <th width="100px">Payment-By</th>
                                    <th>Attached File</th>
                                    <th>View/Comment</th>
                                    <th>Invoice Status</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="invoice_Details_modal">
        <div class="modal-dialog" style="max-width: 900px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">
                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-paper-plane-o"></i>
                        Invoice Details</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body" style="padding: 0;">
                    <div class="animated fadeIn">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card" style="margin: 0">
                                    <div class="card-body" style="background: #e3e3e7;">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Invoice
                                                        Status</label>
                                                </div>

                                                <select name="select" id="Select"
                                                        class="form-control form-control col-md-5 invoiceStatus">
                                                    <option value="1">Mark it as Paid</option>
                                                    <option value="0">Mark it as Pending</option>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col-md-3">
                                                    <label for="select" class=" form-control-label">Transaction
                                                        ID</label>
                                                </div>
                                                <input id="trId" name="name" type="text"
                                                       value=""
                                                       class="form-control col-md-5 trId">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class="form-control-label">Amount</label>
                                                </div>
                                                <input id="ammount" name="name" type="text"
                                                       value=""
                                                       class="form-control col-md-5 ammount" disabled="true">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class="form-control-label">Payment By</label>
                                                </div>
                                                <input id="paymentBy" name="name" type="text"
                                                       value=""
                                                       class="form-control col-md-5 paymentBy" disabled="true">
                                            </div>
                                            <div class="form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class="form-control-label">Payment Id</label>
                                                </div>
                                                <input id="paymentId" name="name" type="text"
                                                       value=""
                                                       class="form-control col-md-5 paymentId" disabled="true">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class="form-control-label">Date</label>
                                                </div>
                                                <input id="date" name="name" type="text"
                                                       value=""
                                                       class="form-control col-md-5 date" disabled="true">
                                            </div>
                                        </div>
                                        <div class="col-md-12">

                                            <div class="card widget">
                                                <div class="card-header">
                                                    <i class="fa fa-commenting-o" aria-hidden="true"></i>

                                                    <h5 class="panel-title">
                                                        Recent Comments</h5>
                                                    <span class="mesg" style="text-align:center;">(No Comments)</span>
                                                    <span class="label label-info totalComments">78</span>
                                                </div>
                                                <div class="card-body">
                                                    <ul class="list-group appendData">

                                                    </ul>
                                                    <a href="#" class="btn btn-primary btn-sm btn-block"
                                                       role="button"><i class="fa fa-refresh"
                                                                        aria-hidden="true"></i>
                                                        More</a>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="hero-unit">
                                                    <div>
                                                        <ul class="form__files allFiles"
                                                            id="attachment-filesInvoice"></ul>
                                                    </div>
                                                    <div class="commentInvoiceData" id="editor"></div>
                                                    <div class="btn-toolbar" data-role="editor-toolbar"
                                                         data-target="#editor" style="width: 101.6%;">
                                                        <div class="btn-group">
                                                            <a class="btn dropdown-toggle" data-toggle="dropdown"
                                                               title="Font"><i class="icon-font"></i><b
                                                                        class="caret"></b></a>
                                                            <ul class="dropdown-menu">
                                                            </ul>
                                                        </div>
                                                        <div class="btn-group">
                                                            <a class="btn dropdown-toggle" data-toggle="dropdown"
                                                               title="Font Size"><i
                                                                        class="icon-text-height"></i>&nbsp;<b
                                                                        class="caret"></b></a>
                                                            <ul class="dropdown-menu">
                                                                <li>
                                                                    <a data-edit="fontSize 5">
                                                                        <font size="5">Huge</font>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a data-edit="fontSize 3">
                                                                        <font size="3">Normal</font>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a data-edit="fontSize 1">
                                                                        <font size="1">Small</font>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-group">
                                                            <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i
                                                                        class="icon-bold"></i></a>
                                                            <a class="btn" data-edit="italic"
                                                               title="Italic (Ctrl/Cmd+I)"><i
                                                                        class="icon-italic"></i></a>
                                                            <a class="btn" data-edit="strikethrough"
                                                               title="Strikethrough"><i class="icon-strikethrough"></i></a>
                                                            <a class="btn" data-edit="underline"
                                                               title="Underline (Ctrl/Cmd+U)"><i
                                                                        class="icon-underline"></i></a>
                                                        </div>
                                                        <div class="btn-group">
                                                            <a class="btn" data-edit="undo" title="Undo (Ctrl/Cmd+Z)"><i
                                                                        class="icon-undo"></i></a>
                                                            <a class="btn" data-edit="redo" title="Redo (Ctrl/Cmd+Y)"><i
                                                                        class="icon-repeat"></i></a>
                                                        </div>
                                                        <input type="text" data-edit="inserttext" id="voiceBtn"
                                                               x-webkit-speech="">
                                                        <label for="attachmentInvoice" class="form__file"
                                                               style="width:5%;box-shadow: none;border: none;color: #000;">
                                                            <span class="form__file-filename" id="filename1"
                                                                  data-placeholder="Attach file"
                                                                  style="display: none;"></span>
                                                            <span class="form__file-browse" style="opacity: 1;top: 10px;
right: 15px;"></span>
                                                            <input type="file" name="invoiceCommentFile"
                                                                   class="form__file-input"
                                                                   id="attachmentInvoice">
                                                        </label>
                                                        <button class="btn btn-info invoiceCommentbtn" style="position: absolute;
bottom: 7%;
right: 2%;cursor: pointer;">Comment
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script>
        $(function () {
            function initToolbarBootstrapBindings() {
                var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'
                    ],
                    fontTarget = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts, function (idx, fontName) {
                    fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({
                    container: 'body'
                });
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });

                $('[data-role=magic-overlay]').each(function () {
                    var overlay = $(this),
                        target = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset = $('#editor').offset();
                    $('#voiceBtn').css('position', 'absolute').offset({
                        top: editorOffset.top,
                        left: editorOffset.left + $('#editor').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg = '';
                if (reason === 'unsupported-file-type') {
                    msg = "Unsupported format " + detail;
                } else {
                    console.log("error uploading file", reason, detail);
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings();
            $('#editor').wysiwyg({
                fileUploadError: showErrorAlert
            });
            window.prettyPrint && prettyPrint();
        });
    </script>
    <script>
        function padToTwo(number) {
            if (number <= 9999) {
                number = ("0" + number).slice(-2);
            }
            return number;
        }

        (function ($) {
            $.fn.monthly = function (options) {
                var months = options.months || [
                        "January",
                        "February",
                        "March",
                        "April",
                        "May",
                        "June",
                        "July",
                        "August",
                        "September",
                        "October",
                        "November",
                        "December"
                    ],
                    Monthly = function (el) {
                        this._el = $(el);
                        this._init();
                        this._render();
                        this._renderYears();
                        this._renderMonths();
                        this._bind();
                    };

                Monthly.prototype = {
                    _init: function () {
                        this._el.html(months[0] + " " + options.years[0]);
                    },

                    _render: function () {
                        var linkPosition = this._el.offset(),
                            cssOptions = {
                                display: "none",
                                position: "absolute",
                                top:
                                linkPosition.top + this._el.height() + (options.topOffset || 0),
                                left: linkPosition.left
                            };
                        this._container = $('<div class="monthly-wrp">')
                            .css(cssOptions)
                            .appendTo($("body"));
                    },

                    _bind: function () {
                        var self = this;
                        this._el.on("click", $.proxy(this._show, this));
                        $(document).on("click", $.proxy(this._hide, this));
                        this._yearsSelect.on("click", function (e) {
                            e.stopPropagation();
                        });
                        this._container.on("click", "button", $.proxy(this._selectMonth, this));
                    },

                    _show: function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        this._container.css("display", "inline-block");
                    },

                    _hide: function () {
                        this._container.css("display", "none");
                    },

                    _selectMonth: function (e) {
                        var monthIndex = $(e.target).data("value"),
                            month = months[monthIndex],
                            year = this._yearsSelect.val();
                        this._el.html(month + " " + year);
                        if (options.onMonthSelect) {
                            options.onMonthSelect(monthIndex, month, year);
                        }
                    },

                    _renderYears: function () {
                        var markup = $.map(options.years, function (year) {
                            return "<option>" + year + "</option>";
                        });
                        var yearsWrap = $('<div class="years">').appendTo(this._container);
                        this._yearsSelect = $("<select class='currentYear'>")
                            .html(markup.join(""))
                            .appendTo(yearsWrap);
                        var curntyear = new Date().getFullYear();
                        $('.currentYear :selected').text(curntyear);
                    },

                    _renderMonths: function () {
                        var markup = ["<table>", "<tr>"];
                        $.each(months, function (i, month) {
                            if (i > 0 && i % 4 === 0) {
                                markup.push("</tr>");
                                markup.push("<tr>");
                            }
                            markup.push(
                                '<td><button data-value="' + i + '">' + month + "</button></td>"
                            );
                        });
                        markup.push("</tr>");
                        markup.push("</table>");
                        this._container.append(markup.join(""));
                    }
                };

                return this.each(function () {
                    return new Monthly(this);
                });
            };
        })(jQuery);

        let data = [];
        for (var v = 2000; v < 2099; v++) {
            data.push(v);
        }

        $(function () {
            $("#selection").monthly({
                years: data,
                topOffset: 28,
                onMonthSelect: function (mi, m, y) {
                    mi = padToTwo(mi);
                    $("#selection").val(m + " " + y);
                    $("#monthly").val(y + "-" + mi);
                    console.log('=================',  $("#selection").val());
                    $('#invoiceTable').DataTable({
                        lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                        processing: true,
                        serverSide: true,
                        destroy: true,
                        ajax: {
                            url: '/filteringOfInvoiceAjaxHandler',
                            method:'post',
                            data: function (f) {
                                f.chooseMethod = 'FilertingByMonth';
                                f.mnthValue = $("#selection").val();
                            }
                        },
                        columns: [
                            {data: 'serialNumber', name: 'serialNumber'},
                            {data: 'inviceNumber', name: 'inviceNumber'},
                            {data: 'sender', name: 'sender'},
                            {data: 'receiver', name: 'receiver'},
                            {data: 'startDate', name: 'startDate'},
                            {data: 'paymentBy', name: 'paymentBy'},
                            {data: 'status', name: 'status'},
                            {data: 'attachFile', name: 'attachFile'},
                            {data: 'viewDetails', name: 'viewDetails'},
                        ],
                        "order": [[0, 'desc']]
                    });
                }
            });
        });

    </script>
    <script>
        var sessionData =`{{Session::get('co_admin.checkModal')}}`;
        if(parseInt(sessionData) === 1){
            $('body').toggleClass('open');
        }
        $(document).ready(function () {

            let handleInvoiceDatatable = function (target = 0, sortingType = "desc") {
                $('#invoiceTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: '/invoiceDataAjaxHandler',
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'inviceNumber', name: 'inviceNumber'},
                        {data: 'sender', name: 'sender'},
                        {data: 'receiver', name: 'receiver'},
                        {data: 'startDate', name: 'startDate'},
                        {data: 'paymentBy', name: 'paymentBy'},
                        {data: 'attachFile', name: 'attachFile'},
                        {data: 'viewDetails', name: 'viewDetails'},
                        {data: 'status', name: 'status'},
                    ],
                    "order": [[0, 'desc']]
                });
            };

            handleInvoiceDatatable();

            $(document.body).on('click', '.attachmentBtn', function () {
                $.ajax({
                    url: "/fetchFile",
                    type: "post",
                    dataType: "json",
                    data: {
                        invoiceId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $.each(response.data, function (i, v) {
                                window.open(v, '_blank');
                            });
                        }
                    }
                });
            });

            $(document.body).on('click', '.viewInvoiceDetails', function () {
                $('.invoiceCommentbtn').attr('data-id', $(this).attr('data-id'));
                $('.invoiceStatus').attr('data-id', $(this).attr('data-id'));
                $('.commentData').attr('data-id', $(this).attr('data-id')).text("");
                $(".allFiles").empty('');
                $.ajax({
                    url: "/fetchInvoiceData",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'fetchInvoiceAndComments',
                        invoiceId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('.mesg').hide();
                            $('.ammount').val(response.data[0].dueAmount);
                            $('.paymentBy').val(response.data[0].paymentBy);
                            $('.paymentId').val(response.data[0].paymentId);
                            $('.date').val(response.data[0].dueDate);
                            $('.invoiceStatus').val(response.data[0].invoiceStatus);
                            $('.totalComments').text(response.comments.length);
                            let data = '';
                            if (response.comments.length > 0) {
                                $('.mesg').hide();
                                $.each(response.comments, function (i, val) {
                                    if (val.commentBy === 'Admin') {
                                        data += '<li class="list-group-item commentClass' + val.invoice_comment_id + '"><div class="row">' +
                                            '<div class="col-xs-2 col-md-2"><img src="' + val.profilePic + '" class="img-circle img-responsive" alt=""/>' +
                                            '<span style="color:black;font-size: 12px;margin-left: 12px;">' + val.commentBy + '</span></div>' +
                                            '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                            'By: <a href="#">' + val.commentBy + '</a> on ' + val.commentPostedOn + '</div></div>' +
                                            '<div class="comment-text" style="">' + val.comment + '</div>';
                                        if (val.attachment_files) {
                                            $.each(val.attachment_files, function (i, v) {
                                                data += '<a href=' + v + ' target="_blank" class="btn btn-info"><i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + '   <i class="fa fa-download" aria-hidden="true"></i></a>';
                                            });
                                        }
                                        data += '<div class="action">' +
                                            '<button type="button" class="btn btn-danger btn-xs deleteInvoiceComment" data-id="' + val.invoice_comment_id + '" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
                                            '<button type="button" class="btn btn-info btn-xs editInvoiceComment" data-id="' + val.invoice_comment_id + '" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
                                            '<div class="panel" style="max-height: 181px; display: none;">' +
                                            '<div class="user-contact-form_field">' +
                                            '<textarea name="message" id="commentTextarea' + val.invoice_comment_id + '">' + val.comment + '</textarea>\n' +
                                            '</div>' +
                                            '<div class="user-contact-form_buttons">' +
                                            '<a class="cancel-message accordion cancelInvoiceBtn">Cancel</a>' +
                                            '<a class="send-message accordion updateInvoiceComment" data-id='+val.invoice_comment_id+'>Ok</a>' +
                                            '</div></div>' +
                                            '</div></div></div></li>';
                                    } else {
                                        data += '<li class="list-group-item commentClass' + val.invoice_comment_id + '"><div class="row">' +
                                            '<div class="col-xs-2 col-md-2"><img src="' + val.profilePic + '" class="img-circle img-responsive" alt=""/>' +
                                            '<span style="color:black;font-size: 12px;margin-left: 12px;">' + val.commentBy + '</span></div>' +
                                            '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                            'By: <a href="#">' + val.commentBy + '</a> on ' + val.commentPostedOn + '</div></div>' +
                                            '<div class="comment-text" style="">' + val.comment + '</div>';
                                        if (val.attachment_files) {
                                            $.each(val.attachment_files, function (i, v) {
                                                data += '<a href=' + v + ' target="_blank" class="btn btn-info"><i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + '   <i class="fa fa-download" aria-hidden="true"></i></a>';
                                            });
                                        }
                                        data += '</div></div></li>';
                                    }
                                });
                            } else {
                                $('.mesg').show();
                            }
                            $('.appendData').html('').append(data);
                        }
                    }
                });
            });

            /* --------------------------------------------- Filteration ---------------------------------------------------*/

            $(document.body).on('change', '.filterByStaff', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleInvoiceDatatable();
                } else {
                    invoiceTable('/filteringOfInvoiceAjaxHandler','FilertingByStaff','',staffId);
                }
            });

            $(document.body).on('change', '.filterByView', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleInvoiceDatatable();
                } else {
                    invoiceTable('/filteringOfInvoiceAjaxHandler','FilertingByView','',staffId);
                }
            });

            $(document.body).on('change', '.filterByTime', function () {
                console.log($(this).val());
                let timeVal = $(this).val();
                if (timeVal == 0) {
                    handleInvoiceDatatable();
                } else if (timeVal == 1) {
                    filterByTime('today');
                } else if (timeVal == 2) {
                    filterByTime('7 days');
                } else if (timeVal == 3) {
                    filterByTime('30 days');
                }
            });

            function filterByTime(val) {
                invoiceTable('/filteringOfInvoiceAjaxHandler','FilertingByTime',val,'')
            }

            function invoiceTable(url,method,val,staffId) {
                $('#invoiceTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: url,
                        method:'post',
                        data: function (f) {
                            f.chooseMethod = method;
                            f.time = val;
                            f.staffId = staffId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'inviceNumber', name: 'inviceNumber'},
                        {data: 'sender', name: 'sender'},
                        {data: 'receiver', name: 'receiver'},
                        {data: 'startDate', name: 'startDate'},
                        {data: 'paymentBy', name: 'paymentBy'},
                        {data: 'attachFile', name: 'attachFile'},
                        {data: 'viewDetails', name: 'viewDetails'},
                        {data: 'status', name: 'status'},
                    ],
                    "order": [[0, 'desc']]
                });
            }

        });
    </script>
@endsection