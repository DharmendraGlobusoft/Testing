@extends('Admin::Dashboard/layouts.bodyLayout')

@section('title','ProjectInfo || Cloud Office')

@section('pageCSS')
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
    {{--<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">--}}
    {{--<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">--}}
    {{--<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">--}}
    <style>

        body {
            padding-right: 0px !important;
        }

        .modal_xsm {
            min-height: 200px;
        }

        .loaderClass {
            position: absolute;
            left: 45%;
            top: 25%;
            max-height: 200px;
        }

        .buying-selling.active {
            background: #3ca1eb;
        }

        .buying-selling {
            width: 130px;
            padding: 10px;
            position: relative;
        }

        .buying-selling-word {
            font-size: 14px;
            font-weight: 600;
            margin-left: 5px;
        }

        .radio-dot:before,
        .radio-dot:after {
            content: "";
            display: block;
            position: absolute;
            background: #fff;
            border-radius: 100%;
        }

        .radio-dot:before {
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            top: 10px;
            left: 30px;
        }

        .radio-dot:after {
            width: 12px;
            height: 12px;
            border-radius: 100%;
            top: 14px;
            left: 34px;
        }

        .buying-selling.active .buying-selling-word {
            color: #fff;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active .radio-dot:before {
            background: #fff;
            border-color: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:before {
            border-color: #adadad;
        }

        .buying-selling.active:hover .radio-dot:before {
            border-color: #3ca1eb;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active:hover .radio-dot:after {
            background: #3ca1eb;
        }

        @media (max-width: 400px) {
            .mobile-br {
                display: none;
            }

            .buying-selling {
                width: 49%;
                padding: 10px;
                position: relative;
            }
        }

        a.name .name_show {
            display: none;
        }

        a.name:hover .name_show {
            display: block;
            position: absolute;
            z-index: 999;
            background: #fff;
            min-width: 5%;
            color: #fff !important;
            box-shadow: 0px 0px 15px #6A6A6A;
            margin-left: -5%;
            padding: 2%;
            background-color: #333;
            border-radius: 4px;
        }

        .name_show p {
            color: #fff;
        }

        .select2-container {
            width: 420px !important;
        }

        .popover-body {
            max-height: 200px;
            overflow: auto;
        }

        /* tab css */
        .tabs {
            background: #eee;
            margin: 0 auto;
            max-width: 950px;
            overflow: hidden;
            position: relative;
        }

        .tabs__header {
            display: flex;
            justify-content: space-between;
        }

        .tabs__header li {

            list-style: none;
        }

        .tabs__header--title {
            background: #272c33;;
            color: #fff;
            cursor: pointer;
            flex: 1 0 auto;
            padding: 10px;
            position: relative;
            text-align: center;
            transition: opacity 0.3s;
        }

        .tabs__header--title::after {
            background: #E91E63;
            bottom: -1px;
            content: '';
            display: none;
            height: 4px;
            left: 50%;
            position: absolute;
            transform: translateX(-50%) scaleX(0);
            transition: transform 0.3s;
            width: 100%;
        }

        .tabs__header--title.active::after {
            transform: translateX(-50%) scaleX(1);
        }

        .tabs__underline {
            width: 50%;
            background: #3CA1EB;
            height: 4px;
            position: absolute;
            left: 0;
            top: 40px;
            transition: transform 0.5s cubic-bezier(1, -1.25, 0, 1.75);
        }

        .tabs__content {
            background: #eee;
            display: none;
            padding: 15px 20px;
        }

        .tabs__content.active {
            animation: fadeIn 1s;
            display: block;
        }

        .tabs__content.active .tabs__content--title,
        .tabs__content.active .tabs__content--text {
            animation: fadeInUp 0.3s forwards;
        }

        .tabs__content.active .tabs__content--text {
            animation-delay: 0.3s;
        }

        .tabs__content--title {
            font-family: "Lustria", serif;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .tabs__content--text {
            line-height: 1.4;
            opacity: 0;
        }

        @media only screen and (min-width: 651px) {
            .tabs__header--title:hover {
                opacity: .7;
            }

            .tabs__header--title:not(:last-of-type) {
                border-right: 1px solid #fff;
            }
        }

        @media only screen and (max-width: 650px) {
            body {
                padding: 0;
            }

            .tabs__header {
                flex-wrap: wrap;
            }

            .tabs__header--title {
                border-bottom: 1px solid #fff;
                width: 100%;
            }

            .tabs__header--title::after {
                display: block;
            }

            .tabs__underline {
                display: none;
            }
        }

        @keyframes fadeIn {
            0% {
                display: none;
                opacity: 0;
            }
            1% {
                display: block;
                opacity: 0;
            }
            100% {
                display: block;
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #stafflist_modal .list-group-item {
            padding: 10px 0 0 0;
            border: none;
        }

        #issuelist_modal .list-group-item {
            border: none;
        }

        .img-circle {

            border-radius: 50%;
        }

        .select2-container--default .select2-search--inline .select2-search__field {
            background: transparent;
            border: none;
            outline: 0;
            box-shadow: none;
            -webkit-appearance: textfield;
            width: auto !important;
        }

        .staff_list {
            border-bottom: 1px solid #d4d2d2 !important;
            padding: 6px 15px !important;
            margin: 0px;
            font-size: 15px;
        }

        /* Staff List CSS*/

        .custom_tooltip {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
        }

        .custom_tooltip .tooltiptext {
            visibility: hidden;
            width: auto;
            background-color: #3ca1eb;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            top: 70%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .custom_tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent #3ca1eb transparent;
        }

        .custom_tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        .tooltiptext.swing:before,
        .tooltiptext.swing:after {
            transform: translate3d(0, 30px, 0) rotate3d(0, 0, 1, 60deg);
            transform-origin: 0 0;
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:after {
            transform: translate3d(0, 60px, 0);
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:hover:before,
        .tooltiptext.swing:hover:after {
            opacity: 1;
            transform: translate3d(0, 0, 0) rotate3d(1, 1, 1, 0deg);
        }

        /*        Scoll bar CSS*/

        #boxscroll {
            height: 400px;
            overflow-y: auto;
        }

        /*
        }
                #boxscroll  a{
                    overflow-x: hidden ;
                    width: 100%;
                }
        */

        .nicescroll-cursors {
            background-color: rgba(70, 166, 248, 0.8) !important;
        }

        /*        Staff details modal css*/

        .details {
            list-style-type: none;
            border: 1px solid #eee;
            margin: 0;
            padding: 0;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            background: #3c4451;
            border-radius: 5px;
        }

        .details:hover {
            box-shadow: 0 8px 12px 0 rgba(0, 0, 0, 0.2)
        }

        .details .header {
            font-size: 20px;
            padding: 15px;
            color: #fff;
            background: #db3b5e;
        }

        .details li {

            padding: 18px 20px;
            color: #fff;
        }

        .details .grey {
            background-color: #e94633;
            font-size: 20px;
            color: #fff;
        }

        .staff_img_section {
            background: #fff;
            text-align: center;
        }

        .staff_img {
            width: 150px;
            border-radius: 50%;
            border: 4px solid #3ca1eb;
        }

        /*        Custom select */
        select.soflow,
        select.soflow-color {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            -webkit-border-radius: 3px;
            /*  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);*/
            -webkit-padding-end: 20px;
            -webkit-padding-start: 2px;
            -webkit-user-select: none;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            border: 1px solid #D4D1D1;
            color: #555;
            font-size: inherit;
            /*  margin: 20px;*/
            overflow: hidden;
            padding: 5px 10px;
            text-overflow: ellipsis;
            white-space: nowrap;
            /*  width: 300px;*/
        }

        select.soflow-color {
            color: #fff;
            background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#779126, #779126 40%, #779126);
            background-color: #779126;
            -webkit-border-radius: 20px;
            -moz-border-radius: 20px;
            border-radius: 20px;
            padding-left: 15px;
        }

        select.form-control:not([size]):not([multiple]) {
            height: calc(2rem + 2px);
        }

        body {
            font-size: 14px;
        }

        /*        Month select */
        .monthly-wrp {
            padding: 1em;
            top: 6px;
            z-index: 1000;
            border-radius: 3px;
            background-color: #2C3E50;
            top: 43% !important;
            left: 35% !important;
        }

        .monthly-wrp:before {
            content: "";
            border-bottom: 6px solid #2C3E50;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            position: absolute;
            top: -6px;
            left: 6px;
            z-index: 1002;
        }

        .monthly-wrp .years {
            margin-bottom: 0.8em;
            text-align: center;
        }

        .monthly-wrp .years select {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            border: 0;
            border-radius: 3px;
            width: 100%;
            height: 30px;
            -webkit-appearance: button;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            background-color: #f6f7f5 !important;
        }

        .monthly-wrp .years select:focus {
            outline: none;
        }

        .monthly-wrp table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        .monthly-wrp td {
            padding: 1px;
        }

        .monthly-wrp table button {
            width: 100%;
            border: none;
            background-color: #3ca1eb;
            color: #FFFFFF;
            font-size: 14px;
            padding: 0.4em;
            cursor: pointer;
            border-radius: 3px;
        }

        .monthly-wrp table button:hover {
            background-color: #3ca1eb;
        }

        .monthly-wrp table button:focus {
            outline: none;
        }

        .monthly-wrp table {
            width: auto !important;
        }
    </style>
@endsection

@section('body')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Projects</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/admin/dashboard">Dashboard</a></li>
                        <li class="active">Projects</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            {{--<strong class="card-title">Project List</strong>--}}
                            <button type="button" class="btn btn-info" data-toggle="collapse"
                                    data-target="#filter-panel" style="padding: 4px 10px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>
                            <button class="btn btn-info pull-right" data-toggle="modal" data-target="#addNewproject">
                                <i class="fa fa-plus-circle" aria-hidden="true"></i> Add New Project
                            </button>

                            <div id="filter-panel" class="collapse filter-panel" style="margin-top: 15px;">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <form class="form" role="form">
                                            <div class="form-group col-xs-2 col-md-2 ">
                                                <label class="control-label" for="pref-perpage">Time</label>
                                                <select id="pref-perpage" class="form-control soflow filterByTime">
                                                    <option value="0">All Time</option>
                                                    <option value="1">Today</option>
                                                    <option value="2">Last 7 days</option>
                                                    <option value="3">Last 30 days</option>
                                                </select>
                                            </div> <!-- form group [rows] -->

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-perpage">Month</label>
                                                <input class="soflow form-control filterByMonthndYear" type="text"
                                                       id="selection"
                                                       value="{{date('M Y')}}" style="font-size: inherit;">
                                            </div>
                                            <div class="form-group col-xs-4 col-md-4">
                                                <label class="control-label" for="pref-search">Project</label>
                                                <select id="pref-search" class="form-control soflow filterByProject">
                                                    <option value="0">All</option>
                                                    @foreach($projectName as $K=>$val)
                                                        <option value="{{$val->project_name}}">{{$val->project_name}}</option>
                                                    @endforeach
                                                </select>
                                            </div><!-- form group [search] -->
                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-orderby">Staff</label>
                                                <select id="pref-orderby " class="form-control soflow filterByStaff">
                                                    <option value="0">All</option>
                                                    @foreach($staffData as $i=>$v)
                                                        <option value="{{$v->id}}">{{$v->name}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-orderby">View</label>
                                                <select id="pref-orderby" class="form-control soflow filterByView">
                                                    <option value="0">All</option>
                                                    <option value="1">Latest Project</option>
                                                </select>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            {{--bootstrap-data-table--}}
                            <table id="projectTable" class="table table-striped table-bordered projectTable">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    {{--<th>Id</th>--}}
                                    <th>Project Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Manager</th>
                                    <th>Status</th>
                                    <th>User List</th>
                                    <th class="pendingIssues">Pending Issues</th>
                                    <th>Action</th>
                                    <th hidden>Total Issues</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addNewproject">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">
                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Add New
                        Project</h4>
                    <button type="button" class="close closeProjectBtn" data-dismiss="modal">&times;</button>

                </div>
                <!-- Modal body -->
                <div class="modal-body">

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Project Name</label>
                            <input id="projName" name="projName" type="text" placeholder="Project Name"
                                   class="form-control col-md-8" maxlength=60 onKeyUp=check();>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Project Status</label>
                            <select id="projStatus">
                                <option value="1">Active</option>
                                <option value="0">In-Active</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Manager</label>
                            <select data-placeholder="Manager name" id="managerInput"
                                    class="form-control col-md-8">
                                <option value="0">Choose Manger</option>
                                @foreach($managerData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Staff Name</label>
                            <select class="addProjectUsers form-control js-example-placeholder-multiple"
                                    name="userDataInput[]" multiple="multiple">
                                {{--<option value=""></option>--}}
                                @foreach($userData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Start Date</label>
                            <input id="startDate" name="startDate" type="date" placeholder="Your name"
                                   class="form-control col-md-3" style="padding: 5px 0px;">

                            <label class="col-md-2 control-label" for="name">End Date</label>
                            <input id="endDate" name="endDate" type="date" placeholder="Your name"
                                   class="form-control col-md-3" style="padding: 5px 0px;">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Privacy</label>
                            <div class="buying-selling-group" id="buying-selling-group" data-toggle="buttons"
                                 style="display: inline-block;">
                                <label class="btn btn-default buying-selling">
                                    <input type="radio" name="options" id="publicRadioBtn" autocomplete="off">
                                    <span class="radio-dot"></span>
                                    <span class="buying-selling-word">Public</span>
                                </label>

                                <label class="btn btn-default buying-selling">
                                    <input type="radio" name="options" id="privateRadioBtn" autocomplete="off">
                                    <span class="radio-dot"></span>
                                    <span class="buying-selling-word">Private</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12" style="text-align: center;margin-top:2%;">
                        <button class="btn btn-success addProjectButton" style="padding: 8px 25px;">Add Project
                        </button>

                    </div>

                </div>
                {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-danger closeProjectBtn" data-dismiss="modal">Close</button>--}}
                {{--</div>--}}

            </div>
        </div>
    </div>
    <div class="modal fade" id="editProjectmodal">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Edit
                        Project</h4>
                    <button type="button" class="close editCloseBtn" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Project Name</label>
                            <input id="projectName" name="name" type="text" placeholder="Project Name"
                                   class="form-control col-md-8">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Project Status</label>
                            <select name="projectStatus" id="projectStatus">
                                <option value="1">Active</option>
                                <option value="0">In-Active</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Manager</label>
                            <select data-placeholder="Manager name" id="managerInputData" name="projectManager"
                                    class="form-control col-md-8">
                                <option value="0">Choose Manger</option>
                                @foreach($managerData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group" id="selectUserData">
                            <label class="col-md-3 control-label" for="name">Staff Name</label>

                            <select class="userDataInput form-control js-example-placeholder-multiple"
                                    name="userDataInput[]"
                                    multiple="multiple">
                                @foreach($userData as $k=>$val)
                                    <option value="{{$val->username}}">{{$val->name}}[{{$val->username}}]</option>
                                @endforeach
                            </select>
                            {{--<select data-placeholder="Choose your User..." multiple--}}
                            {{--class="form-control col-md-8 staffNames standardSelect" id="userDataInput"--}}
                            {{--name="projectStaffs">--}}

                            {{--@foreach($userData as $k=>$val)--}}
                            {{--<option value="{{$val->name}}">{{$val->name}}</option>--}}
                            {{--@endforeach--}}
                            {{--</select>--}}
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Start Date</label>
                            <input id="startDate" name="name" type="date" placeholder="Your name"
                                   class="form-control col-md-3 ProjstartDate" style="padding: 5px 0px;">

                            <label style="text-align: right;" class="col-md-2 control-label" for="name">End Date</label>
                            <input id="endDate" name="name" type="date" placeholder="Your name"
                                   class="form-control col-md-3 projEndDate" style="padding: 5px 0px;">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="name">Privacy</label>
                            <div class="buying-selling-group" id="buying-selling-group" data-toggle="buttons"
                                 style="display: inline-block;">
                                <label class="btn btn-default buying-selling">
                                    <input type="radio" value="public" name="privacyOptions" class="publicBtn"
                                           id="option1" autocomplete="off">
                                    <span class="radio-dot"></span>
                                    <span class="buying-selling-word">Public</span>
                                </label>

                                <label class="btn btn-default buying-selling">
                                    <input type="radio" value="private" name="privacyOptions" class="privateBtn"
                                           id="option2" autocomplete="off">
                                    <span class="radio-dot"></span>
                                    <span class="buying-selling-word">Private</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12" style="text-align: center;margin-top:2%;">
                        <button class="btn btn-success updateProjectDataBtn"
                                style="padding: 8px 25px;">Update
                        </button>

                    </div>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger editCloseBtn" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="stafflist_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="true">
        <div class="modal-dialog modal-sm" role="document" style="max-width: 425px;">
            <div class="modal-content modal_xsm" style="border: none;">
                <div class="modal-header" style="background: #1e8cdd;">
                    <h5 class="modal-title" id="exampleModalLabel" style="color: #fff;">Staff List</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body text-center p-lg"
                     style="padding:0;max-height: 400px;overflow: auto;margin-bottom: 10px;">
                    <div class="loaderClass hide">
                        <img src="/images/cloud_loading.gif" style="width: 50px;">
                    </div>
                    <div class="col-md-12" style="padding: 0;">
                        <ul class="list-group" style="text-align: left;">
                            <li class="list-group-item staff_list"><img src="images/admin1.jpg" class="img-circle"
                                                                        width="40px">
                                Siddu Venkatapur
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="issuelist_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: #1e8cdd;">
                    <h5 class="modal-title" id="exampleModalLabel" style="color: #fff;">Issues List</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body text-center p-lg"
                     style="adding: 0.5rem;max-height: 400px;overflow: auto;margin-bottom: 20px;">
                    <div class="col-md-12">

                        <ul type="1" start="1" class="list-group issueList" style="text-align: left;">
                            <li class="list-group-item">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmProjectModal">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete The Project? </p>
                        {{--Once you delete the delete the project relates task and issues also deleted!--}}
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmOKBtn" style="padding: 4px 7px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
                {{--<div class="modal-footer">--}}
                {{--<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>--}}
                {{--</div>--}}
            </div>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js'></script>
    <script src="/assets/js/toastr/toastr.min.js"></script>
    {{--<script src="/assets/js/bootstrap-popover-x.min.js" type="text/javascript"></script>--}}
    <script>
        jQuery(document).ready(function () {
            jQuery(".standardSelect").chosen({
                disable_search_threshold: 10,
                no_results_text: "Oops, nothing found!",
                width: "50%"
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            $('[data-toggle="popover"]').popover();
        });
    </script>

    <script>
        $(document).ready(function () {
            $('.user-area').click(function () {
                $(this).toggleClass('show');
                $(this).siblings("user-menu").toggleClass('show')
            })

        });
    </script>

    <script>
        function padToTwo(number) {
            if (number <= 9999) {
                number = ("0" + number).slice(-2);
            }
            return number;
        }

        (function ($) {
            $.fn.monthly = function (options) {
                var months = options.months || [
                        "January",
                        "February",
                        "March",
                        "April",
                        "May",
                        "June",
                        "July",
                        "August",
                        "September",
                        "October",
                        "November",
                        "December"
                    ],
                    Monthly = function (el) {
                        this._el = $(el);
                        this._init();
                        this._render();
                        this._renderYears();
                        this._renderMonths();
                        this._bind();
                    };

                Monthly.prototype = {
                    _init: function () {
                        this._el.html(months[0] + " " + options.years[0]);
                    },

                    _render: function () {
                        var linkPosition = this._el.offset(),
                            cssOptions = {
                                display: "none",
                                position: "absolute",
                                top:
                                linkPosition.top + this._el.height() + (options.topOffset || 0),
                                left: linkPosition.left
                            };
                        this._container = $('<div class="monthly-wrp">')
                            .css(cssOptions)
                            .appendTo($("body"));
                    },

                    _bind: function () {
                        var self = this;
                        this._el.on("click", $.proxy(this._show, this));
                        $(document).on("click", $.proxy(this._hide, this));
                        this._yearsSelect.on("click", function (e) {
                            e.stopPropagation();
                        });
                        this._container.on("click", "button", $.proxy(this._selectMonth, this));
                    },

                    _show: function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        this._container.css("display", "inline-block");
                    },

                    _hide: function () {
                        this._container.css("display", "none");
                    },

                    _selectMonth: function (e) {
                        var monthIndex = $(e.target).data("value"),
                            month = months[monthIndex],
                            year = this._yearsSelect.val();
                        this._el.html(month + " " + year);
                        if (options.onMonthSelect) {
                            options.onMonthSelect(monthIndex, month, year);
                        }
                    },

                    _renderYears: function () {
                        var markup = $.map(options.years, function (year) {
                            return "<option>" + year + "</option>";
                        });
                        var yearsWrap = $('<div class="years">').appendTo(this._container);
                        this._yearsSelect = $("<select class='currentYear'>")
                            .html(markup.join(""))
                            .appendTo(yearsWrap);
                        var curntyear = new Date().getFullYear();
                        $('.currentYear :selected').text(curntyear);
                    },

                    _renderMonths: function () {
                        var markup = ["<table>", "<tr>"];
                        $.each(months, function (i, month) {
                            if (i > 0 && i % 4 === 0) {
                                markup.push("</tr>");
                                markup.push("<tr>");
                            }
                            markup.push(
                                '<td><button data-value="' + i + '">' + month + "</button></td>"
                            );
                        });
                        markup.push("</tr>");
                        markup.push("</table>");
                        this._container.append(markup.join(""));
                    }
                };

                return this.each(function () {
                    return new Monthly(this);
                });
            };
        })(jQuery);

        let data = [];
        for (var v = 2000; v < 2099; v++) {
            data.push(v);
        }

        $(function () {
            $("#selection").monthly({
                years: data,
                topOffset: 28,
                onMonthSelect: function (mi, m, y) {
                    mi = padToTwo(mi);
                    $("#selection").val(m + " " + y);
                    $("#monthly").val(y + "-" + mi);
                    console.log('=================', $("#selection").val());
                    $('#projectTable').DataTable({
                        lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                        destroy: true,
                        processing: true,
                        serverSide: true,
                        ajax: {
                            url: '/filteringOfDataAjaxHandler',
                            data: function (f) {
                                f.chooseMethod = 'FilertingByMonth';
                                f.mnthValue = $("#selection").val();
                            }
                        },
                        columns: [
                            {data: 'serialNumber', name: 'serialNumber'},
                            {data: 'projectName', name: 'projectName'},
                            {data: 'startDate', name: 'startDate'},
                            {data: 'endDate', name: 'endDate'},
                            {data: 'manager', name: 'manager'},
                            {data: 'projectStatus', name: 'projectStatus'},
                            {data: 'staffDetails', name: 'staffDetails'},
                            {data: 'pendingIssues', name: 'pendingIssues'},
                            {data: 'action', name: 'action'},
                            {data: 'totalPendingIssues', name: 'totalPendingIssues', visible: false}
                        ],
                        "order": [[0, 'desc']],
                        createdRow: function (row, data, index) {
                            let projName = data.projName.replace(/&amp;/g, '&');
                            $('td', row).eq(1).attr({
                                'data-tooltip': projName
                            });
                        },
                    });
                }
            });
        });

    </script>

    {{--<!-- Bandana Codes... -->==========================================================================--}}
    <script>
        $(document).ready(function () {
            toastr.options.positionClass = "toast-top-right";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicate = true
        });
    </script>

    <script>
        var sessionData = `{{Session::get('co_admin.checkModal')}}`;
        if (parseInt(sessionData) === 1) {
            $('body').toggleClass('open');
        }

        function check() {
            stringLength = $('#projName').val().length;
            if (stringLength >= 60) {
                toastr.error('Project Name shoud be less than 60 characters.');
            }
        }

        $(document).ready(function () {

            $(".userDataInput").select2({
                placeholder: "Select Your Staffs"
            });
            $('.addProjectUsers').select2({
                placeholder: "Select Your Staff"
            });

            let handleProjectDatatable = function (target = 0, sortingType = "desc") {
                $('#projectTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: '/projectInfoAjaxHandler',
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'startDate', name: 'startDate'},
                        {data: 'endDate', name: 'endDate'},
                        {data: 'manager', name: 'manager'},
                        {data: 'projectStatus', name: 'projectStatus'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'pendingIssues', name: 'pendingIssues'},
                        {data: 'action', name: 'action'},
                        {data: 'totalPendingIssues', name: 'totalPendingIssues', visible: false}
                    ],
                    "order": [[target, sortingType]],
                    createdRow: function (row, data, index) {
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': projName
                        });
                    },
                });
            };

            handleProjectDatatable();

            $(document.body).on('click', '.pendingIssues', function () {
                let elem = $(this);
                if (elem.hasClass("asc")) {
                    elem.addClass("desc").removeClass('asc');
                    handleProjectDatatable(9, "desc");
                } else {
                    elem.addClass("asc").removeClass('desc');
                    handleProjectDatatable(9, "asc");
                }
            });

            $(document.body).on('click', '.addProjectButton', function () {
                let projName, projStatus, projManager, projUsers, projStartDate, projEndDate, privacyStatus,
                    projectDataToInsert = {};

                projName = $('#projName').val();
                projectDataToInsert.projName = projName;
                projStatus = $('select#projStatus').val();
                projectDataToInsert.projStatus = projStatus;
                projManager = $('select#managerInput').val();
                projectDataToInsert.projManager = projManager;
                projUsers = $('select.addProjectUsers').val();
                projectDataToInsert.projUsers = projUsers;

                projStartDate = $('#startDate').val();
                if (projStartDate) {
                    projectDataToInsert.projStartDate = Date.parse(projStartDate) / 1000;
                } else {
                    projectDataToInsert.projStartDate = projStartDate;
                }

                projEndDate = $('#endDate').val();
                if (projEndDate) {
                    projectDataToInsert.projEndDate = Date.parse(projEndDate) / 1000;
                } else {
                    projectDataToInsert.projEndDate = projEndDate;
                }

                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();

                if ($('#publicRadioBtn').prop('checked') === true) {
                    privacyStatus = 1; // 0 - public  || 1 - private
                } else if ($('#privateRadioBtn').prop('checked') === true) {
                    privacyStatus = 0;
                }
                projectDataToInsert.privacyStatus = privacyStatus;

                if (projName.trim() === "") {
                    toastr.error('Please Enter Valid Project Name');
                } else if ($('#startDate').val() !== "" && $('#endDate').val() === "") {
                    toastr.error('Please Choose Your End Date.');
                } else if ($('#startDate').val() === "" && $('#endDate').val() !== "") {
                    toastr.error('Please Choose Your End Date.');
                } else if ($('#startDate').val() !== "" && Date.parse(date) / 1000 > Date.parse(projStartDate) / 1000) {
                    toastr.error('Start Date Should be greater than current date.');
                } else if ($('#endDate').val() !== "" && Date.parse(projEndDate) / 1000 < Date.parse(projStartDate) / 1000) {
                    toastr.error('Please Choose Your End Date which should be greater than Start Date.');
                } else {
                    $.ajax({
                        url: "/addProjectPage",
                        type: "post",
                        dataType: "json",
                        data: projectDataToInsert,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#addNewproject').modal('hide').find("input[name=projName],input[type=date],input[type=radio],select").val('').end();
                                $('li.select2-selection__choice').remove();
                                $('select#managerInput').val(0);
                                $('select#projStatus').val(1);
                                $('#projectTable').DataTable().ajax.reload();
                                let data = '';
                                data = '<option style="max-height:50px;overflow: auto;" value="0">Please select</option>';
                                $.each(response.data, function (i, v) {
                                    data += '<option value="' + v.project_name + '">' + v.project_name + '</option>';
                                });
                                $('.selectProName').html('').append(data);
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.closeProjectBtn', function () {
                $('#addNewproject').find("input[name=projName],input[type=date],input[type=radio],select").val('').end();
                $('select#projStatus').val(1);
                $('li.select2-selection__choice').remove();
                $('select#managerInput').val(0);
            });

            let userData = $.parseJSON('<?php echo isset($userData) ? json_encode($userData) : []; ?>');
            let positionArr = [];
            $(document.body).on('click', '.editProjectData', function () {
                $('.updateProjectDataBtn').attr('data-id', $(this).attr('data-id'));
                $.ajax({
                    url: "/editProjectAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        projectId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            console.log(response.data[0]);
                            $('#projectName').val(response.data[0].projectName);
                            response.data[0].projectStatus === 'Active' ? $('[name=projectStatus]').val(1) : $('[name=projectStatus]').val(0);
                            if (response.data[0].privacyStatus === 'Private') {
                                $('.privateBtn').trigger('click');
                            } else {
                                $('.publicBtn').trigger('click')
                            }
                            response.data[0].manager === "" ? $('[name=projectManager]').val(0) : $('[name=projectManager]').val(response.data[0].manager);
                            $('.ProjstartDate').val(response.data[0].startDate);
                            $('.projEndDate').val(response.data[0].endDate);
                            $('.userDataInput').val(response.data[0].staffDetails).trigger('change');
                        }
                    }
                });
            });

            $(document.body).on('click', '.staffListModal', function () {
                $.ajax({
                    url: "/fetchProDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: "fetchStaff",
                        projectId: $(this).attr('data-id')
                    },
                    beforeSend: function () {
                        $('.list-group').html('');
                        $('.loaderClass').addClass('show').removeClass('hide');
                    },
                    success: function (response) {
                        $('.loaderClass').addClass('hide').removeClass('show');
                        let data = '';
                        if (response.status === 200) {
                            $.each(response.data, function (i, v) {
                                let pic = v[0].profile_pic == null ? '/images/default.png' : v[0].profile_pic;
                                data += '<li class="list-group-item staff_list"><img src="' + pic + '" class="img-circle" width="40px" style="margin-right: 10px;">' + v[0].name + '</li>'
                            });
                            $('.list-group').html('').append(data);
                        } else {
                            data = '<h5 style="text-align: center;padding: 50px;">No Staffs are there!</h5>';
                            $('.list-group').html('').append(data);
                        }
                    }
                });
            });

            $(document.body).on('click', '.issueListModal', function () {
                $.ajax({
                    url: "/fetchProDataAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: "fetchIssue",
                        projectId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        let data = '';
                        if (response.status === 200) {
                            $.each(response.data, function (i, v) {
                                data += '<li>' + v.issue_topic + '</li>'
                            });
                            $('.issueList').html('').append(data);
                        } else {
                            data = '<h5 style="text-align: center;">No Pending Issues are there!</h5>';
                            $('.issueList').html('').append(data);
                        }
                    }
                });
            });

            let updateProName, updateProStatus, updateProManager, updateProUsers, updateProStartDate, updateProEndDate,
                updatePrivacyStatus,
                projectDataToUpdate = {};

            $(document.body).on('change', '#projectName', function () {
                updateProName = $(this).val();
                projectDataToUpdate.project_name = updateProName;
            });

            $(document.body).on('change', 'select#projectStatus', function () {
                updateProStatus = parseInt($(this).val());
                projectDataToUpdate.project_status = updateProStatus;
            });

            $(document.body).on('change', 'select#managerInputData', function () {
                updateProManager = $(this).val();
                projectDataToUpdate.manager_id = updateProManager;
            });

            $(document.body).on('change', 'select.userDataInput', function () {
                updateProUsers = $(this).val();
                if (updateProUsers.length === 0) {
                    projectDataToUpdate.staff_id = '';
                } else {
                    projectDataToUpdate.staff_id = updateProUsers;
                }
            });

            $(document.body).on('change', '.ProjstartDate', function () {
                updateProStartDate = $(this).val();
                if (updateProStartDate) {
                    projectDataToUpdate.start_date = Date.parse(updateProStartDate) / 1000;
                } else {
                    projectDataToUpdate.start_date = updateProStartDate;
                }
            });

            $(document.body).on('change', '.projEndDate', function () {
                updateProEndDate = $(this).val();
                if (updateProEndDate) {
                    projectDataToUpdate.end_date = Date.parse(updateProEndDate) / 1000;
                } else {
                    projectDataToUpdate.end_date = updateProEndDate;
                }
            });

            $(document.body).on('click', '.updateProjectDataBtn', function () {
                let startDate = Date.parse($('.ProjstartDate').val()) / 1000;
                let endDate = Date.parse($('.projEndDate').val()) / 1000;
                let nowDate = new Date();
                let date = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1) + '-' + nowDate.getDate();
                if ($('.publicBtn').prop('checked') === true) {
                    updatePrivacyStatus = 1; // 0 - public  || 1 - private
                } else if ($('.privateBtn').prop('checked') === true) {
                    updatePrivacyStatus = 0;
                }
                projectDataToUpdate.privacy_status = updatePrivacyStatus;

                if (updateProName === "") {
                    toastr.error('Please Enter Valid Project Name.');
                } else if ($('.ProjstartDate').val() !== "" && $('.projEndDate').val() === "") {
                    toastr.error('Please Choose Your End Date.');
                } else if ($('.ProjstartDate').val() === "" && $('.projEndDate').val() !== "") {
                    toastr.error('Please Choose Your Start Date.');
                } else if (Date.parse(updateProStartDate) / 1000 === startDate && Date.parse(date) / 1000 > startDate) {
                    toastr.error('Start Date Should be greater than current date.');
                } else if ($('.projEndDate').val() !== "" && endDate < startDate) {
                    toastr.error('Please Choose Your End Date which should be greater than Start Date.');
                } else {
                    projectDataToUpdate.project_id = $(this).attr('data-id');
                    $.ajax({
                        url: "/updateProjectDetails",
                        type: "post",
                        dataType: "json",
                        data: projectDataToUpdate,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#editProjectmodal').modal('hide');
                                $('#projectTable').DataTable().ajax.reload();
                                projectDataToUpdate = {};
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                projectDataToUpdate = {};
                                $('#editProjectmodal').modal('hide');
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.editCloseBtn', function () {
                projectDataToUpdate = {};
            });

            $(document.body).on('click', '.deleteProject', function () {
                $('.confirmOKBtn').attr('data-id', $(this).attr('data-id'));
            });

            $('.confirmOKBtn').click(function () {
                $.ajax({
                    url: "/deleteProjectAjaxHandler",
                    type: "post",
                    dataType: "json",
                    data: {
                        projectId: $(this).attr('data-id')
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmProjectModal').modal('hide');
                            $('#projectTable').DataTable().ajax.reload();
                            toastr.success(response.message, {timeOut: 3000})
                        } else {
                            $('#confirmProjectModal').modal('hide');
                            $('#projectTable').DataTable().ajax.reload();
                            toastr.error(response.message, {timeOut: 3000})
                        }
                    }
                });
            });

            $(document.body).on('change', '.filterByStaff', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleProjectDatatable();
                } else {
                    projectTable('/filteringOfDataAjaxHandler', 'FilertingByStaff', '', '', staffId);
                }
            });

            $(document.body).on('change', '.filterByProject', function () {
                console.log($(this).val());
                let projName = $(this).val();
                if (projName == 0) {
                    handleProjectDatatable();
                } else {
                    projectTable('/filteringOfDataAjaxHandler', 'FilertingByProject', '', projName, '');
                }
            });

            $(document.body).on('change', '.filterByView', function () {
                console.log($(this).val());
                let staffId = $(this).val();
                if (staffId == 0) {
                    handleProjectDatatable();
                } else {
                    projectTable('/filteringOfDataAjaxHandler', 'FilertingByView', '', '', '');
                }
            });

            $(document.body).on('change', '.filterByTime', function () {
                console.log($(this).val());
                let timeVal = $(this).val();
                if (timeVal == 0) {
                    handleProjectDatatable();
                } else if (timeVal == 1) {
                    filterByTime('today');
                } else if (timeVal == 2) {
                    filterByTime('7 days');
                } else if (timeVal == 3) {
                    filterByTime('30 days');
                }
            });

            function filterByTime(val) {
                projectTable('/filteringOfDataAjaxHandler', 'FilertingByTime', val, '', '');
            }

            function projectTable(url, method, val, projName, staffId) {
                $('#projectTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    ajax: {
                        url: url,
                        data: function (f) {
                            f.chooseMethod = method;
                            f.time = val;
                            f.projName = projName;
                            f.staffId = staffId
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'projectName', name: 'projectName'},
                        {data: 'startDate', name: 'startDate'},
                        {data: 'endDate', name: 'endDate'},
                        {data: 'manager', name: 'manager'},
                        {data: 'projectStatus', name: 'projectStatus'},
                        {data: 'staffDetails', name: 'staffDetails'},
                        {data: 'pendingIssues', name: 'pendingIssues'},
                        {data: 'action', name: 'action'},
                        {data: 'totalPendingIssues', name: 'totalPendingIssues', visible: false}
                    ],
                    "order": [[0, 'desc']],
                    createdRow: function (row, data, index) {
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(1).attr({
                            'data-tooltip': projName
                        });
                    },
                });
            }

        });
    </script>
@endsection