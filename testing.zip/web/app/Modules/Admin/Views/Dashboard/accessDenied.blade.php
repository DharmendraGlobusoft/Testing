<html>
<head>
    <title>Cloud Office</title>
    <link rel="shortcut icon" href="/images/favicon.png">
</head>
<body>
<div align="center">
    <div style="margin-top: 130px;width:550px;text-align:left;display:table;height:120px;">
        <div style=" text-align: center; "><img src="https://img.zohostatic.com/projects/d31/images/access-denied.svg"
                                                style="margin: 4px 0px 0px 19px;width: 206px;"><span
                    style="font-family: 'LatoSemiBold','ProximaNovaLtSemibold',Arial,Helvetica,sans-serif; color: #ff0000; margin-bottom: 9px; float:left; width: 610px; font-size: 23px; margin-left:10px;">Ouch ! Permission Denied</span><span
                    style="display:block;font-family: 'LatoRegular', 'ProximaNovaRegular',Arial,Helvetica,sans-serif; color: #000; font-size: 14px; line-height: 25px; margin: 0px auto;">It looks like you do not have access to this page. We'll take you back to the portal <a
                        href="/admin/dashboard" style="color:#00f; text-decoration:underline;">Click Here</a></span>
        </div>
    </div>
</div>
</body>
</html>