{{--<!doctype html>--}}
{{--<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->--}}
{{--<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->--}}
{{--<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->--}}
{{--<!--[if gt IE 8]><!-->--}}
{{--<html class="no-js" lang="">--}}
{{--<!--<![endif]-->--}}

{{--<head>--}}
{{--<meta charset="utf-8">--}}
{{--<meta http-equiv="X-UA-Compatible" content="IE=edge">--}}
{{--<title>Cloud Office</title>--}}
{{--<meta name="author" content="Siddu Venkatapur">--}}
{{--<meta name="description" content="Cloud office Project Management Software">--}}
{{--<meta name="viewport" content="width=device-width, initial-scale=1">--}}
{{--<meta name="csrf-token" content="{{ csrf_token() }}">--}}
{{--<link rel="apple-touch-icon" href="/apple-icon.png">--}}
{{--<link rel="shortcut icon" href="/images/favicon.png">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/normalize.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/themify-icons.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/scss/style.css">--}}
{{--<link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">--}}
{{--<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>--}}
{{--<style>--}}
{{--.error {--}}
{{--color: darkred !important;--}}
{{--}--}}

{{--/*.login-form label {*/--}}
{{--/*text-transform: lowercase !important;*/--}}
{{--/*}*/--}}
{{--</style>--}}
{{--</head>--}}
{{--<body class="bg-dark" style="background-image: url(/images/bg2.jpg);">--}}
{{--<div class="sufee-login d-flex align-content-center flex-wrap">--}}
{{--<div class="container">--}}
{{--<div class="login-content">--}}
{{--<div class="login-logo">--}}
{{--<a href="">--}}
{{--<img class="align-content" src="/images/logo4.png" alt="">--}}
{{--</a>--}}
{{--</div>--}}
{{--<div class="login-form" style="background: #cfcbcb;">--}}
{{--<form action="/staff/login" method="post" id="formId">--}}
{{--{{csrf_field()}}--}}
{{--<h4 style="text-align: center;margin-bottom: 25px;color:#333;">Login</h4>--}}
{{--<div class="form-group">--}}
{{--<label>Email / Username</label>--}}
{{--<input type="text" class="form-control" name="email" id="email" required placeholder="Email">--}}
{{--</div>--}}
{{--<div class="form-group">--}}
{{--<label>Password</label>--}}
{{--<input type="password" class="form-control" name="password" id="password" placeholder="Password">--}}
{{--</div>--}}
{{--<div class="checkbox">--}}
{{--<label>--}}
{{--<input type="checkbox" name="remember" id="remember"> Remember Me--}}
{{--</label>--}}
{{--<label class="pull-right">--}}
{{--<a href="/staff/forgetPassword">Forgotten Password?</a>--}}
{{--</label>--}}
{{--</div>--}}

{{--<button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" style="margin: 3% 0;">Sign in</button>--}}
{{--<span id="errorMess"></span>--}}
{{--<div class="register-link m-t-15 text-center">--}}
{{--<p>Don't have account ? <a href="/staff/register" style="color:#0e94f6;"> Sign Up Here</a></p>--}}
{{--</div>--}}
{{--</form>--}}
{{--</div>--}}
{{--</div>--}}
{{--</div>--}}
{{--</div>--}}
{{--<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>--}}
{{--<script src="/staffAssets/js/popper.min.js"></script>--}}
{{--<script src="/staffAssets/js/plugins.js"></script>--}}
{{--<script src="/staffAssets/js/main.js"></script>--}}
{{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>--}}
{{--<script src="/staffAssets/js/toastr/toastr.min.js"></script>--}}
{{--<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>--}}
{{--<script type="text/javascript">--}}
{{--$(document).ready(function () {--}}
{{--toastr.options.positionClass = "toast-top-center";--}}
{{--toastr.options.progressBar = true;--}}
{{--toastr.options.preventDuplicate = true;--}}

{{--window.history.pushState(null, "", window.location.href);--}}
{{--window.onpopstate = function () {--}}
{{--window.history.pushState(null, "", window.location.href);--}}
{{--};--}}

{{--$("#formId").validate({--}}
{{--rules: {--}}

{{--email: {--}}
{{--required: true,--}}
{{--// email: true--}}
{{--},--}}
{{--password: {--}}
{{--required: true,--}}
{{--minlength: 4--}}
{{--}--}}
{{--},--}}
{{--messages: {--}}
{{--email: {--}}
{{--required: "Email/Username is required..!!"--}}
{{--// email: "Please Enter Valid Email..!!"--}}
{{--},--}}
{{--password: {--}}
{{--required: 'Password is required..!!',--}}
{{--minlength: "Minimum length should be 4 characters..!!"--}}
{{--}--}}
{{--}--}}
{{--});--}}
{{--});--}}





{{--@if(\Illuminate\Support\Facades\Session::has('msg'))--}}
{{--toastr.error('{{\Illuminate\Support\Facades\Session::get('msg')}}', {timeOut: 10000});--}}
{{--@endif--}}
{{--@if(\Illuminate\Support\Facades\Session::has('msg1'))--}}
{{--toastr.success('{{\Illuminate\Support\Facades\Session::get('msg1')}}', {timeOut: 10000});--}}
{{--@endif--}}
{{--@if(\Illuminate\Support\Facades\Session::has('msg2'))--}}
{{--toastr.warning('{{\Illuminate\Support\Facades\Session::get('msg2')}}', {timeOut: 10000});--}}
{{--@endif--}}
{{--@if(\Illuminate\Support\Facades\Session::has('msg0'))--}}
{{--document.getElementById('errorMess').innerHTML ='Please enter valid credentials..!!';--}}
{{--$('#errorMess').css('color', 'red');--}}
{{--toastr.warning('{{\Illuminate\Support\Facades\Session::get('msg0')}}', {timeOut: 10000});--}}
{{--@endif--}}


{{--</script>--}}
{{--</body>--}}

{{--</html>--}}


        <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Project Management Software">
    <meta name="author" content="Siddu Venkatapur(UI Developer)">
    <meta name="author" content="Bandana Sahu(Web Developer)">
    <meta name="author" content="Dharmendra Sharma(Web Developer)">
    <link rel="icon" href="/landingAssets/img/favicon.png">

    <title>Cloud Office</title>

    <!--Bootstrap core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Font Awesome icon style  -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link href="/landingAssets/css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="/landingAssets/css/contact-input-style.css">
    <link rel="stylesheet" type="text/css" href="/landingAssets/css/loaders.css"/>
    <link rel="stylesheet" type="text/css" href="/landingAssets/css/style.css">
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
        .check {
            color: #999;
            font-size: 15px;
            position: relative;
        }

        .check pre {
            position: relative;
            padding-left: 30px;
            font-family: "Roboto", sans-serif;
        }

        .check pre:after {
            content: '';
            width: 18px;
            height: 18px;
            border: 2px solid #fff;
            position: absolute;
            left: 0;
            top: 0px;
            border-radius: 0%;
            box-sizing: border-box;
            -ms-box-sizing: border-box;
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
        }

        .check input[type="checkbox"] {
            cursor: pointer;
            position: absolute;
            width: 50%;
            height: 100%;
            z-index: 1;
            opacity: 0;
            display: none;
            filter: alpha(opacity=0);
            -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)"
        }

        .check input[type="checkbox"]:checked + pre {
            /*       */
        }

        .check input[type="checkbox"]:checked + pre:before {
            content: '';
            width: 9px;
            height: 6px;
            position: absolute;
            border: 2px solid #fff;
            border-top-width: 2px;
            border-right-width: 2px;
            border-top-style: solid;
            border-right-style: solid;
            border-top-color: rgb(255, 255, 255);
            border-right-color: rgb(255, 255, 255);
            left: 4px;
            top: 5px;
            -webkit-transform: rotate(-45deg);
            transform: rotate(-45deg);
            border-top: none;
            border-right: none;
            background: transparent;
            /*            margin-left: -20px !important;*/
        }

        pre {
            display: block;
            padding: 0px;
            /*        padding-left: 9.5px;*/
            margin: 0 0 -2px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #333;
            word-break: break-all;
            word-wrap: break-word;
            background-color: transparent;
            border: 1px solid transparent;
            border-radius: 4px;
            overflow: visible;

        }

        .checkbox label,
        .radio label {

            min-height: 20px;
            padding-left: 0px;
            margin-bottom: 0;
            font-weight: 400;
            cursor: pointer;

        }

        /*          Social Icons*/

        ul.social-network {
            list-style: none;
            display: inline;
            margin-left: 0 !important;
            padding: 0;
        }

        ul.social-network li {
            display: inline;
            margin: 0 5px;
        }

        /* footer social icons */

        .social-network a.icoRss:hover {
            background-color: #F56505;
        }

        .social-network a.icoFacebook:hover {
            background-color: #3B5998;
        }

        .social-network a.icoTwitter:hover {
            background-color: #33ccff;
        }

        .social-network a.icoGoogle:hover {
            background-color: #BD3518;
        }

        .social-network a.icoVimeo:hover {
            background-color: #0590B8;
        }

        .social-network a.icoLinkedin:hover {
            background-color: #007bb7;
        }

        .social-network a.icoRss:hover i,
        .social-network a.icoFacebook:hover i,
        .social-network a.icoTwitter:hover i,
        .social-network a.icoGoogle:hover i,
        .social-network a.icoVimeo:hover i,
        .social-network a.icoLinkedin:hover i {
            color: #fff;
        }

        a.socialIcon:hover,
        .socialHoverClass {
            color: #44BCDD;
        }

        .social-circle li a {
            display: inline-block;
            position: relative;
            margin: 0 auto 0 auto;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
            text-align: center;
            width: 50px;
            height: 50px;
            font-size: 20px;
        }

        .social-circle li i {
            margin: 0;
            line-height: 50px;
            text-align: center;
        }

        .social-circle li a:hover i,
        .triggeredHover {
            -moz-transform: rotate(360deg);
            -webkit-transform: rotate(360deg);
            -ms--transform: rotate(360deg);
            transform: rotate(360deg);
            -webkit-transition: all 0.2s;
            -moz-transition: all 0.2s;
            -o-transition: all 0.2s;
            -ms-transition: all 0.2s;
            transition: all 0.2s;
        }

        .social-circle i {
            color: #000;
            -webkit-transition: all 0.8s;
            -moz-transition: all 0.8s;
            -o-transition: all 0.8s;
            -ms-transition: all 0.8s;
            transition: all 0.8s;
        }

        .social-circle a {
            background-color: #fff;
            margin-bottom: 0px;
        }

        /*          about sec */

        .aboutus-title {
            font-size: 30px;
            letter-spacing: 0;
            line-height: 32px;
            margin: 0 0 39px;
            padding: 0 0 11px;
            position: relative;
            text-transform: uppercase;
            color: #000;
        }

        .aboutus-title::after {
            background: #3ca1eb none repeat scroll 0 0;
            bottom: 0;
            content: "";
            height: 2px;
            left: 0;
            position: absolute;
            width: 54px;
        }

        .aboutus-text {
            color: #515151;
            font-size: 14px;
            line-height: 25px;
            margin: 0 0 35px;
        }

        a:hover,
        a:active {
            color: #3ca1eb;
            text-decoration: none;
            outline: 0;
        }

        .aboutus-more {
            border: 1px solid #3ca1eb;
            border-radius: 25px;
            color: #3ca1eb;
            display: inline-block;
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 0;
            padding: 7px 20px;
            text-transform: uppercase;
        }

        .feature .feature-box .iconset {
            background: #fff none repeat scroll 0 0;
            float: left;
            position: relative;
            width: 18%;
        }

        .feature .feature-box .iconset::after {
            background: #3ca1eb none repeat scroll 0 0;
            content: "";
            height: 150%;
            left: 43%;
            position: absolute;
            top: 100%;
            width: 1px;
        }

        /*
                .feature .feature-box .feature-content h4 {
                    color: #0f0f0f;
                    font-size: 18px;
                    letter-spacing: 0;
                    line-height: 22px;
                    margin: 0 0 5px;
                    padding: 25px 0;
                }
        */

        .feature .feature-box .feature-content {
            float: left;
            padding-left: 28px;
            width: 82%;
        }

        .feature .feature-box .feature-content h4 {
            color: #0f0f0f;
            font-size: 18px;
            letter-spacing: 0;
            line-height: 22px;
            margin: 0 0 5px;
            padding: 35px 0;
        }

        .feature .feature-box .feature-content p {
            color: #606060;
            font-size: 13px;
            line-height: 22px;
        }

        .icon {
            color: #3ca1eb;
            padding: 0px;
            font-size: 40px;
            border: 1px solid #3ca1eb;
            border-radius: 100px;
            color: #3ca1eb;
            font-size: 28px;
            height: 70px;
            line-height: 70px;
            text-align: center;
            width: 70px;
        }

        /*          Scroll wraper */

        .scroll-top-wrapper {
            position: fixed;
            opacity: 0;
            visibility: hidden;
            overflow: hidden;
            text-align: center;
            z-index: 99999999;
            background-color: #777777;
            color: #eeeeee;
            width: 50px;
            height: 48px;
            line-height: 48px;
            right: 30px;
            bottom: 30px;
            padding-top: 2px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            border-bottom-left-radius: 10px;
            -webkit-transition: all 0.5s ease-in-out;
            -moz-transition: all 0.5s ease-in-out;
            -ms-transition: all 0.5s ease-in-out;
            -o-transition: all 0.5s ease-in-out;
            transition: all 0.5s ease-in-out;
        }

        .scroll-top-wrapper:hover {
            background-color: #888888;
        }

        .scroll-top-wrapper.show {
            visibility: visible;
            cursor: pointer;
            opacity: 1.0;
        }

        .scroll-top-wrapper i.fa {
            line-height: inherit;
        }

        input[type=checkbox].hidden {
            opacity: 0 !important;
        }

        .custom_line_height {
            line-height: 2;
        }

        .register {
            text-align: right;
            margin-top: -12% !important;
            margin-bottom: 5% !important;
            font-size: 14px;
        }

        .custom_icon {
            border: 1px solid #3ca1eb;
            padding: 10px;
            border-radius: 50%;
        }
    </style>

</head>

<body>
<div class="loader loader-bg">
    <div class="loader-inner ball-pulse-rise">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>

<!-- Static navbar -->
<nav class="navbar navbar-default top-bar affix" data-spy="affix" data-offset-top="250">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <img src="/landingAssets/img/logo4.png" class="image-responsive" width="200px">
        </div>
        <div id="navbar" class="navbar-collapse collapse">

            <ul class="nav navbar-nav navbar-right">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#product">Terms & Privacy</a></li>
                <li><a href="#contact">Contact</a></li>

            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
</nav>

<div class="jumbotron" id="home">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 content-sec">
                <!-- LOGIN MODULE -->
                <div class="login-page">
                    <div class="form login-form">
                        <form class="register-form acrylic">
                            <span>Reset Password</span>
                            <input type="text" placeholder="Enter Email for Reset password"/>
                            <!--                <input type="password" placeholder="Password" />-->
                            <button id="SignUp">Reset</button>
                            <p class="message"><a href="#"> have Account?</a></p>
                        </form>
                        {{--<form class="login-form acrylic">--}}


                        <form class="login-form acrylic" action="/staff/login" method="post" id="formId">
                            <span>Login</span>
                            <input type="text" class="" name="email" id="email" required placeholder="Email">
                            <input type="password" class="" name="password" id="password" placeholder="Password">
                            <div class="checkbox" style="text-align: left;color: #fff;margin-top: 4%;width: 50%;">
                                <label class="check inline">
                                    <input type="checkbox" name="remember" id="remember">
                                    <pre style="color:#fff;font-size: 14px;">Remember Me</pre>
                                </label>
                            </div>
                            <div class="message register" style=""><a href="/staff/forgetPassword" style="font-size: 14px;">Forgot Password?</a>
                            {{--<div class="message register" style=""><a href="#">Forgot Password?</a>--}}
                            </div>
                            <button id="SignIn" type="submit" >Login
                            </button>
                            <span id="errorMess" style="font-size: 16px;"></span>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<section class="about-sec" id="about">

    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-6 col-xs-12">
                <div class="aboutus">
                    <h2 class="aboutus-title">About Us</h2>
                    <p class="aboutus-text">Cloudoffice Ltd is changing the way remote teams work by providing an
                        on-demand, digital platform for scaling business teams that need higher levels of
                        professionalism, security and support </p>
                    {{--<a class="aboutus-more hidden-xs" href="#">read more</a>--}}
                </div>
            </div>

            <div class="col-md-5 col-sm-6 col-xs-12">
                <div class="feature">
                    <div class="feature-box">
                        <div class="clearfix">
                            <div class="iconset">
                                <img class="custom_icon" src="/landingAssets/img/quality.png" width="70px">
                                <!--                                    <span class="glyphicon glyphicon-heart icon"></span>-->
                            </div>
                            <div class="feature-content">
                                <h4>Dedicated manager/ Quality control account</h4>
                            </div>
                        </div>
                    </div>
                    <div class="feature-box">
                        <div class="clearfix">
                            <div class="iconset">
                                <img class="custom_icon" src="/landingAssets/img/traning.png" width="70px">
                                <!--                                    <span class="glyphicon glyphicon-cog icon"></span>-->
                            </div>
                            <div class="feature-content">
                                <h4>Bespoke training and on boarding</h4>
                            </div>
                        </div>
                    </div>
                    <div class="feature-box">
                        <div class="clearfix">
                            <div class="iconset">
                                <img class="custom_icon" src="/landingAssets/img/users.png" width="70px">
                                <!--                                    <span class="glyphicon glyphicon-user icon"></span>-->
                            </div>
                            <div class="feature-content">
                                <h4>Unlimited users and projects</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-6 col-xs-12 hidden-xs">
                <div class="aboutus-banner">
                    <img src="/landingAssets/img/aboutus.png" alt="" width="220px">
                </div>
            </div>
        </div>
    </div>

</section>

<section class="product-sec" id="product">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="aboutus-title">Terms of Service</h2>
                <h3>Your Agreement with Us</h3>
                <p>Your use of our platform is governed by this agreement (the "Terms"). "Company", "We", or "Us" means
                    Cloudoffice Ltd. The "Service" means the services We make available, Our web sites (including
                    www.cloudoffice Ltd), Our blog, and any other software, sites, and services offered by Company in
                    connection to any of those. "Customer Content" means any content you submit to Company for the
                    purpose of using the Service/Platform . In order to use the platform, You (the "Staff", "You", or
                    "Your") must first agree to the Terms. You understand and agree that we will treat Your use of the
                    Service as acceptance of the Terms from that point onwards. We may make changes to the Terms from
                    time to time. You may reject the changes by terminating Your account. You understand and agree that
                    if You use the Service after the date on which the Terms have changed, We will treat Your use as
                    acceptance of the updated Terms. If you have any question about the Terms, please contact us here.
                </p>
                <h3>Use of the Service</h3>
                <div>
                    <ul class="custom_line_height">
                        <li>You must provide accurate and complete registration information any time You register to use
                            the platform.
                        </li>
                        <li>You are responsible for the security of Your passwords and for any use of Your account.</li>
                        <li>Your use of the Service must comply with all applicable laws, regulations and ordinances.
                        </li>
                        <li>You agree to not engage in any activity that interferes with or disrupts the platform.</li>
                        <li>You may not allow multiple people to use the same account or otherwise access the platform
                            in a manner intended to impersonate a user.
                        </li>
                    </ul>


                </div>
                <h3>Cancellation and Termination</h3>
                <div>
                    <ul class="custom_line_height">
                        <li>You agree that Company, in its sole discretion and for any or no reason, may terminate or
                            suspend Your account. You agree that any termination of Your access to the Service may be
                            without prior notice, and You agree that We will not be liable to You or any third party for
                            such termination.
                        </li>
                    </ul>
                    <h3>Customer Content</h3>
                    <div>
                        <ul class="custom_line_height">
                            <li>Company claims no ownership or control over any Customer Content. You retain copyright
                                and any other rights You already hold in the Customer Content and You are responsible
                                for protecting those rights, as appropriate.
                            </li>
                            <li>You retain sole responsibility for any collaborators or third-party services that you
                                allow to access your account and entrust them at your own risk.
                            </li>
                            <li>Company is not responsible if you fail to configure, or misconfigure, your account and
                                inadvertently allow unauthorized parties to view Customer Content.
                            </li>
                        </ul>
                    </div>

                    <h3>Ideas and Feedback</h3>
                    <p>You may choose to or we may invite You to submit comments or ideas about the Service, including
                        but not limited to ideas about improving the Service or our products (“Ideas”). By submitting
                        any Idea, You agree that Your disclosure is unsolicited and without restriction and will not
                        place Company under any fiduciary or other obligation, and that we are free to use the Idea
                        without any additional compensation to You, and/or to disclose the Idea on a non-confidential
                        basis or otherwise to anyone.</p>
                    <h3>Modification of the Service</h3>
                    <div>
                        <ul class="custom_line_height">
                            <li>You acknowledge and agree that the Service may change from time to time without prior
                                notice to You.
                            </li>
                            <li>Changes include, without limitation, changes to fee and payment policies, security
                                patches, added or removed functionality, and other enhancements or restrictions.
                            </li>
                            <li>We shall not be liable to you or to any third party for any modification, price change,
                                suspension or discontinuance of the Service.
                            </li>
                        </ul>
                    </div>
                    <h3>External Resources</h3>
                    <p>The Services may include hyperlinks to other web sites or services. You acknowledge and agree
                        that Company is not responsible for the availability of any such external sites or resources,
                        and does not endorse any advertising, products or other materials on or available from such web
                        sites or resources.</p>
                    <h3>License from Company and Restrictions</h3>
                    <p>Company gives You a personal, worldwide, royalty-free, non-assignable and non-exclusive license
                        to use the software provided to You by Company as part of the Service as provided to You by
                        Company. This license is for the sole purpose of enabling You to use and enjoy the benefit of
                        the Service as provided by Company, in the manner permitted by the Terms.<br>
                        You may not (and You may not permit anyone else to): (a) copy, modify, create a derivative work
                        of, reverse engineer, decompile or otherwise attempt to extract the source code of the Service
                        or any part thereof, unless this is expressly permitted or required by law, or unless You have
                        been specifically told that You may do so by Company, in writing (e.g., through an open source
                        software license); or (b) attempt to disable or circumvent any security mechanisms used by the
                        Service. <br>
                        Open source software licenses for components of the Service released under an open source
                        license constitute separate written agreements. To the limited extent that the open source
                        software licenses expressly supersede these Terms, the open source licenses govern Your
                        agreement with Company for the use of the components of the Service released under an open
                        source license.</p>
                    <h3>Exclusion of warranties</h3>
                    <div>
                        <ul class="custom_line_height">
                            <li>You expressly understand and agree that your use of the service is at your sole risk and
                                that the service is provided "as is" and "as available.".
                            </li>
                            <li>You agree that Company has no responsibility or liability for the deletion or failure to
                                store any Content and other communications maintained or transmitted through use of the
                                Service.
                            </li>
                            <li>COMPANY DOES NOT WARRANT TO YOU THAT: (A) YOUR USE OF THE SERVICE WILL MEET YOUR
                                REQUIREMENTS, (B) YOUR USE OF THE SERVICE WILL BE UNINTERRUPTED, TIMELY, SECURE OR FREE
                                FROM ERROR, (C) THE RESULTS OR DATA PROVIDED BY THE SERVICE WILL BE ACCURATE, (D) THE
                                QUALITY OF THE SERVICE WILL MEET YOUR EXPECTATIONS AND (E) ANY ERRORS IN THE SERVICE
                                WILL BE FIXED.
                            </li>
                        </ul>
                    </div>
                    <h3>Limitation of liability</h3>
                    <p>YOU EXPRESSLY UNDERSTAND AND AGREE THAT COMPANY, ITS SUBSIDIARIES AND AFFILIATES, AND ITS
                        LICENSORS SHALL NOT BE LIABLE TO YOU FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL CONSEQUENTIAL
                        OR EXEMPLARY DAMAGES WHICH MAY BE INCURRED BY YOU, HOWEVER CAUSED AND UNDER ANY THEORY OF
                        LIABILITY. THIS SHALL INCLUDE, BUT NOT BE LIMITED TO, ANY LOSS OF PROFIT (WHETHER INCURRED
                        DIRECTLY OR INDIRECTLY), ANY LOSS OF GOODWILL OR BUSINESS REPUTATION, ANY LOSS OF DATA SUFFERED,
                        COST OF PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, OR OTHER INTANGIBLE LOSS (WHETHER OR NOT
                        COMPANY HAS BEEN ADVISED OF OR SHOULD HAVE BEEN AWARE OF THE POSSIBILITY OF ANY SUCH LOSSES
                        ARISING).</p>
                    <h3>Indemnification</h3>
                    <p>YOU AGREE TO HOLD HARMLESS AND INDEMNIFY COMPANY, AND ITS SUBSIDIARIES, AFFILIATES, OFFICERS,
                        AGENTS, EMPLOYEES, ADVERTISERS, LICENSORS, SUPPLIERS OR PARTNERS (COLLECTIVELY "COMPANY AND
                        PARTNERS") FROM AND AGAINST ANY THIRD PARTY CLAIM ARISING FROM OR IN ANY WAY RELATED TO (A) YOUR
                        BREACH OF THE TERMS, (B) YOUR USE OF THE SERVICE, (C) YOUR VIOLATION OF APPLICABLE LAWS, RULES
                        OR REGULATIONS IN CONNECTION WITH THE SERVICE, OR (D) YOUR CUSTOMER SOURCE CODE, INCLUDING ANY
                        LIABILITY OR EXPENSE ARISING FROM ALL CLAIMS, LOSSES, DAMAGES (ACTUAL AND CONSEQUENTIAL), SUITS,
                        JUDGMENTS, LITIGATION COSTS AND ATTORNEYS' FEES, OF EVERY KIND AND NATURE. IN SUCH A CASE,
                        COMPANY WILL PROVIDE YOU WITH WRITTEN NOTICE OF SUCH CLAIM, SUIT OR ACTION.</p>
                    <h3>General Legal Terms</h3>
                    <p>The Terms constitute the whole legal agreement between You and Company and govern Your use of the
                        platform and completely replace any prior agreements between You and Company in relation to the
                        Service.
                        You agree that if Company does not exercise or enforce any legal right or remedy which is
                        contained in the Terms (or which Company has the benefit of under any applicable law), this will
                        not be taken to be a formal waiver of Company's rights and that those rights or remedies will
                        still be available to Company.
                        Company shall not be liable for failing or delaying performance of its obligations resulting
                        from any condition beyond its reasonable control, including but not limited to, governmental
                        action, acts of terrorism, earthquake, fire, flood or other acts of God, labor conditions, power
                        failures, and Internet disturbances.
                    </p>
                    <h3>Privacy Policy</h3>
                    <p>Cloud Office Ltd ("us", "we", or "our") operates the www.cloudoffice.ltd website (the "Service").
                        This page informs you of our policies regarding the collection, use, and disclosure of personal
                        data when you use our Service and the choices you have associated with that data. Our Privacy
                        Policy for Cloud Office Ltd is managed through Free Privacy Policy.<br>

                        We use your data to provide and improve the Service. By using the Service, you agree to the
                        collection and use of information in accordance with this policy. Unless otherwise defined in
                        this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms
                        and Conditions, accessible from www.cloudoffice.ltd<br>

                        Information Collection And Use
                        We collect several different types of information for various purposes to provide and improve
                        our Service to you.<br>

                        Types of Data Collected
                        Personal Data
                        While using our Service, we may ask you to provide us with certain personally identifiable
                        information that can be used to contact or identify you ("Personal Data"). Personally
                        identifiable information may include, but is not limited to: <br><br>

                        Email address
                        First name and last name
                        Phone number
                        Address, State, Province, ZIP/Postal code, City
                        Cookies and Usage Data
                        Usage Data <br>
                        We may also collect information how the Service is accessed and used ("Usage Data"). This Usage
                        Data may include information such as your computer's Internet Protocol address (e.g. IP
                        address), browser type, browser version, the pages of our Service that you visit, the time and
                        date of your visit, the time spent on those pages, unique device identifiers and other
                        diagnostic data.<br>

                        Tracking & Cookies Data
                        We use cookies and similar tracking technologies to track the activity on our Service and hold
                        certain information. <br>

                        Cookies are files with small amount of data which may include an anonymous unique identifier.
                        Cookies are sent to your browser from a website and stored on your device. Tracking technologies
                        also used are beacons, tags, and scripts to collect and track information and to improve and
                        analyze our Service. <br>

                        You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
                        However, if you do not accept cookies, you may not be able to use some portions of our Service.
                        <br>

                        <b>Examples of Cookies we use: </b><br>

                        Session Cookies : We use Session Cookies to operate our Service.<br>

                        Preference Cookies : We use Preference Cookies to remember your preferences and various
                        settings.
                        Security Cookies. We use Security Cookies for security purposes. <br>
                        Use of Data <br>
                        <b>Cloud Office Ltd uses the collected data for various purposes:</b><br>
                        To provide and maintain the Service<br>
                        To notify you about changes to our Service<br>
                        To allow you to participate in interactive features of our Service when you choose to do so <br>
                        To provide customer care and support <br>
                        To provide analysis or valuable information so that we can improve the Service<br>
                        To monitor the usage of the Service <br>
                        To detect, prevent and address technical issues<br>
                        Transfer Of Data <br>

                        Your information, including Personal Data, may be transferred to — and maintained on — computers
                        located outside of your state, province, country or other governmental jurisdiction where the
                        data protection laws may differ than those from your jurisdiction.<br>

                        If you are located outside KENYA and choose to provide information to us, please note that we
                        transfer the data, including Personal Data, to KENYA and process it there. <br>

                        Your consent to this Privacy Policy followed by your submission of such information represents
                        your agreement to that transfer. <br>

                        Cloud Office Ltd will take all steps reasonably necessary to ensure that your data is treated
                        securely and in accordance with this Privacy Policy and no transfer of your Personal Data will
                        take place to an organization or a country unless there are adequate controls in place including
                        the security of your data and other personal information.<br>

                        Disclosure Of Data Legal Requirements <br>
                        <b>Cloud Office Ltd may disclose your Personal Data in the good faith belief that such action is
                            necessary to: </b><br>

                        To comply with a legal obligation <br>
                        To protect and defend the rights or property of Cloud Office Ltd <br>
                        To prevent or investigate possible wrongdoing in connection with the Service<br>
                        To protect the personal safety of users of the Service or the public<br>
                        To protect against legal liability<br>
                        Security Of Data <br>
                        The security of your data is important to us, but remember that no method of transmission over
                        the Internet, or method of electronic storage is 100% secure. While we strive to use
                        commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute
                        security. <br>

                        <b>Service Providers</b><br>
                        We may employ third party companies and individuals to facilitate our Service ("Service
                        Providers"), to provide the Service on our behalf, to perform Service-related services or to
                        assist us in analyzing how our Service is used. <br>

                        These third parties have access to your Personal Data only to perform these tasks on our behalf
                        and are obligated not to disclose or use it for any other purpose. <br>

                        <b>Links To Other Sites</b><br>
                        Our Service may contain links to other sites that are not operated by us. If you click on a
                        third party link, you will be directed to that third party's site. We strongly advise you to
                        review the Privacy Policy of every site you visit. <br>

                        We have no control over and assume no responsibility for the content, privacy policies or
                        practices of any third party sites or services.<br>

                        <b>Children's Privacy</b><br>
                        Our Service does not address anyone under the age of 18 ("Children").<br>

                        We do not knowingly collect personally identifiable information from anyone under the age of 18.
                        If you are a parent or guardian and you are aware that your Children has provided us with
                        Personal Data, please contact us. If we become aware that we have collected Personal Data from
                        children without verification of parental consent, we take steps to remove that information from
                        our servers. <br>

                        <b>Changes To This Privacy Policy</b> <br>
                        We may update our Privacy Policy from time to time. We will notify you of any changes by posting
                        the new Privacy Policy on this page.<br>

                        We will let you know via email and/or a prominent notice on our Service, prior to the change
                        becoming effective and update the "effective date" at the top of this Privacy Policy. <br>

                        You are advised to review this Privacy Policy periodically for any changes. Changes to this
                        Privacy Policy are effective when they are posted on this page. <br>

                        <b>Contact Us</b> <br>
                        If you have any questions about this Privacy Policy, please contact us: <br>

                        By visiting this page on our website: <a target="_blank" href="http://www.cloudoffice.ltd">http://www.cloudoffice.ltd</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="content contact-sec" id="contact">
    <div class="contact-us">
        <div class="container">
            <div class="contact-form">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <h2 class="aboutus-title">contact us</h2>
                        <form id="ajax-contact" method="post" action="contact-form-mail.php" class="formContactClass"
                              role="form">
                            <div class="messages" id="form-messages"></div>
                            <div class="controls">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="form_name">Firstname *</label>
                                            <input id="form_name" type="text" name="name" class="form-control"
                                                   placeholder="Please enter your firstname *" required="required"
                                                   data-error="Firstname is required.">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="form_lastname">Lastname *</label>
                                            <input id="form_lastname" type="text" name="surname" class="form-control"
                                                   placeholder="Please enter your lastname *" required="required"
                                                   data-error="Lastname is required.">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="form_email">Email *</label>
                                            <input id="form_email" type="email" name="email" class="form-control"
                                                   placeholder="Please enter your email *" required="required"
                                                   data-error="Valid email is required.">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="form_phone">Phone*</label>
                                            <input id="form_phone" type="tel" name="phone" class="form-control"
                                                   placeholder="Please enter your phone*" required
                                                   oninvalid="setCustomValidity('Please enter your phone number ')"
                                                   onchange="try{setCustomValidity('')}catch(e){}">

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="form_message">Message *</label>
                                            <textarea id="form_message" name="message" class="form-control"
                                                      placeholder="Message for me *" rows="4" required="required"
                                                      data-error="Please,leave us a message."></textarea>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="button" class="btn btn-primary mobile_margin sendMsgBtn"
                                               value="Send message">
                                    </div>
                                </div>
                            </div>

                        </form>

                    </div>
                    <!--
                                            <div class="col-sm-5">
                                                <div class="row col1">
                                                    <div class="col-xs-4">
                                                        <i class="fa fa-envelope"></i>   Email
                                                    </div>
                                                    <div class="col-xs-8">
                                                        <a href="#">hr@globussoft.in</a> <br> <a href="#">support@globussoft.com</a>
                                                    </div>
                                                </div><br>

                                            </div>
                    -->
                </div>

            </div>
        </div>
    </div>


</section>
<div class="scroll-top-wrapper ">
        <span class="scroll-top-inner">
    <i class="fa fa-2x fa-arrow-circle-up"></i>
  </span>
</div>

<footer>

    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-md-4" style="line-height: 4;">&copy;
                <script type="text/javascript">
                    document.write(new Date().getFullYear());
                </script>
                www.cloudoffice.ltd
            </div>
            {{--<div class="col-lg-8 col-sm-8 col-md-8">--}}
                {{--<ul class="social-network social-circle  pull-right">--}}
                    {{--<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>--}}
                    {{--<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>--}}
                    {{--<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>--}}
                    {{--<li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>--}}
                    {{--<li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>--}}
                {{--</ul>--}}

            {{--</div>--}}
        </div>

    </div>

</footer>


<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>
<script src="/landingAssets/js/core.js"></script>
<script src="/staffAssets/js/toastr/toastr.min.js"></script>

<script>
    if ((".loader").length) {
        // show Preloader until the website ist loaded
        $(window).on('load', function () {
            $(".loader").fadeOut("slow");
        });
    }
</script>
<script>
    $('.message a').click(function () {
        $('form').animate({
            height: "toggle",
            opacity: "toggle"
        }, "slow");
    });
</script>
<script>
    $(document).ready(function () {

        $(function () {

            $(document).on('scroll', function () {

                if ($(window).scrollTop() > 100) {
                    $('.scroll-top-wrapper').addClass('show');
                } else {
                    $('.scroll-top-wrapper').removeClass('show');
                }
            });

            $('.scroll-top-wrapper').on('click', scrollToTop);
        });

        function scrollToTop() {
            verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
            element = $('body');
            offset = element.offset();
            offsetTop = offset.top;
            $('html, body').animate({
                scrollTop: offsetTop
            }, 500, 'linear');
        }

    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        toastr.options.positionClass = "toast-top-center";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicate = true;

        window.history.pushState(null, "", window.location.href);
        window.onpopstate = function () {
            window.history.pushState(null, "", window.location.href);
        };

        $("#formId").validate({
            rules: {

                email: {
                    required: true,
                    // email: true
                },
                password: {
                    required: true,
                    minlength: 4
                }
            },
            messages: {
                email: {
                    required: "Email/Username is required..!!"
                    // email: "Please Enter Valid Email..!!"
                },
                password: {
                    required: 'Password is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                }
            }
        });
    });


    @if(\Illuminate\Support\Facades\Session::has('msg'))
    toastr.error('{{\Illuminate\Support\Facades\Session::get('msg')}}', {timeOut: 10000});
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msg1'))
    toastr.success('{{\Illuminate\Support\Facades\Session::get('msg1')}}', {timeOut: 10000});
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msg2'))
    toastr.warning('{{\Illuminate\Support\Facades\Session::get('msg2')}}', {timeOut: 10000});
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msg0'))
    document.getElementById('errorMess').innerHTML = 'Please enter valid credential !';
    $('#errorMess').css('color', 'red');
{{--    toastr.error('{{\Illuminate\Support\Facades\Session::get('msg0')}}', {timeOut: 10000});--}}
    @endif


</script>

<script>
    $(document).ready(function () {
        $(document.body).on('click', '.sendMsgBtn', function () {
            let allInfo = $('.formContactClass').serializeArray();
            $.ajax({
                url: "/sendContactForm",
                type: "post",
                dataType: "json",
                data: allInfo,
                success: function (response) {
                    if (response.status === 200) {
                        $('.formContactClass')[0].reset();
                        toastr.success(response.message, {timeOut: 3000});
                    } else {
                        toastr.error(response.message, {timeOut: 3000});
                    }
                }
            });

        });
    });
</script>


</body>

</html>



