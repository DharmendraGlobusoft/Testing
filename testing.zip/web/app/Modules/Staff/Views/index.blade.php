<?php

echo trans('Staff::example.welcome');