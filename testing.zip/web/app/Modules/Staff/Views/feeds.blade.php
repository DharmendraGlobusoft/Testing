@extends('Staff::layouts.master')

@section('title')
    <title> Notifications || Cloud Office</title>
@endsection

@section('page-style')
    <style>
        .feed_msg1 {
            font-size: .94rem;
            color: #E95656;
            text-decoration: none;
            font-weight: 400;
            line-height: 1.629rem;
        }

        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        .activity-stream {
            list-style-type: none;
            margin: 2em 3em;
            padding: 0;
            border-left: 1px solid #ccc;
            padding-left: 1.5em;
        }

        .activity-stream li {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li textarea {
            border: 1px solid #ccc;
            padding: 1em 1em 0.2em 1em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li .icon {
            height: 60px;
            width: 60px;
            padding: 4px 4px;
            color: #fff;
            box-sizing: border-box;
            display: block;
            background: #53b2ea;
            position: absolute;
            left: -4.0em;
            top: .5em;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .activity-stream li:before,
        .activity-stream li:after {
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: transparent;
            border-left: 0;
        }

        .activity-stream li:before {
            top: 1em;
            left: -8px;
            /* If 1px darken stroke slightly */
            border-right-color: #aaa;
            border-width: 7px;
        }

        .activity-stream li:after {
            top: 1em;
            left: -7px;
            border-right-color: white;
            border-width: 7px;
        }

        /*comment css*/
        .comments-container {
            margin: 60px auto 15px;
            width: 768px;
        }

        .comments-container h1 {
            font-size: 36px;
            color: #283035;
            font-weight: 400;
        }

        .comments-container h1 a {
            font-size: 18px;
            font-weight: 700;
        }

        .comments-list {
            margin-top: 30px;
            position: relative;
        }

        .comments-list:before {
            content: '';
            width: 2px;
            height: 100%;
            background: #c7cacb;
            position: absolute;
            left: 32px;
            top: 0;
        }

        .comments-list:after {
            content: '';
            position: absolute;
            background: #c7cacb;
            bottom: 0;
            left: 27px;
            width: 7px;
            height: 7px;
            border: 3px solid #dee1e3;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            border-radius: 50%;
        }

        .reply-list:before, .reply-list:after {
            display: none;
        }

        .reply-list li:before {
            content: '';
            width: 60px;
            height: 2px;
            background: #c7cacb;
            position: absolute;
            top: 25px;
            left: -55px;
        }

        .comments-list li {
            margin-bottom: 15px;
            display: block;
            position: relative;
        }

        .comments-list li:after {
            content: '';
            display: block;
            clear: both;
            height: 0;
            width: 0;
        }

        .reply-list {
            padding-left: 88px;
            clear: both;
            margin-top: 15px;
        }

        .comments-list .comment-avatar {
            width: 65px;
            height: 65px;
            position: relative;
            z-index: 99;
            float: left;
            border: 3px solid #FFF;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .comments-list .comment-avatar img {
            width: 100%;
            height: 100%;
        }

        .reply-list .comment-avatar {
            width: 50px;
            height: 50px;
        }

        .comment-main-level:after {
            content: '';
            width: 0;
            height: 0;
            display: block;
            clear: both;
        }

        .comments-list .comment-box {
            width: 90%;
            float: right;
            position: relative;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            background-color: #FFF;
        }

        .comments-list .comment-box:before, .comments-list .comment-box:after {
            content: '';
            height: 0;
            width: 0;
            position: absolute;
            display: block;
            border-width: 10px 12px 10px 0;
            border-style: solid;
            border-color: transparent #FCFCFC;
            top: 8px;
            left: -11px;
        }

        .comments-list .comment-box:before {
            border-width: 11px 13px 11px 0;
            border-color: transparent rgba(0, 0, 0, 0.05);
            left: -12px;
        }

        .reply-list .comment-box {
            width: 90%;
        }

        .comment-box .comment-head {
            background: #FCFCFC;
            padding: 10px 12px;
            border-bottom: 1px solid #E5E5E5;
            overflow: hidden;
            -webkit-border-radius: 4px 4px 0 0;
            -moz-border-radius: 4px 4px 0 0;
            border-radius: 4px 4px 0 0;
        }

        .comment-box .comment-head i {
            float: right;
            margin-left: 14px;
            position: relative;
            top: 2px;
            color: #A6A6A6;
            cursor: pointer;
            -webkit-transition: color 0.3s ease;
            -o-transition: color 0.3s ease;
            transition: color 0.3s ease;
        }

        .comment-box .comment-head i:hover {
            color: #03658c;
        }

        .comment-box .comment-name {
            color: #283035;
            font-size: 14px;
            font-weight: 700;
            float: left;
            margin-right: 10px;
        }

        .comment-box .comment-name a {
            color: #283035;
        }

        .comment-box .comment-head span {
            float: left;
            color: #999;
            font-size: 13px;
            position: relative;
            top: 1px;
        }

        .comment-box .comment-content {
            background: #FFF;
            padding: 12px;
            font-size: 15px;
            color: #595959;
            -webkit-border-radius: 0 0 0px 0px;
            -moz-border-radius: 0 0 0px 0px;
            border-radius: 0 0 0px 0px;
            border-bottom: .5px solid #e5e5e5;
        }

        .comment-box .comment-footer {
            border-radius: 0 0 4px 4px;
            padding: 12px;
            width: 100%;
            background: #fff none repeat scroll 0 0;
        }

        .comment-box .comment-footer textarea {
            resize: none;
            width: 100%;
            border-radius: 4px;
            padding: 1%;
        }

        .comment-box .send-button, .comment-box .comment-open {
            padding: 12px;
            background: #fff none repeat scroll 0 0;
            margin-top: 5px;
        }

        .comment-box .send-button .btn-send, .comment-box .comment-open .btn-send {
            background-color: #03658c;
            border-color: #03658c;
            color: #fff;
            padding: 6px 12px;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
        }

        .comment-box .send-button .btn-send, .comment-box .comment-open .btn-send {
            text-decoration: none;
        }

        .comment-box .btn-reply {
            cursor: pointer;
        }

        .comment-box .comment-name.by-author, .comment-box .comment-name.by-author a {
            color: #03658c;
        }

        .comment-box .comment-name.by-author:after {
            /*content: '';*/
            background: #03658c;
            color: #FFF;
            font-size: 12px;
            padding: 3px 5px;
            font-weight: 700;
            margin-left: 10px;
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
        }

        .comment-box .posted-time {
            margin-top: 8px;
        }

        .comment-box .comment-footer {
            display: none;
        }

        @media only screen and (max-width: 766px) {
            .comments-container {
                width: 480px;
            }

            .comments-list .comment-box {
                width: 390px;
            }

            .reply-list .comment-box {
                width: 320px;
            }
        }

        .feed_msg {
            color: #3ca1eb;;
        }

        .link_btn {
            padding: 0px;
            background-color: #fff;
            color: #3ca1eb;
            margin-top: -4px;
        }

    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Notifications</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/staff/dashboard">Dashboard</a></li>
                        <li class="active">Feeds</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Notifications</h4>
                        </div>
                        <div class="card-body" style="background: #e3e3e7;">
                            <div class="fade show active appendClass">
                                @if(count($allFeed) > 0)
                                    <ul id="comments-list" class="comments-list">
                                        @foreach($allFeed as $k=>$val)
                                            <li>
                                                <div class="comment-main-level">
                                                    <div class="comment-avatar">
                                                        <a href="@if($val->profile_pic === null) /images/default.png @else {{$val->profile_pic}} @endif"
                                                           target="_blank">
                                                            <img src="@if($val->profile_pic === null) /images/default.png @else {{$val->profile_pic}} @endif"
                                                                 alt="">
                                                        </a>
                                                    </div>
                                                    <div class="comment-box">
                                                        <div class="comment-head">
                                                            <span class="posted-time">Posted on <?php echo whatIsToday($val)?></span>
                                                        </div>


                                                        @if($val->notify_type == 0)
                                                            <div class="comment-content">
                                                                {{$val->name}} has assigned <a class="feed_msg"
                                                                                               target="_blank"
                                                                                               href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Issue </a> to you.
                                                            </div>
                                                        @elseif($val->notify_type == 1)
                                                            <div class="comment-content">
                                                                {{$val->name}} has assigned <a class="feed_msg"
                                                                                               target="_blank"
                                                                                               href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Task </a> to you.
                                                            </div>
                                                        @elseif($val->notify_type == 2)
                                                            <div class="comment-content">
                                                                {{$val->name}} has assigned <a class="feed_msg"
                                                                                               target="_blank"
                                                                                               href="/staff/projects">
                                                                    Project </a> to you.
                                                            </div>
                                                        @elseif($val->notify_type == 3)
                                                            <div class="comment-content">
                                                                {{$val->name}} has sent <a class="feed_msg"
                                                                                           target="_blank"
                                                                                           href="/staff/message">
                                                                    Message </a> to you.
                                                            </div>
                                                        @elseif($val->notify_type == 4)
                                                            <div class="comment-content">
                                                                <form action="/staff/redirectToMessage" method="post">
                                                                    {{csrf_field()}}
                                                                    <input type="hidden" name="sid"
                                                                           value="{{json_decode($val->receiver_message)[0]->sid}}"/>
                                                                    <input type="hidden" name="rid"
                                                                           value="{{json_decode($val->receiver_message)[0]->rid}}"/>
                                                                    {{$val->name}} has sent
                                                                    <button type="submit"
                                                                            class="btn btn-default link_btn">Message
                                                                    </button>
                                                                    to you.
                                                                </form>

                                                                {{--{{$val->name}} has sent <a class="feed_msg" target="_blank" href="/staff/redirectToMessage/{{json_decode($val->receiver_message)[0]->sid}}/{{json_decode($val->receiver_message)[0]->rid}}"> Message </a> to you.--}}
                                                            </div>
                                                        @elseif($val->notify_type == 5)
                                                            <div class="comment-content">
                                                                {{--{{$val->name}} has raised one <a class="feed_msg" target="_blank" href="/admin/support-list"> Ticket </a> for you.--}}
                                                                {{$val->name}} has raised one <a
                                                                        class="feed_msg ticketClass" target="_blank"
                                                                        href="/staff/supportTicket">
                                                                    Support Ticket </a>for you.
                                                            </div>
                                                        @elseif($val->notify_type == 6)
                                                            <div class="comment-content">
                                                                {{$val->name}} has replied on your <a
                                                                        class="feed_msg ticketClass" target="_blank"
                                                                        href="/staff/supportTicket/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Support Ticket </a>.
                                                            </div>
                                                        @elseif($val->notify_type == 7)
                                                            <div class="comment-content">
                                                                {{$val->name}} has commented on your <a class="feed_msg"
                                                                                                        target="_blank"
                                                                                                        href="/staff/invoice-comment/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Invoice </a>.
                                                            </div>
                                                        @elseif($val->notify_type == 8)
                                                            <div class="comment-content">
                                                                {{$val->name}} has successfully Paid <a class="feed_msg"
                                                                                                        target="_blank"
                                                                                                        href="/staff/invoice-comment/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Invoice </a>amount.
                                                            </div>
                                                        @elseif($val->notify_type == 9)
                                                            <div class="comment-content">
                                                                {{$val->name}} has changed <a class="feed_msg"
                                                                                              target="_blank"
                                                                                              href="/staff/invoice-comment/{{json_decode($val->receiver_message)[0]->id}}">
                                                                    Invoice </a>status.

                                                            </div>
                                                        @elseif($val->notify_type == 10)
                                                            <div class="comment-content">
                                                                {{$val->name}} has <a class="feed_msg"
                                                                                      href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                                      target="_blank">Commented
                                                                </a> on your Task.
                                                            </div>
                                                        @elseif($val->notify_type == 11)
                                                            <div class="comment-content">
                                                                {{$val->name}} has <a class="feed_msg"
                                                                                      href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                                      target="_blank">Commented
                                                                </a> on your Issue.
                                                            </div>
                                                        @elseif($val->notify_type == 12)
                                                            <div class="comment-content">

                                                            </div>
                                                        @elseif($val->notify_type == 13)
                                                            <div class="comment-content">

                                                            </div>
                                                        @elseif($val->notify_type == 14)
                                                            <div class="comment-content">

                                                            </div>
                                                        @elseif($val->notify_type == 15)
                                                            <div class="comment-content">

                                                            </div>
                                                        @elseif($val->notify_type == 16)
                                                            <div class="comment-content">

                                                            </div>
                                                        @elseif($val->notify_type === 17)
                                                            <div class="comment-content">
                                                                {{$val->name}} has added milestone for <a
                                                                        class="feed_msg"
                                                                        href="/staff/dashboard"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 18)
                                                            <div class="comment-content">
                                                                {{$val->name}} marked the <a
                                                                        class="feed_msg"
                                                                        href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                        target="_blank">Task</a>
                                                                as {{json_decode($val->receiver_message)[0]->msg}} in <a
                                                                        class="feed_msg"
                                                                        href="/staff/projects"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 19)
                                                            <div class="comment-content">
                                                                {{$val->name}} marked the <a
                                                                        class="feed_msg"
                                                                        href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                        target="_blank">Issue</a>
                                                                as {{json_decode($val->receiver_message)[0]->msg}} in <a
                                                                        class="feed_msg"
                                                                        href="/staff/projects"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 20)
                                                            <div class="comment-content">
                                                                {{$val->name}} has deleted the <span
                                                                        class="feed_msg1">{{json_decode($val->receiver_message)[0]->pId}}</span>
                                                                Task.

                                                            </div>
                                                        @elseif($val->notify_type === 21)
                                                            <div class="comment-content">
                                                                {{$val->name}} has deleted the <span
                                                                        class="feed_msg1">{{json_decode($val->receiver_message)[0]->pId}}</span>
                                                                Issue.
                                                            </div>
                                                        @elseif($val->notify_type === 22)
                                                            <div class="comment-content">
                                                                {{$val->name}} has updated the <a
                                                                        class="feed_msg"
                                                                        href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->msg}}</a>
                                                                in <a
                                                                        class="feed_msg"
                                                                        href="/staff/projects"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 23)
                                                            <div class="comment-content">
                                                                {{$val->name}} has updated the <a
                                                                        class="feed_msg"
                                                                        href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->msg}}</a>
                                                                in <a class="feed_msg"
                                                                      href="/staff/projects"
                                                                      target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 24)
                                                            <div class="comment-content">
                                                                {{$val->name}} has updated
                                                                the <span
                                                                        class="feed_msg1">{{json_decode($val->receiver_message)[0]->msg}}</span>
                                                                in
                                                                <a
                                                                        class="feed_msg"
                                                                        href="/staff/projects"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 25)
                                                            <div class="comment-content">
                                                                {{$val->name}} has updated
                                                                the <span
                                                                        class="feed_msg1">{{json_decode($val->receiver_message)[0]->msg}}</span>
                                                                in
                                                                <a
                                                                        class="feed_msg"
                                                                        href="/staff/projects"
                                                                        target="_blank">{{json_decode($val->receiver_message)[0]->pName}}</a>
                                                                project.
                                                            </div>
                                                        @elseif($val->notify_type === 28)
                                                            @if(json_decode($val->receiver_message)[0]->msg != "")
                                                                <div class="comment-content">
                                                                     <a class="feed_msg"
                                                                            href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                            target="_blank"> Task </a> duetime
                                                                    is {{json_decode($val->receiver_message)[0]->msg}}
                                                                    of deadline,Please complete the task soon.
                                                                </div>
                                                            @else
                                                                <div class="comment-content">
                                                                     <a class="feed_msg"
                                                                            href="/staff/viewSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                            target="_blank"> Task </a> is overdue
                                                                    .please complete your task soon.
                                                                </div>
                                                            @endif
                                                        @elseif($val->notify_type === 29)
                                                            @if(json_decode($val->receiver_message)[0]->msg != "")
                                                                <div class="comment-content">
                                                                     <a class="feed_msg"
                                                                            href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                            target="_blank"> Issue </a> duetime is
                                                                     {{json_decode($val->receiver_message)[0]->msg}}
                                                                    of deadline,Please complete the issue soon.
                                                                </div>
                                                            @else
                                                                <div class="comment-content">
                                                                     <a class="feed_msg"
                                                                            href="/staff/issueSubmittion/{{json_decode($val->receiver_message)[0]->pId}}/{{json_decode($val->receiver_message)[0]->id}}"
                                                                            target="_blank"> Issue </a> is overdue
                                                                    .please complete your issue soon.
                                                                </div>
                                                            @endif
                                                        @elseif($val->notify_type === 30)
                                                            <div class="comment-content">
                                                                {{$val->name}} has added one <a
                                                                        class="feed_msg"
                                                                        href="/staff/view-resource-page/{{json_decode($val->receiver_message)[0]->id}}"
                                                                        target="_blank">Resource</a>
                                                            </div>
                                                        @endif
                                                        <div class="comment-footer">
                                                            <div class="comment-form">
                                                                <textarea class="form-control" name="" id="getid"
                                                                          value=""></textarea>
                                                                <div class="pull-right send-button">
                                                                    <a class="btn-send" name="send">send</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                        @endforeach
                                    </ul>
                                @else
                                    <p> There Are No Notifications..!!</p>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('page-scripts')
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn-reply', function (eve) {
                eve.preventDefault();
                $(this).parent().parent().siblings('.comment-footer').slideToggle();
                eve.stopImmediatePropagation();
            });

            $(document).on('click', '.adddiv', function () {
                let contents = '<li class="type_reply" style="margin-left:15% !important;"><a href="/images/admin.jpg" target="_blank"><img src="/images/admin.jpg" class="user-avatar rounded-circle icon" width="100"></a><textarea style="margin: 16px 0px;resize: none; height: 100px; width: 100%"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</textarea>\n' +
                    '<button class="btn btn-success" style="padding: 6px 10px;position: absolute;right: 10%;bottom: 15px;">Send</button>' +
                    '<button class="btn btn-danger" style="padding: 6px 10px;position: absolute;right: 9px;bottom: 15px;">cancel</button>' +
                    '</li>';
                $(".mainchat").after(contents);
            });

        });
    </script>


    <script>
        // $(document).ready(function () {
        //
        //     var skipdata = 1;
        //     $(window).on("scroll", function () {
        //         var scrollHeight = $(document).height();
        //         var scrollPosition = $(window).height() + $(window).scrollTop();
        //         if ((scrollHeight - scrollPosition) / scrollHeight === 0) {
        //             // when scroll to bottom of the page
        //
        //             var limit = 15;
        //             var skip = limit * skipdata;
        //             $.ajax({
        //                 url: "/staff/feedsNoti",
        //                 type: "post",
        //                 dataType: "json",
        //                 data: {
        //                     skip: skip,
        //                     limit: limit
        //                 },
        //                 success: function (response) {
        //                     if (response.status === 200) {
        //                         var data = '', pic = '';
        //                         $.each(response.data, function (i, v) {
        //
        //                             if (v.profile_pic === null) {
        //                                 pic = '/images/default.png';
        //                             } else {
        //                                 pic = v.profile_pic
        //                             }
        //
        //
        //
        //
        //                             data += '<li id="' + v.notification_id + '">' +
        //                                 '<div class="comment-main-level"><div class="comment-avatar"><img src="' + pic + '" alt=""></div>' +
        //                                 '<div class="comment-box"><div class="comment-head"><span class="posted-time time">Posted on ' + getDateAndTime(v.created_at) + '</span></div>';
        //                             if (v.notify_type === 0) {
        //                                 data += '<div class="comment-content">' +
        //                                     '' + v.name + ' has added one new <a class="feed_msg" target="_blank" href="/admin/issue-submission/' + JSON.parse(v.receiver_message)[0].id + '">\n' +
        //                                     ' Issue </a> for ' + JSON.parse(v.receiver_message)[0].pName + ' project.</div>';
        //                             }
        //
        //                             if (v.notify_type === 25) {
        //                                 data += '<div class="comment-content">' +
        //                                     ' ' + v.name + ' has updated the <span class="feed_msg1">' + JSON.parse(v.receiver_message)[0].msg + '</span> in' +
        //                                     '<a class="feed_msg" href="/admin/projects-info" target="_blank">' + JSON.parse(v.receiver_message)[0].pName + '</a> project.</div>';
        //                             }
        //                             if (v.notify_type === 26) {
        //                                 data += '<div class="comment-content">' +
        //                                     ' ' + v.name + ' has deleted the <span class="feed_msg1">' + JSON.parse(v.receiver_message)[0].pName + '</span> Project .</div>';
        //                             }
        //                             if (v.notify_type === 27) {
        //                                 data += '<div class="comment-content">' +
        //                                     ' ' + v.name + ' has deleted the milestone for <span class="feed_msg1">' + JSON.parse(v.receiver_message)[0].pName + '</span> Project .</div>';
        //                             }
        //                             data += '<div class="comment-footer"><div class="comment-form">' +
        //                                 '<textarea class="form-control" name="" id="getid" value=""></textarea>\n' +
        //                                 '<div class="pull-right send-button"><a class="btn-send" name="send">send</a></div>\n' +
        //                                 '</div></div></div></div></li>';
        //                         });
        //                         $('.comments-list').append(data);
        //                         skipdata++;
        //                     } else {
        //                         toastr.error(response.message, {timeOut: 3000});
        //                     }
        //                 }
        //             });
        //         }
        //     });
        // });
    </script>


@endsection

<?php
function whatIsToday($getDate)
{
    date_default_timezone_set('Asia/Kolkata');
    $timestamp = $getDate->created_at;
    $datetimeFormat = 'Y-m-d H:i:s';

    $date = new \DateTime();
    $date->setTimestamp($timestamp);
    return $date->format($datetimeFormat);
}
?>

