<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/19/2018
 * Time: 5:18 PM
 */
?>

@extends('Staff::layouts.master')

{{--@section('title','Project')--}}
@section('title')
    <title> Support Ticket || Cloud Office</title>
@endsection

@section('page-style')
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">

    <style>
        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        .activity-stream {
            list-style-type: none;
            margin: 2em 3em;
            padding: 0;
            border-left: 1px solid #ccc;
            padding-left: 1.5em;
        }

        .activity-stream li {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .type_reply {
            border: 1px solid #ccc !important;
            padding: 1em 1em 3em 1em !important;
            margin: 1em !important;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li textarea {
            border: 1px solid #ccc;

            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li .icon {
            height: 60px;
            width: 60px;
            padding: 4px 4px;
            color: #fff;
            box-sizing: border-box;
            display: block;
            background: #53b2ea;
            position: absolute;
            left: -4.5em;
            top: .5em;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .activity-stream li:before,
        .activity-stream li:after {
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: transparent;
            border-left: 0;
        }

        .activity-stream li:before {
            top: 1em;
            left: -8px;
            /* If 1px darken stroke slightly */
            border-right-color: #aaa;
            border-width: 7px;
        }

        .activity-stream li:after {
            top: 1em;
            left: -7px;
            border-right-color: white;
            border-width: 7px;
        }

        .comments-container {
            margin: 60px auto 15px;
            width: 768px;
        }

        .comments-container h1 {
            font-size: 36px;
            color: #283035;
            font-weight: 400;
        }

        .comments-container h1 a {
            font-size: 18px;
            font-weight: 700;
        }

        .comments-list {
            margin-top: 30px;
            position: relative;
        }

        .comments-list:before {
            content: '';
            width: 2px;
            height: 100%;
            background: #c7cacb;
            position: absolute;
            left: 32px;
            top: 0;
        }

        .comments-list:after {
            content: '';
            position: absolute;
            background: #c7cacb;
            bottom: 0;
            left: 27px;
            width: 7px;
            height: 7px;
            border: 3px solid #dee1e3;
            -webkit-border-radius: 50%;
            -moz-border-radius: 50%;
            border-radius: 50%;
        }

        .reply-list:before, .reply-list:after {
            display: none;
        }

        .reply-list li:before {
            content: '';
            width: 60px;
            height: 2px;
            background: #c7cacb;
            position: absolute;
            top: 25px;
            left: -55px;
        }

        .comments-list li {
            margin-bottom: 15px;
            display: block;
            position: relative;
        }

        .comments-list li:after {
            content: '';
            display: block;
            clear: both;
            height: 0;
            width: 0;
        }

        .reply-list {
            padding-left: 88px;
            clear: both;
            margin-top: 15px;
        }

        .comments-list .comment-avatar {
            width: 65px;
            height: 65px;
            position: relative;
            z-index: 99;
            float: left;
            border: 3px solid #FFF;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            border-radius: 4px;
            -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .comments-list .comment-avatar img {
            width: 100%;
            height: 100%;
        }

        .reply-list .comment-avatar {
            width: 50px;
            height: 50px;
        }

        .comment-main-level:after {
            content: '';
            width: 0;
            height: 0;
            display: block;
            clear: both;
        }

        .comments-list .comment-box {
            width: 90%;
            float: right;
            position: relative;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            -moz-box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.15);
            background-color: #FFF;
        }

        .comments-list .comment-box:before, .comments-list .comment-box:after {
            content: '';
            height: 0;
            width: 0;
            position: absolute;
            display: block;
            border-width: 10px 12px 10px 0;
            border-style: solid;
            border-color: transparent #FCFCFC;
            top: 8px;
            left: -11px;
        }

        .comments-list .comment-box:before {
            border-width: 11px 13px 11px 0;
            border-color: transparent rgba(0, 0, 0, 0.05);
            left: -12px;
        }

        .reply-list .comment-box {
            width: 90%;
        }

        .comment-box .comment-head {
            background: #FCFCFC;
            padding: 10px 12px;
            border-bottom: 1px solid #E5E5E5;
            overflow: hidden;
            -webkit-border-radius: 4px 4px 0 0;
            -moz-border-radius: 4px 4px 0 0;
            border-radius: 4px 4px 0 0;
        }

        .comment-box .comment-head i {
            float: right;
            margin-left: 14px;
            position: relative;
            top: 2px;
            color: #A6A6A6;
            cursor: pointer;
            -webkit-transition: color 0.3s ease;
            -o-transition: color 0.3s ease;
            transition: color 0.3s ease;
        }

        .comment-box .comment-head i:hover {
            color: #03658c;
        }

        .comment-box .comment-name {
            color: #283035;
            font-size: 14px;
            font-weight: 700;
            float: left;
            margin-right: 10px;
        }

        .comment-box .comment-name a {
            color: #283035;
        }

        .comment-box .comment-head span {
            float: left;
            color: #999;
            font-size: 13px;
            position: relative;
            top: 1px;
        }

        .comment-box .comment-content {
            background: #FFF;
            padding: 12px;
            font-size: 15px;
            color: #595959;
            -webkit-border-radius: 0 0 0px 0px;
            -moz-border-radius: 0 0 0px 0px;
            border-radius: 0 0 0px 0px;
            border-bottom: .5px solid #e5e5e5;
        }

        .comment-box .comment-footer {
            border-radius: 0 0 4px 4px;
            padding: 12px;
            width: 100%;
            background: #fff none repeat scroll 0 0;
        }

        .comment-box .comment-footer textarea {
            resize: none;
            width: 100%;
            border-radius: 4px;
            padding: 1%;
        }

        .comment-box .send-button, .comment-box .comment-open {
            padding: 12px;
            background: #fff none repeat scroll 0 0;
            margin-top: 5px;
        }

        .comment-box .send-button .btn-send, .comment-box .comment-open .btn-send {
            background-color: #03658c;
            border-color: #03658c;
            color: #fff;
            padding: 6px 12px;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
        }

        .comment-box .send-button .btn-send, .comment-box .comment-open .btn-send {
            text-decoration: none;
        }

        .comment-box .btn-reply {
            cursor: pointer;
        }

        .comment-box .comment-name.by-author, .comment-box .comment-name.by-author a {
            color: #03658c;
        }

        .comment-box .comment-name.by-author:after {
            /*content: '';*/
            background: #03658c;
            color: #FFF;
            font-size: 12px;
            padding: 3px 5px;
            font-weight: 700;
            margin-left: 10px;
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
        }

        .comment-box .posted-time {
            margin-top: 8px;
        }

        .comment-box .comment-footer {
            display: none;
        }

        @media only screen and (max-width: 766px) {
            .comments-container {
                width: 480px;
            }

            .comments-list .comment-box {
                width: 390px;
            }

            .reply-list .comment-box {
                width: 320px;
            }
        }

        /* Staff List CSS*/

        .custom_tooltip {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
        }

        .custom_tooltip .tooltiptext {
            visibility: hidden;
            width: auto;
            background-color: #3ca1eb;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            top: 70%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .custom_tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            bottom: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent #3ca1eb transparent;
        }

        .custom_tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        .tooltiptext.swing:before,
        .tooltiptext.swing:after {
            transform: translate3d(0, 30px, 0) rotate3d(0, 0, 1, 60deg);
            transform-origin: 0 0;
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:after {
            transform: translate3d(0, 60px, 0);
            transition: transform .15s ease-in-out, opacity .2s;
        }

        .tooltiptext.swing:hover:before,
        .tooltiptext.swing:hover:after {
            opacity: 1;
            transform: translate3d(0, 0, 0) rotate3d(1, 1, 1, 0deg);
        }

        /*        Scoll bar CSS*/

        #boxscroll {
            height: 400px;
            overflow-y: auto;
        }

        /*
        }
                #boxscroll  a{
                    overflow-x: hidden ;
                    width: 100%;
                }
        */

        .nicescroll-cursors {
            background-color: rgba(70, 166, 248, 0.8) !important;
        }

        /*        Staff details modal css*/

        .details {
            list-style-type: none;
            border: 1px solid #eee;
            margin: 0;
            padding: 0;
            -webkit-transition: 0.3s;
            transition: 0.3s;
            background: #3c4451;
            border-radius: 5px;
        }

        .details:hover {
            box-shadow: 0 8px 12px 0 rgba(0, 0, 0, 0.2)
        }

        .details .header {
            font-size: 20px;
            padding: 15px;
            color: #fff;
            background: #db3b5e;
        }

        .details li {

            padding: 18px 20px;
            color: #fff;
        }

        .details .grey {
            background-color: #e94633;
            font-size: 20px;
            color: #fff;
        }

        .staff_img_section {
            background: #fff;
            text-align: center;
        }

        .staff_img {
            width: 150px;
            border-radius: 50%;
            border: 4px solid #3ca1eb;
        }

        /*        Custom select */
        select.soflow,
        select.soflow-color {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            -webkit-border-radius: 3px;
            /*  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);*/
            -webkit-padding-end: 20px;
            -webkit-padding-start: 2px;
            -webkit-user-select: none;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            border: 1px solid #D4D1D1;
            color: #555;
            font-size: inherit;
            /*  margin: 20px;*/
            overflow: hidden;
            padding: 5px 10px;
            text-overflow: ellipsis;
            white-space: nowrap;
            /*  width: 300px;*/
        }

        select.soflow-color {
            color: #fff;
            background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#779126, #779126 40%, #779126);
            background-color: #779126;
            -webkit-border-radius: 20px;
            -moz-border-radius: 20px;
            border-radius: 20px;
            padding-left: 15px;
        }

        select.form-control:not([size]):not([multiple]) {
            height: calc(2rem + 2px);
        }

        body {
            font-size: 14px;
        }

        /*        Month select */
        .monthly-wrp {
            padding: 1em;
            top: 6px;
            z-index: 1000;
            border-radius: 3px;
            background-color: #2C3E50;
            top: 40% !important;
            left: 36% !important;
        }

        .monthly-wrp:before {
            content: "";
            border-bottom: 6px solid #2C3E50;
            border-left: 6px solid transparent;
            border-right: 6px solid transparent;
            position: absolute;
            top: -6px;
            left: 6px;
            z-index: 1002;
        }

        .monthly-wrp .years {
            margin-bottom: 0.8em;
            text-align: center;
        }

        .monthly-wrp .years select {
            appearance: button;
            -o-appearance: button;
            -ms-appearance: button;
            -moz-appearance: button;
            -khtml-appearance: button;
            border: 0;
            border-radius: 3px;
            width: 100%;
            height: 30px;
            -webkit-appearance: button;
            background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
            background-position: 97% center;
            background-repeat: no-repeat;
            background-color: #f6f7f5 !important;
        }

        .monthly-wrp .years select:focus {
            outline: none;
        }

        .monthly-wrp table {
            border-collapse: collapse;
            table-layout: fixed;
        }

        .monthly-wrp td {
            padding: 1px;
        }

        .monthly-wrp table button {
            width: 100%;
            border: none;
            background-color: #3ca1eb;
            color: #FFFFFF;
            font-size: 14px;
            padding: 0.4em;
            cursor: pointer;
            border-radius: 3px;
        }

        .monthly-wrp table button:hover {
            background-color: #3ca1eb;
        }

        .monthly-wrp table button:focus {
            outline: none;
        }

        .monthly-wrp table {
            width: auto !important;
        }


    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Support List</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/staff/dashboard">Dashboard</a></li>
                        <li class="active">Support List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            {{--<strong class="card-title">Support Details</strong>--}}
                            <button type="button" class="btn btn-info" data-toggle="collapse"
                                    data-target="#filter-panel" style="padding: 4px 10px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>
                            <div id="filter-panel" class="collapse filter-panel" style="margin-top: 15px;">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <form class="form" role="form">
                                            <div class="form-group col-xs-2 col-md-2 ">
                                                <label class="control-label" for="pref-perpage">Time</label>
                                                <select id="pref-perpage" class="form-control soflow filterByTime">
                                                    <option value="0">All Time</option>
                                                    <option value="1">Today</option>
                                                    <option value="2">Last 7 days</option>
                                                    <option value="3">Last 30 days</option>
                                                </select>
                                            </div> <!-- form group [rows] -->

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-perpage">Month</label>
                                                <input class="soflow form-control filterByMonthndYear" type="text"
                                                       id="selection"
                                                       value="{{date('M Y')}}" style="font-size: inherit;">
                                            </div>
                                            {{--<div class="form-group col-xs-4 col-md-4">--}}
                                                {{--<label class="control-label" for="pref-search">Project</label>--}}
                                                {{--<select id="pref-search" class="form-control soflow filterByProject">--}}
                                                    {{--<option value="0">All</option>--}}
                                                    {{--@foreach($projectName as $K=>$val)--}}
                                                        {{--<option value="{{$val['project_id']}}">{{$val['project_name']}}</option>--}}
                                                    {{--@endforeach--}}
                                                {{--</select>--}}
                                            {{--</div><!-- form group [search] -->--}}
                                            {{--<div class="form-group col-xs-2 col-md-2">--}}
                                                {{--<label class="control-label" for="pref-orderby">View</label>--}}
                                                {{--<select id="pref-orderby" class="form-control soflow filterByView">--}}
                                                    {{--<option value="0">All</option>--}}
                                                    {{--<option value="1">Latest Task(Last 7 Days)</option>--}}
                                                {{--</select>--}}
                                            {{--</div>--}}
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-info pull-right" data-toggle="modal" data-target="#supportTicket">
                                <i class="fa fa-plus-circle" aria-hidden="true"></i> Add New Ticket
                            </button>
                        </div>
                        <div class="card-body">
                            <table id="ticketTable1" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    {{--<th>SL NO</th>--}}
                                    <th>Ticket ID</th>
                                    <th>Ticket Raised By</th>
                                    <th>Support Personal</th>
                                    <th>Subject</th>
                                    <th>Description</th>
                                    <th>Queried_at</th>
                                    <th>Status</th>
                                    <th>View Query</th>
                                </tr>
                                </thead>
                                {{--<tbody>--}}
                                {{--<tr>--}}
                                {{--<td>1</td>--}}
                                {{--<td>Glb-D18</td>--}}
                                {{--<td>Mr.Mike</td>--}}
                                {{--<td>Mr.Shaswath</td>--}}
                                {{--<td> 03/12/2018</td>--}}
                                {{--<td>Solved</td>--}}
                                {{--</tr>--}}
                                {{--</tbody>--}}
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="supportTicket">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-plus-circle"></i>
                        Create New
                        Ticket</h4>
                    <button type="button" class="close cancelTicket" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Staff</label>
                            </div>
                            <input id="staffName" name="name" type="text" placeholder="Staff name"
                                   class="form-control col-md-9 staffName"
                                   {{--                                   value="{{Auth::user()['name']}}" readonly>--}}
                                   value="{{\Illuminate\Support\Facades\Session::get('staff_detail')['name']}} {{\Illuminate\Support\Facades\Session::get('staff_detail')['last_name']}}"
                                   readonly>
                        </div>
                    </div>
                    <!--                    --><?php //dd($data); ?>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Recipient</label>
                            </div>
                            {{--<input id="name" name="name" type="text" placeholder="Reciepient name"--}}
                            {{--class="form-control col-md-9">--}}
                            <select name="select" id="Select" data-placeholder="Recipient Name"
                                    class="form-control form-control col-md-9 selectName">
                                <option style="max-height:50px;overflow: auto;" value="0">Recipient Name</option>
                                @foreach($data as $k=>$val)
                                    <option value="{{$val->id}}">{{$val->name}} [{{$val->username}}
                                        ] @if($val->role == 'M') [Manager] @else [Admin] @endif</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col col-md-3">
                                <label class="control-label" for="name">Subject</label>
                            </div>
                            <input id="subject" onkeyup="subMaxLength()" name="subject" type="text" placeholder="Enter Subject"
                                   class="form-control col-md-9 subject" maxlength="101">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="col-md-3">
                                <label for="textarea-input" class=" form-control-label">Ticket Description</label>
                            </div>

                            <textarea name="textarea-input" id="textarea-input" rows="9" placeholder="Description..."
                                      class="form-control col-md-9 ticketDesc"></textarea>

                            <div class="col-lg-12" style="text-align: center;margin:4% 0;">
                                <button class="btn btn-success addSupportTicket" style="padding: 7.5px 10px;">Add Ticket
                                </button>
                                <button type="button" class="btn btn-danger cancelTicket" data-dismiss="modal">Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editStaffDetails">
        <div class="modal-dialog" style="max-width: 80%;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-comments"></i> Reply
                        On Tickets</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body" style="overflow-y: scroll;
    max-height: 450px;">

                    <div class="card">
                        <div class="card-header">
                            <h4>Conversation</h4>
                        </div>
                        <div class="card-body" style="background: #e3e3e7;">
                            <div id="loaderClass" class="loaderClass hide" style="text-align: center">
                                <img src="/images/cloud_loading.gif" style="width: 100px">
                            </div>
                            <div class="fade show active appendClass">
                                <ul id="comments-list" class="comments-list">
                                    <li>
                                        <div class="comment-main-level">
                                            <div class="comment-avatar"><img src="/images/admin.jpg" alt=""></div>
                                            <div class="comment-box">
                                                <div class="comment-head">
                                                    <h6 class="comment-name by-author"><a href="#">Vandana</a>
                                                    </h6>
                                                    <span class="posted-time">10-5-2018</span>
                                                </div>
                                                <div class="comment-content">
                                                    fdgdfg rgfdgfdgfg gffhfhgf ghfhghgh ghghghgfhgfh
                                                    <div class="comment-open" name="reply">
                                                        <a class="btn-reply">
                                                            <i class="fa fa-reply"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="comment-footer">
                                                    <div class="comment-form">
                                    <textarea class="form-control" name="" id="getid"
                                              value=""></textarea>

                                                        <div class="pull-right send-button">
                                                            <a class="btn-send" name="send">send</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <ul class="comments-list reply-list">
                                            <li>
                                                <div class="comment-avatar"><img src="http://dummyimage.com/60" alt="">
                                                </div>

                                                <div class="comment-box">
                                                    <div class="comment-head">
                                                        <h6 class="comment-name by-author"><a href="#">User Name</a>
                                                        </h6>
                                                        <span class="posted-time">Posted on DD-MM-YYYY HH:MM</span>
                                                        {{--<i class="fa fa-heart"></i>--}}
                                                    </div>
                                                    <div class="comment-content">
                                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit
                                                        omnis animi et iure laudantium vitae, praesentium optio,
                                                        sapiente distinctio illo?
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>


    <div class="modal fade" id="viewDescription" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true" data-backdrop="true">
        <div class="modal-dialog modal-sm" role="document" style="max-width: 450px;">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #3ab3d4;">
                    <h5 class="modal-title" id="exampleModalLabel">Description</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body text-center p-lg"
                     style="adding: 0.5rem;max-height: 400px;overflow: auto;margin-bottom: 20px;">
                    <div class="col-md-12">
                        <div id="descriptionData" style="white-space: pre-wrap; text-align: justify;"> </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


@endsection

@section('page-scripts')
    <script src="/staffAssets/js/toastr/toastr.min.js"></script>

    <script>
        $(document).on('click', '.btn-reply', function (eve) {
            eve.preventDefault();
            $(this).parent().parent().siblings('.comment-footer').slideToggle();
            eve.stopImmediatePropagation();
        });
    </script>
    <script>
        let getDateAndTime = function (getDate) {
            let date = new Date(getDate * 1000);
            let month = date.getMonth() + 1;
            let day = date.getDate();
            let hour = date.getHours();
            let min = date.getMinutes();
            let sec = date.getSeconds();

            month = (month < 10 ? "0" : "") + month;
            day = (day < 10 ? "0" : "") + day;
            hour = (hour < 10 ? "0" : "") + hour;
            min = (min < 10 ? "0" : "") + min;
            sec = (sec < 10 ? "0" : "") + sec;

            let str = date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

            return str;
        };
        if (window.location.href.split('/')[5]) {
            var ticketId = window.location.href.split('/')[5];
            $('.appendClass').attr('data-id', ticketId);
        }
        $(document).ready(function () {
            toastr.options.positionClass = "toast-top-center";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicates = true;


            $(document).on('click', '.adddiv', function () {
                let contents = ' <li class="type_reply" style="margin-left:15% !important;"><textarea class="textData" style="margin: 16px 0px;resize: none; height: 100px; width: 100%"></textarea> <button class="btn btn-success sendBtn" style="padding: 6px 10px;position: absolute;right: 15px;bottom: 15px;">Send</button> </li>';
                $(".mainchat").after(contents);
                $(this).hide();
            });

            $(document.body).on('click', '.addSupportTicket', function () {
                let ticketRaisedBy, ticketReciepient, subject, ticketDesc, ticketDataToInsert = {};

                ticketRaisedBy = $('.staffName').val();
                ticketDataToInsert.ticketRaisedBy = ticketRaisedBy;
                ticketReciepient = $('.selectName').val();
                ticketDataToInsert.ticketReciepient = ticketReciepient;
                subject = $('.subject').val();
                ticketDataToInsert.subject = subject;
                ticketDesc = $('.ticketDesc').val();
                ticketDataToInsert.ticketDesc = ticketDesc;

                if (ticketRaisedBy === "") {
                    toastr.error('Please Enter Your Name in Staff Field.');
                    return false;
                } else if (ticketReciepient === "0") {
                    toastr.error('Please Enter Your Recipient Name.');
                    return false;
                } else if (subject.trim().replace(/\s/g, '') === "") {
                    toastr.error('Please Enter Your Subject.');
                    return false;
                }else if (subject.length > 100) {
                    toastr.error('Subject length exceeds 100 characters..');
                    return false;
                }
                else if (ticketDesc.trim() === "") {
                    toastr.error('Please Enter Your Ticket Description.');
                    return false;
                } else {
                    $.ajax({
                        url: "/staff/addNewTicket",
                        type: "post",
                        dataType: "json",
                        data: ticketDataToInsert,
                        success: function (response) {
                            if (response.status === 200) {
                                $('#supportTicket').modal('hide').find("input[name=subject],textarea,select").val('').end();
                                $('.selectName').val(0);
                                $('#ticketTable1').DataTable().ajax.reload();
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.cancelTicket', function () {
                $('#supportTicket').modal('hide').find("input[name=subject],textarea,select").val('').end();
                $('.selectName').val(0);
            });

            $('#ticketTable1').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                ajax: '/staff/ticketsInfoAjaxHandler',
                columns: [
                    {data: 'ticketId', name: 'ticketId'},
                    {data: 'ticketRaisedBy', name: 'ticketRaisedBy'},
                    {data: 'supportPersonal', name: 'supportPersonal'},
                    {data: 'subject', name: 'subject'},
                    {data: 'description', name: 'description'},
                    {data: 'queried_at', name: 'queried_at'},
                    {data: 'status', name: 'status'},
                    {data: 'viewQuery', name: 'viewQuery'}
                ], createdRow: function (row, data, index) {
                    let sub = data.tckSubject.replace(/&amp;/g, '&');
                    $('td', row).eq(3).attr({
                        'data-tooltip': sub,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });

            $(document.body).on('change', '.statusSelect', function () {
                $.ajax({
                    url: "/staff/updateStatusOfTicket",
                    type: "post",
                    dataType: "json",
                    data: {
                        ticketId: $(this).attr('data-id'),
                        ticketStatus: $(this).val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('click', '.viewDescriptionBtn', function () {
                var description=$(this).attr('data-id');
                $('#descriptionData').text(description);
            });
            $(document.body).on('click', '.viewQueryBtn', function () {
                $('.sendBtn,.appendClass').attr('data-id', $(this).attr('data-id'));
                $.ajax({
                    url: "/staff/fetchTicketReply",
                    type: "post",
                    dataType: "json",
                    data: {
                        ticketId: $(this).attr('data-id'),
                    },
                    beforeSend: function () {
                        $('.loaderClass').show();
                        $('.appendClass').html('');
                    },
                    success: function (response) {
                        $('.loaderClass').hide();
                        if (response.status === 200) {
                            let domData = '';
                            $.each(response.data, function (inx, val) {
                                if (val.ticket_status === 0) {
                                    domData += '<h2 style="color: red">This ticket has closed.</h2>';
                                }
                                domData += '<ul id="comments-list" class="comments-list"><li>' +
                                    '<div class="comment-main-level">' +
                                    '<div class="comment-avatar"> <a href="' + val.profile_pic + '" target="_blank"><img src="' + val.profile_pic + '" alt=""></a></div>' +
                                    '<div class="comment-box"><div class="comment-head">' +
                                    '<h6 class="comment-name by-author"><a href="#">' + val.name + '</a></h6>' +
                                    '<span class="posted-time">' + getDateAndTime(val.ticket_queried_at) + '</span></div>' +
                                    '<div class="comment-content" style="white-space: pre-wrap;"><b>Subject: </b>' + val.ticket_subject + '' +
                                    '<div class="comment-content" style="white-space: pre-wrap; padding: 5px 0;"><b>Description: </b>' + val.ticket_description + '';
                                if (val.ticket_status === 1) {
                                    domData += '<div class="comment-open" name="reply">' +
                                        '<a class="btn-reply"><i class="fa fa-reply"></i></a>' +
                                        '</div>';
                                }
                                domData += '</div>' +
                                    '<div class="comment-footer"><div class="comment-form">' +
                                    '<textarea class="form-control" name="" id="textValue" value=""></textarea>' +
                                    '<div class="pull-right send-button">' +
                                    '<a class="btn-send sendBtn" name="send">send</a>' +
                                    '</div></div></div></div></div>' +
                                    '</li></ul>';
                                $.each(response.allTicketReplies, function (i, v) {
                                    domData += '<ul class="comments-list reply-list">' +
                                        '<li>' +
                                        '<div class="comment-avatar"><a href="' + v.profilePic + '" target="_blank"><img src="' + v.profilePic + '" alt=""></a></div>' +
                                        '<div class="comment-box"><div class="comment-head">' +
                                        '<h6 class="comment-name by-author"><a href="#">' + v.replied_by + '</a></h6>' +
                                        '<span class="posted-time">Posted on ' + getDateAndTime(v.reply_posted_on) + '</span></div>' +
                                        '<div class="comment-content" style="white-space: pre-wrap;">' + v.replies + '</div>' +
                                        '</div></li></ul>'
                                });
                            });
                            $('.appendClass').html('').append(domData);
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('click', '.sendBtn', function () {
                var len = $('#textValue').val().trim().length;
                if (len < 1) {
                    toastr.warning('Please comment something', {timeOut: 3000});
                    return false;
                }
                $.ajax({
                    url: "/staff/sendReplyForTicket",
                    type: "post",
                    dataType: "json",
                    data: {
                        ticketId: $('.appendClass').attr('data-id'),
                        ticketReply: $('#textValue').val()
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            let data = '';
                            let reply_text = $('.sendBtn').parent().siblings('textarea').val();

                            $(this).parent().siblings('textarea').val(" ");
                            $(this).parent().parent().parent().slideUp("fast");
//
                            if ($.trim(reply_text) === " " || $.trim(reply_text) === "") {
                                alert("insert comment");
                            } else {
                                        {{--                                let profilePic = '{{\Illuminate\Support\Facades\Auth::user()['profile_pic']}}';--}}
                                let profilePic = '{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}';
                                        {{--                                let name = '{{\Illuminate\Support\Facades\Auth::user()['name']}}';--}}
                                let name = '{{\Illuminate\Support\Facades\Session::get('staff_detail')['name']}}';
                                data = '<ul class="comments-list reply-list">' +
                                    '<li>' +
                                    '<div class="comment-avatar"><a href="' + profilePic + '" target="_blank"><img src="' + profilePic + '" alt=""></a></div>' +
                                    '<div class="comment-box"><div class="comment-head">' +
                                    '<h6 class="comment-name by-author"><a href="#">' + name + '_staff</a></h6>' +
                                    '<span class="posted-time">Posted on ' + getDateAndTime(response.data) + '</span></div>' +
                                    '<div class="comment-content" style="white-space: pre-wrap;">' + $('#textValue').val() + '</div>' +
                                    '</div></li></ul>';
                            }
                            $('.comment-footer').css('display', 'none');
                            $('.appendClass ul:first-child').after(data);
                            $('#textValue').val('');
                            toastr.success(response.message, {timeOut: 3000});
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            });


            var id = '<?php echo $id ?>';
            if (id) {
                $('#editStaffDetails').modal('show');
                $.ajax({
                    url: "/staff/fetchTicketReply",
                    type: "post",
                    dataType: "json",
                    data: {
                        ticketId: id,
                    },
                    beforeSend: function () {
                        $('.loaderClass').show();
                        $('.appendClass').html('');
                    },
                    success: function (response) {
                        $('.loaderClass').hide();
                        if (response.status === 200) {
                            let domData = '';
                            $.each(response.data, function (inx, val) {
                                if (val.ticket_status === 0) {
                                    domData += '<h2 style="color: red">This ticket has closed.</h2>';
                                }
                                domData += '<ul id="comments-list" class="comments-list"><li>' +
                                    '<div class="comment-main-level">' +
                                    '<div class="comment-avatar"><a href="'+ val.profile_pic +'" target="_blank"><img src="' + val.profile_pic + '" alt=""></a></div>' +
                                    '<div class="comment-box"><div class="comment-head">' +
                                    '<h6 class="comment-name by-author"><a href="#">' + val.name + '</a></h6>' +
                                    '<span class="posted-time">' + getDateAndTime(val.ticket_queried_at) + '</span></div>' +
                                    '<div class="comment-content" style="white-space: pre-wrap;"><b>Subject: </b>' + val.ticket_subject + '' +
                                    '<div class="comment-content" style="white-space: pre-wrap; padding: 5px 0;"><b>Description: </b>' + val.ticket_description + '';
                                if (val.ticket_status === 1) {
                                    domData += '<div class="comment-open" name="reply">' +
                                        '<a class="btn-reply"><i class="fa fa-reply"></i></a>' +
                                        '</div>';
                                }
                                domData += '</div>' +
                                    '<div class="comment-footer"><div class="comment-form">' +
                                    '<textarea class="form-control" name="" id="textValue" value=""></textarea>' +
                                    '<div class="pull-right send-button">' +
                                    '<a class="btn-send sendBtn" name="send">send</a>' +
                                    '</div></div></div></div></div>' +
                                    '</li></ul>';
                                $.each(response.allTicketReplies, function (i, v) {
                                    domData += '<ul class="comments-list reply-list">' +
                                        '<li>' +
                                        '<div class="comment-avatar"><a href="'+v.profilePic +'" target="_blank"><img src="' + v.profilePic + '" alt=""></a></div>' +
                                        '<div class="comment-box"><div class="comment-head">' +
                                        '<h6 class="comment-name by-author"><a href="#">' + v.replied_by + '</a></h6>' +
                                        '<span class="posted-time">Posted on ' + getDateAndTime(v.reply_posted_on) + '</span></div>' +
                                        '<div class="comment-content" style="white-space: pre-wrap;">' + v.replies + '</div>' +
                                        '</div></li></ul>'
                                });
                            });
                            $('.appendClass').html('').append(domData);
                        } else {
                            toastr.error(response.message, {timeOut: 3000});
                        }
                    }
                });
            }


            //----------------------Support Filter--------------------------

            $(document.body).on('change', '.filterByProject', function () {
                let projId = $('.filterByProject').val();
                allSupportFilter('projectId',projId)
            });
            $(document.body).on('change', '.filterByView', function () {
                let view = $('.filterByView').val();
                allSupportFilter('view',view)
            });
            $(document.body).on('change', '.filterByTime', function () {
                let time = $('.filterByTime').val();
                allSupportFilter('time',time)
            });
            function allSupportFilter(id,value) {
                $('#ticketTable1').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: '/staff/ticketsInfoAjaxHandler',
                        method: 'post',
                        data: function (f) {
                            f.id = id;
                            f.value = value;
                        }
                    },
                    columns: [
                        {data: 'ticketId', name: 'ticketId'},
                        {data: 'ticketRaisedBy', name: 'ticketRaisedBy'},
                        {data: 'supportPersonal', name: 'supportPersonal'},
                        {data: 'subject', name: 'subject'},
                        {data: 'description', name: 'description'},
                        {data: 'queried_at', name: 'queried_at'},
                        {data: 'status', name: 'status'},
                        {data: 'viewQuery', name: 'viewQuery'}
                    ], createdRow: function (row, data, index) {
                        let sub = data.tckSubject.replace(/&amp;/g, '&');
                        $('td', row).eq(3).attr({
                            'data-tooltip': sub,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            }
        });

        function subMaxLength() {
            var len=$('.subject').val();
            if(len.length > 100){
                toastr.error('Subject length exceeds 100 characters..');
                return false;
            }
        }

    </script>
    <script>
        function padToTwo(number) {
            if (number <= 9999) {
                number = ("0" + number).slice(-2);
            }
            return number;
        }

        (function ($) {
            $.fn.monthly = function (options) {
                var months = options.months || [
                        "January",
                        "February",
                        "March",
                        "April",
                        "May",
                        "June",
                        "July",
                        "August",
                        "September",
                        "October",
                        "November",
                        "December"
                    ],
                    Monthly = function (el) {
                        this._el = $(el);
                        this._init();
                        this._render();
                        this._renderYears();
                        this._renderMonths();
                        this._bind();
                    };

                Monthly.prototype = {
                    _init: function () {
                        this._el.html(months[0] + " " + options.years[0]);
                    },

                    _render: function () {
                        var linkPosition = this._el.offset(),
                            cssOptions = {
                                display: "none",
                                position: "absolute",
                                top:
                                linkPosition.top + this._el.height() + (options.topOffset || 0),
                                left: linkPosition.left
                            };
                        this._container = $('<div class="monthly-wrp">')
                            .css(cssOptions)
                            .appendTo($("body"));
                    },

                    _bind: function () {
                        var self = this;
                        this._el.on("click", $.proxy(this._show, this));
                        $(document).on("click", $.proxy(this._hide, this));
                        this._yearsSelect.on("click", function (e) {
                            e.stopPropagation();
                        });
                        this._container.on("click", "button", $.proxy(this._selectMonth, this));
                    },

                    _show: function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        this._container.css("display", "inline-block");
                    },

                    _hide: function () {
                        this._container.css("display", "none");
                    },

                    _selectMonth: function (e) {
                        var monthIndex = $(e.target).data("value"),
                            month = months[monthIndex],
                            year = this._yearsSelect.val();
                        this._el.html(month + " " + year);
                        if (options.onMonthSelect) {
                            options.onMonthSelect(monthIndex, month, year);
                        }
                    },

                    _renderYears: function () {
                        var markup = $.map(options.years, function (year) {
                            return "<option>" + year + "</option>";
                        });
                        var yearsWrap = $('<div class="years">').appendTo(this._container);
                        this._yearsSelect = $("<select class='currentYear'>")
                            .html(markup.join(""))
                            .appendTo(yearsWrap);
                        var curntyear = new Date().getFullYear();
                        $('.currentYear :selected').text(curntyear);
                    },

                    _renderMonths: function () {
                        var markup = ["<table>", "<tr>"];
                        $.each(months, function (i, month) {
                            if (i > 0 && i % 4 === 0) {
                                markup.push("</tr>");
                                markup.push("<tr>");
                            }
                            markup.push(
                                '<td><button data-value="' + i + '">' + month + "</button></td>"
                            );
                        });
                        markup.push("</tr>");
                        markup.push("</table>");
                        this._container.append(markup.join(""));
                    }
                };

                return this.each(function () {
                    return new Monthly(this);
                });
            };
        })(jQuery);

        let data1 = [];
        var now = new Date();
        var currentYear = now.getFullYear();
        var UpperLimt= currentYear+20;
        for (var v = 2000; v < UpperLimt; v++) {
            data1.push(v);
        }

        $(function () {
            $("#selection").monthly({
                years: data1,
                topOffset: 28,
                onMonthSelect: function (mi, m, y) {
                    mi = padToTwo(mi);
                    $("#selection").val(m + " " + y);
                    $("#monthly").val(y + "-" + mi);
                    console.log('=================',  $("#selection").val());
                    let month = $('#selection').val();
                    $('#ticketTable1').DataTable({
                        lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                        processing: true,
                        serverSide: true,
                        destroy: true,
                        ajax: {
                            url: '/staff/ticketsInfoAjaxHandler',
                            method:'post',
                            data: function (f) {
                                f.id = 'month';
                                f.value = month;
                            }
                        },
                        columns: [
                            {data: 'ticketId', name: 'ticketId'},
                            {data: 'ticketRaisedBy', name: 'ticketRaisedBy'},
                            {data: 'supportPersonal', name: 'supportPersonal'},
                            {data: 'subject', name: 'subject'},
                            {data: 'description', name: 'description'},
                            {data: 'queried_at', name: 'queried_at'},
                            {data: 'status', name: 'status'},
                            {data: 'viewQuery', name: 'viewQuery'}
                        ], createdRow: function (row, data, index) {
                            let sub = data.tckSubject.replace(/&amp;/g, '&');
                            $('td', row).eq(3).attr({
                                'data-tooltip': sub,
                                'style': 'word-break: break-all'
                            });
                        },
                        "order": [[0, 'desc']]
                    });
                }
            });
        });

    </script>
@endsection
