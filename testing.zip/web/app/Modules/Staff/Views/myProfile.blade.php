<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/24/2018
 * Time: 7:01 PM
 */
?>

@extends('Staff::layouts.master')

{{--@section('title','Project')--}}
@section('title')
    <title> Profile|| Cloud Office</title>
@endsection

@section('page-style')

    <style>
        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        #addNewproject .form-control {
            display: inline-block;
        }

        /*        Radio Css*/

        .buying-selling.active {
            background: #3ca1eb;
        }

        .buying-selling {
            width: 130px;
            padding: 10px;
            position: relative;
        }

        .buying-selling-word {
            font-size: 15px;
            font-weight: 600;
            margin-left: 22px;
        }

        .radio-dot:before,
        .radio-dot:after {
            content: "";
            display: block;
            position: absolute;
            background: #fff;
            border-radius: 100%;
        }

        .radio-dot:before {
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            top: 10px;
            left: 18px;
        }

        .radio-dot:after {
            width: 12px;
            height: 12px;
            border-radius: 100%;
            top: 14px;
            left: 22px;
        }

        .buying-selling.active .buying-selling-word {
            color: #fff;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active .radio-dot:before {
            background: #fff;
            border-color: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:before {
            border-color: #adadad;
        }

        .buying-selling.active:hover .radio-dot:before {
            border-color: #3ca1eb;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active:hover .radio-dot:after {
            background: #3ca1eb;
        }

        @media (max-width: 400px) {
            .mobile-br {
                display: none;
            }

            .buying-selling {
                width: 49%;
                padding: 10px;
                position: relative;
            }
        }

        a.name .name_show {
            display: none;
        }

        a.name:hover .name_show {
            display: block;
            position: absolute;
            z-index: 999;
            background: #fff;
            min-width: 5%;
            color: #fff !important;
            box-shadow: 0px 0px 15px #6A6A6A;
            margin-left: -5%;
            padding: 2%;
            background-color: #333;
            border-radius: 4px;
        }

        .name_show p {
            color: #fff;
        }

        /*        Image Upload CSS*/
        .avatar-upload {
            position: relative;
            max-width: 205px;
            margin: 0px auto;

        }

        .avatar-upload .avatar-edit {
            position: absolute;
            right: 0px;
            z-index: 1;
            top: 40px;
            z-index: 4;
        }

        .avatar-upload .avatar-edit input {
            display: none;
        }

        .avatar-upload .avatar-edit input + label {
            display: inline-block;
            width: 50px;
            height: 50px;
            margin-bottom: 0;
            border-radius: 100%;
            background: #3CA1EB;
            border: 1px solid transparent;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
            cursor: pointer;
            font-weight: normal;
            transition: all 0.2s ease-in-out;
            z-index: 5;
        }

        .avatar-upload .avatar-edit input + label:hover {
            background: #3CA1EB;
            border-color: #d6d6d6;
        }

        .avatar-upload .avatar-edit input + label:after {
            content: "\f040";
            font-family: 'FontAwesome';
            color: #fff;
            position: absolute;
            top: 15px;
            left: 0;
            right: 0;
            text-align: center;
            margin: auto;
        }

        .avatar-upload .avatar-preview {
            width: 200px;
            height: 200px;
            position: relative;
            border-radius: 100%;
            border: 6px solid #3CA1EB;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
            z-index: 3;
        }

        .avatar-upload .avatar-preview > div {
            width: 100%;
            height: 100%;
            border-radius: 100%;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        /*      IMage Upload CSS Ends  */

        /*        tabs Css*/
        .tabs {
            background: #eee;
            margin: 0 auto;
            max-width: 950px;
            overflow: hidden;
            position: relative;
        }

        .tabs__header {
            display: flex;
            justify-content: space-between;
        }

        .tabs__header li {

            list-style: none;
        }

        .tabs__header--title {
            background: #272c33;;
            color: #fff;
            cursor: pointer;
            flex: 1 0 auto;
            padding: 10px;
            position: relative;
            text-align: center;
            transition: opacity 0.3s;
        }

        .tabs__header--title::after {
            background: #E91E63;
            bottom: -1px;
            content: '';
            display: none;
            height: 4px;
            left: 50%;
            position: absolute;
            transform: translateX(-50%) scaleX(0);
            transition: transform 0.3s;
            width: 100%;
        }

        .tabs__header--title.active::after {
            transform: translateX(-50%) scaleX(1);
        }

        .tabs__header--title.active {
            border-bottom: 4px solid #3CA1EB;
        }

        /*.tabs__underline {*/
        /*width: 33%;*/
        /*background: #3CA1EB;*/
        /*height: 4px;*/
        /*position: absolute;*/
        /*left: 0;*/
        /*top: 40px;*/
        /*transition: transform 0.5s cubic-bezier(1, -1.25, 0, 1.75);*/
        /*}*/

        .tabs__content {
            background: #eee;
            display: none;
            padding: 30px 20px;
        }

        .tabs__content.active {
            animation: fadeIn 1s;
            display: block;
        }

        .tabs__content.active .tabs__content--title,
        .tabs__content.active .tabs__content--text {
            animation: fadeInUp 0.3s forwards;
        }

        .tabs__content.active .tabs__content--text {
            animation-delay: 0.3s;
        }

        .tabs__content--title {
            font-family: "Lustria", serif;
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .tabs__content--text {
            line-height: 1.4;
            opacity: 0;
        }

        @media only screen and (min-width: 651px) {
            .tabs__header--title:hover {
                opacity: .7;
            }

            .tabs__header--title:not(:last-of-type) {
                border-right: 1px solid #fff;
            }
        }

        @media only screen and (max-width: 650px) {
            body {
                padding: 0;
            }

            .tabs__header {
                flex-wrap: wrap;
            }

            .tabs__header--title {
                border-bottom: 1px solid #fff;
                width: 100%;
            }

            .tabs__header--title::after {
                display: block;
            }

            .tabs__underline {
                display: none;
            }
        }

        @keyframes fadeIn {
            0% {
                display: none;
                opacity: 0;
            }
            1% {
                display: block;
                opacity: 0;
            }
            100% {
                display: block;
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .submit-btn {
            text-align: center;
            margin: 3% 0;
        }

        .error {
            color: red;
        }
        /*        Country code CSS*/
        .forms {
            margin-top: 40px;
        }

        /* added to global styles */
        .has-error.form-control {
            color: #9f005b;
            border-color: #9f005b;
            box-shadow: inset 0 0 0 1px #9f005b;
        }

        .has-error.form-control:focus {
            box-shadow: inset 0 0 0 2px #9f005b;
        }

        /* for example purposes - floating labels needed to properly work */
        #phone-number-country {
            color: #000;
        }

        .userimageresponsive{
            width: 200px;
            border-radius: 50%;
            border: 5px solid #5599f5;
        }

    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Account Settings</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/staff/dashboard">Dashboard</a></li>
                        <li class="active">Account Settings</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Account Settings Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="card-body">
                                <section class="tabs">
                                    <ul class="tabs__header">
                                        <li class="tabs__header--title js-tabs-title active" data-tab="#tab-1">Edit
                                            Personal Details
                                        </li>
                                        <li class="tabs__header--title js-tabs-title" data-tab="#tab-2">Change
                                            Password
                                        </li>
                                        <li class="tabs__header--title js-tabs-title"
                                            data-tab="#tab-3">Change Avatar
                                        </li>
                                    </ul>
                                    {{--<div class="tabs__underline js-tabs-underline"></div>--}}
                                    <article class="tabs__content js-tabs-content active" id="tab-1">
                                        <form id="presonalDetails">
                                            <div class="form-group col-md-6">
                                                <label for="firstName">First Name:</label>
                                                <input type="text" onkeyup="verifyName()" class="form-control"
                                                       id="firstName"
                                                       placeholder="Enter First Name" name="firstName">
                                                <span id="fname"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="lastName">Last Name:</label>
                                                <input type="text" onkeyup="verifyLastName()" class="form-control"
                                                       id="lastName"
                                                       placeholder="Enter Last Name" name="lastName">
                                                <span id="lname"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="Email">Email:</label>
                                                <input type="text" id="emailId" class="form-control" disabled >
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="UserName">User Name:</label>
                                                <input type="text" id="userName" class="form-control" disabled >
                                            </div>
                                            <div class="form-group col-md-6">
                                                <div class="col-md-6" style="padding: 0;">
                                                    <label for="phoneNumber">Choose Country:</label>
                                                    <select class="form-control" id="countryName" onchange="jsFunction(this.value);">
                                                        <option value="0" id="pastCountryName" >Select Country</option>
                                                        <?php
                                                        foreach ($code as $value){?>
                                                        <option value="{{$value['code']}}">{{$value['country']}}</option>
                                                        <?php }
                                                        ?>
                                                    </select>
                                                </div>
                                                <input type="text" id="country_name" name="countryName" hidden>
                                                <div class="col-md-2" style="padding: 0;">
                                                    <label for="phoneNumber">Code:</label>
                                                    <input type="text" maxlength="5" class="form-control"
                                                           id="code" name="code">
                                                </div>
                                                <div class="col-md-4" style="padding: 0;">
                                                    <label for="phoneNumber">Phone Number:</label>
                                                    <input type="text" maxlength="13" onblur="verifyPhoneNumber()"
                                                           class="form-control"
                                                           id="phoneNumber"
                                                           placeholder="Phone Number" name="phoneNumber">
                                                </div>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="paypalEmail">Paypal Email ID:</label>
                                                <input type="email" onblur="verifyPaypalEmail()" class="form-control"
                                                       id="paypalEmail"
                                                       placeholder="Enter Paypal Email ID" name="paypalEmail">
                                                <span id="pemail"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="mPesaNumber">mPesa Number:</label>
                                                <input type="text" maxlength="14" onblur="verifymPesaNumber()"
                                                       class="form-control"
                                                       {{--<input type="text" maxlength="11" class="form-control"--}}
                                                       id="mPesaNumber"
                                                       placeholder="Enter mPesa Number" name="mPesaNumber">
                                                <span id="mPesa"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Select Country:</label>
                                                <select id="country" onchange="getCountry()" name="country" class="form-control">
                                                    <option value="-1" id="pastCountryName" >Select Country</option>
                                                </select>
                                                <span id="selectCountry"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Select State:</label>
                                                <select name="state" id="state" class="form-control">
                                                </select>
                                                <span id="selectState"></span>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="phoneNumber">Set Avaliability:</label>
                                                <select id="available" name="availabity" class="form-control">
                                                    <option>Active</option>
                                                    <option>In-Active</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-12 submit-btn">
                                                <button type="button" class="btn btn-success"
                                                        style="padding: 6px 35px;" onclick="updatePersonalDetails()">
                                                    SUBMIT
                                                </button>
                                            </div>
                                        </form>
                                    </article>
                                    <article class="tabs__content js-tabs-content" id="tab-2">
                                        <form action="/staff/updatePassword" method="post" id="passwordValidation">
                                            {{csrf_field()}}
                                            <div class="col-md-6 offset-md-3">
                                                <div class="form-group">
                                                    <label for="currentPassword">Current Password:</label>
                                                    <input type="password" class="form-control" id="currentPassword"
                                                           placeholder="Enter Current Password" name="currentPassword"
                                                           onblur="varifyPassword()">
                                                    <p id="curpwd"></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="newpwd">New Password:</label>
                                                    <input type="password" class="form-control" id="new_password"
                                                           placeholder="Enter New password" name="new_password"
                                                           onblur="varifyNewPassword()">
                                                    <p id="newpwd"></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="pwd">Confirm Password:</label>
                                                    <input type="password" class="form-control" id="cnf_password"
                                                           placeholder="Confirm password" name="cnf_password">
                                                </div>

                                                <div class="form-group col-md-12 submit-btn">
                                                    <button class="btn btn-success" type="submit"
                                                            style="padding: 6px 35px;">SUBMIT
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </article>
                                    <article class="tabs__content js-tabs-content" id="tab-3" style="text-align: center;">
{{--                                        <a href="{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}" target="_blank">--}}
                                            <img src="{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}" class="image-responsive userimageresponsive">
                                        {{--</a>--}}

                                        <div class="wrapper">
                                            <div class="change-icon imguploading"><a href="#" data-toggle='modal' data-target='#image-editor'><span class="change-icon-text"><i class="fa fa-pencil" aria-hidden="true"></i></span></a></div>
                                        </div>
                                    </article>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <div id="image-editor" class="modal fade editor-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h2 class="modal-title">Edit Your Image</h2>
                    </div>
                    <div class="modal-body">
                        <div class="editor-wrapper">
                            <div class="editor-container">
                                <div class="editor">
                                    <div class="resize-container">
                                        <span class="resize-handle resize-handle-nw"></span>
                                        <span class="resize-handle resize-handle-ne"></span>
                                        <img class="resize-image" src="" alt="">
                                        <span class="resize-handle resize-handle-se"></span>
                                        <span class="resize-handle resize-handle-sw"></span>
                                    </div>
                                    <div class="overlay">
                                        <div class="overlay-inner"></div>
                                    </div>
                                    <div class="overlay overlay-preview">
                                        <div class="overlay-inner"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="upload" >
                            <form action="#"  role="form">
                                <input type="file" acccept="images/" class="form-control" id="uploaded-img" placeholder="Input field" accept="image/*">
                                <div class="upload-button" style="margin: 0 auto;">
                                    <label for="uploaded-img">
                                        <span class="label-text">Choose an Image</span><span class="upload-icon"><i class="fa fa-upload"></i></span>
                                    </label>
                                </div>
                                <!--
                                                                                    <div class="upload-button">
                                                                                        <label for="webcam-img">
                                                                                            <span class="label-text"> From Webcam</span><span class="upload-icon"><i class="fa fa-camera"></i></span>
                                                                                        </label>
                                                                                    </div>
                                -->
                                <div class="edit-button">
                                    <button class="btn form-control preview-crop">Preview</button>
                                    <button type="submit" class="js-crop btn form-control" data-dismiss="modal">upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('page-scripts')
    <script src="/staffAssets/js/toastr/toastr.min.js"></script>
    <script src="/staffAssets/js/countries.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <script src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>
    <script src='https://1cf5229636340d3e1dd5-0eccc4d82b7628eccb93a74a572fd3ee.ssl.cf1.rackcdn.com/testing/intlTelInput.min.js'></script>
    <script src='https://1cf5229636340d3e1dd5-0eccc4d82b7628eccb93a74a572fd3ee.ssl.cf1.rackcdn.com/testing/jquery.formatter.min.js'></script>
    <script language="javascript">

        window.onload = function () {
            populateCountries("country", "state");
        }

    </script>
    <script type="text/javascript">

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        jQuery(document).ready(function () {
            jQuery(".standardSelect").chosen({
                disable_search_threshold: 10,
                no_results_text: "Oops, nothing found!",
                width: "50%"
            });
        });

        $(document).ready(function () {

            $('#bootstrap-data-table-export').DataTable();

            toastr.options.positionClass = "toast-top-right";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicates = true
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload").change(function () {
            readURL(this);
        });
        $('.js-tabs-title').on('click', function () {
            var openTab = $(this).data('tab'),
                linePosition = $(this).position().left;
            $('.js-tabs-underline').css('transform', 'translateX(' + linePosition + 'px)');
            $('.js-tabs-title').removeClass('active');
            $(this).addClass('active');
            $('.js-tabs-content').removeClass('active');
            $(openTab).addClass('active');
        });

        function jsFunction(value)
        {
            $('#code').val(value);
            var e = document.getElementById("countryName");
            var strUser = e.options[e.selectedIndex].text;
            $('#country_name').val(strUser);
        }

        $.ajax({
            url: "/staff/getProfileData",
            method: "post",
            dataType: "json",
            success: function (response) {
                if (response.data.countryName == null){
                    //
                }else{
                    $('#pastCountryName').html(response.data.countryName);
                }
                if (response.data.country == null){
                    //
                }else{
                    $('#country').val(response.data.country);
                }
                if (response.data.state == null){
                    $('#state').html('<option>' +"Select State"+ '</option>');
                }else{
                    $('#state').html('<option>' + response.data.state + '</option>');
                }
                $('#firstName').val(response.data.first_name);
                $('#emailId').val(response.data.email);
                $('#userName').val(response.data.username);
                $('#lastName').val(response.data.last_name);
                $('#code').val(response.data.countryCode);
                $('#phoneNumber').val(response.data.mobile_number);
                $('#available').val(response.data.staff_status);
                $('#paypalEmail').val(response.data.paypalEmail);
                $('#mPesaNumber').val(response.data.mPesaNumber);
            }
        });
        $("#passwordValidation").validate({
            rules: {
                currentPassword: {
                    required: true
                },
                new_password: {
                    required: true,
                    minlength: 4
                },
                cnf_password: {
                    required: true,
                    equalTo: "#new_password"
                }
            },
            messages: {
                currentPassword: {
                    required: 'Password is required..!!'
                },
                new_password: {
                    required: ' New Password is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                },
                cnf_password: {
                    required: 'Confirm password is Required..!!',
                    equalTo: "Password do not matched..!!"
                }
            },
            submitHandler: function (form) {
                // var formdata = new FormData(form);
                $.ajax({
                    url: "/staff/updatePassword",
                    method: "post",
                    data: $('#passwordValidation').serializeArray(),
                    // data: formdata,
                    dataType: "json",
                    success: function (response) {

                        if (response.msg == 1) {
                            location.reload();
                            // toastr.success('Password Updated Successfully', {timeOut: 10000});
                        } else {
                            toastr.error('Error Occured...!!', {timeOut: 10000});
                        }
                    }
                });
            }
        });

        function varifyPassword() {
            document.getElementById("curpwd").innerHTML = "";
            var password = $('#currentPassword').val();
            if (password.length > 0) {
                $.ajax({
                    url: "/staff/password",
                    method: "post",
                    data: {
                        'password': password
                    },
                    dataType: "json",
                    success: function (response) {
                        if (response.msg == 1) {
                            document.getElementById("curpwd").innerHTML = "";
                        } else {
                            document.getElementById("curpwd").innerHTML = "Please provide correct password..!!";
                            $('#curpwd').css('color', 'red');
                            $('#currentPassword').val("");
                            return false;
                        }
                    }
                });
            } else {
                return false;
            }
        }

        function varifyNewPassword() {
            document.getElementById("newpwd").innerHTML = "";
            var password = $('#new_password').val();
            if (password.length > 0) {
                $.ajax({
                    url: "/staff/password",
                    method: "post",
                    data: {
                        'password': password
                    },
                    dataType: "json",
                    success: function (response) {
                        if (response.msg == 1) {
                            document.getElementById("newpwd").innerHTML = "New Password same as old password..!!";
                            $('#newpwd').css('color', 'red');
                            $('#new_password').val("");
                            return false;
                        } else {
                            document.getElementById("newpwd").innerHTML = "";
                        }
                    }
                });
            } else {
                return false;
            }
        }

        function updatePersonalDetails() {
// ---------------------------firstname----------------------------
            var inputVal = $('#firstName').val().replace(/\s/g, "");
            $('#firstName').val(inputVal);
            if (inputVal.length < 2) {
                toastr.error('First name is required', {timeOut: 10000});
                return false;
            } else {
                var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
                if (!characterReg.test(inputVal)) {
                    $('#fname').css('color', 'red');
                    textInput = inputVal.replace(/[^A-Za-z]/g, "");
                    toastr.error('Only alphabets are allowed', {timeOut: 10000});
                    return false;
                }
                else {
                    // return true;
                }
            }
            // -------------------------------lastName-------------------------
            var inputVal = $('#lastName').val().replace(/\s/g, "");
            $('#lastName').val(inputVal);
            if (inputVal.length < 2) {
                toastr.error('Last name is required', {timeOut: 10000});
                return false;
            } else {
                var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
                if (!characterReg.test(inputVal)) {
                    $('#lname').css('color', 'red');
                    textInput = inputVal.replace(/[^A-Za-z]/g, "");
                    toastr.error('Only alphabets are allowed', {timeOut: 10000});
                    return false;
                }
                else {
                    // return true;
                }
            }


// ----------------------------------------Check Country code--------------------------------

            var code = $('#code').val().trim();
            var filter = /^[0-9-+-]+$/;
            if (code == '' || code == 0) {
                toastr.error('Please choose country for Code', {timeOut: 10000});
                return false;
            }else if (filter.test(code)) {
                if (code.length > 6 || code.length < 1) {
                    toastr.error('Please enter valid phone number code', {timeOut: 10000});
                    return false;
                }
            }else {
                toastr.error('Only numeric digits are allowed for phone number code', {timeOut: 10000});
                return false;
            }


            //--------------------------------------mobile number-------------------------------------

            var a = $('#phoneNumber').val().trim();
            var filter = /^[0-9-+-]+$/;
            if (a == '') {
                toastr.error('Phone number required', {timeOut: 10000});
                return false;
            } else if (filter.test(a)) {
                if (a.length > 15 || a.length < 10) {
                    toastr.error('Please enter valid phone number', {timeOut: 10000});
                    return false;
                }
            } else {
                toastr.error('Only numeric digits are allowed for phone number', {timeOut: 10000});
                return false;
            }

            // ------------------------payPalEmail-----------------------
            var email = $('#paypalEmail').val().trim();
            var m = $('#mPesaNumber').val().trim();

            if (email == '' && m == '') {
                toastr.error('Either payPal email or mPesa number is required', {timeOut: 10000});
                return false;
            }

            if (email != '') {
                if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                    toastr.error('Enter valid paypal email id', {timeOut: 10000});
                    return false;
                }
            }

            //--------------------------------------mPesa-------------------------------------

            var m = $('#mPesaNumber').val().trim();
            var filter = /^[0-9-+]+$/;

            if (m != '') {
                if (filter.test(m)) {
                    if (m.length > 15 || m.length < 10) {
                        toastr.error('Please enter valid mPesa number', {timeOut: 10000});
                        return false;
                    }
                }
                else {
                    toastr.error('Only numeric digits are allowed for mPesa number', {timeOut: 10000});
                    return false;
                }
            }



// --------------------------------country-----------------------------------
            if ($('#country').val() == null) {
                toastr.error('Please select any Country', {timeOut: 10000});
                return false;
            }
            var country = $('#country').val().trim();
            var state = $('#state').val();
            if (country == -1) {
                toastr.error('Please select any Country', {timeOut: 10000});
                return false;
            } else {
                // return true;
            }
            if (state == '') {
                toastr.error('Please select any state', {timeOut: 10000});
                return false;
            } else {
                $('#selectState').val('')
            }

// -------------------------------------------state-------------------------------------
            var state = $('#state').val().trim();
            if (state == '') {
                toastr.error('Please select any state', {timeOut: 10000});
                return false;
            } else {
                // return true;
            }




// ----------------------------------------Update Data to Database--------------------------------
            $.ajax({
                url: "/staff/updateDetails",
                method: "post",
                data: $('#presonalDetails').serializeArray(),
                dataType: "json",
                success: function (response) {
                    if (response.status == 200) {
                        toastr.success('Details Updated Successfully', {timeOut: 10000});
                        // setTimeout(function () {
                        //     window.location.reload(true);
                        // },3000)
                    } else {
                        toastr.error('Nothing updated Try Again...!!', {timeOut: 10000});
                    }
                }
            });
        }

        function updatePic() {
            var formdata = new FormData();
            var files = $('#imageUpload')[0].files[0];
            formdata.append('imageFile', files);

            $.ajax({
                url: '/staff/updatePic',
                type: 'post',
                data: formdata,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.msg === 1) {
                        $('#header').find('img.user-avatar').attr('src', response.imgSrc);
                        toastr.success('Successfully Updated', {timeOut: 10000});
                    } else {
                        toastr.error('Failed to upload...!!', {timeOut: 10000});
                    }
                }
            });
        }

        function getProfilePic() {
            $.ajax({
                url: "/staff/getProfileData",
                method: "post",
                dataType: "json",
                success: function (response) {
                    $('#profile_pic').val(response.data.profile_pic);
                    var pic = response.data.profile_pic;
                    $('#imagePreview').css('background-image', 'url(' + pic + ')');
                }
            });
        }

        function verifyName() {
            var inputVal = $('#firstName').val().replace(/\s/g, "");
            $('#firstName').val(inputVal);
            if (inputVal.length < 2) {
                toastr.error('First name is required', {timeOut: 10000});
                return false;
                // document.getElementById('fname').innerHTML = 'First name is required';
                // $('#fname').css('color', 'red');
            } else {
                var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
                if (!characterReg.test(inputVal)) {
                    $('#fname').css('color', 'red');
                    textInput = inputVal.replace(/[^A-Za-z]/g, "");
                    toastr.error('Only alphabets are allowed', {timeOut: 10000});
                    return false;
                }
                else {
                    // return true;
                }
            }

        }

        function verifyLastName() {
            var inputVal = $('#lastName').val().replace(/\s/g, "");
            $('#lastName').val(inputVal);
            if (inputVal.length < 2) {
                toastr.error('Last name is required', {timeOut: 10000});
                return false;
            } else {
                var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
                if (!characterReg.test(inputVal)) {
                    $('#lname').css('color', 'red');
                    textInput = inputVal.replace(/[^A-Za-z]/g, "");
                    toastr.error('Only alphabets are allowed', {timeOut: 10000});
                    return false;
                }
                else {
                    // return true;
                }
            }

        }

        function verifyPhoneNumber() {
            var a = $('#phoneNumber').val().trim();
            var filter = /^[0-9-+-]+$/;
            if (a == '') {
                toastr.error('Phone number required', {timeOut: 10000});
                return false;
            } else if (filter.test(a)) {
                if (a.length > 15 || a.length < 10) {
                    toastr.error('Please enter valid phone number', {timeOut: 10000});
                    return false;
                }
            } else {
                toastr.error('Only numeric digits are allowed for phone number', {timeOut: 10000});
                return false;
            }

        }

        function verifyPaypalEmail() {
            var email = $('#paypalEmail').val().trim();
            if (email != '') {
                if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                    toastr.error('Enter valid paypal email id', {timeOut: 10000});
                    return false;
                }
            }
            // else if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
            //     toastr.error('Enter valid paypal email id', {timeOut: 10000});
            //     return false;
            // }
        }

        function verifymPesaNumber() {
            var m = $('#mPesaNumber').val().trim();
            var filter = /^[0-9-+]+$/;
            if (m == '') {
                // toastr.error('mPesa number required', {timeOut: 10000});
                // return false;
            } else if (filter.test(m)) {
                if (m.length > 15 || m.length < 10) {
                    toastr.error('Please enter valid mPesa number', {timeOut: 10000});
                    return false;
                }
            }
            // else {
            //     toastr.error('Only numeric digits are allowed for mPesa number', {timeOut: 10000});
            //     return false;
            // }
        }

        $('#country').change(testCountry);

        function testCountry() {
            var country = $('#country').val().trim();
            var state = $('#state').val();
            if (country == -1) {
                $("#state option[value='']").hide();
                toastr.error('Please select any Country', {timeOut: 10000});
                return false;
            } else {
                // return true;
            }
            if (state == '') {
                toastr.error('Please select any state', {timeOut: 10000});
                return false;
            } else {
                $('#selectState').val('')
            }
        }

        $('#state').change(testState);

        function testState() {
            var state = $('#state').val().trim();
            if (state == '') {
                toastr.error('Please select any state', {timeOut: 10000});
                return false;
            } else {
                // return true;
            }
        }

    </script>

@endsection