<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/11/2018
 * Time: 1:31 PM
 */
?>

        <!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office, Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="assets/css/normalize.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/scss/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="assets/css/index.css">
</head>
<body>
<div id="right-panel" class="right-panel">
    <!-- Header-->
    <header id="header" class="header" style="background-color: #222;">
        <div class="header-menu">
            <div class="col-sm-7">
                <div class="header-left">
                    <img src="/images/logo4.png" width="30%">
                </div>
            </div>
            <div class="col-sm-5" style="margin-top:1%;">
                {{--<button class="btn btn-success pull-right" style="padding:5px 20px !important;">Login</button>--}}
            </div>
        </div>
    </header>
    <div class="mt-3">
        <div class="animated fadeIn" style="text-align: center;">

            <div class="col-lg-4 offset-lg-4" style="margin-top:10%;">
                <div class="alert alert-success alert-dismissible" >
                    {{--<button type="button" class="close" data-dismiss="alert">&times;</button>--}}
                    <strong><h3>Error..!!</h3></strong><h1 style="color: red;">Link Expired..!!</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="assets/js/plugins.js"></script>
</body>
</html>

