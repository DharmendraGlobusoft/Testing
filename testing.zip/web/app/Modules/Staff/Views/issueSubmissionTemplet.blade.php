<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 9/7/2018
 * Time: 12:15 PM
 */
?>

<!DOCTYPE html>
<html>
<header>
    <title>Issue Submission</title>
</header>

<body style="background-color: #E9ECF2;margin-top:5%;">
<center>
    <table style="color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;">
        <tr>
            <td style="width:80%;" align="left"><img src="images/logo3.png" width="150px;"></td>
            <td align="right" style="font-size:13px;">Wed, Aug 29, 1:48 PM</td>
        </tr>
    </table>
    <table style="background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    max-width:580px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;">
        <tr>
            <td style="width: 200px;"><h2>Issue Submission</h2></td>
        </tr>
        <tr style="padding-top:9px;padding-bottom:50px;">
            <td style="padding-bottom: 10px;"><b>Project Name</b></td>
            <td style="padding-bottom: 10px;">: Cloud Office</td>
        </tr>
        <tr style="padding-top:5px;padding-bottom:20px;">
            <td style="padding-bottom: 10px;"><b>Issues List</b></td>
            <td style="padding-bottom: 10px;">: <a href="#">Click here to check List</a></td>
        </tr>


        <tr style="padding-top:5px;padding-bottom:20px;">
            <td style="padding-bottom: 10px;"><b>Due Date</b></td>
            <td style="padding-bottom: 10px;">: 7/9/2018</td>
        </tr>
        <tr style="padding-top:5px;padding-bottom:20px;">
            <td style="padding-bottom: 10px;"><b>Severity</b></td>
            <td style="padding-bottom: 10px;">: Minor</td>
        </tr>
        <tr style="padding-top:5px;padding-bottom:20px;">
            <td style="padding-bottom: 10px;"><b>Issue Description</b> </td>
            <td style="padding-bottom: 10px;">:issues need to fix for message module</td>
        </tr>
        <tr>
            <td style="padding-top:40px;"><button style="background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;" >Check Details</button>

            </td>
        </tr>
    </table>
</center>
</body>

</html>
