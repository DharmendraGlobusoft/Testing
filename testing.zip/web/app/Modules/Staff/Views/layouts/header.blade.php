
<style>
    table{
        width: 100% !important;
    }

    body{
        font-size: 13px;
        background-color: #e6e6e6;
    }

    table p {
        font-size: 13px;
        color: #212529;
    }

    /*Data Table CSS*/
    .table-bordered td, .table-bordered th {
        border:none;
    }
    .table-bordered tbody tr{
        border-top: 1px solid #eae9e9;
    }

    .table-striped tbody tr:nth-of-type(2n+1) {
        background-color: rgba(242, 240, 240, 0.1);
    }
    .table thead th {

        border-bottom: 1px solid #eae9e9;
    }

    .table-bordered {
        border: 1px solid #eaeaea;
    }

    .table td, .table th {
        border-top: 1px solid #ededed !important;
    }
    .card{
        border: 1px solid rgba(84, 83, 83, 0.1);
    }
    .card-header{
        border-bottom: 1px solid rgba(132, 131, 131, 0.1);
    }
    .table th{
        color:#525252;
        font-size: 15px;
    }
    .page-item.disabled .page-link {
        border-color: #e9e9ea;
    }
    .page-link {
        border-color: #e9e9ea;
    }
    .table thead th {
        border-bottom: 1px solid #e4e1e1;
        border-top: none !important;
    }


    .custom_text_info{
        color: rgb(17, 103, 167) !important;
        cursor: pointer;
        font-weight: 600;
    }

    .custom_text_info:hover{
        color: rgb(17, 103, 167);
        cursor: pointer;
        font-weight: 600;
    }
    .custom_text_danger{
        color: rgb(251, 86, 86) !important;;
        cursor: pointer;
        font-weight: 600;
    }

    .btn-info {
        color: #fff;
        background-color: #3ca1eb;
        border-color: #3ca1eb;
        padding: 4px 6px;
        border-radius: 3px;
        font-size: 15px;
    }

    .btn-info:hover {
        color: #fff;
        background-color: #1e8cdd;
        border-color: #1e8cdd;
    }
    .btn-success {
        color: #fff;
        background-color: #55ad69;
        border-color: #55ad69;
        padding: 4px 7px;
        border-radius: 3px !important;
        font-size: 14px;

    }
    .btn-success:hover {
        color: #fff;
        background-color: #39a852;
        border-color: #39a852;
    }

    .popover {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        font-weight: bold;
        color: #FFFFFF;
    }

    .popover1 {
        border: 2px dotted deepskyblue;
        font-size: 15px;
        text-align: center;
        font-weight: bold;
        color: dodgerblue;
    }

    .content_wrap {
        white-space: nowrap;
        width: 120px;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    /*        Tooltip*/

    [data-tooltip] {
        /*z-index: 2;*/
        position: relative;
        cursor: pointer;
        white-space: pre-wrap;
    }

    [data-tooltip]:before,
    [data-tooltip]:after {
        visibility: hidden;
        -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        opacity: 0;
        pointer-events: none;
        z-index: 99999999 !important;
    }

    [data-tooltip]:before {
        position: absolute;
        top: 70%;
        left: 50%;
        margin-bottom: 5px;
        margin-left: -80px;
        padding: 7px;
        min-width: 200px;
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        border-radius: 3px;
        background-color: #3ca1eb;
        background-color: #3ca1eb;
        color: #fff;
        content: attr(data-tooltip);
        text-align: center;
        font-size: 14px;
        line-height: 1.2;
    }

    [data-tooltip]:after {
        position: absolute;
        top: 63%;
        left: 50%;
        margin-left: -5px;
        width: 0;
        border-bottom: 5px solid #3ca1eb;
        /*border-top: 5px solid #3ca1eb;*/
        border-right: 5px solid transparent;
        border-left: 5px solid transparent;
        content: " ";
        font-size: 0;
        line-height: 0;
    }

    [data-tooltip]:hover:before,
    [data-tooltip]:hover:after {
        visibility: visible;
        -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
        filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=100);
        opacity: 1;
    }

</style>

<header id="header" class="header">
    <div class="header-menu">
        <div class="col-sm-7">
            <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
            <div class="header-left">
                <a href="/staff/feeds">
                    <div class="dropdown for-notification">
                        {{--<button class="btn btn-secondary dropdown-toggle" type="button" id="notification" aria-haspopup="true" aria-expanded="false">--}}
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="notification"
                                    aria-haspopup="true" aria-expanded="false" aria-hidden="true" data-toggle="popover2" data-content="" style="font-size: 22px">                            <i class="fa fa-bell"></i>
                            <span class="count bg-danger" id="countNotification" style="display: none">0</span>
                        </button>
                    </div>
                </a>
                <a href="/staff/resource-page" style="cursor: pointer;font-size:20px;margin:0 0 0 3%;"><i class="fa fa-info-circle" aria-hidden="true"  data-toggle="popover" data-content="" style="font-size: 18px;vertical-align: middle;padding-top: 5px;"></i>
                </a>
            </div>
        </div>
        <div class="col-sm-5">
            <div class="user-area dropdown float-right">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle" src="{{ \Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}" alt="User Avatar">
                </a>

                <div class="user-menu dropdown-menu">
                    <a class="nav-link" href="/staff/myProfile"><i class="fa fa -cog"></i>Settings</a>
                    <a class="nav-link" href="/staff/logout"><i class="fa fa-power -off"></i>Logout</a>
                </div>
            </div>
        </div>
    </div>
</header>

