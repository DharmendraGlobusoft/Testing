<!DOCTYPE html>
<html>
<head>
    {{--<title>Cloud Office</title>--}}
    @include('Staff::layouts.head')
    @yield('title')
    @yield('page-style')
</head>
<body>
@include('Staff::layouts.sidebar')
<div id="right-panel" class="right-panel">
@include('Staff::layouts.header')
        @yield('page-content')
</div>
@include('Staff::layouts.footer')
@include('Staff::layouts.script')
@yield('page-scripts')
</body>
</html>