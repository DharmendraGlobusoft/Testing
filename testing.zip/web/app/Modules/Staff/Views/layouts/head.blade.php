<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
{{--<title>Cloud Office</title>--}}
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="author" content="Siddu Venkatapur">
<meta name="description" content="Cloud office, Project Management Software">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="apple-touch-icon" href="/apple-icon.png">
<link rel="shortcut icon" href="/images/favicon.png">
<link rel="stylesheet" href="/staffAssets/css/normalize.css">
<link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">
<link rel="stylesheet" href="/staffAssets/css/bootstrap-popover-x.css">
<link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">
<link rel="stylesheet" href="/staffAssets/css/themify-icons.css">
<link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">
<link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">
<link rel="stylesheet" href="/staffAssets/css/lib/datatable/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="/staffAssets/scss/style.css">
<link rel="stylesheet" href="/staffAssets/css/invoice.css">
<link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
<link rel="stylesheet" href="/staffAssets/css/lib/chosen/chosen.min.css">
<link rel="stylesheet" href="/staffAssets/css/print.css" media="print">
<link rel="stylesheet" href="/staffAssets/css/file_attach.css">
<link rel="stylesheet" href="/staffAssets/css/image_uploaderstyle.css">

<link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet">
<link href="/staffAssets/css/index.css" rel="stylesheet">
{{--<link href="/external/google-code-prettify/prettify.css" rel="stylesheet">--}}
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.standalone.min.css'>
<link  href="/staffAssets/css/datepicker_style.css" rel="stylesheet" type="text/css">