{{--<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>--}}
{{--<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>--}}
{{--<script src="/staffAssets/js/popper.min.js"></script>--}}

<script src="/staffAssets/js/main.js"></script>
<!--  Chart js -->


<!-- Data Table   -->

{{--<script src="/staffAssets/js/lib/data-table/datatables.min.js"></script>--}}
<script src="/staffAssets/js/lib/data-table/jquery.dataTables.min.js"></script>
<script src="/staffAssets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="/staffAssets/js/plugins.js"></script>
<script src="/staffAssets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="/staffAssets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="/staffAssets/js/lib/data-table/jszip.min.js"></script>
<script src="/staffAssets/js/lib/data-table/pdfmake.min.js"></script>
<script src="/staffAssets/js/lib/data-table/vfs_fonts.js"></script>
<script src="/staffAssets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="/staffAssets/js/lib/data-table/buttons.print.min.js"></script>
<script src="/staffAssets/js/lib/data-table/buttons.colVis.min.js"></script>
{{--<script src="/staffAssets/js/lib/data-table/datatables-init.js"></script>--}}
{{--<script src="/external/google-code-prettify/prettify.js"></script>--}}
<script src="/staffAssets/js/jquery.hotkeys.js"></script>
<script src="/staffAssets/js/bootstrap-wysiwyg.js"></script>
<script src="/staffAssets/js/lib/chosen/chosen.jquery.min.js"></script>
<script src="/staffAssets/js/file_attach.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js'></script>
<script src="/staffAssets/js/datepicker_js.js"></script>
<script src="/staffAssets/js/image_uploader.js" type="text/javascript"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>
<script src="/assets/js/jquery.nicescroll.min.js"></script>


<script type="text/javascript">

    jQuery(document).ready(function () {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "50%"
        });
    });
//-----------------------This is for highliting the clicked function in side bar-------------------------
    $(document).ready(function () {
        $('#bootstrap-data-table-export').DataTable();
        $.each($('.navbar-nav li'), function () {
            if ($(this).find('a').attr('href') === window.location.pathname) {
                $(this).addClass('active').siblings().removeClass('active');
            }
        });
    });
// ------------------------------------------------------------------------------------------------------------
    $('[data-toggle="popover2"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Notifications'
    });

    $('[data-toggle="popover"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Resource Page'
    });

    $('[data-toggle="popover3"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Dashboard'
    });
    $('[data-toggle="popover4"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Projects'
    });
    $('[data-toggle="popover5"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Messages'
    });
    $('[data-toggle="popover6"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Support Tickets'
    });
    $('[data-toggle="popover7"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Invoice'
    });
    $('[data-toggle="popover8"]').popover({
        placement: 'bottom',
        trigger: 'hover',
        html: true,
        content: 'Logout'
    });

    $(document).ready(function () {
        $('.user-area').click(function () {
            console.log($(this));
            $(this).addClass('show');
            $(this).find('.user-menu').addClass('show');
        })
    });

//-------------------------------------------for showing notification-----------------------------
    $(document).ready(function () {
        $('#countNotification').hide();
        notification();
        function notification() {
            setTimeout(function () {
                $.ajax({
                    url: '/staff/getNotification',
                    method: "post",
                    dataType: 'json',
                    cache: true,
                    success: function (response) {
                        if (response.status === 200) {
                            $('#countNotification').show();
                            document.getElementById("countNotification").innerHTML = response.count;
                            // document.getElementById("countNotification").innerHTML = 300;
                        } else {
                            // $('#countNotification').show();
                            $('#countNotification').hide();
                        }
                    }
                });
                notification();
            }, 60000);
        }
    });


</script>