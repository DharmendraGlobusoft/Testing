<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/7/2018
 * Time: 4:35 PM
 */
?>


@extends('Staff::layouts.master')

@section('title','Project')

@section('page-style')
    <style>
        body {
            padding-right: 0px !important;
        }

        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        #addResource .form-control {
            display: inline-block;
        }
        .activity-stream {
            list-style-type: none;
            margin: 2em 3em;
            padding: 0;
            border-left: 1px solid #ccc;
            padding-left: 1.5em;
        }

        .activity-stream li {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li textarea {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li .icon {
            height: 60px;
            width: 60px;
            padding: 4px 4px;
            color: #fff;
            box-sizing: border-box;
            display: block;
            background: #53b2ea;
            position: absolute;
            left: -4.5em;
            top: .5em;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .activity-stream li:before,
        .activity-stream li:after {
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: transparent;
            border-left: 0;
        }

        .activity-stream li:before {
            top: 1em;
            left: -8px;
            /* If 1px darken stroke slightly */
            border-right-color: #aaa;
            border-width: 7px;
        }

        .activity-stream li:after {
            top: 1em;
            left: -7px;
            border-right-color: white;
            border-width: 7px;
        }
        /*   Resource CSS    */

        .lib-panel {
            margin-bottom: 20Px;
        }

        .lib-panel img {
            width: 100%;
            background-color: transparent;
        }

        .lib-panel .row,
        .lib-panel .col-md-6 {
            padding: 5px;
            background-color: #FFFFFF;
        }

        .lib-panel .lib-row {
            padding: 0 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header {
            background-color: #FFFFFF;
            font-size: 20px;
            padding: 10px 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header .lib-header-seperator {
            height: 2px;
            width: 26px;
            background-color: #d9d9d9;
            margin: 7px 0 7px 0;
        }

        .lib-panel .lib-row.lib-desc {
            position: relative;
            height: 100%;
            display: block;
            font-size: 13px;
        }

        .lib-panel .lib-row.lib-desc a {
            position: absolute;
            width: 100%;
            bottom: 10px;
            left: 20px;
        }

        .row-margin-bottom {
            margin: 15px;
        }

        .box-shadow {
            -webkit-box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
            box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
        }

        .no-padding {
            padding: 0;
        }
        /*   Resources CSS  Ends*/

        /*        Radio Css*/

        .buying-selling.active {
            background: #3ca1eb;
        }

        .buying-selling {
            width: 130px;
            padding: 10px;
            position: relative;
        }

        .buying-selling-word {
            font-size: 15px;
            font-weight: 600;
            margin-left: 22px;
        }

        .radio-dot:before,
        .radio-dot:after {
            content: "";
            display: block;
            position: absolute;
            background: #fff;
            border-radius: 100%;
        }

        .radio-dot:before {
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            top: 10px;
            left: 16px;
        }

        .radio-dot:after {
            width: 12px;
            height: 12px;
            border-radius: 100%;
            top: 14px;
            left: 20px;
        }

        .buying-selling.active .buying-selling-word {
            color: #fff;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active .radio-dot:before {
            background: #fff;
            border-color: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:before {
            border-color: #adadad;
        }

        .buying-selling.active:hover .radio-dot:before {
            border-color: #3ca1eb;
        }

        .buying-selling.active .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling:hover .radio-dot:after {
            background: #3ca1eb;
        }

        .buying-selling.active:hover .radio-dot:after {
            background: #3ca1eb;
        }

        @media (max-width: 400px) {
            .mobile-br {
                display: none;
            }

            .buying-selling {
                width: 49%;
                padding: 10px;
                position: relative;
            }
        }
        .popover.bottom .arrow {
            left:14%;
        }

        .thumb-contenido{

            margin-bottom:1%;
            margin-left: 0px;
            padding-left: 0px;
        }

    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Resources|News Board </h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="#">Staff</a></li>
                        <li class="active">Resources List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header" style="background:rgb(60, 161, 235);color: #ffff;">
                            <h4 style="display: inline-block">Post Details</h4>
                        </div>
                        <div class="card-body" style="">
                            <div class="container">
                                <div class="well">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?php
                                            $im = $data['resource_image'];
                                            $images = json_decode($im);
//                                            dd($data);
                                            ?>
                                            <?php
                                            foreach ($images as $image){ ?>
                                                <div class="pull-left col-md-4 col-xs-12 thumb-contenido"><img class="center-block img-responsive" src='{{$image}}' /></div>
                                            <?php } ?>
                                            {{--<div class="pull-left col-md-4 col-xs-12 thumb-contenido"><img class="center-block img-responsive" src='/images/admin1.jpg' /></div>--}}
                                            <div class="">
                                                <h1  class="hidden-xs hidden-sm">{{$data['resource_title']}}</h1>
                                                <hr>
                                                <small>{{date('d/M/Y',$data['created_at'])}}</small><br>
                                                <small><strong>Author</strong></small>
                                                <hr>
                                                <?php
                                                $fullPath = storage_path('app/'.$data['resource_content']);
                                                $text=file_get_contents($fullPath);
                                                print_r(html_entity_decode($text));
                                                ?>
                                                <p class="text-justify">Sed porttitor lectus nibh. Nulla quis lorem ut libero malesuada feugiat.
                                                    Quisque velit nisi, pretium ut lacinia in, elementum id enim. Sed porttitor lectus nibh.
                                                    Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.
                                                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur aliquet quam id dui posuere blandit.
                                                    Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sapien massa,
                                                    convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Nulla quis lorem ut libero malesuada feugiat.
                                                    Donec rutrum congue leo eget malesuada.<br><br>

                                                    Sed porttitor lectus nibh. Nulla quis lorem ut libero malesuada feugiat.
                                                    Quisque velit nisi, pretium ut lacinia in, elementum id enim. Sed porttitor lectus nibh.
                                                    Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.
                                                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur aliquet quam id dui posuere blandit.
                                                    Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sapien massa,
                                                    convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Nulla quis lorem ut libero malesuada feugiat.
                                                    Donec rutrum congue leo eget malesuada.<br><br>

                                                    Sed porttitor lectus nibh. Nulla quis lorem ut libero malesuada feugiat.
                                                    Quisque velit nisi, pretium ut lacinia in, elementum id enim. Sed porttitor lectus nibh.
                                                    Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.
                                                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur aliquet quam id dui posuere blandit.
                                                    Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sapien massa,
                                                    convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Nulla quis lorem ut libero malesuada feugiat.
                                                    Donec rutrum congue leo eget malesuada.<br><br>

                                                    Nulla quis lorem ut libero malesuada feugiat. <br>

                                                    Quisque velit nisi, pretium ut lacinia in, elementum id enim. Sed porttitor lectus nibh.
                                                    Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat.
                                                    Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur aliquet quam id dui posuere blandit.
                                                    Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sapien massa,
                                                    convallis a pellentesque nec, egestas non nisi. Proin eget tortor risus. Nulla quis lorem ut libero malesuada feugiat.
                                                    Donec rutrum congue leo eget malesuada.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .animated -->
    </div>
    <div id="moreinfo" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header" style="background-color: #0ad6fc;color: #222222 ;">

                    <h4 class="modal-title">More Info</h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <div class="modal-body" style="background-color:#fff;">
                    <p> Hiiii ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor
                        Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor
                        Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor
                    </p>
                </div>
                <div class="modal-footer" style="background-color: #fff;color: white;">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('page-scripts')


@endsection
