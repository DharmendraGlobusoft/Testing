<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/19/2018
 * Time: 5:41 PM
 */
?>

@extends('Staff::layouts.master')

{{--@section('title','Project')--}}
@section('title')
    <title> Invoice || Cloud Office</title>
@endsection

@section('page-style')
    <style>
        #tab_logic .fa-window-close {

            position: absolute;
        }
    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Invoice</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/staff/dashboard">Dashboard</a></li>
                        <li class="active">Invoices</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="pull-right" style="margin: 15px;">
        <a href="/staff/invoiceDetails" class="btn btn-info">View Invoice Details</a></div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-10 offset-md-1"
                     style="padding: 40px 0px 0px 0px;box-shadow: 0px 0px 15px #6A6A6A;margin-bottom: 5%;">
                    <div class="col-md-12">
                        <h4 style="text-align: center;">
                            <div class="form-group" style="margin-bottom: 2rem;">Invoice Form
                            </div>
                        </h4>
                    </div>
                    <form id="invoice">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col col-md-4">
                                    <label class="control-label" for="name">To</label>
                                </div>
                                <input id="receiver" name="to" type="text"
                                       class="form-control col-md-8" value="Admin" disabled="disabled">
                                {{--<select name="to" id="receiver" class="form-control form-control col-md-8">--}}
                                    {{--<option value="1">Admin</option>--}}
                                    {{--@foreach($mdata as $key=>$val)--}}
                                        {{--<option value={{$val['id']}}>{{$val['first_name']." ".$val['last_name']}}</option>--}}
                                    {{--@endforeach--}}
                                    {{--<option value="2">Manager</option>--}}
                                {{--</select>--}}
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col col-md-4">
                                    <label class="control-label" for="name">From</label>
                                </div>
                                <input id="sender" name="from" disabled="disabled" placeholder="Sender name"
                                       value="{{ \Illuminate\Support\Facades\Session::get('staff_detail')['name']." ".\Illuminate\Support\Facades\Session::get('staff_detail')['last_name']}}"
                                       class="form-control col-md-8">
                                {{--                                       value="{{ Auth::user()->name." ".Auth::user()->last_name}}" class="form-control col-md-8">--}}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col col-md-4">
                                    <label class="control-label" for="name">Subject</label>
                                </div>
                                <input id="subject" name="subject" type="text" placeholder="Enter Subject"
                                       class="form-control col-md-8">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-4">
                                    <label for="textarea-input" class=" form-control-label">Message</label>
                                </div>
                                <textarea name="message" id="message" rows="2"
                                          placeholder="Type Message here..." class="form-control col-md-8"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="col-md-4 control-label" for="name">Payment By</label>
                                <div class="buying-selling-group" id="buying-selling-group" data-toggle="buttons"
                                     style="display: inline-block;">
                                    <label class="btn btn-default buying-selling">
                                        <input type="radio" name="options" id="mPesaRadioBtn" autocomplete="off">
                                        <span class="radio-dot"></span>
                                        <span class="buying-selling-word">mPesa</span>
                                    </label>

                                    <label class="btn btn-default buying-selling">
                                        <input type="radio" name="options" id="payPalRadioBtn" autocomplete="off">
                                        <span class="radio-dot"></span>
                                        <span class="buying-selling-word">Paypal</span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col col-md-4">
                                    <label class="control-label" for="name">Due Amount</label>
                                </div>
                                <input id="due_amount" onkeyup="verifyDueAmount()" name="due_amount" type="text"
                                       placeholder="Enter Amount"
                                       class="form-control col-md-4" style="display: inline-block;">

                                <select class="form-control select-currency col-md-3" tabindex="27" id="currencySelect"
                                        name="currencySelect"
                                        onchange="InvoiceGenerator.showCurrencySelect('currencySelect', 'currencySym')"
                                        style="padding: 6px;display: inline-block;">
                                    <option value="USD">USD</option>
                                    <option value="KSHS">KSHS</option>
                                </select>
                                <span id="dueAmount"></span>
                            </div>
                        </div>
                        {{--<div class="col-md-12" style="padding: 0;">--}}
                            {{--<div class="col-md-6 datepart">--}}
                                {{--<div class="form-group">--}}
                                    {{--<div class="col col-md-4">--}}
                                        {{--<label class="control-label" for="name">Start Date</label>--}}
                                    {{--</div>--}}
                                    {{--<input id="start_date" name="start_date" type="date" placeholder="Your name"--}}
                                           {{--class="form-control col-md-8">--}}
                                {{--</div>--}}
                            {{--</div>--}}

                            {{--<div class="col-md-6 datepart">--}}
                                {{--<div class="form-group">--}}
                                    {{--<div class="col col-md-4">--}}
                                        {{--<label class="control-label" for="name">End Date</label>--}}
                                    {{--</div>--}}
                                    {{--<input id="end_date" name="end_date" type="date" placeholder="Your name"--}}
                                           {{--class="form-control col-md-8">--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        <div class="col-md-12" style="padding: 0;">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-4">
                                    <label class="">Attachment</label>
                                </div>
                                <label for="attachment" class="form__file col-md-8" style="display: inline-block;">
                                    <span class="form__file-filename" id="filename" data-placeholder="Attach file">Attach file</span>
                                    <span class="form__file-browse">Browse</span>
                                    <input type="file" name="filedata" class="form__file-input col-md-9"
                                           id="attachment">
                                </label>

                            </div>
                            <div class="col-md-8 offset-md-4" style="padding: 0;">
                                <ul class="form__files" id="attachment-files"></ul>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-4">
                                    <label for="textarea-input" class=" form-control-label">Create Invoice</label>
                                </div>
                                <a href="/staff/invoice_form" class="btn btn-info">
                                    Click here to Create Invoice
                                </a>
                            </div>
                        </div>
                        </div>

                        <div class="col-lg-12" style="text-align: center;margin:4% 0;">
                            <button class="btn btn-success sendInvoiceBtn" type="button" style="padding: 6px 10px;">Send
                                Invoice
                            </button>
                            <button type="button" onclick="cancelBtn()" class="btn btn-danger" data-dismiss="modal">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="invoiceCreationmodal">
        <div class="modal-dialog" style="max-width: 800px;">
            <div class="modal-content" style="border:2px solid #3ca1eb;">
            </div>
        </div>
    </div>

    <div id="loader" class="hide">
        <div class=""
             style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); width: 100%; height: 100%; position: fixed; top: 0%; background: rgb(6, 6, 6) none repeat scroll 0% 0%;
opacity: 0.8; z-index: 1004; cursor: wait; right: 0px;"></div>
        <div class="blockUI blockMsg blockPage "
             style="padding: 0px; margin: 0px; top: 30%; color: rgb(0, 0, 0); font-weight: normal; font-size: 20px; left: 40%; text-align: center; z-index: 999999 ! important; position: fixed; width: 30%;">
            <img src="\images\cloud_loading.gif"
                 style="height:150px;display: block; margin-left: auto;margin-right: auto">
            <p style="text-align: center; font-size: 20px;color: #fff">Processing please wait...</p>
        </div>
    </div>

@endsection

@section('page-scripts')
    <script src="/assets/js/toastr/toastr.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>
    <script>
        $(document).ready(function () {
            $('#loader').hide();
            toastr.options.positionClass = "toast-top-center";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicates = true;
        });
    </script>
    <script>
        $(document).ready(function () {
            var i = 1;
            $(document).on('click', '#add_row', function (e) {
                $('#addr' + i).html("<td><input name='Item Description" + i + "' type='text' placeholder='Item Description' class='form-control input-md'  />" +
                    " </td><td><input  name='Quantity" + i + "' type='text' placeholder='Quantity'  class='form-control input-md'>" +
                    "</td><td><input  name='Rate" + i + "' type='text' placeholder='Rate'  class='form-control input-md'></td>" +
                    "<td><input  name='Amount" + i + "' type='text' placeholder='Amount'  class='form-control input-md'></td>" +
                    "<td name='closebtn" + i + "' style='border: 1px solid #fff;'><i class='fa fa-window-close'></i></td>");

                $('.addingrow').before('<tr id="addr' + (i + 1) + '"></tr>');
                i++;
                $("tbody tr").hover(function () {
                    $(".fa-window-close").css("display", "none");
                    $(this).find(".fa-window-close").css("display", "block");

                });
                $(this).find(".fa-window-close").click(function () {
                    $(this).parents("tr").remove();
                });
            });
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // let formdata = new FormData();

        var invoiceFormData = new FormData();
        var count = 0;

        $(document).ready(function () {

            $('#attachment').on('change', function (event) {

                var ext = $('#attachment').val().split('.').pop().toLowerCase();
                if ($.inArray(ext, ['pdf', 'doc', 'docx']) == -1) {
                    toastr.warning('Only .pdf, .doc, .docx type files are allowed', {timeOut: 10000});
                    return false;
                }

                var imageName = 'taskFiles' + ++count;
                invoiceFormData.append(imageName, $('input[name=filedata]')[0].files[0]);

                var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

                if (typeof filename === 'undefined') {
                    return false;
                }

                var $file = $(this).closest('.form__file');

                $file
                    .addClass('form__file--attached')
                    .find('.form__file-filename')
                    .html(filename);

                $file
                    .find('.form__file-input')
                    .prop('disabled', true);

                // list of files
                var $files = $('#attachment-files');

                // show files list
                if ($files.find('li').length === 0) {
                    $files.removeClass('form__files--hide').addClass('form__files--show');
                }

                // create a new item
                var $item = $('<li/>')
                    .addClass('form__files-item')
                    .addClass('form__files-item--loading')
                    .append($('<span/>').addClass('form__files-item-link').html(filename))
                    .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                    .append($('<span/>').addClass('form__files-item-progress'))
                    .append($('<input/>').attr({
                        type: 'hidden',
                        name: 'attachments[]',
                        value: '{}'
                    }));

                $files.append($item);

                // progress bar
                $item.find('.form__files-item-progress').animate({
                    width: '100%'
                }, 2000);

                $('#attachment-files').trigger('contentChanged');

                setTimeout(function () {
                    $file.removeClass('form__file--attached');

                    $file
                        .find('.form__file-input')
                        .prop('disabled', false);

                    var v = $file.find('.form__file-filename').data('placeholder');
                    $file.find('.form__file-filename').html(v);
                    $file.find('.form__file-input').val('');

                    $item
                        .removeClass('form__files-item--loading')
                        .addClass('form__files-item--done');

                    $item.find('.form__files-item-link').replaceWith(function () {
                        var text = $.trim($(this).text());
                        return $('<a/>').attr({
                            href: '#',
                            target: '_blank'
                        }).addClass('form__files-item-link').html(text);
                    });

                    var _itemData = JSON.stringify({
                        id: uuidv4(),
                        name: filename,
                        url_view: '',
                        url_delete: ''
                    }, null, '');

                    $item
                        .find('input[type=hidden]')
                        .val(_itemData);


                    $item.find('[data-file-remove=true]').on('click', function () {
                        var imageName = $(this).attr('imageName');
                        invoiceFormData.delete(imageName);
                        var $removeItem = $(this).closest('.form__files-item'),
                            itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                        // ajax request

                        $removeItem.addClass('form__files-item--hide');

                        // hide files list
                        if ($files.find('li').length <= 1) {
                            $files.removeClass('form__files--show').addClass('form__files--hide');
                        }

                        $('#attachment-files').trigger('contentChanged');

                        setTimeout(function () {
                            $removeItem.remove();
                        }, 500);

                    });
                }, 2000);
            });

            $('#attachment-files').on('contentChanged', function () {
            });

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

            $('#invoice')[0].reset();
            $(document.body).on('click', '.sendInvoiceBtn', function () {
                if (invoiceFormData === "") {
                    toastr.error('Please Choose File', {timeOut: 10000});
                    return false;
                }
                var receiver, sender, message, subject, currencySelect, due_amount, start_date, end_date, option1,
                    option2, file;
                file = $('#file').val();
                receiver = $('#receiver').val();
                invoiceFormData.append('receiver', receiver);
                sender = $('#sender').val();
                invoiceFormData.append('sender', sender);
                subject = $('#subject').val();
                invoiceFormData.append('subject', subject);
                message = $('#message').val();
                invoiceFormData.append('message', message);
                currencySelect = $('#currencySelect').val();
                invoiceFormData.append('currencySelect', currencySelect);
                due_amount = $('#due_amount').val();
                invoiceFormData.append('due_amount', due_amount);
                option1 = $('#mPesaRadioBtn').prop('checked');
                option2 = $('#payPalRadioBtn').prop('checked');
                if (option1==true){
                    var mpesanum='{{$mpesanum}}';
                    if (mpesanum){
                    //
                    }else{
                        toastr.error('You have not provided mPesa number in your profile details', {timeOut: 10000});
                        return false;
                    }
                }
                if (option2==true){
                    var paypalEmail='{{$paypalEmail}}';
                    if (paypalEmail){
                    //
                    }else{
                        toastr.error('You have not provided payPal email in your profile details', {timeOut: 10000});
                        return false;
                    }
                }

                if ($('#subject').val().length > 100) {
                    toastr.error('Subject length exceeds maximum limit(100 characters)', {timeOut: 10000});
                    return false;
                }
                var today='{{$today}}';
                if (today === "Friday") {
                } else {
                    toastr.error('Please Wait For Friday', {timeOut: 10000});
                    return false;
                }
                if (sender === "") {
                    toastr.error('Please Choose Sender', {timeOut: 10000});
                    return false;
                } else if (receiver.trim() === "") {
                    toastr.error('Please Enter Receiver', {timeOut: 10000});
                    return false;
                } else if (subject.trim() === "") {
                    toastr.error('Please Enter Subject', {timeOut: 10000});
                    return false;
                } else if (message.trim() === "") {
                    toastr.error('Please Enter Message', {timeOut: 10000});
                    return false;
                } else if (due_amount.trim() === "") {
                    toastr.error('Please Enter Due Amount', {timeOut: 10000});
                    return false;
                }
                if (option1 === false && option2 === false) {
                    toastr.error('Please Choose Your Payment Option', {timeOut: 10000});
                    return false;
                }

                invoiceFormData.append('option1', option1);
                invoiceFormData.append('option2', option2);
                var tz = jstz.determine(); // Determines the time zone of the browser client
                var timezone = tz.name();
                invoiceFormData.append('timeZone', timezone);

                if (count === 0) {
                    toastr.error('Please Choose attachement', {timeOut: 10000});
                    return false;
                }
                // if (new Date(start_date) <= new Date(end_date)) {
                //     // alert('if');
                // } else {
                //     toastr.error('Start date should be less than end date', {timeOut: 10000});
                //     return false;
                // }
                $.ajax({
                    url: "/staff/invoice",
                    method: "post",
                    dataType: "json",
                    data: invoiceFormData,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        $('#loader').show();
                    },
                    success: function (response) {
                        $('#loader').hide();
                        $('#attachment-files').hide();
                        if (response.msg === 1) {
                            toastr.success('Invoice Sent Successfully', {timeOut: 2000});
                            // $('#invoice')[0].reset();
                            setTimeout(function () {
                                window.location.href = '/staff/invoiceDetails'
                            }, 3000);
                        } else if (response.msg === 198) {
                            toastr.error('Please Choose attachement', {timeOut: 10000});
                        } else if (response.code == 400) {
                            toastr.error('Please Wait For Friday', {timeOut: 10000});
                        }else if (response.code == 201) {
                            toastr.error('Mail not delivered, Please try again', {timeOut: 10000});
                        } else {
                            toastr.error('Failed Try Again...!!', {timeOut: 10000});
                        }
                    }
                });

            });

        });

        function cancelBtn() {
            $('#invoice')[0].reset();
            location.reload();
        }

        function savePdf() {

            var divToPrint = document.getElementById('invoiceCreationmodal');
            // var formHtml = $('#invoiceCreationmodal').html();


            var newWin = window.open('', 'Print-Window');

            // newWin.document.open();

            newWin.document.write('<html><head>' +
                '<link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/bootstrap-popover-x.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/themify-icons.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/invoice.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/lib/datatable/dataTables.bootstrap.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/scss/style.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/invoice.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/lib/chosen/chosen.min.css">\n' +
                '<link rel="stylesheet" href="/staffAssets/css/print.css" media="print">' +
                '</head><body onload="window.print()">' + divToPrint.innerHTML + '</body></html>');

            newWin.document.close();

            setTimeout(function () {
                newWin.close();
            }, 30000);
        }

        window.onload = function () {
            $('body').find('#myiframe').contents().find('button.closeiframe').on('click', function () {
                $('#myModal').modal('hide');
            });
        }

        function verifyDueAmount() {
            var m = $('#due_amount').val();
            var filter = /^[0-9]+$/;
            if (filter.test(m)) {
                document.getElementById('dueAmount').innerHTML = '';
                if (m.length < 1) {
                    toastr.error('Please enter valid amount', {timeOut: 10000});
                    // document.getElementById('dueAmount').innerHTML = 'Please enter valid amount';
                    // $('#dueAmount').css('color', 'red');
                    return false;
                }
            }
            else {

                // document.getElementById('dueAmount').innerHTML = 'Only numeric digits are allowed';
                var amount = m.replace(/[^0-9.]/g, "");
                $('#due_amount').val(amount);
                toastr.error('Only numeric digits are allowed', {timeOut: 10000});
                return false;
                // $('#dueAmount').css('color', 'red');
            }
        }

    </script>
@endsection

