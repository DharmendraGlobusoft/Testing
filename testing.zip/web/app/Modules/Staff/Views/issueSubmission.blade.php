<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/4/2018
 * Time: 3:14 PM
 */
?>

@extends('Staff::layouts.master')

@section('title')
    <title> Issue Submission || Cloud Office</title>
@endsection


@section('page-style')
    <style>
        body {
            padding-right: 0px !important;
        }

        .side-area .user-avatar {
            margin: 20px 10px;
            width: 80px;
        }

        .side-area {
            text-align: center;
        }

        .side-area .dropdown-toggle::after {
            display: none;
        }

        #editProjectmodal .form-control {
            display: inline-block;
        }

        .activity-stream {
            list-style-type: none;
            margin: 2em 3em;
            padding: 0;
            border-left: 1px solid #ccc;
            padding-left: 1.5em;
        }

        .activity-stream li {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li textarea {
            border: 1px solid #ccc;
            padding: 1em 1em 3.5em 3em;
            margin: 1em;
            display: block;
            position: relative;
            background: #fff;
            /* Stroke */
            /* Fill */
        }

        .activity-stream li .icon {
            height: 60px;
            width: 60px;
            padding: 4px 4px;
            color: #fff;
            box-sizing: border-box;
            display: block;
            background: #53b2ea;
            position: absolute;
            left: -4.5em;
            top: .5em;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .activity-stream li:before,
        .activity-stream li:after {
            content: "";
            position: absolute;
            width: 0;
            height: 0;
            border-style: solid;
            border-color: transparent;
            border-left: 0;
        }

        .activity-stream li:before {
            top: 1em;
            left: -8px;
            /* If 1px darken stroke slightly */
            border-right-color: #aaa;
            border-width: 7px;
        }

        .activity-stream li:after {
            top: 1em;
            left: -7px;
            border-right-color: white;
            border-width: 7px;
        }

        /*   Resource CSS    */

        .lib-panel {
            margin-bottom: 20Px;
        }

        .lib-panel img {
            width: 100%;
            background-color: transparent;
        }

        .lib-panel .row,
        .lib-panel .col-md-6 {
            padding: 5px;
            background-color: #FFFFFF;
        }

        .lib-panel .lib-row {
            padding: 0 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header {
            background-color: #FFFFFF;
            font-size: 20px;
            padding: 10px 20px 0 20px;
        }

        .lib-panel .lib-row.lib-header .lib-header-seperator {
            height: 2px;
            width: 26px;
            background-color: #d9d9d9;
            margin: 7px 0 7px 0;
        }

        .lib-panel .lib-row.lib-desc {
            position: relative;
            height: 100%;
            display: block;
            font-size: 13px;
        }

        .lib-panel .lib-row.lib-desc a {
            position: absolute;
            width: 100%;
            bottom: 10px;
            left: 20px;
        }

        .row-margin-bottom {
            margin: 15px;
        }

        .box-shadow {
            -webkit-box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
            box-shadow: 0 0 10px 0 rgba(0, 0, 0, .10);
        }

        .no-padding {
            padding: 0;
        }

        .body_container {
            max-height: 400px;
            overflow-y: scroll;
        }

        /*   Resources CSS  Ends*/

        /* Comment CSS  */

        .widget .card-body {
            padding: 0px;
        }

        .widget .list-group {
            margin-bottom: 0;
        }

        .widget .panel-title {
            display: inline
        }

        .widget .label-info {
            float: right;
            background-color: #5489e4;
            color: #fff;
            padding: 6px 9px;
            border-radius: 50%;
        }

        .widget li.list-group-item {
            border-radius: 0;
            border: 0;
            border-top: 1px solid #ddd;
        }

        .widget li.list-group-item:hover {
            background-color: rgba(86, 61, 124, .1);
        }

        .widget .mic-info {
            color: #666666;
            font-size: 11px;
        }

        .widget .action {
            margin-top: 5px;
        }

        .widget .comment-text {
            font-size: 16px;
        }

        .widget .btn-block {
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .img-circle {
            border-radius: 50%;
        }

        .btn {
            padding: 5px 10px !important;
        }

        /*    Edit Comment*/

        .accordion {
            /*    background-color: #eee;*/
            color: #444;
            cursor: pointer;
            padding: 18px;
            /*    width: 100%;*/
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        .panel {
            padding: 0 18px;
            margin-top: 1%;
            /*background-color: rgba(113, 92, 144, 0.1);*/
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }

        .user-contact-form_field {
            margin: 0 0 8px;
            box-sizing: border-box;
        }

        .user-contact-form_field input,
        .user-contact-form_field textarea {
            font-size: 1em;
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #c1c1c1;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .user-contact-form_field textarea {
            width: 100%;
            max-width: 100%;
            min-width: 100%;
            min-height: 115px;
            margin-top: 3%;
        }

        .user-contact-form_field input:focus,
        .user-contact-form_field textarea:focus {
            border-color: #3e5e7e;
            outline: 0 solid transparent;
        }

        .user-contact-form_buttons {
            float: right;
        }

        .user-contact-form_buttons a {
            padding: 5px 10px;
            text-decoration: none;
            box-sizing: border-box;
            cursor: pointer;
        }

        .user-contact-form_buttons a.send-message {
            margin-left: 20px;
            float: left;
            background: #3e5e7e;
            border: 1px solid transparent;
            color: #fff;
        }

        .user-contact-form_buttons a.cancel-message {
            float: left;
            border: 1px solid rgba(0, 0, 0, 0.1);
            color: #fff;
            background-color: #f84d4d;
        }

        /*textarea {*/
            /*resize: none;*/
        /*}*/

        label {
            line-height: 2.5;
        }

        .comment_btn {
            /*position: absolute;*/
            /*bottom: 1px;*/
            /*right: 1%;*/
            margin: 10px 0px;
            /*cursor: pointer;*/
            /*padding: 4px 8px !important;*/
            font-size: 13px;
        }

        .comment_align ul, ol {
            padding-left: 15px;
        }

        .comment_align ul {
            list-style-type: disc;
        }

        .cut-text {
            text-overflow: ellipsis;
            overflow: hidden;
            width: 160px;
            height: 1.2em;
            white-space: nowrap;
        }

        /*.dotDot{*/
        /*display:inline-block;*/
        /*width:180px;*/
        /*white-space: nowrap;*/
        /*overflow:hidden !important;*/
        /*text-overflow: ellipsis;*/
        /*}*/

        #editor2 .panel {
            padding: 0 0px;
            margin-top: 1%;
            /*        background-color: rgba(113, 92, 144, 0.1);*/
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }

        .editIssueBtn{
            padding: 7px 11px !important;
            color: #fff;
        }
    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Issue Submission </h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <a href="/staff/dashboard" style="cursor: pointer;"> <img src="\uploads\previous.png"
                                                                                  width="35px"></a>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        {{--<div class="card-header">--}}
                        {{--<h4>Issue Submission</h4>--}}
                        {{--</div>--}}
                        <div class="card-body" style="background: #fff;">
                            <div class="col-md-12">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="row" style="margin-left: 0px;margin-right: 0px;">
                                            <div class="col-md-3">
                                                <label for="select" class=" form-control-label">Assignee</label>
                                            </div>

                                            {{--<select name="select" id="Select" class="form-control col-md-3">--}}
                                            {{--<option value="0">Please select</option>--}}
                                            {{--<option value="1">Siddu</option>--}}
                                            {{--<option value="2">Dharmendra</option>--}}
                                            {{--<option value="3">Bandana</option>--}}
                                            {{--</select>--}}
                                            {{--                                            {{dd($data)}}--}}

                                            <input id="name" name="name" type="text" placeholder="Assignee name"
                                                   disabled="disabled"
                                                   {{--value="{{$allStaffName}}"--}}
                                                   value="{{ Session::get('staff_detail')['name']." ".Session::get('staff_detail')['last_name']}}"
                                                   class="form-control col-md-9">


                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="col-lg-6" style="margin-bottom: 1rem;padding: 0;">
                                            <div class="col-lg-6">
                                                <label class="control-label" for="name">Due Date</label>
                                            </div>
                                            <input id="name" name="name" value="{{$data['due_date']}}"
                                                   class="form-control col-lg-6 issueDueDate" disabled>
                                        </div>
                                        <div class="col-lg-6" style="padding: 0">
                                            <div class="col-lg-6" style="text-align: right;
line-height: 2;">
                                                <label class="control-label" for="name">Due Hours</label>
                                            </div>
                                            <input id="issueDueHour" name="name" value="{{$data['due_hour']}}"
                                                   class="form-control col-lg-6 issueDueHour" disabled>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col col-md-3">
                                            <label for="select" class="form-control-label">Project Name</label>
                                        </div>

                                        {{--<select name="select" id="Select" class="form-control col-md-9">--}}
                                        {{--<option value="0">Please select</option>--}}
                                        {{--<option value="1">Project #1</option>--}}
                                        {{--<option value="2">Project #2</option>--}}
                                        {{--<option value="3">Project #3</option>--}}
                                        {{--<option value="4">Project #4</option>--}}
                                        {{--<option value="5">Project #5</option>--}}
                                        {{--</select>--}}

                                        <input id="name" name="name" disabled="disabled" type="text"
                                               value="{{$data['project_name']}}"
                                               class="form-control col-md-9">
                                        <input id="projectId" name="projectId" hidden type="text"
                                               value="{{$data['project_id']}}">
                                        <input id="issueId" name="issueId" hidden type="text"
                                               value="{{$data['issue_id']}}">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col col-md-3">
                                            <label class="control-label" for="name">Issue Name</label>
                                        </div>
                                        <input id="name" name="name" readonly type="text"
                                               value="{{$data['issue_topic']}}"
                                               class="form-control col-md-9">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-3">
                                            <label for="textarea-input" class=" form-control-label">Issue
                                                Descriptions</label>
                                        </div>

                                        <textarea name="textarea-input" style="min-height:150px" id="textarea-input"
                                                  rows="2" readonly
                                                  class="form-control col-md-9">{{$data['issue_desc']}}</textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-2">
                                            <label class=" form-control-label"> Assigned Files</label>
                                        </div>
                                        {{--<div class="assignedFilesData col-md-10">--}}
                                        <div class="col-md-10">

                                            <?php
                                            if (isset($data['issue_attachment_files'])){
                                            foreach ($data['issue_attachment_files'] as $v1){
                                            $split = explode('/', $v1);?>
                                            <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 2px"
                                               href='{{$v1}}'
                                               target="_blank" class="btn btn-info"><i class="fa fa-file-o"
                                                                                       aria-hidden="true"></i>
                                                {{$split[6]}} <i class="fa fa-download" aria-hidden="true"></i>
                                            </a>
                                            <?php    }
                                            }else{?>
                                            <p>
                                                No Files Has been Attached
                                            </p>
                                            <?php  }
                                            ?>


                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-2">
                                            <label class=" form-control-label"> Copy Scape Files</label>
                                        </div>
                                        <div class="col-md-10">
                                            <?php
                                            if (isset($data['copyScapeFiles'])){
                                            foreach ($data['copyScapeFiles'] as $v1){
                                            //                                                dd($v1['filePath']);
                                            $split = explode('/', $v1['filePath']);?>
                                            <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 2px"
                                               href='{{$v1['filePath']}}'
                                               target="_blank" class="btn btn-info">
                                                <i class="fa fa-file-o" aria-hidden="true"></i>
                                                {{$split[5]}} <i class="fa fa-download" aria-hidden="true"></i>
                                            </a>
                                            <u><a style="color: purple" href='{{$v1['copyScapeUrl']}}'
                                                  target="_blank">
                                                    Verified Url
                                                </a>
                                            </u>
                                            <?php    }
                                            }else{?>
                                            <p>
                                                No Files Has been Attached
                                            </p>

                                            <?php  }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-2">
                                            <label class=" form-control-label"> General Files</label>
                                        </div>
                                        <div class=" col-md-10">
                                            <?php
                                            if (isset($data['allFiles'])){
                                            foreach ($data['allFiles'] as $v1){
                                            $split = explode('/', $v1);?>
                                            <a style="background-color: #5489e4;border-radius: 3px; margin: 3px 2px"
                                               href='{{$v1}}'
                                               target="_blank" class="btn btn-info"><i class="fa fa-file-o"
                                                                                       aria-hidden="true"></i>
                                                {{$split[5]}} <i class="fa fa-download" aria-hidden="true"></i>
                                            </a>
                                            <?php    }
                                            }else{?>
                                            <p>
                                                No Files Has been Attached
                                            </p>
                                            <?php  }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12" style="margin: 3% 0;">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <!--                                <label class="col-md-3" for="attachment">Attachment</label>-->

                                            {{--<label for="taskAttachments" class="form__file">--}}
                                            {{--<span class="form__file-filename" id="filename"--}}
                                            {{--data-placeholder="Attach file to verify with CopyScape<b>(.doc,.docx,pdf)">Attach file to verify with CopyScape<b>(.doc,.docx,pdf)</b></span>--}}
                                            {{--<span class="form__file-browse">Browse</span>--}}
                                            {{--<input name="taskAttachments" class="form__file-input taskAttachments"--}}
                                            {{--id="taskAttachments" type="file">--}}
                                            {{--</label>--}}
                                            {{--<ul class="form__files col-md-6" id="attachment-taskFiles" style="margin-bottom: 15px;"></ul>--}}

                                            <label for="attachment" class="form__file siddu">
                                                <span class="form__file-filename" id="filename"
                                                      data-placeholder="Attach file to verify with CopyScape<b>(.doc,.docx,pdf)">Attach file to verify with CopyScape<b>(.doc,.docx,pdf)</b></span>
                                                <span class="form__file-browse">Browse</span>
                                                <input name="attachment" class="form__file-input fileAttachClass"
                                                       id="attachment" type="file">

                                            </label>
                                        </div>
                                        {{--<div class="col-md-12" style="text-align: left;padding:0;">--}}
                                        {{--<button class="btn btn-success submitFile" style="padding: 6px 10px;">Submit--}}
                                        {{--</button>--}}
                                        {{--</div>--}}
                                    </div>

                                    <div class="col-md-6" style="padding: 0;">
                                        <div class="form-group ">
                                            <!--                                <label class="col-md-3" for="attachment">Attachment</label>-->

                                            <label for="taskAttachments3" class="form__file ">
                                            <span class="form__file-filename" id="filename3"
                                                  data-placeholder="Attach file">Attach file</span>
                                                <span class="form__file-browse">Browse</span>
                                                <input name="taskAttachments3" class="form__file-input taskAttachments3"
                                                       id="taskAttachments3" type="file">

                                            </label>
                                            <ul class="form__files " id="attachment-taskFiles3"
                                                style="margin-bottom: 15px;">

                                            </ul>


                                        </div>
                                        <div class="col-md-12" style="padding:0;">
                                            <button class="btn btn-success submitFile3 pull-right"
                                                    style="padding: 6px 10px;">Submit Files
                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <div class="col-md-12" style="text-align:center;padding: 16px;">
                                    <button class="btn btn-success" id="finalIssueButton" onclick="finalIssueSubmission()">Final Issue Submission</button>
                                </div>

                                {{--</form>--}}
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="card widget comment_align" style="min-width: 100%;">
                                            <div class="card-header">
                                                <i class="fa fa-commenting-o" aria-hidden="true"></i>

                                                <h5 class="panel-title">
                                                    Recent Comments</h5>
                                                <span class="label label-info" id="totalComment">0</span>
                                            </div>
                                            <div class="card-body" id="header1 ">
                                                <div id="loaderClass" class="loaderClass hide"
                                                     style="text-align: center">
                                                    <img src="/images/cloud_loading.gif" style="width: 100px">
                                                </div>
                                                <ul class="list-group"
                                                    style="max-height: 600px;overflow: auto; padding: 0;">


                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12" style="border: 1px solid #c6c6c6;
padding: 0;">
                                    <div class="form-group">
                                        <div class="hero-unit">
                                            {{--<ul class="form__files" id="attachment-taskFiles1"></ul>--}}
                                            <div id="editor" contenteditable="true"></div>
                                            <div class="btn-toolbar" data-role="editor-toolbar" data-target="#editor"
                                                 style="width: 100%;">


                                                <div class="btn-group">
                                                    <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i
                                                                class="icon-bold"></i></a>
                                                    <a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i
                                                                class="icon-italic"></i></a>

                                                    <a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i
                                                                class="icon-underline"></i></a>
                                                </div>
                                                <div class="btn-group">
                                                    <a class="btn" data-edit="insertunorderedlist" title=""
                                                       data-original-title="Bullet list"><i
                                                                class="icon-list-ul"></i></a>
                                                    <a class="btn" data-edit="insertorderedlist" title=""
                                                       data-original-title="Number list"><i
                                                                class="icon-list-ol"></i></a>


                                                </div>

                                                <input type="text" data-edit="inserttext" id="voiceBtn"
                                                       x-webkit-speech="">
                                                <label for="taskAttachments1" class="form__file"
                                                       style="width:5%;box-shadow: none;border: none;color: #000;">
                                                    {{--<span class="form__file-filename" id="filename1"></span>--}}
                                                    <span class="form__file-browse" style="opacity: 1;top: 10px;
right: 15px;">Browse</span>
                                                    <input type="file" name="taskAttachments1"
                                                           class="form__file-input taskAttachments1"
                                                           id="taskAttachments1">
                                                </label>
                                                {{--<input type="file" name="file" class="form__file-input"--}}
                                                {{--id="attachment1">--}}
                                                {{--<button class="btn btn-info comment_btn issueCommentBtn" onclick="comment()" >Comment--}}
                                                {{--</button>--}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12" style="padding: 0;">
                                    <ul class="form__files" id="attachment-taskFiles1"></ul>
                                </div>
                                <div class="col-md-12">
                                    <i class="fa fa-spinner fa-spin spinnerIssueClass" style="position: absolute;
right: 4.5%;
top: 45%;color: #212121;display: none"></i>
                                    <button class="btn btn-info comment_btn issueCommentBtn pull-right"
                                            onclick="comment()">Comment
                                    </button>
                                </div>
                                {{--<div class="col-md-12" style="text-align:center;">--}}
                                    {{--<button class="btn btn-success">Final Issue Submission</button>--}}
                                {{--</div>--}}
                            </div>
                        </div>
                    </div>
                </div>
                <!-- .animated -->
            </div>
            <!-- .content -->

        </div>
    </div>
    <div id="loader" class="hide">
        <div class=""
             style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); width: 100%; height: 100%; position: fixed; top: 0%; background: rgb(6, 6, 6) none repeat scroll 0% 0%;
opacity: 0.8; z-index: 1004; cursor: wait; right: 0px;"></div>
        <div class="blockUI blockMsg blockPage "
             style="padding: 0px; margin: 0px; top: 30%; color: rgb(0, 0, 0); font-weight: normal; font-size: 20px; left: 40%; text-align: center; z-index: 999999 ! important; position: fixed; width: 30%;">
            <img src="\images\cloud_loading.gif"
                 style="height:150px;display: block; margin-left: auto;margin-right: auto">
            <p style="text-align: center; font-size: 20px;color: #fff">Processing please wait...</p>
        </div>
    </div>

@endsection

@section('page-scripts')
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js'></script>
    <script src="/assets/js/toastr/toastr.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#loader').hide();
            toastr.options.positionClass = "toast-top-center";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicate = true;

            var hexaholdem = $('<a style="color:#FF811B" data-toggle="modal" data-target="#moreinfo" >....More</a>');

            var txt = $('.more').text();
            if (txt.length > 200)
                $('.more').text(txt.substring(0, 200)).append(hexaholdem);
        });

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-36251023-1']);
        _gaq.push(['_setDomainName', 'jqueryscript.net']);
        _gaq.push(['_trackPageview']);

        (function () {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();


        $(function () {
            function initToolbarBootstrapBindings() {
                var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'
                    ],
                    fontTarget = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts, function (idx, fontName) {
                    fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({
                    container: 'body'
                });
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });
                $('[data-role=magic-overlay]').each(function () {
                    var overlay = $(this),
                        target = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset = $('#editor').offset();
                    $('#voiceBtn').css('position', 'absolute').offset({
                        top: editorOffset.top,
                        left: editorOffset.left + $('#editor').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg = '';
                if (reason === 'unsupported-file-type') {
                    msg = "Unsupported format " + detail;
                } else {
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings();
            $('#editor').wysiwyg({
                fileUploadError: showErrorAlert
            });
            window.prettyPrint && prettyPrint();
        });


        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-37452180-6', 'github.io');
        ga('send', 'pageview');


        (function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "http://connect.facebook.net/en_GB/all.js#xfbml=1";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));


        !function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (!d.getElementById(id)) {
                js = d.createElement(s);
                js.id = id;
                js.src = "http://platform.twitter.com/widgets.js";
                fjs.parentNode.insertBefore(js, fjs);
            }
        }(document, "script", "twitter-wjs");

        let taskFormData = new FormData();
        let count = 0;
        let count1 = 0;
        let count2 = 0;
        let taskFormData1 = new FormData();
        let taskFormData3 = new FormData();

    </script>
    <script type="text/javascript">
        //******************************copyscape file upload code********************************

        $('#attachment-taskFiles').on('contentChanged', function () {

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

        });

        $(document.body).on('change', '#attachment', function (event) {
//------------------------------check file type-----------------------------------------
            var ext = $('input[name=attachment]').val().split('.').pop().toLowerCase();
            if ($.inArray(ext, ['pdf', 'doc', 'docx']) == -1) {
                toastr.warning('Only .pdf, .doc, .docx type files are allowed', {timeOut: 10000});
                return false;
            }
            var imageName = 'taskFiles' + ++count;
            taskFormData.append(imageName, $('input[name=attachment]')[0].files[0]);
            // taskFormData.append('taskFiles' + ++count, $('input[name=attachments]')[0].files[0]);

            var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

            if (typeof filename === 'undefined') {
                return false;
            }

            var $file = $(this).closest('.form__file');

            $file
                .addClass('form__file--attached')
                .find('.form__file-filename')
                .html(filename);

            $file
                .find('.form__file-input')
                .prop('disabled', true);

            // list of files
            var $files = $('#attachment-files');

            // show files list
            if ($files.find('li').length === 0) {
                $files.removeClass('form__files--hide').addClass('form__files--show');
            }

            // create a new item
            var $item = $('<li/>')
                .addClass('form__files-item')
                .addClass('form__files-item--loading')
                .append($('<span/>').addClass('form__files-item-link').html(filename))
                .append($('<span/>').addClass('form__files-item-remove fileRemoveClass').attr('data-file-remove', true).attr('imageName', imageName).attr('id', count).html('Remove'))
                .append($('<span/>').addClass('form__files-item-progress'))
                .append('<div class="col-md-12 custom_verify' + count + '" style="margin-bottom: 3%;;">' +
                    '<div class="col-md-12" style="text-align: center;cursor: pointer;">' +
                    '<span class="text-info verrifyClass" id="' + imageName + '">Verify With Copyscape</span>' +
                    '<span class="text-info successLink' + imageName + ' hide" id="' + imageName + '"></span></div>' +
                    '</div> ')
                .append($('<input/>').attr({
                    type: 'hidden',
                    name: 'attachments[]',
                    value: '{}'
                }));

            $files.append($item);

            // progress bar
            $item.find('.form__files-item-progress').animate({
                width: '100%'
            }, 2000);

            $('#attachment-files').trigger('contentChanged');

            setTimeout(function () {
                $file.removeClass('form__file--attached');

                $file
                    .find('.form__file-input')
                    .prop('disabled', false);

                var v = $file.find('.form__file-filename').data('placeholder');
                $file.find('.form__file-filename').html(v);
                $file.find('.form__file-input').val('');

                $item
                    .removeClass('form__files-item--loading')
                    .addClass('form__files-item--done');

                $item.find('.form__files-item-link').replaceWith(function () {
                    var text = $.trim($(this).text());
                    return $('<a/>').attr({
                        href: '#',
                        target: '_blank'
                    }).addClass('form__files-item-link').html(text);
                });

                var _itemData = JSON.stringify({
                    id: uuidv4(),
                    name: filename,
                    url_view: '',
                    url_delete: ''
                }, null, '');

                $item
                    .find('input[type=hidden]')
                    .val(_itemData);


                $item.find('[data-file-remove=true]').on('click', function () {
                    var imageName = $(this).attr('imageName');
                    taskFormData.delete(imageName);
                    var $removeItem = $(this).closest('.form__files-item'),
                        itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                    $removeItem.addClass('form__files-item--hide');

                    // hide files list
                    if ($files.find('li').length <= 1) {
                        $files.removeClass('form__files--show').addClass('form__files--hide');
                    }

                    $('#attachment-files').trigger('contentChanged');

                    setTimeout(function () {
                        $removeItem.remove();
                    }, 500);

                });
            }, 2000);
        });
        $(document.body).on('contentChanged', '#attachment-files', function () {

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

        });

        function uuidv4() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0,
                    v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        }

        //******************************allFile upload code********************************

        $('#taskAttachments1').on('change', function (event) {
            var imageName = 'taskFiles' + ++count1;
            taskFormData1.append(imageName, $('input[name=taskAttachments1]')[0].files[0]);
            $('html, body').animate({
                scrollTop: $('body').height()
            }, 800);
            var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

            if (typeof filename === 'undefined') {
                return false;
            }

            var $file = $(this).closest('.form__file');

            $file
                .addClass('form__file--attached')
                .find('.form__file-filename')
                .html(filename);

            $file
                .find('.form__file-input')
                .prop('disabled', true);

            // list of files
            var $files = $('#attachment-taskFiles1');

            // show files list
            if ($files.find('li').length === 0) {
                $files.removeClass('form__files--hide').addClass('form__files--show');
            }
            // create a new item
            var $item = $('<li/>')
                .addClass('form__files-item')
                .addClass('form__files-item--loading')
                .append($('<span/>').addClass('form__files-item-link').html(filename))
                .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                .append($('<span/>').addClass('form__files-item-progress'))
                .append($('<input/>').attr({
                    type: 'hidden',
                    name: 'attachments[]',
                    value: '{}'
                }));

            $files.append($item);

            // progress bar
            $item.find('.form__files-item-progress').animate({
                width: '100%'
            }, 2000);

            $('#attachment-taskFiles1').trigger('contentChanged');

            setTimeout(function () {
                $file.removeClass('form__file--attached');

                $file
                    .find('.form__file-input')
                    .prop('disabled', false);

                var v = $file.find('.form__file-filename').data('placeholder');
                $file.find('.form__file-filename').html(v);
                $file.find('.form__file-input').val('');

                $item
                    .removeClass('form__files-item--loading')
                    .addClass('form__files-item--done');

                $item.find('.form__files-item-link').replaceWith(function () {
                    var text = $.trim($(this).text());
                    return $('<a/>').attr({
                        href: '#',
                        target: '_blank'
                    }).addClass('form__files-item-link').html(text);
                });

                // var _itemData = JSON.stringify({
                //     id: uuidv4(),
                //     name: filename,
                //     url_view: '',
                //     url_delete: ''
                // }, null, '');
                //
                // $item
                //     .find('input[type=hidden]')
                //     .val(_itemData);


                $item.find('[data-file-remove=true]').on('click', function () {

                    var imageName = $(this).attr('imageName');
                    taskFormData1.delete(imageName);


                    var $removeItem = $(this).closest('.form__files-item'),
                        itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                    // ajax request

                    $removeItem.addClass('form__files-item--hide');

                    // hide files list
                    if ($files.find('li').length <= 1) {
                        $files.removeClass('form__files--show').addClass('form__files--hide');
                    }

                    $('#attachment-taskFiles1').trigger('contentChanged');

                    setTimeout(function () {
                        $removeItem.remove();
                    }, 500);

                });
            }, 2000);
        });

        $('#attachment-taskFiles1').on('contentChanged', function () {

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

        });

        //******************************file3 upload code********************************

        $('#taskAttachments3').on('change', function (event) {
            var imageName = 'taskFiles' + ++count2;
            taskFormData3.append(imageName, $('input[name=taskAttachments3]')[0].files[0]);

            var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

            if (typeof filename === 'undefined') {
                return false;
            }

            var $file = $(this).closest('.form__file');

            $file
                .addClass('form__file--attached')
                .find('.form__file-filename')
                .html(filename);

            $file
                .find('.form__file-input')
                .prop('disabled', true);

            // list of files
            var $files = $('#attachment-taskFiles3');

            // show files list
            if ($files.find('li').length === 0) {
                $files.removeClass('form__files--hide').addClass('form__files--show');
            }
            // create a new item
            var $item = $('<li/>')
                .addClass('form__files-item')
                .addClass('form__files-item--loading')
                .append($('<span/>').addClass('form__files-item-link').html(filename))
                .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                .append($('<span/>').addClass('form__files-item-progress'))
                .append($('<input/>').attr({
                    type: 'hidden',
                    name: 'attachments[]',
                    value: '{}'
                }));

            $files.append($item);

            // progress bar
            $item.find('.form__files-item-progress').animate({
                width: '100%'
            }, 2000);

            $('#attachment-taskFiles3').trigger('contentChanged');

            setTimeout(function () {
                $file.removeClass('form__file--attached');

                $file
                    .find('.form__file-input')
                    .prop('disabled', false);

                var v = $file.find('.form__file-filename').data('placeholder');
                $file.find('.form__file-filename').html(v);
                $file.find('.form__file-input').val('');

                $item
                    .removeClass('form__files-item--loading')
                    .addClass('form__files-item--done');

                $item.find('.form__files-item-link').replaceWith(function () {
                    var text = $.trim($(this).text());
                    return $('<a/>').attr({
                        href: '#',
                        target: '_blank'
                    }).addClass('form__files-item-link').html(text);
                });

                // var _itemData = JSON.stringify({
                //     id: uuidv4(),
                //     name: filename,
                //     url_view: '',
                //     url_delete: ''
                // }, null, '');
                //
                // $item
                //     .find('input[type=hidden]')
                //     .val(_itemData);


                $item.find('[data-file-remove=true]').on('click', function () {

                    var imageName = $(this).attr('imageName');
                    taskFormData3.delete(imageName);


                    var $removeItem = $(this).closest('.form__files-item'),
                        itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                    // ajax request

                    $removeItem.addClass('form__files-item--hide');

                    // hide files list
                    if ($files.find('li').length <= 1) {
                        $files.removeClass('form__files--show').addClass('form__files--hide');
                    }

                    $('#attachment-taskFiles3').trigger('contentChanged');

                    setTimeout(function () {
                        $removeItem.remove();
                    }, 500);

                });
            }, 2000);
        });

        $('#attachment-taskFiles3').on('contentChanged', function () {

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

        });


        //=============================== Dharmendra Sharma  codes ============================================

        //--------------------------verify file with copyscape--------------------------------
        $('.submitFile').click(function () {

            var fileId = $(this).attr('id');
            var projectId = $('#projectId').val();
            var issueId = $('#issueId').val();
            taskFormData.append('projectId', projectId);
            taskFormData.append('issueId', issueId);
            taskFormData.append('fileId', fileId);
            // return false;
            $.ajax({
                url: "/staff/issueFileSubmittion",
                method: "post",
                dataType: "json",
                data: taskFormData,
                contentType: false,
                processData: false,
                success: function (response) {
                    $(".form__files-item-remove").click();
                    if (response.msg === 200) {
                        toastr.success('File Uploaded Successfully', {timeOut: 10000});
                    } else if (response.msg === 400) {
                        toastr.warning('Please choose file to upload', {timeOut: 10000});
                    } else if (response.msg === 500) {
                        toastr.warning('Failed to perform action Balance below $2, Please credit your CopyScape Account to continue..', {timeOut: 10000});
                    } else {
                        toastr.error('Failed Try Again...!!', {timeOut: 10000});
                    }
                }
            });
        });
        //-----------------------------------upload any files---------------------------------
        $('.submitFile3').click(function () {
            var projectId = $('#projectId').val();
            var issueId = $('#issueId').val();
            taskFormData3.append('projectId', projectId);
            taskFormData3.append('issueId', issueId);
            // return false;
            $.ajax({
                url: "/staff/issueFileSubmittionAllFiles",
                method: "post",
                dataType: "json",
                data: taskFormData3,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loader').show();
                },
                success: function (response) {
                    $('#attachment-taskFiles3').hide();
                    $('#loader').hide();
                    $(".form__files-item-remove").click();
                    if (response.msg === 200) {
                        toastr.success('File Uploaded Successfully', {timeOut: 10000});
                        location.reload();
                    } else if (response.msg === 400) {
                        toastr.warning('Please choose file to upload', {timeOut: 10000});
                    } else if (response.msg === 500) {
                        toastr.warning('Failed to perform action Balance below $2, Please credit your CopyScape Account to continue..', {timeOut: 10000});
                    } else {
                        toastr.error('Failed Try Again...!!', {timeOut: 10000});
                    }
                }
            });
        });

        //-----------------------------------------------post comment----------------------------------------
        function comment() {
            var comment = $('#editor').html();
            let text = $('#editor');
            var issueId = $('#issueId').val();
            taskFormData1.append('issueId', issueId);
            taskFormData1.append('comment', comment);
            if (text.html() === "") {
                toastr.error("Please write a comment!");
                text.focus();
            } else if (text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === " " || text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                toastr.error("Please type a message to send!");
            }
            else {
                var name = $('#name').val();
                // var date = new Date($.now());
                var date = '{{ time() }}'
                date=getDateAndTime(date);
                $.ajax({
                    url: "/staff/postIssueComment",
                    method: "post",
                    dataType: "json",
                    data: taskFormData1,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        // $('.issueCommentBtn').attr('disabled', 'disabled');
                        $('#editor').html('');
                        $('.spinnerIssueClass').css('display', 'block');
                        $('.issueCommentBtn').css('opacity', '0.4');
                    },
                    success: function (response) {
                        // $('.issueCommentBtn').removeAttr("disabled");
                        $('.spinnerIssueClass').css('display', 'none');
                        $('.issueCommentBtn').css('opacity', '');
                        // $('#attachment-taskFiles1').hide();
                        if (response.msg === 200) {
                            var commentOn = response.data.comment_posted_on;
                            var pic = "{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}";
                            var doc = '';
                            if (response.data.attachment_files) {
                                $.each(response.data.attachment_files, function (i, v) {
                                    doc += `<p><a href='${v}' target="_blank" class="btn btn-info dotDot">` +
                                        '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + ' <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                });
                            }

                            var chat = '<li id="' + response.data.issue_comment_id + '"  class="list-group-item commentClass' + response.data.issue_comment_id + '">\n' +
                                '<div class="row">\n' +
                                '<div class="col-xs-1 col-md-1">\n' +
                                '<img src="' + pic + '"' +
                                'class="img-circle img-responsive" width=65px; alt=""/>\n' +
                                '<p style="color:black;font-size: 12px;">Staff</p>\n' +
                                '</div>\n' +
                                '<div class="col-xs-10 col-md-10">\n' +
                                '<div>\n' +
                                '<span id="del' + response.data.issue_comment_id + '" hidden>' + response.data.issue_comment_id + '</span>\n' +
                                '<div class="mic-info">\n' +
                                'By: <a href="#">' + name + '</a> on ' + date + '' +
                                '</div>\n' +
                                '</div>\n' +
                                '<div class="comment-text" id="cmt' + response.data.issue_comment_id + '">\n' + comment +
                                '</div>\n' +
                                '<span>' + doc + '</span>\n' +
                                '<div class="action">\n' +
                                '<button onclick="confirmation(' + issueId + ',' + commentOn + ',' + response.data.issue_comment_id + ')" type="button" class="btn btn-danger btn-xs"\n' +
                                'title="Delete">\n' +
                                '<i class="fa fa-trash" aria-hidden="true"></i>\n' +
                                '</button>\n' +
                                '<button type="button" class="btn btn-primary btn-xs accordion editIssueBtn" data-id="' + response.data.issue_comment_id + '"  title="Edit">\n' +
                                '<i class="fa fa-pencil" aria-hidden="true"></i>\n' +
                                '</button>\n' +
                                '<div class="panel" style="max-height: 210px;padding:0;display: none;">\n' +
                                '<div class="user-contact-form_field">\n' +
                                '\n' +
                                '<div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">\n' +
                                '<div class="form-group">\n' +
                                '<div class="hero-unit">\n' +
                                '<div id="editor2" class="edit' + response.data.issue_comment_id + ' editor2" contenteditable="true">' + comment + '</div>\n' +
                                '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar1"\n' +
                                'data-target="#editor2" style="width: 100%;">\n' +
                                '\n' +
                                '<div class="btn-group">\n' +
                                '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i\n' +
                                'class="icon-bold"></i></a>\n' +
                                '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i\n' +
                                'class="icon-italic"></i></a>\n' +
                                '\n' +
                                '<a class="btn" data-edit="underline"\n' +
                                'title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>\n' +
                                '</div>\n' +
                                '\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="btn-group">\n' +
                                ' <a class="btn" data-edit="insertunorderedlist" title="" data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                '<a class="btn" data-edit="insertorderedlist" title="" data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                '\n' +
                                '</div>\n' +
                                '</div>\n' +
                                '</div>\n' +
                                '</div>\n' +
                                '</div>\n' +
                                '</div>\n' +
                                '<div class="user-contact-form_buttons">\n' +
                                '<a class="cancel-message accordion">Cancel</a>\n' +
                                '<a class="send-message updateTaskComment" onclick="editComment(' + issueId + ',' + response.data.issue_comment_id + ')">Send</a>\n' +
                                '</div>\n' +
                                '</div>' +

                                '</li>';

                            $('.list-group').append(chat).scrollTop(100000000000000000);
                            $('#totalComment').html($('.list-group-item').length);
                            $('#editor').html('');
                            // location.reload();
                            toastr.success('Action Performed Successfully', {timeOut: 10000});
                            $(".form__files-item-remove").click();
                            // location.reload();
                        } else if (response.msg === 500) {
                            toastr.warning('Failed to perform action Balance below $2, Please credit your CopyScape Account to continue..', {timeOut: 10000});
                        } else {
                            toastr.error('Failed Try Again...!!', {timeOut: 10000});
                        }
                    }
                });
            }
        }

        $(document).ready(function () {
            var issueId = $('#issueId').val();
            $.ajax({
                url: "/staff/getIssueComment",
                method: "post",
                dataType: 'json',
                data: {
                    issueId: issueId
                },
                beforeSend: function () {
                    $('#loaderClass').show();
                },
                success: function (response) {
                    $('#loaderClass').hide();
                    if (response.msg === 200) {
                        var chat = '';
                        $('#totalComment').html(response.count);
                        $.each(response.data, function (key, value) {
                            var pic = value.profile_pic;
                            if (value.role == 'Staff') {

                                var data = '';
                                if (value.attachment_files) {
                                    $.each(value.attachment_files, function (i, v) {
                                        data += `<p><a href='${v}' target="_blank" class="btn btn-info dotDot">` +
                                            '<i class="fa fa-file-o" aria-hidden="true"></i> ' + v.split('/')[5] + ' <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                    });
                                }

                                chat += '<li id="' + value.issue_comment_id + '"  class="list-group-item commentClass' + value.issue_comment_id + '">\n' +

                                    '<div class="row">\n' +
                                    '<div class="col-xs-1 col-md-1">\n' +
                                    '<img src="' + pic + '"' +
                                    'class="img-circle img-responsive" width="65px" alt=""/>\n' +
                                    '<p style="color:black;font-size: 12px;">' + value.role + ' </p>\n' +
                                    '</div>\n' +
                                    '<div class="col-xs-10 col-md-10">\n' +
                                    '<div>\n' +
                                    '<span id="del' + value.issue_comment_id + '" hidden>' + value.issue_comment_id + '</span>\n' +
                                    '<div class="mic-info">\n' +
                                    'By: <a href="#">' + value.first_name + '  ' + value.last_name + '</a> on ' + getDateAndTime(value.comment_posted_on) + '\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '<div class="comment-text" id="cmt' + value.issue_comment_id + '">\n' + value.comments +
                                    '</div>\n' +
                                    '<span>' + data + '</span>\n' +
                                    '<div class="action">\n' +
                                    '<button onclick="confirmation(' + issueId + ',' + value.commentOn + ',' + value.issue_comment_id + ')" type="button" class="btn btn-danger btn-xs"\n' +
                                    'title="Delete">\n' +
                                    '<i class="fa fa-trash" aria-hidden="true"></i>\n' +
                                    '</button>\n' +
                                    '<button type="button" class="btn btn-primary btn-xs accordion editIssueBtn" data-id="' + value.issue_comment_id + '"  title="Edit">\n' +
                                    '<i class="fa fa-pencil" aria-hidden="true"></i>\n' +
                                    '</button>\n' +
                                    '<div class="panel" style="max-height: 210px;padding:0;display: none;">\n' +
                                    '<div class="user-contact-form_field">\n' +
                                    '\n' +
                                    '<div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">\n' +
                                    '<div class="form-group">\n' +
                                    '<div class="hero-unit">\n' +
                                    '<div id="editor2" class="edit' + value.issue_comment_id + ' editor2" contenteditable="true">' + value.comments + '</div>\n' +
                                    '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar1"\n' +
                                    'data-target="#editor2" style="width: 100%;">\n' +
                                    '\n' +
                                    '<div class="btn-group">\n' +
                                    '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i\n' +
                                    'class="icon-bold"></i></a>\n' +
                                    '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i\n' +
                                    'class="icon-italic"></i></a>\n' +
                                    '\n' +
                                    '<a class="btn" data-edit="underline"\n' +
                                    'title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>\n' +
                                    '</div>\n' +
                                    '\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="btn-group">\n' +
                                    ' <a class="btn" data-edit="insertunorderedlist" title="" data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                    '<a class="btn" data-edit="insertorderedlist" title="" data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                    '\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '<div class="user-contact-form_buttons">\n' +
                                    '<a class="cancel-message accordion">Cancel</a>\n' +
                                    '<a class="send-message updateTaskComment" onclick="editComment(' + issueId + ',' + value.issue_comment_id + ')">Send</a>\n' +
                                    '</div>\n' +
                                    '</div>' +
                                    '</li>';
                            } else {

                                var data1 = '';
                                if (value.attachment_files) {
                                    $.each(value.attachment_files, function (i, v) {
                                        data1 += `<span><a href='${v}' target="_blank" class="btn btn-info cut-text dotDot">` +
                                            '<i class="fa fa-file-o" aria-hidden="true"></i> ' + v.split('/')[5] + ' <i class="fa fa-download" aria-hidden="true"></i></a></span>';
                                    });
                                }

                                chat += '<li id="' + value.issue_comment_id + '"  class="list-group-item">\n' +
                                    '<div class="row">\n' +
                                    '<div class="col-xs-1 col-md-1">\n' +
                                    '<img src="' + pic + '"' +
                                    'class="img-circle img-responsive" width="65px" alt=""/>\n' +
                                    '<p style="color:black;font-size: 12px;">' + value.role + ' </p>\n' +
                                    '</div>\n' +
                                    '<div class="col-xs-10 col-md-10">\n' +
                                    '<div>\n' +
                                    '<span id="del' + value.issue_comment_id + '" hidden>' + value.issue_comment_id + '</span>\n' +
                                    '<div class="mic-info">\n' +
                                    'By: <a href="#">' + value.first_name + '  ' + value.last_name + '</a> on ' + getDateAndTime(value.comment_posted_on) + '\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '<div class="comment-text" id="cmt' + value.issue_comment_id + '">\n' + value.comments +
                                    '<span>' + data1 + '</span>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</div>\n' +
                                    '</li>';
                            }
                        });

                        $(document.body).on('click', '.editIssueBtn', function () {
                            $('.editor2').wysiwyg({
                                toolbarSelector: '.editor-toolbar2'
                            });
                        });
                        $('.list-group').append(chat).scrollTop(100000000000000000);
                    } else {
                        $('#totalComment').html(response.count);
                        $('.list-group').append('');
                    }
                }
            });
        });

        function confirmation(issueId, commentOn, rowId) {
            var retVal = confirm("Do you want to continue..!!! \n\nIt will be permanently deleted..?");
            if (retVal == true) {
                var del = $('#del' + rowId).html();
                $.ajax({
                    url: '/staff/deleteIssueComment',
                    method: "post",
                    dataType: 'json',
                    cache: true,
                    data: {
                        issueId: issueId,
                        commentOn: commentOn,
                        rowId: rowId
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            var id = response.data.issue_comment_id;
                            $('#' + id).hide();
                            var count = $('#totalComment').html();
                            var newCount = count - 1;
                            $('#totalComment').html(newCount);
                            // location.reload();
                            toastr.success(response.msg, {timeOut: 10000});
                        } else if (response.status === 198) {
                            toastr.error(response.msg, {timeOut: 10000});
                        } else if (response.status === 400) {
                            toastr.warning(response.msg, {timeOut: 10000});
                        } else if (response.status === 404) {
                            toastr.error(response.msg, {timeOut: 10000});
                        }
                    }
                });

            }
        }

        function editComment(issueId, commentId) {
            // alert(commentId)
            var editComment = $('.edit' + commentId).html();
            var text = $('.edit' + commentId);
            if (text.html() === "") {
                toastr.warning("Please write some comment!");
                text.focus();
            } else if (text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === " " || text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                toastr.error("Please type a message to send!");
            } else {
                $.ajax({
                    url: '/staff/editIssueComment',
                    method: "post",
                    dataType: 'json',
                    cache: true,
                    data: {
                        commentTxt: editComment,
                        commentId: commentId
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#cmt' + commentId).html(editComment);
                            $('.updateTaskComment').parent().parent().removeClass('show').css('display', 'none');
                            toastr.success('Comment edited successfully', {timeOut: 10000});
                        } else {
                            toastr.error(response.msg, {timeOut: 10000});
                        }
                    }
                });
            }
        }

        function getDateAndTime(getDate) {
            let date = new Date(getDate * 1000);
            let month = date.getMonth() + 1;
            let day = date.getDate();
            let hour = date.getHours();
            let min = date.getMinutes();
            let sec = date.getSeconds();

            month = (month < 10 ? "0" : "") + month;
            day = (day < 10 ? "0" : "") + day;
            hour = (hour < 10 ? "0" : "") + hour;
            min = (min < 10 ? "0" : "") + min;
            sec = (sec < 10 ? "0" : "") + sec;

            let str = date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

            return str;
        }

        $(document.body).on('click', '.accordion', function () {
            let obj = $('.list-group');
            // $(this).parents('.action').find('.panel').toggle();
            // $('.list-group').scrollTop(100000000000000000);
            if (obj.find('li.list-group-item').last().attr('class') === $(this).last().parents().eq(3).attr('class')) {
                obj.animate({scrollTop: obj.prop("scrollHeight")}, 500);
            }

            $('.edit' + $(this).attr('data-id')).html($('.commentClass' + $(this).attr('data-id')).find('.comment-text').html());

            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $(this).next().removeClass('show').css('display', 'none');
            } else {
                $('.accordion').removeClass('active');
                $('.panel').removeClass('show').css('display', 'none');
                $(this).addClass('active');
                $(this).next().addClass('show').css('display', 'block');
            }

        });

        $(document.body).on('click', '.verrifyClass', function () {

            var fileId = $(this).attr('id');
            var projectId = $('#projectId').val();
            var issueId = $('#issueId').val();
            taskFormData.append('projectId', projectId);
            taskFormData.append('issueId', issueId);
            taskFormData.append('fileId', fileId);
            $.ajax({
                url: "/staff/issueFileSubmittion",
                method: "post",
                dataType: "json",
                data: taskFormData,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loader').show();
                },
                success: function (response) {
                    $('#loader').hide();
                    if (response.msg === 200) {
                        $('#' + fileId).hide();
                        $('.successLink' + fileId).removeClass('hide').addClass('show');
                        $('.successLink' + fileId).html('').append('<a target="_blank" href=' + response.copyscapeUrl + '  style="color: green">View Copyscape Result</a>');
                    } else if (response.msg === 400) {
                        toastr.warning('Please choose file to upload', {timeOut: 10000});
                    } else if (response.msg === 500) {
                        toastr.warning(response.data, {timeOut: 10000});
                    } else {
                        toastr.error('Failed Try Again...!!', {timeOut: 10000});
                    }
                }
            });
        });

    </script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.fileAttachClass', function () {
                var contents = '<div class="row" style="padding: 0px 15px;"><ul class="form__files col-md-12" id="attachment-files"></ul>' +
                    '</div>';
                $(".siddu").after(contents);
            });
            $(document).on('click', '.fileRemoveClass', function () {
                var id = $(this).attr('id');
                $(".custom_verify" + id).css("display", "none");
            })
        });

        function finalIssueSubmission() {
            $('#finalIssueButton').prop('disabled', true).css('background', 'black');
            var tz = jstz.determine(); // Determines the time zone of the browser client
            var timezone = tz.name();
            var issueDesc='{{$data['issue_desc']}}';
            $.ajax({
                url: '/staff/finalIssueSubmission',
                method: "post",
                dataType: 'json',
                cache: true,
                data: {
                    projectName: '{{$data['project_name']}}',
                    issueList: '{{$data['issue_topic']}}',
                    severity: '{{$data['severity']}}',
                    issueDesc: issueDesc,
                    dueDate: '{{$data['due_date']}}',
                    timezone: timezone,
                    issueId: '{{$data['issue_id']}}'
                },
                success: function (response) {
                    if (response.code === 200) {
                        toastr.success('Issue submitted successfully', {timeOut: 10000});
                        $('#finalIssueButton').prop('disabled', false).css('background', '#55ad69');
                    } else {
                        toastr.success('Failed, Please try again..!!', {timeOut: 10000});
                    }
                }
            });
        }
    </script>
@endsection
