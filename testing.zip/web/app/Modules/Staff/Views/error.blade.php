<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 8/29/2018
 * Time: 2:02 PM
 */
?>

<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
            padding-top: 8%;
        }
        body{
            background-color: white;
        }
    </style>
</head>
<body>
<img src="\uploads\profile_pic\error3.jpg" alt="Page Not Found" style="width:50%;">
</body>
</html>
