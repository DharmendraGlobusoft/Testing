<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/18/2018
 * Time: 3:35 PM
 */
?>


        <!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="apple-touch-icon" href="/apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/staffAssets/css/normalize.css">
    <link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/staffAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/staffAssets/scss/style.css">
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .error {
            color: darkred !important;
        }

        .login-form label {
            text-transform: lowercase !important;
        }
    </style>
</head>
<body class="bg-dark" style="background-image: url(/images/bg2.jpg);">
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a href="index.html">
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form" style="background: #cfcbcb;">
                <form action="/staff/changePassword/{{$code}}" method="post" id="formId">
                    {{csrf_field()}}
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Reset Password</h4>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" class="form-control" name="new_password" id="new_password" placeholder="New Password">
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password">
                    </div>
                    <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30" style="margin: 3% 0;">SUBMIT</button>
                    {{--<div class="register-link m-t-15 text-center">--}}
                        {{--<p>Don't have account ? <a href="/staff/register" style="color:#0e94f6;"> Sign Up Here</a></p>--}}
                    {{--</div>--}}
                </form>
            </div>
        </div>
    </div>
</div>
<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/staffAssets/js/popper.min.js"></script>
<script src="/staffAssets/js/plugins.js"></script>
<script src="/staffAssets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="/staffAssets/js/toastr/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script type="text/javascript">

    $(document).ready(function () {
        $("#formId").validate({
            rules: {
                new_password: {
                    required: true,
                    minlength: 4
                },
                confirm_password: {
                    required: true,
                    equalTo: "#new_password"
                }
            },
            messages: {
                new_password: {
                    required: 'Password is required..!!',
                    minlength: "Minimum length should be 4 characters..!!"
                },
                confirm_password: {
                    required: 'Confirm password is Required..!!',
                    equalTo: "Password do not matched..!!"
                }
            }
        });

    });
</script>
</body>

</html>
