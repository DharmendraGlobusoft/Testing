@extends('Staff::layouts.master')

@section('title')
    <title> Invoice Comment || Cloud Office</title>
@endsection

@section('page-style')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">

    {{--<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">--}}
    <style>
        .widget .card-body {
            padding: 0px;
        }

        .widget .list-group {
            margin-bottom: 0;
        }

        .widget .panel-title {
            display: inline
        }

        .widget .label-info {
            float: right;
            background-color: #5489e4;
            color: #fff;
            padding: 6px 9px;
            border-radius: 50%;
        }

        .widget li.list-group-item {
            border-radius: 0;
            border: 0;
            border-top: 1px solid #efedee;;
        }

        .widget li.list-group-item:hover {
            background-color: rgba(236, 231, 231, 0.1);
        }

        .widget .mic-info {
            color: #666666;
            font-size: 11px;
        }

        .widget .action {
            margin-top: 5px;
        }

        .widget .comment-text {
            font-size: 15px;
            word-break: break-all;
        }

        .widget .btn-block {
            border-top-left-radius: 0px;
            border-top-right-radius: 0px;
        }

        .img-circle {
            border-radius: 50%;
        }

        .btn {
            padding: 5px 10px !important;
        }

        /*    Radio Button CSS*/

        .radio {
            padding-left: 20px;
        }

        .radio label {
            display: inline-block;
            position: relative;
            padding-left: 5px;
        }

        .radio label::before {
            content: "";
            display: inline-block;
            position: absolute;
            width: 17px;
            height: 17px;
            left: 0;
            margin-left: -20px;
            border: 1px solid #cccccc;
            border-radius: 50%;
            background-color: #fff;
            -webkit-transition: border 0.15s ease-in-out;
            -o-transition: border 0.15s ease-in-out;
            transition: border 0.15s ease-in-out;
        }

        .radio label::after {
            display: inline-block;
            position: absolute;
            content: " ";
            width: 11px;
            height: 11px;
            left: 3px;
            top: 3px;
            margin-left: -20px;
            border-radius: 50%;
            background-color: #555555;
            -webkit-transform: scale(0, 0);
            -ms-transform: scale(0, 0);
            -o-transform: scale(0, 0);
            transform: scale(0, 0);
            -webkit-transition: -webkit-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            -moz-transition: -moz-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            -o-transition: -o-transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
            transition: transform 0.1s cubic-bezier(0.8, -0.33, 0.2, 1.33);
        }

        .radio input[type="radio"] {
            opacity: 0;
        }

        .radio input[type="radio"]:focus + label::before {
            outline: thin dotted;
            outline: 5px auto -webkit-focus-ring-color;
            outline-offset: -2px;
        }

        .radio input[type="radio"]:checked + label::after {
            -webkit-transform: scale(1, 1);
            -ms-transform: scale(1, 1);
            -o-transform: scale(1, 1);
            transform: scale(1, 1);
        }

        .radio input[type="radio"]:disabled + label {
            opacity: 0.65;
        }

        .radio input[type="radio"]:disabled + label::before {
            cursor: not-allowed;
        }

        .radio.radio-inline {
            margin-top: 0;
        }

        .radio-primary input[type="radio"] + label::after {
            background-color: #428bca !important;
        }

        .radio-primary input[type="radio"]:checked + label::before {
            border-color: #428bca;
        }

        .radio-primary input[type="radio"]:checked + label::after {
            background-color: #428bca !important;
        }

        /*    Edit Comment*/

        .accordion {
            /*    background-color: #eee;*/
            color: #444;
            cursor: pointer;
            padding: 18px;
            /*    width: 100%;*/
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
            transition: 0.4s;
        }

        #issue_Submition_modal .panel {
            padding: 0 18px;
            margin-top: 1%;
            background-color: rgba(113, 92, 144, 0.1);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }

        .user-contact-form_field {
            margin: 0 0 8px;
            box-sizing: border-box;
        }

        .user-contact-form_field input,
        .user-contact-form_field textarea {
            font-size: 1em;
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #c1c1c1;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .user-contact-form_field textarea {
            width: 100%;
            max-width: 100%;
            min-width: 100%;
            min-height: 115px;
            margin-top: 3%;
        }

        .user-contact-form_field input:focus,
        .user-contact-form_field textarea:focus {
            border-color: #3e5e7e;
            outline: 0 solid transparent;
        }

        .user-contact-form_buttons {
            float: right;
        }

        .user-contact-form_buttons a {
            padding: 5px 10px;
            text-decoration: none;
            box-sizing: border-box;
            cursor: pointer;
        }

        .user-contact-form_buttons a.send-message {
            margin-left: 4px;
            float: left;
            background: #3e5e7e;
            border: 1px solid transparent;
            color: #fff;
        }

        .user-contact-form_buttons a.cancel-message {
            float: left;
            border: 1px solid rgba(0, 0, 0, 0.1);
            color: #fff;
            background-color: #f84d4d;
        }

        #issue_Submition_modal textarea {
            resize: none;
        }

        .form-control {
            border: 1px solid #e7e8e9;
        }

        .card {
            border: 1px solid rgba(84, 83, 83, 0.1);
        }

        .comment_align ul, ol {
            padding-left: 15px;
        }

        .comment_align ul {
            list-style-type: disc;
        }

        .comment_btn {
            /*position: absolute;*/
            /*bottom: 1px;*/
            /*right: 1%;*/
            margin: 10px 0px;
            /*cursor: pointer;*/
            /*padding: 4px 8px !important;*/
            font-size: 13px;
        }
    </style>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Invoice Details</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <a href="/staff/invoice" style="cursor: pointer;"> <img src="\uploads\previous.png"
                                                                                width="35px"></a>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card" style="margin: 0">
                        <div class="card-body" style="background: #fff;">
                            <div class="col-md-12">
                                <input type="text" id="invId" value="{{$invoice['invoice_id']}}" hidden>
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class=" form-control-label">Invoice
                                            Status</label>
                                    </div>
                                    <?php if (isset($invoice['invoice_status'])) {
                                        if ($invoice['invoice_status'] == 1) {
                                            $status = 'Paid';
                                        } else {
                                            $status = 'Un-Paid';
                                        }
                                    } else {
                                        $status = '--';
                                    } ?>

                                    <input name="select" id="Select" value="{{$status}}"
                                           class="form-control form-control col-md-5 invoiceStatus" disabled>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class="form-control-label">Amount</label>
                                    </div>
                                    <input id="ammount" name="name" type="text"
                                           value="{{$invoice['due_amount']}}"
                                           class="form-control col-md-5 ammount" disabled="true">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class="form-control-label">Subject</label>
                                    </div>
                                    <input id="subject" name="name" type="text"
                                           value="{{$invoice['subject']}}"
                                           class="form-control col-md-5 subject" disabled="true">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class="form-control-label">Message</label>
                                    </div>
                                    <textarea id="message" name="name" type="text"
                                              value=""
                                              class="form-control col-md-5 message" rows="5"
                                              disabled="true">{{$invoice['message']}}</textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class="form-control-label">Payment By</label>
                                    </div>
                                    <input id="paymentBy" name="name" type="text"
                                           value="{{$invoice['payment_by']}}"
                                           class="form-control col-md-5 paymentBy" disabled="true">
                                </div>
                                <div class="form-group">
                                    <div class="col col-md-3">
                                        <label for="select" class="form-control-label">Payment Id</label>
                                    </div>
                                    <input id="paymentId" name="name" type="text"
                                           value="{{$paymentId}}"
                                           class="form-control col-md-5 paymentId" disabled="true">
                                </div>
                            </div>

                            <div class="col-md-12" style="padding: 0;">

                                <div class="card widget comment_align">
                                    <div class="card-header">
                                        <i class="fa fa-commenting-o" aria-hidden="true"></i>

                                        <h5 class="panel-title">
                                            Recent Comments</h5>
                                        <span class="mesg" style="text-align:center;">(No Comments)</span>
                                        <span class="label label-info totalComments">78</span>
                                    </div>
                                    <div class="card-body">
                                        <ul class="list-group appendData" style="max-height: 600px;overflow: auto;">


                                        </ul>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-12" style="border: 1px solid #dedddd;padding: 0;">
                                <div class="form-group">
                                    <div class="hero-unit">

                                        <div class="commentInvoiceData" id="editor"></div>
                                        <div class="btn-toolbar" data-role="editor-toolbar"
                                             data-target="#editor" style="width: 100%;">

                                            <div class="btn-group">
                                                <a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i
                                                            class="icon-bold"></i></a>
                                                <a class="btn" data-edit="italic"
                                                   title="Italic (Ctrl/Cmd+I)"><i
                                                            class="icon-italic"></i></a>
                                                <a class="btn" data-edit="underline"
                                                   title="Underline (Ctrl/Cmd+U)"><i
                                                            class="icon-underline"></i></a>
                                            </div>
                                            <div class="btn-group">
                                                <a class="btn" data-edit="insertunorderedlist" title=""
                                                   data-original-title="Bullet list"><i class="icon-list-ul"></i></a>
                                                <a class="btn" data-edit="insertorderedlist" title=""
                                                   data-original-title="Number list"><i class="icon-list-ol"></i></a>
                                            </div>
                                            <label for="attachmentInvoice" class="form__file"
                                                   style="width:5%;box-shadow: none;border: none;color: #000;">
                                                            <span class="form__file-filename" id="filename1"
                                                                  data-placeholder="Attach file"
                                                                  style="display: none;"></span>
                                                <span class="form__file-browse" style="opacity: 1;top: 10px;
right: 15px;"></span>
                                                <input type="file" name="invoiceCommentFile"
                                                       class="form__file-input"
                                                       id="attachmentInvoice">
                                            </label>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12" style="padding: 0;">
                                <ul class="form__files allFiles"
                                    id="attachment-filesInvoice"></ul>
                            </div>
                            <div class="col-md-12">
                                <i class="fa fa-spinner fa-spin spinnerInvoiceClass" style="position: absolute;
right: 4.5%;
top: 45%;color: #212121;display: none"></i>

                                <button class="btn btn-info comment_btn invoiceCommentbtn pull-right">Comment
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- .animated -->
    </div>

    <div class="modal fade" id="confirmInvoiceCommentModal" style="z-index:9999;">
        <div class="modal-dialog">
            <div class="modal-content" style="border:5px solid #222251;">
                <div class="modal-header" style="background-color:#222251">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-warning"
                                                                                       style="font-size:40px;color:yellow;text-align: center"></i>
                    </h4>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="col-lg-12" style="text-align: center;">
                        <p> Are You Sure Want to Delete This Comment? </p>
                    </div>
                    <div class="col-lg-12" style="text-align: center;margin-top:6%;">
                        <button class="btn btn-success confirmInvoiceCmntBtn" style="padding: 8px 25px;">OK</button>
                        <button class="btn btn-danger" data-dismiss="modal">cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('page-scripts')
    <script src="/assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="/assets/js/lib/chart-js/chartjs-init.js"></script>
    <script>
        $(function () {
            function initToolbarBootstrapBindings() {
                var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
                        'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
                        'Times New Roman', 'Verdana'],
                    fontTarget = $('[title=Font]').siblings('.dropdown-menu');
                $.each(fonts, function (idx, fontName) {
                    fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
                });
                $('a[title]').tooltip({container: 'body'});
                $('.dropdown-menu input').click(function () {
                    return false;
                })
                    .change(function () {
                        $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
                    })
                    .keydown('esc', function () {
                        this.value = '';
                        $(this).change();
                    });

                $('[data-role=magic-overlay]').each(function () {
                    var overlay = $(this), target = $(overlay.data('target'));
                    overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
                });
                if ("onwebkitspeechchange" in document.createElement("input")) {
                    var editorOffset = $('#editor').offset();
                    $('#voiceBtn').css('position', 'absolute').offset({
                        top: editorOffset.top,
                        left: editorOffset.left + $('#editor').innerWidth() - 35
                    });
                } else {
                    $('#voiceBtn').hide();
                }
            };

            function showErrorAlert(reason, detail) {
                var msg = '';
                if (reason === 'unsupported-file-type') {
                    msg = "Unsupported format " + detail;
                }
                else {
                }
                $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
                    '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
            };
            initToolbarBootstrapBindings();
            $('#editor').wysiwyg({fileUploadError: showErrorAlert});
            window.prettyPrint && prettyPrint();
        });
    </script>
    {{--<!-- Dharmendra Codes... -->==========================================================================--}}
    <script src="/assets/js/toastr/toastr.min.js"></script>
    <script>
        $(document).ready(function () {
            toastr.options.positionClass = "toast-top-center";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicates = true;
        });
    </script>

    <script>
        $(document).ready(function () {

            $(document.body).on('click', '.editInvoiceComment', function () {
                $('.editor2').wysiwyg({
                    toolbarSelector: '.editor-toolbar2'
                });
            });

            // $('.appendData').html('').append(data).scrollTop(100000000000000000);

            let commentInvoiceData = new FormData();
            let count = 0;

            $('#attachmentInvoice').on('change', function (event) {
                var imageName = 'commentFiles' + ++count;
                commentInvoiceData.append(imageName, $('input[name=invoiceCommentFile]')[0].files[0]);
                $('html, body').animate({
                    scrollTop: $('body').height()
                }, 800);

                var filename = $($(this).val().match(/([^\/\\]+)$/)).get(1);

                // file not choosed
                if (typeof filename === 'undefined') {
                    return false;
                }


                var $file = $(this).closest('.form__file');
                $file
                    .addClass('form__file--attached')
                    .find('.form__file-filename')
                    .html(filename);

                $file
                    .find('.form__file-input')
                    .prop('disabled', true);

                // list of files
                var $files = $('#attachment-filesInvoice');

                // show files list
                if ($files.find('li').length === 0) {
                    $files.removeClass('form__files--hide').addClass('form__files--show');
                }

                // create a new item
                var $item = $('<li/>')
                    .addClass('form__files-item')
                    .addClass('form__files-item--loading')
                    .append($('<span/>').addClass('form__files-item-link').html(filename))
                    .append($('<span/>').addClass('form__files-item-remove').attr('data-file-remove', true).attr('imageName', imageName).html('Remove'))
                    .append($('<span/>').addClass('form__files-item-progress'))
                    .append($('<input/>').attr({
                        type: 'hidden',
                        name: 'attachments[]',
                        value: '{}'
                    }));

                $files.append($item);

                // progress bar
                $item.find('.form__files-item-progress').animate({
                    width: '100%'
                }, 2000);

                $('#attachment-filesInvoice').trigger('contentChanged');

                setTimeout(function () {
                    $file.removeClass('form__file--attached');

                    $file
                        .find('.form__file-input')
                        .prop('disabled', false);

                    var v = $file.find('.form__file-filename').data('placeholder');
                    $file.find('.form__file-filename').html(v);
                    $file.find('.form__file-input').val('');

                    $item
                        .removeClass('form__files-item--loading')
                        .addClass('form__files-item--done');

                    $item.find('.form__files-item-link').replaceWith(function () {
                        var text = $.trim($(this).text());
                        return $('<a/>').attr({
                            href: '#',
                            target: '_blank'
                        }).addClass('form__files-item-link').html(text);
                    });

                    var _itemData = JSON.stringify({
                        id: uuidv4(),
                        // file: textFile,
                        name: filename,
                        url_view: '',
                        url_delete: ''
                    }, null, '');

                    $item
                        .find('input[type=hidden]')
                        .val(_itemData);


                    $item.find('[data-file-remove=true]').on('click', function () {
                        var imageName = $(this).attr('imageName');
                        commentInvoiceData.delete(imageName);
                        var $removeItem = $(this).closest('.form__files-item'),
                            itemData = JSON.parse($removeItem.find('input[type=hidden]').attr('value'));

                        // ajax request

                        $removeItem.addClass('form__files-item--hide');

                        // hide files list
                        if ($files.find('li').length <= 1) {
                            $files.removeClass('form__files--show').addClass('form__files--hide');
                        }

                        $('#attachment-filestask').trigger('contentChanged');

                        setTimeout(function () {
                            $removeItem.remove();
                        }, 500);

                    });
                }, 2000);
            });
            $('#attachment-filesInvoice').on('contentChanged', function () {

                // $(this).each(function() {
                //   if ($(this).length <= 1) {
                //     $(this).removeClass('form__files--show').addClass('form__files--hide');
                //   }
                // });
            });

            function uuidv4() {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    var r = Math.random() * 16 | 0,
                        v = c == 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            }

            $(document.body).on('click', '.invoiceCommentbtn', function () {
                let text = $('.commentInvoiceData');
                if (text.html() === "") {
                    toastr.error("Plesea write a comment!");
                    text.focus();
                } else if (text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === " " || text.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                    toastr.error("Please type a message to send!");
                } else {
                    let comment = text.html();
                    if ($(".allFiles > li").length > 0) {
                        commentInvoiceData.append('comment', comment);
                        commentInvoiceData.append('invoiceId', $('#invId').val());
                        commentInvoiceData.append('chooseMethod', 'insertInvoiceComment');
                        ajaxHandletData(commentInvoiceData, comment, text);
                    } else {
                        let formDataInvoice = new FormData();
                        formDataInvoice.append('comment', comment);
                        formDataInvoice.append('invoiceId', $('#invId').val());
                        formDataInvoice.append('chooseMethod', 'insertInvoiceComment');
                        ajaxHandletData(formDataInvoice, comment, text);
                    }
                }
            });

            function ajaxHandletData(formData, comment, text) {
                $.ajax({
                    url: "/staff/insertInvoiceComment",
                    type: "post",
                    dataType: "json",
                    data: formData,
                    processData: false,
                    contentType: false,
                    beforeSend: function () {
                        $('.commentInvoiceData').html('');
                        $('.spinnerInvoiceClass').css('display', 'block');
                        $('.invoiceCommentbtn').css('opacity', '0.4');
                    },
                    success: function (response) {
                        $('.spinnerInvoiceClass').css('display', 'none');
                        $('.invoiceCommentbtn').css('opacity', '');
                        // $('#attachment-filesInvoice').hide();
                        if (response.status === 200) {
                            $.each(response.file, function (i, v) {
                                commentInvoiceData.delete('commentFiles' + (i + 1));
                                count = 0;
                            });
                            let data = '';
                            let profilePic = '{{Session::get('staff_detail')['profile_pic']}}';
                            data = '<li class="list-group-item commentClass' + response.id + '"><div class="row">' +
                                '<div class="col-xs-1 col-md-1"><img src="' + profilePic + '" class="img-circle img-responsive" width="65px" alt=""/>' +
                                '<span style="color:black;font-size: 12px;margin-left: 4px;">Staff</span></div>' +
                                '<div class="col-xs-10 col-md-10">' +
                                '<div><div class="mic-info">By: <a href="#">Staff</a> on ' + getDateAndTime(response.data) + '</div></div>' +
                                '<div class="comment-text" style="">' + comment + '</div>';
                            $.each(response.file, function (i, v) {
                                data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                    '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + '   <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                            });// this is when user comment
                            data += '<div class="action">' +
                                '<button type="button" class="btn btn-danger btn-xs deleteInvoiceComment" data-toggle="modal" data-target="#confirmInvoiceCommentModal" data-id="' + response.id + '" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
                                '<button type="button"class="btn btn-info btn-xs accordion editInvoiceComment" data-id="' + response.id + '" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
                                '<div class="panel" style="max-height: 210px;display: none;">' +
                                '<div class="user-contact-form_field"><div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">' +
                                '<div class="form-group"><div class="hero-unit">' +
                                '<div id="editor2" contenteditable="true" class="commentTextarea' + response.id + ' editor2">' + comment + '</div>' +
                                '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar1" data-target="#editor2" style="width: 100%;">' +
                                '<div class="btn-group">' +
                                '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="icon-bold"></i></a>' +
                                '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="icon-italic"></i></a>' +
                                '<a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>' +
                                '</div>' +
                                '<div class="btn-group">' +
                                '<a class="btn" data-edit="insertunorderedlist" title=""\n' +
                                'data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                '<a class="btn" data-edit="insertorderedlist" title=""\n' +
                                'data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                '</div>' +
                                '</div></div></div></div></div>' +
                                '<div class="user-contact-form_buttons"><a class="cancel-message accordion cancelInvoiceBtn">Cancel</a>' +
                                '<a class="send-message updateInvoiceComment" data-id=' + response.id + '>Send</a></div></div>' +
                                '</div></div>' +
                                '</div></li>';
                            $('.appendData').append(data).scrollTop(100000000000000000);
                            $('.totalComments').text($(".appendData > li").length);
                            text.html("");
                            $(".allFiles").empty('');
                            $('.mesg').hide();
                        }
                    }
                });
            }

            $(document.body).on('click', '.deleteInvoiceComment', function () {
                $('.confirmInvoiceCmntBtn').attr('data-id', $(this).attr('data-id'));
            });

            $(document.body).on('click', '.confirmInvoiceCmntBtn', function () {
                let id = $(this).attr('data-id');
                $.ajax({
                    url: "/staff/deleteInvoiceData",
                    type: "post",
                    dataType: "json",
                    data: {
                        chooseMethod: 'deleteInvoiceComment',
                        invoiceCommentId: id
                    },
                    success: function (response) {
                        if (response.status === 200) {
                            $('#confirmInvoiceCommentModal').modal('hide');
                            $('.commentClass' + id).remove();
                            $('.totalComments').text($(".appendData > li").length);
                            toastr.success(response.message, {timeOut: 3000});
                        }
                    }
                });
            });

            $(document.body).on('click', '.updateInvoiceComment', function (e) {
                e.preventDefault();
                let id = $(this).attr('data-id');
                let comment = $('.commentTextarea' + id);
                if (comment.html() === "") {
                    toastr.error('Please Type a message to send!');
                } else if (comment.html().replace(/(?:&nbsp;|<br>|<div>|<\/div>)/g, '').trim() === "") {
                    toastr.error("Please type a message to send!");
                } else {
                    let commentData = comment.html();
                    $.ajax({
                        url: "/staff/updateInvoiceComment",
                        type: "post",
                        dataType: "json",
                        data: {
                            invoiceCommentId: $(this).attr('data-id'),
                            comment: commentData
                        },
                        success: function (response) {
                            if (response.status === 200) {
                                let data = '<div class="comment-text">' + commentData + '</div>';
                                $('.commentClass' + id).find('.comment-text').html('').append(data);
                                $('.updateInvoiceComment').parent().parent().removeClass('show').css('display', 'none');
                                toastr.success(response.message, {timeOut: 3000});
                            } else {
                                toastr.error(response.message, {timeOut: 3000});
                            }
                        }
                    });
                }
            });

            $(document.body).on('click', '.accordion', function () {
                let obj = $('.appendData');
                // $(this).parents('.action').find('.panel').toggle();
                // $('.appendData').scrollTop(100000000000000000);
                if (obj.find('li.list-group-item').last().attr('class') === $(this).last().parents().eq(3).attr('class')) {
                    obj.animate({scrollTop: obj.prop("scrollHeight")}, 500);
                }
                $('.commentTextarea' + $(this).attr('data-id')).html($('.commentClass' + $(this).attr('data-id')).find('.comment-text').html());
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active');
                    $(this).next().removeClass('show').css('display', 'none');
                } else {
                    $('.accordion').removeClass('active');
                    $('.panel').removeClass('show').css('display', 'none');
                    $(this).addClass('active');
                    $(this).next().addClass('show').css('display', 'block');
                }
            });

            function getDateAndTime(getDate) {
                let date = new Date(getDate * 1000);
                let month = date.getMonth() + 1;
                let day = date.getDate();
                let hour = date.getHours();
                let min = date.getMinutes();
                let sec = date.getSeconds();

                month = (month < 10 ? "0" : "") + month;
                day = (day < 10 ? "0" : "") + day;
                hour = (hour < 10 ? "0" : "") + hour;
                min = (min < 10 ? "0" : "") + min;
                sec = (sec < 10 ? "0" : "") + sec;

                let str = date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

                return str;
            }

        // function textAreaAdjust(o) {
        //     o.style.height = "1px";
        //     o.style.height = (25+o.scrollHeight)+"px";
        // }
        {{--</script>--}}
        {{--<script>--}}
        //     $(document).ready(function () {
        var invoiceId = $('#invId').val();
        $.ajax({
            url: "/staff/getInvoiceComment",
            method: "post",
            dataType: 'json',
            cache: true,
            data: {
                invoiceId: invoiceId
            },
            beforeSend: function () {
                // $('#loaderClass').show();
            },
            success: function (response) {
                // $('#loaderClass').hide();
                if (response.msg === 200) {
                    var data = '';
                    var commentData = response.data;
                    $('.totalComments').text(response.data.length);
                    if (commentData.length > 0) {
                        $('.mesg').hide();
                        $.each(commentData, function (i, val) {
                            if (val.commentBy.indexOf('Staff') !== -1) {
                                data += '<li class="list-group-item commentClass' + val.invoice_comment_id + '"><div class="row">' +
                                    '<div class="col-xs-1 col-md-1"><img src="' + val.profilePic + '" class="img-circle img-responsive" width="65px" alt=""/>' +
                                    '<span style="color:black;font-size: 12px;margin-left: 4px;">' + val.commentBy + '</span></div>' +
                                    '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                    'By: <a href="#">' + val.commentBy + '</a> on ' + getDateAndTime(val.commentPostedOn) + '</div></div>' +
                                    '<div class="comment-text" style="">' + val.comment + '</div>';
                                if (val.attachment_files) {
                                    $.each(val.attachment_files, function (i, v) {
                                        data += `<p><a href='${v}' target="_blank" class="btn btn-info">` +
                                            '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[5] + '   <i class="fa fa-download" aria-hidden="true"></i></a></p>';
                                    });// this is when user reload
                                }
                                data += '<div class="action">' +
                                    '<button type="button" class="btn btn-danger btn-xs deleteInvoiceComment" data-toggle="modal" data-target="#confirmInvoiceCommentModal" data-id="' + val.invoice_comment_id + '" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
                                    '<button type="button" class="btn btn-info btn-xs accordion editInvoiceComment" data-id="' + val.invoice_comment_id + '" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
                                    '<div class="panel" style="max-height: 210px;display: none;">' +
                                    '<div class="user-contact-form_field"><div class="col-md-12" style="border: 1px solid #e6e6e6;padding: 0;margin-bottom: 8px;">' +
                                    '<div class="form-group"><div class="hero-unit">' +
                                    '<div id="editor2" contenteditable="true" class="commentTextarea' + val.invoice_comment_id + ' editor2">' + val.comment + '</div>' +
                                    '<div class="btn-toolbar editor-toolbar2" id="editor-toolbar1" data-target="#editor2" style="width: 100%;">' +
                                    '<div class="btn-group">' +
                                    '<a class="btn" data-edit="bold" title="Bold (Ctrl/Cmd+B)"><i class="icon-bold"></i></a>' +
                                    '<a class="btn" data-edit="italic" title="Italic (Ctrl/Cmd+I)"><i class="icon-italic"></i></a>' +
                                    '<a class="btn" data-edit="underline" title="Underline (Ctrl/Cmd+U)"><i class="icon-underline"></i></a>' +
                                    '</div>' +
                                    '<div class="btn-group">' +
                                    '<a class="btn" data-edit="insertunorderedlist" title=""\n' +
                                    'data-original-title="Bullet list"><i class="icon-list-ul"></i></a>\n' +
                                    '<a class="btn" data-edit="insertorderedlist" title=""\n' +
                                    'data-original-title="Number list"><i class="icon-list-ol"></i></a>\n' +
                                    '</div>' +
                                    '</div></div></div></div></div>' +
                                    '<div class="user-contact-form_buttons"><a class="cancel-message accordion cancelInvoiceBtn">Cancel</a>' +
                                    '<a class="send-message updateInvoiceComment" data-id=' + val.invoice_comment_id + '>Send</a></div></div>' +
                                    '</div></div>' +
                                    '</div></li>';
                            } else {
                                data += '<li class="list-group-item commentClass' + val.invoice_comment_id + '"><div class="row">' +
                                    '<div class="col-xs-1 col-md-1"><img src="' + val.profilePic + '" class="img-circle img-responsive" alt=""/>' +
                                    '<span style="color:black;font-size: 12px;margin-left: 4px;">' + val.commentBy + '</span></div>' +
                                    '<div class="col-xs-10 col-md-10"><div><div class="mic-info">' +
                                    'By: <a href="#">' + val.commentBy + '</a> on ' + getDateAndTime(val.commentPostedOn) + '</div></div>' +
                                    '<div class="comment-text" style="">' + val.comment + '</div>';
                                if (val.attachment_files) {
                                    $.each(val.attachment_files, function (i, v) {
                                        data += `<a href='${v}' target="_blank" class="btn btn-info">` +
                                            '<i class="fa fa-file-o" aria-hidden="true"></i>  ' + v.split('/')[6] + '   <i class="fa fa-download" aria-hidden="true"></i></a>';
                                    });// when admin post comment
                                }
                                data += '</div></div></li>';
                            }
                        });
                        $(document.body).on('click', '.editInvoiceComment', function () {
                            $('.editor2').wysiwyg({
                                toolbarSelector: '.editor-toolbar2'
                            });
                        });
                        $('.appendData').html('').append(data).scrollTop(100000000000000000);
                    } else {
                        $('.mesg').show();
                    }

                } else {
                    $('.totalComments').html(response.count);
                    $('.list-group').append('');
                }
            }
        });
        });


    </script>
@endsection