<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/14/2018
 * Time: 1:26 PM
 */
?>

        <!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="/apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/staffAssets/css/normalize.css">
    <link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/staffAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/staffAssets/scss/style.css">
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
        .error {
            color: red !important;
        }


    </style>
</head>
{{--<h1 style="color: green;text-align: center">{{\Illuminate\Support\Facades\Session::has('msg')?\Illuminate\Support\Facades\Session::get('msg'):''}}</h1>--}}
<body class="bg-dark" style="background-image: url(/images/bg2.jpg);">
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a>
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form">
                <form action="/staff/register" method="post" id="formId" onsubmit="return checkData()">
                    {{--<form id="formId" >--}}
                    {{csrf_field()}}
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Sign Up</h4>
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" id="first_name" onblur="verifyName()" class="form-control"
                               {{--<input type="text" name="first_name" id="first_name" class="form-control"--}}
                               placeholder="First name">
                        <span id="msg"></span>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" id="last_name" onblur="verifyLastName()"
                               class="form-control"
                               {{--<input type="text" name="last_name" id="last_name" class="form-control"--}}
                               placeholder="Last name">
                        <span id="last_msg"></span>
                    </div>
                    <div class="form-group">
                        <label>User Name</label>
                        <input type="text" id="username" onblur="verifyUserName()" name="username" class="form-control"
                               {{--<input type="text" id="username" name="username" class="form-control"--}}
                               placeholder="User Name">
                        <span id="message"></span>
                    </div>
                    <!--                    --><?php //dd($email);  ?>
                    <div class="form-group">
                        <label>Email address</label>

                        <input type="email" name="email" value="{{isset($email)?  $email:old('email')}}" id="email"
                               disabled="disabled" class="form-control"
                               {{--<input type="email" name="email" id="email"  class="form-control"--}}
                               {{--<input type="email" name="email" id="email" onblur="verifyEmail()" class="form-control"--}}
                               placeholder="Email">
                        <span id="msgg"></span>
                    </div>
                    <input type="email1" name="email1" hidden value="{{isset($email)?  $email:old('email')}}">
                    <input hidden name="code" value="{{isset($code)?  $code:old('code')}}">
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" onblur="passwordField()" id="password" class="form-control"
                               placeholder="Password">
                        <span id="pass"></span>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" name="confirmPassword" onblur="confirmPasswordField()" id="confirmPassword" class="form-control"
                               placeholder="Confirm password">
                        <span id="confirmPass"></span>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" onblur="checkBoxVal()" id="checkbox" name="checkbox"> Agree the terms and policy
                        </label>
                        <span id="chek"></span>
                    </div>
                    <button type="submit" id="signUpform" class="btn btn-primary btn-flat m-b-30 m-t-30 "
                            style="margin: 3% 0;">
                        {{--<button id="signUpform" class="btn btn-primary btn-flat m-b-30 m-t-30 "--}}
                        {{--style="margin: 3% 0;">--}}
                        Register
                    </button>
                    {{--<div class="register-link m-t-15 text-center">--}}
                    {{--<p>Already have account ? <a href="/staff/login"> Sign in</a></p>--}}
                    {{--</div>--}}
                </form>
            </div>
        </div>
    </div>
</div>


<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/staffAssets/js/popper.min.js"></script>
<script src="/staffAssets/js/plugins.js"></script>
<script src="/staffAssets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script src="/staffAssets/js/toastr/toastr.min.js"></script>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var check = document.getElementById("checkbox").checked;
    $(document).ready(function () {
        $('#formId')[0].reset();
        toastr.options.positionClass = "toast-top-center";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicate = true
    });


    //*********************For showing Success Message using Toastr*******************************


    @if(\Illuminate\Support\Facades\Session::has('msg'))
    toastr.success('{{\Illuminate\Support\Facades\Session::get('msg')}}', {timeOut: 10000});
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msggg'))
    toastr.warning('{{\Illuminate\Support\Facades\Session::get('msggg')}}', {timeOut: 10000});
    @endif


    function passwordField() {
        document.getElementById('pass').innerHTML = '';
        var password = $('#password').val().trim();
        document.getElementById('pass').innerHTML = '';
        if (password.length < 1) {
            document.getElementById('pass').innerHTML = 'Password is required';
            $('#pass').css('color', 'red');
            return false;
        } else if (password.length <= 3) {
            document.getElementById('pass').innerHTML = 'Minimum four character required';
            $('#pass').css('color', 'red');
            return false;
        } else {
            document.getElementById('pass').innerHTML = '';
        }
    }
    // ------------------Confirm Password---------------------

    function confirmPasswordField() {
        document.getElementById('confirmPass').innerHTML = '';
        var password = $('#confirmPassword').val().trim();
        document.getElementById('confirmPass').innerHTML = '';
        if (password.length < 1) {
            document.getElementById('confirmPass').innerHTML = 'Confirm password is required';
            $('#confirmPass').css('color', 'red');
            return false;
        } else if (password.length <= 3) {
            document.getElementById('confirmPass').innerHTML = 'Minimum four character required';
            $('#confirmPass').css('color', 'red');
            return false;
        } else {
            document.getElementById('confirmPass').innerHTML = '';
        }
    }


    function checkBoxVal() {
        document.getElementById('chek').innerHTML = '';
        if ($("#checkbox").is(':checked')) {
            document.getElementById('chek').innerHTML = '';
        } else {
            document.getElementById('chek').innerHTML = 'Please check checkbox';
            $('#chek').css('color', 'red');
            return false
        }
    }


    //******************************************validate First name**********************************************

    function verifyName() {
        var inputVal = $('#first_name').val().trim();
        document.getElementById('msg').innerHTML = '';
        if (inputVal.length < 1) {
            document.getElementById('msg').innerHTML = 'First name is required';
            $('#msg').css('color', 'red');
        } else {
            var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
            if (!characterReg.test(inputVal)) {
                document.getElementById('msg').innerHTML = 'Only alphabets are allowed';
                $('#msg').css('color', 'red');
                var first_name = inputVal.replace(/[^A-Za-z']/g, "");
                $('#first_name').val(first_name);
            } else {
                if (inputVal.length <1) {
                    document.getElementById('msg').innerHTML = 'First name is required';
                    $('#msg').css('color', 'red');
                } else {
                    var space=$('#first_name').val().indexOf(' ') >= 0;
                    if(space){
                        document.getElementById('msg').innerHTML = 'Blank spaces are not allowed';
                        $('#msg').css('color', 'red');
                        return false;
                    }
                    document.getElementById('msg').innerHTML = '';
                }
            }

        }

    }

    //******************************************validate Last name**********************************************

    function verifyLastName() {
        var inputVal = $('#last_name').val().trim();
        document.getElementById('last_msg').innerHTML = '';
        if (inputVal.length < 1) {
            document.getElementById('last_msg').innerHTML = 'Last name is required';
            $('#last_msg').css('color', 'red');
        } else {
            var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
            if (!characterReg.test(inputVal)) {
                document.getElementById('last_msg').innerHTML = 'Only alphabets are allowed';
                $('#last_msg').css('color', 'red');
                var last_name = inputVal.replace(/[^A-Za-z']/g, "");
                $('#last_name').val(last_name);
            } else {
                if (inputVal.length <1) {
                    document.getElementById('last_msg').innerHTML = 'Last name is required';
                    $('#last_msg').css('color', 'red');
                } else {
                    var space=$('#last_name').val().indexOf(' ') >= 0;
                    if(space){
                        document.getElementById('last_msg').innerHTML = 'Blank spaces are not allowed';
                        $('#last_msg').css('color', 'red');
                        return false;
                    }
                    document.getElementById('last_msg').innerHTML = '';
                }
            }

        }

    }

    //******************************************Verify User Name througth ajax*****************************************

    function verifyUserName() {
        var inputVal = $('#username').val().trim();
        document.getElementById('message').innerHTML = '';
        if (inputVal.length < 1) {
            document.getElementById('message').innerHTML = 'User name is required';
            $('#message').css('color', 'red');
        } else {
            if (inputVal.length < 3) {
                document.getElementById('message').innerHTML = 'Minimum four character required';
                $('#message').css('color', 'red');
                return false;
            }
            // var space=inputVal.test(/\s/gi, "X");
            var space=$('#username').val().indexOf(' ') >= 0;
            if(space){
                document.getElementById('message').innerHTML = 'Blank spaces are not allowed';
                $('#message').css('color', 'red');
                return false;
            }


            document.getElementById('message').innerHTML = '';
            $.ajax({
                url: "/staff/ajaxVerify",
                method: "post",
                data: {
                    'username': $('#username').val()
                },
                dataType: "json",
                success: function (verify) {
                    if (verify.msg == 1) {
                        // $('#message').text('This user name already exists');
                        document.getElementById('message').innerHTML = 'This user name already taken';
                        $('#message').css('color', 'red');
                        $('#username').val("");

                    } else {
                        if (inputVal.length > 3) {
                            document.getElementById('message').innerHTML = ' Valid user name';
                            $('#message').css('color', 'green');
                        } else {
                            if (inputVal.length <= 3) {
                                document.getElementById('message').innerHTML = 'Minimum four character required';
                                $('#message').css('color', 'red');
                                return false;
                            }
                            document.getElementById('message').innerHTML = '';
                        }
                    }
                }
            });

        }
    }


    function checkData() {
        //******************************************validate First name**********************************************


        var inputVal = $('#first_name').val().trim();
        document.getElementById('msg').innerHTML = '';
        if (inputVal.length < 1) {
            document.getElementById('msg').innerHTML = 'First name is required';
            $('#msg').css('color', 'red');
            return false;
        } else {
            var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
            if (!characterReg.test(inputVal)) {
                document.getElementById('msg').innerHTML = 'Only alphabets are allowed';
                // $('#first_name-error').hide();
                $('#msg').css('color', 'red');
                var first_name = inputVal.replace(/[^A-Za-z']/g, "");
                $('#first_name').val(first_name);
                return false;
            }
            else {
                if (inputVal.length <1) {
                    document.getElementById('msg').innerHTML = 'First name is required';
                    $('#msg').css('color', 'red');
                    return false;
                }
                var space=$('#first_name').val().indexOf(' ') >= 0;
                if(space){
                    document.getElementById('msg').innerHTML = 'Blank spaces are not allowed';
                    $('#msg').css('color', 'red');
                    return false;
                }
                document.getElementById('msg').innerHTML = '';
            }
        }

        //******************************************validate Last name**********************************************

        var inputVal = $('#last_name').val().trim();
        document.getElementById('last_msg').innerHTML = '';
        if (inputVal.length < 1) {
            document.getElementById('last_msg').innerHTML = 'Last name is required';
            $('#last_msg').css('color', 'red');
            return false;
        } else {
            var characterReg = /^\s*[a-zA-Z,\s]+\s*$/;
            if (!characterReg.test(inputVal)) {
                document.getElementById('last_msg').innerHTML = 'Only alphabets are allowed';
                $('#last_msg').css('color', 'red');
                var last_name = inputVal.replace(/[^A-Za-z']/g, "");
                $('#last_name').val(last_name);
                return false;
            }
            else {
                if (inputVal.length <1) {
                    document.getElementById('last_msg').innerHTML = 'Last name is required';
                    $('#last_msg').css('color', 'red');
                    return false;
                }
                var space=$('#last_name').val().indexOf(' ') >= 0;
                if(space){
                    document.getElementById('last_msg').innerHTML = 'Blank spaces are not allowed';
                    $('#last_msg').css('color', 'red');
                    return false;
                }
                document.getElementById('last_msg').innerHTML = '';
            }
        }

        //******************************************Verify User Name througth ajax*****************************************

        var inputVal = $('#username').val().trim();
        if (inputVal.length < 1) {
            document.getElementById('message').innerHTML = 'User name is required';
            $('#message').css('color', 'red');
            return false;
        } else {
            if (inputVal.length <= 3) {
                document.getElementById('message').innerHTML = 'Minimum four character required';
                $('#message').css('color', 'red');
                return false;
            }
            var space=$('#username').val().indexOf(' ') >= 0;
            if(space){
                document.getElementById('message').innerHTML = 'Blank spaces are not allowed';
                $('#message').css('color', 'red');
                return false;
            }

            document.getElementById('message').innerHTML = '';
            $.ajax({
                url: "/staff/ajaxVerify",
                method: "post",
                data: {
                    'username': $('#username').val()
                },
                dataType: "json",
                success: function (verify) {
                    if (verify.msg == 1) {
                        // $('#message').text('This user name already exists');
                        document.getElementById('message').innerHTML = 'This user name already taken';
                        $('#message').css('color', 'red');
                        // $('#username').val("");
                        return false;

                    } else {
                        if (inputVal.length > 3) {
                            document.getElementById('message').innerHTML = ' Valid user name';
                            $('#message').css('color', 'green');
                        } else {
                            document.getElementById('message').innerHTML = '';
                        }
                    }
                }
            });

        }


        //******************************Verify email througth ajax***************************************
        // var email = $('#email').val().trim();
        // if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
        //     document.getElementById('msgg').innerHTML = 'Enter valid email';
        //     $('#msgg').css('color', 'red');
        //     return false;
        // } else {
        //     document.getElementById('msgg').innerHTML = '';
        //     $.ajax({
        //         url: "/staff/verifyEmail",
        //         method: "post",
        //         data: {
        //             'email': $('#email').val()
        //         },
        //         dataType: "json",
        //         success: function (verify) {
        //             if (verify.msg == 1) {
        //                 // $('#message').text('This user name already exists');
        //                 document.getElementById('msgg').innerHTML = 'This email already exists';
        //                 $('#msgg').css('color', 'red');
        //                 return false;
        //
        //             } else {
        //                 document.getElementById('msgg').innerHTML = 'This is valid email';
        //                 $('#msgg').css('color', 'green');
        //             }
        //         }
        //     });
        // }

        //*******************************Password validation*************************************************

        var password = $('#password').val().trim();
        document.getElementById('pass').innerHTML = '';
        if (password.length < 1) {
            document.getElementById('pass').innerHTML = 'Password is required';
            $('#pass').css('color', 'red');
            return false;
        } else if (password.length <= 3) {
            document.getElementById('pass').innerHTML = 'Minimum four character required';
            $('#pass').css('color', 'red');
            return false;
        } else {
            document.getElementById('pass').innerHTML = '';
        }

        function confirmPasswordField() {
            document.getElementById('confirmPass').innerHTML = '';
            var password = $('#confirmPassword').val().trim();
            document.getElementById('confirmPass').innerHTML = '';
            if (password.length < 1) {
                document.getElementById('confirmPass').innerHTML = 'Confirm Password is required';
                $('#confirmPass').css('color', 'red');
                return false;
            } else if (password.length <= 3) {
                document.getElementById('confirmPass').innerHTML = 'Minimum four character required';
                $('#confirmPass').css('color', 'red');
                return false;
            } else {
                document.getElementById('confirmPass').innerHTML = '';
            }
        }

        if ($('#password').val().trim() == $('#confirmPassword').val().trim()){
            document.getElementById('confirmPass').innerHTML = '';
        }else{
            document.getElementById('confirmPass').innerHTML = 'Confirm password should be same as password';
            $('#confirmPass').css('color', 'red');
            return false;
        }


        document.getElementById('chek').innerHTML = '';
        if ($("#checkbox").is(':checked')) {
        } else {
            document.getElementById('chek').innerHTML = 'Please check checkbox';
            $('#chek').css('color', 'red');
            return false;
        }
        return true;


    }
</script>
</body>


</html>
