<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/18/2018
 * Time: 12:11 PM
 */
?>



        <!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cloud Office</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="Siddu Venkatapur">
    <meta name="description" content="Cloud office Project Management Software">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="/apple-icon.png">
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/staffAssets/css/normalize.css">
    <link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/staffAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/staffAssets/scss/style.css">
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body class="bg-dark" style="background-image: url(/images/bg2.jpg);">
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-logo">
                <a href="/staff/login">
                    <img class="align-content" src="/images/logo4.png" alt="">
                </a>
            </div>
            <div class="login-form">
                <form action="/staff/forgetPassword"  onsubmit="return validateForm()" method="post">
                    {{csrf_field()}}
                    <h4 style="text-align: center;margin-bottom: 25px;color:#333;">Reset Password</h4>
                    <p id="errorMess" style="text-align: center"></p>
                    <div class="form-group">
                        <label>Email address</label>
                        {{--<input type="text" name="email" id="email" class="form-control" onblur="verifyEmail()" placeholder="Email">--}}
                        <input type="text" name="email" id="email" class="form-control"  placeholder="Email">
                        <span id="msgg"></span>
                    </div>
                    <button type="submit" class="btn btn-primary btn-flat m-b-15">Submit</button>

                </form>
            </div>
        </div>
    </div>
</div>
<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/staffAssets/js/popper.min.js"></script>
<script src="/staffAssets/js/plugins.js"></script>
<script src="/staffAssets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<script src="/staffAssets/js/toastr/toastr.min.js"></script>
<script type="text/javascript">

    $(document).ready(function () {
        toastr.options.positionClass =  "toast-top-center";
        toastr.options.progressBar = true;
        toastr.options.preventDuplicate = true
    });


    function validateForm() {
        var email = $('#email').val();
        if (email == "") {
            document.getElementById('msgg').innerHTML = 'Email is required';
            $('#msgg').css('color', 'red');
            return false;
        }else{
            if (!(email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/))) {
                document.getElementById('msgg').innerHTML = 'Enter valid email';
                $('#msgg').css('color', 'red');
                return false;
            }
        }
    }
    @if(\Illuminate\Support\Facades\Session::has('msg'))
    toastr.error('{{\Illuminate\Support\Facades\Session::get('msg')}}', {timeOut: 10000});
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msgg'))
    document.getElementById('errorMess').innerHTML ='Please provide REGISTERED email..!!';
    $('#errorMess').css('color', 'red');
{{--    toastr.error('{{\Illuminate\Support\Facades\Session::get('msg')}}', {timeOut: 10000});--}}
    @endif
    @if(\Illuminate\Support\Facades\Session::has('msg1'))
    toastr.success('{{\Illuminate\Support\Facades\Session::get('msg1')}}', {timeOut: 10000});
    setTimeout(locationFun, 2000);
    function locationFun() {
        location.href = "/staff/login";
    }
    @endif

</script>

</body>

</html>
