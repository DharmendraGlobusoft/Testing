<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/14/2018
 * Time: 12:38 PM
 */
?>


@extends('Staff::layouts.master')

@section('page-style')
<style>
    /* Staff List CSS*/

    .custom_tooltip {
        position: relative;
        display: inline-block;
        border-bottom: 1px dotted black;
    }

    .custom_tooltip .tooltiptext {
        visibility: hidden;
        width: auto;
        background-color: #3ca1eb;
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px;
        position: absolute;
        z-index: 1;
        top: 70%;
        left: 50%;
        margin-left: -60px;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .custom_tooltip .tooltiptext::after {
        content: "";
        position: absolute;
        bottom: 100%;
        left: 50%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: transparent transparent #3ca1eb transparent;
    }

    .custom_tooltip:hover .tooltiptext {
        visibility: visible;
        opacity: 1;
    }

    .tooltiptext.swing:before,
    .tooltiptext.swing:after {
        transform: translate3d(0, 30px, 0) rotate3d(0, 0, 1, 60deg);
        transform-origin: 0 0;
        transition: transform .15s ease-in-out, opacity .2s;
    }

    .tooltiptext.swing:after {
        transform: translate3d(0, 60px, 0);
        transition: transform .15s ease-in-out, opacity .2s;
    }

    .tooltiptext.swing:hover:before,
    .tooltiptext.swing:hover:after {
        opacity: 1;
        transform: translate3d(0, 0, 0) rotate3d(1, 1, 1, 0deg);
    }

    /*        Scoll bar CSS*/

    #boxscroll {
        height: 400px;
        overflow-y: auto;
    }

    /*
    }
            #boxscroll  a{
                overflow-x: hidden ;
                width: 100%;
            }
    */

    .nicescroll-cursors {
        background-color: rgba(70, 166, 248, 0.8) !important;
    }

    /*        Staff details modal css*/

    .details {
        list-style-type: none;
        border: 1px solid #eee;
        margin: 0;
        padding: 0;
        -webkit-transition: 0.3s;
        transition: 0.3s;
        background: #3c4451;
        border-radius: 5px;
    }

    .details:hover {
        box-shadow: 0 8px 12px 0 rgba(0, 0, 0, 0.2)
    }

    .details .header {
        font-size: 20px;
        padding: 15px;
        color: #fff;
        background: #db3b5e;
    }

    .details li {

        padding: 18px 20px;
        color: #fff;
    }

    .details .grey {
        background-color: #e94633;
        font-size: 20px;
        color: #fff;
    }

    .staff_img_section {
        background: #fff;
        text-align: center;
    }

    .staff_img {
        width: 150px;
        border-radius: 50%;
        border: 4px solid #3ca1eb;
    }

    /*        Custom select */
    select.soflow,
    select.soflow-color {
        appearance: button;
        -o-appearance: button;
        -ms-appearance: button;
        -moz-appearance: button;
        -khtml-appearance: button;
        -webkit-border-radius: 3px;
        /*  -webkit-box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.1);*/
        -webkit-padding-end: 20px;
        -webkit-padding-start: 2px;
        -webkit-user-select: none;
        background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
        background-position: 97% center;
        background-repeat: no-repeat;
        border: 1px solid #D4D1D1;
        color: #555;
        font-size: inherit;
        /*  margin: 20px;*/
        overflow: hidden;
        padding: 5px 10px;
        text-overflow: ellipsis;
        white-space: nowrap;
        /*  width: 300px;*/
    }

    select.soflow-color {
        color: #fff;
        background-image: url(http://i62.tinypic.com/15xvbd5.png), -webkit-linear-gradient(#779126, #779126 40%, #779126);
        background-color: #779126;
        -webkit-border-radius: 20px;
        -moz-border-radius: 20px;
        border-radius: 20px;
        padding-left: 15px;
    }

    select.form-control:not([size]):not([multiple]) {
        height: calc(2rem + 2px);
    }

    body {
        font-size: 14px;
    }

    /*        Month select */
    .monthly-wrp {
        padding: 1em;
        top: 6px;
        z-index: 1000;
        border-radius: 3px;
        background-color: #2C3E50;
        top: 90% !important;
        left: 36% !important;
    }

    .monthly-wrp:before {
        content: "";
        border-bottom: 6px solid #2C3E50;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        position: absolute;
        top: -6px;
        left: 6px;
        z-index: 1002;
    }

    .monthly-wrp .years {
        margin-bottom: 0.8em;
        text-align: center;
    }

    .monthly-wrp .years select {
        appearance: button;
        -o-appearance: button;
        -ms-appearance: button;
        -moz-appearance: button;
        -khtml-appearance: button;
        border: 0;
        border-radius: 3px;
        width: 100%;
        height: 30px;
        -webkit-appearance: button;
        background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
        background-position: 97% center;
        background-repeat: no-repeat;
        background-color: #f6f7f5 !important;
    }

    .monthly-wrp .years select:focus {
        outline: none;
    }

    .monthly-wrp table {
        border-collapse: collapse;
        table-layout: fixed;
    }

    .monthly-wrp td {
        padding: 1px;
    }

    .monthly-wrp table button {
        width: 100%;
        border: none;
        background-color: #3ca1eb;
        color: #FFFFFF;
        font-size: 14px;
        padding: 0.4em;
        cursor: pointer;
        border-radius: 3px;
    }

    .monthly-wrp table button:hover {
        background-color: #3ca1eb;
    }

    .monthly-wrp table button:focus {
        outline: none;
    }

    .monthly-wrp table {
        width: auto !important;
    }

    /*        Month select */
    .monthly-wrp1 {
        padding: 1em;
        top: 6px;
        z-index: 1000;
        border-radius: 3px;
        background-color: #2C3E50;
        top: 90% !important;
        left: 36% !important;
    }

    .monthly-wrp1:before {
        content: "";
        border-bottom: 6px solid #2C3E50;
        border-left: 6px solid transparent;
        border-right: 6px solid transparent;
        position: absolute;
        top: -6px;
        left: 6px;
        z-index: 1002;
    }

    .monthly-wrp1 .years {
        margin-bottom: 0.8em;
        text-align: center;
    }

    .monthly-wrp1 .years select {
        appearance: button;
        -o-appearance: button;
        -ms-appearance: button;
        -moz-appearance: button;
        -khtml-appearance: button;
        border: 0;
        border-radius: 3px;
        width: 100%;
        height: 30px;
        -webkit-appearance: button;
        background-image: url(/images/15xvbd5.png), -webkit-linear-gradient(#FAFAFA, #F4F4F4 100%, #faf9f9);
        background-position: 97% center;
        background-repeat: no-repeat;
        background-color: #f6f7f5 !important;
    }

    .monthly-wrp1 .years select:focus {
        outline: none;
    }

    .monthly-wrp1 table {
        border-collapse: collapse;
        table-layout: fixed;
    }

    .monthly-wrp1 td {
        padding: 1px;
    }

    .monthly-wrp1 table button {
        width: 100%;
        border: none;
        background-color: #3ca1eb;
        color: #FFFFFF;
        font-size: 14px;
        padding: 0.4em;
        cursor: pointer;
        border-radius: 3px;
    }

    .monthly-wrp1 table button:hover {
        background-color: #3ca1eb;
    }

    .monthly-wrp1 table button:focus {
        outline: none;
    }

    .monthly-wrp1 table {
        width: auto !important;
    }

    /*        Month select */

    .ui-widget-header {
        border: 0px solid #aaa !important;
        background: #fff !important;
        color: #222222 !important;
        font-weight: bold !important;
    }

    .ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {

        border: 1px solid #0000004d !important;
        background: #3ca1eb !important;
        font-weight: normal !important;
        color: #fff !important;

    }

    #filter-panel {
        transition: height 200ms ease-out;
    }
</style>
@endsection

@section('title')
    <title> Dashboard || Cloud Office</title>
@endsection

@section('page-content')
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Dashboard</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">

                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">

                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Overview</strong>
                        </div>
                        <div class="card-body">

                            <div class="col-lg-4 taskClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Tasks</h4>
                                <canvas id="doughutChart"></canvas>
                            </div>
                            <div class="col-lg-4 issueClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Overview of Issues</h4>
                                <canvas id="doughutChart1"></canvas>
                            </div>
                            <div class="col-lg-4 milestoneClass" style="text-align: center;">
                                <h4 class="mb-3" style="text-align: center;">Milestones</h4>
                                <canvas id="doughutChart2"></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                {{--<div class="col-md-12">--}}
                {{--<div class="card">--}}
                {{--<div class="card-header">--}}
                {{--<strong class="card-title">My Tasks</strong>--}}
                {{--</div>--}}
                {{--<div class="card-body">--}}
                {{--<table id="taskTable" class="table table-striped table-bordered">--}}
                {{--<thead>--}}
                {{--<tr>--}}
                {{--<th>Tasks</th>--}}
                {{--<th>Projects</th>--}}
                {{--<th>Date</th>--}}
                {{--<th>Status</th>--}}
                {{--<th>Priority</th>--}}
                {{--</tr>--}}
                {{--</thead>--}}
                {{--<tbody>--}}
                {{--<tr>--}}
                {{--<td>Dashboard Design</td>--}}
                {{--<td>Cloud Office</td>--}}
                {{--<td>03/08/2018</td>--}}
                {{--<td>Active</td>--}}
                {{--<td>High</td>--}}
                {{--</tr>--}}

                {{--</tbody>--}}
                {{--</table>--}}
                {{--</div>--}}
                {{--</div>--}}
                {{--</div>--}}

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">My Tasks</strong>
                            <button type="button" class="btn btn-info pull-right" data-toggle="collapse"
                                    data-target="#filter-panel" style="padding: 4px 10px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>

                            <div id="filter-panel" class="collapse filter-panel" style="margin-top: 15px;">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <form class="form" role="form">
                                            <div class="form-group col-xs-2 col-md-2 ">
                                                <label class="control-label" for="pref-perpage">Time</label>
                                                <select id="pref-perpage" class="form-control soflow filterByTime">
                                                    <option value="0">All Time</option>
                                                    <option value="1">Today</option>
                                                    <option value="2">Last 7 days</option>
                                                    <option value="3">Last 30 days</option>
                                                </select>
                                            </div> <!-- form group [rows] -->

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-perpage">Month</label>
                                                <input class="soflow form-control filterByMonthndYear" type="text"
                                                       id="selection"
                                                       value="{{date('M Y')}}" style="font-size: inherit;">
                                            </div>
                                            <div class="form-group col-xs-4 col-md-4">
                                                <label class="control-label" for="pref-search">Project</label>
                                                <select id="pref-search" class="form-control soflow filterByProject">
                                                    <option value="0">All</option>
                                                    @foreach($projectName as $K=>$val)
                                                        {{--                                                        <option value="{{$val->project_id}}">{{$val->project_name}}</option>--}}
                                                        <option value="{{$val['project_id']}}">{{$val['project_name']}}</option>
                                                    @endforeach
                                                </select>
                                            </div><!-- form group [search] -->
                                            {{--<div class="form-group col-xs-2 col-md-2">--}}
                                                {{--<label class="control-label" for="pref-orderby">View</label>--}}
                                                {{--<select id="pref-orderby" class="form-control soflow filterByView">--}}
                                                    {{--<option value="0">All</option>--}}
                                                    {{--<option value="1">Latest Task(Last 7 Days)</option>--}}
                                                {{--</select>--}}
                                            {{--</div>--}}
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="taskTable" class="table table-striped table-bordered taskTable">
                                <thead>
                                <tr>
                                    <th>SI.No</th>
                                    <th>Tasks</th>
                                    {{--<th>TasksId</th>--}}
                                    <th>Projects</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Priority</th>
                                    <th>Task Submission</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    {{--<td>Dashboard Design</td>--}}
                                    {{--<td>Cloud Office</td>--}}
                                    {{--<td>03/08/2018</td>--}}
                                    {{--<td>Active</td>--}}
                                    {{--<td>High</td>--}}
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">My Issues</strong>
                            <button type="button" class="btn btn-info pull-right" data-toggle="collapse"
                                    data-target="#filter-panel1" style="padding: 4px 10px;">
                                <i class="fa fa-filter" aria-hidden="true"></i>
                                Filters
                            </button>

                            <div id="filter-panel1" class="collapse filter-panel1" style="margin-top: 15px;">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <form class="form" role="form">
                                            <div class="form-group col-xs-2 col-md-2 ">
                                                <label class="control-label" for="pref-perpage">Time</label>
                                                <select id="pref-perpage" class="form-control soflow filterByTime1">
                                                    <option value="0">All Time</option>
                                                    <option value="1">Today</option>
                                                    <option value="2">Last 7 days</option>
                                                    <option value="3">Last 30 days</option>
                                                </select>
                                            </div> <!-- form group [rows] -->

                                            <div class="form-group col-xs-2 col-md-2">
                                                <label class="control-label" for="pref-perpage">Month</label>
                                                <input class="soflow form-control filterByMonthndYear1" type="text"
                                                       id="selection1"
                                                       value="{{date('F Y')}}" style="font-size: inherit;">
                                            </div>
                                            <div class="form-group col-xs-4 col-md-4">
                                                <label class="control-label" for="pref-search">Project</label>
                                                <select id="pref-search" class="form-control soflow filterByProject1">
                                                    <option value="0">All</option>
                                                    @foreach($issueProjectName as $K=>$val)
                                                        {{--                                                        <option value="{{$val->project_id}}">{{$val->project_name}}</option>--}}
                                                        <option value="{{$val['project_id']}}">{{$val['project_name']}}</option>
                                                    @endforeach
                                                </select>
                                            </div><!-- form group [search] -->
                                            {{--<div class="form-group col-xs-2 col-md-2">--}}
                                                {{--<label class="control-label" for="pref-orderby">View</label>--}}
                                                {{--<select id="pref-orderby" class="form-control soflow filterByView1">--}}
                                                    {{--<option value="0">All</option>--}}
                                                    {{--<option value="1">Latest Task(Last 7 Days)</option>--}}
                                                {{--</select>--}}
                                            {{--</div>--}}
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="issueTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>SI.No</th>
                                    <th>Issues List</th>
                                    <th>Projects</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Severity</th>
                                    <th>Issue Submission</th>
                                </tr>
                                </thead>
                                <tbody>

                                {{--<tr>--}}
                                    {{--<td>Dashboard Design</td>--}}
                                    {{--<td>Cloud Office</td>--}}
                                    {{--<td>03/08/2018</td>--}}
                                {{--</tr>--}}
                                {{--<tr>--}}
                                    {{--<td>Dashboard Design</td>--}}
                                    {{--<td>Cloud Office</td>--}}
                                    {{--<td>03/08/2018</td>--}}
                                {{--</tr>--}}
                                {{--<tr>--}}
                                    {{--<td>Dashboard Design</td>--}}
                                    {{--<td>Cloud Office</td>--}}
                                    {{--<td>03/08/2018</td>--}}
                                {{--</tr>--}}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Milestones</strong>
                        </div>
                        <div class="card-body">
                            <table id="milestoneTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>SI.No</th>
                                    <th>Project Name</th>
                                    <th>Milestones</th>
                                    <th>Start Date</th>
                                    <th>Due Date</th>
                                    <th>Milestone Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Dashboard Design</td>
                                    <td>03/08/2018</td>
                                    <td>03/08/2018</td>
                                    <td>Fineshed</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- .animated -->
    </div>
@endsection

@section('page-scripts')

    <script src="/staffAssets/js/lib/chart-js/Chart.bundle.js"></script>
    <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
    <script src="/assets/js/jquery.mtz.monthpicker.js"></script>
    {{--<script>--}}
        {{--function padToTwo(number) {--}}
            {{--if (number <= 9999) {--}}
                {{--number = ("0" + number).slice(-2);--}}
            {{--}--}}
            {{--return number;--}}
        {{--}--}}

        {{--(function ($) {--}}
            {{--$.fn.monthly = function (options) {--}}
                {{--var months = options.months || [--}}
                        {{--"January",--}}
                        {{--"February",--}}
                        {{--"March",--}}
                        {{--"April",--}}
                        {{--"May",--}}
                        {{--"June",--}}
                        {{--"July",--}}
                        {{--"August",--}}
                        {{--"September",--}}
                        {{--"October",--}}
                        {{--"November",--}}
                        {{--"December"--}}
                    {{--],--}}
                    {{--Monthly = function (el) {--}}
                        {{--this._el = $(el);--}}
                        {{--this._init();--}}
                        {{--this._render();--}}
                        {{--this._renderYears();--}}
                        {{--this._renderMonths();--}}
                        {{--this._bind();--}}
                    {{--};--}}

                {{--Monthly.prototype = {--}}
                    {{--_init: function () {--}}
                        {{--this._el.html(months[0] + " " + options.years[0]);--}}
                    {{--},--}}

                    {{--_render: function () {--}}
                        {{--var linkPosition = this._el.offset(),--}}
                            {{--cssOptions = {--}}
                                {{--display: "none",--}}
                                {{--position: "absolute",--}}
                                {{--top:--}}
                                {{--linkPosition.top + this._el.height() + (options.topOffset || 0),--}}
                                {{--left: linkPosition.left--}}
                            {{--};--}}
                        {{--this._container = $('<div class="monthly-wrp">')--}}
                            {{--.css(cssOptions)--}}
                            {{--.appendTo($("body"));--}}
                    {{--},--}}

                    {{--_bind: function () {--}}
                        {{--var self = this;--}}
                        {{--this._el.on("click", $.proxy(this._show, this));--}}
                        {{--$(document).on("click", $.proxy(this._hide, this));--}}
                        {{--this._yearsSelect.on("click", function (e) {--}}
                            {{--e.stopPropagation();--}}
                        {{--});--}}
                        {{--this._container.on("click", "button", $.proxy(this._selectMonth, this));--}}
                    {{--},--}}

                    {{--_show: function (e) {--}}
                        {{--e.preventDefault();--}}
                        {{--e.stopPropagation();--}}
                        {{--this._container.css("display", "inline-block");--}}
                    {{--},--}}

                    {{--_hide: function () {--}}
                        {{--this._container.css("display", "none");--}}
                    {{--},--}}

                    {{--_selectMonth: function (e) {--}}
                        {{--var monthIndex = $(e.target).data("value"),--}}
                            {{--month = months[monthIndex],--}}
                            {{--year = this._yearsSelect.val();--}}
                        {{--this._el.html(month + " " + year);--}}
                        {{--if (options.onMonthSelect) {--}}
                            {{--options.onMonthSelect(monthIndex, month, year);--}}
                        {{--}--}}
                    {{--},--}}

                    {{--_renderYears: function () {--}}
                        {{--var markup = $.map(options.years, function (year) {--}}
                            {{--return "<option>" + year + "</option>";--}}
                        {{--});--}}
                        {{--var yearsWrap = $('<div class="years">').appendTo(this._container);--}}
                        {{--this._yearsSelect = $("<select class='currentYear'>")--}}
                            {{--.html(markup.join(""))--}}
                            {{--.appendTo(yearsWrap);--}}
                        {{--var curntyear = new Date().getFullYear();--}}
                        {{--$('.currentYear :selected').text(curntyear);--}}
                    {{--},--}}

                    {{--_renderMonths: function () {--}}
                        {{--var markup = ["<table>", "<tr>"];--}}
                        {{--$.each(months, function (i, month) {--}}
                            {{--if (i > 0 && i % 4 === 0) {--}}
                                {{--markup.push("</tr>");--}}
                                {{--markup.push("<tr>");--}}
                            {{--}--}}
                            {{--markup.push(--}}
                                {{--'<td><button data-value="' + i + '">' + month + "</button></td>"--}}
                            {{--);--}}
                        {{--});--}}
                        {{--markup.push("</tr>");--}}
                        {{--markup.push("</table>");--}}
                        {{--this._container.append(markup.join(""));--}}
                    {{--}--}}
                {{--};--}}

                {{--return this.each(function () {--}}
                    {{--return new Monthly(this);--}}
                {{--});--}}
            {{--};--}}
        {{--})(jQuery);--}}

        {{--let data = [];--}}
        {{--var now = new Date();--}}
        {{--var currentYear = now.getFullYear();--}}
        {{--var UpperLimt= currentYear+20;--}}
        {{--for (var v = 2000; v < UpperLimt; v++) {--}}
            {{--data.push(v);--}}
        {{--}--}}

        {{--$(function () {--}}
            {{--$("#selection").monthly({--}}
                {{--years: data,--}}
                {{--topOffset: 28,--}}
                {{--onMonthSelect: function (mi, m, y) {--}}
                    {{--mi = padToTwo(mi);--}}
                    {{--$("#selection").val(m + " " + y);--}}
                    {{--$("#monthly").val(y + "-" + mi);--}}
                    {{--console.log('=================',  $("#selection").val());--}}
                    {{--let month = $('#selection').val();--}}
                    {{--$('#taskTable').DataTable({--}}
                        {{--lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],--}}
                        {{--processing: true,--}}
                        {{--serverSide: true,--}}
                        {{--destroy: true,--}}
                        {{--ajax: {--}}
                            {{--// url: '/filteringOfTaskAjaxHandler',--}}
                            {{--url: '/taskAjaxHandler',--}}
                            {{--method:'post',--}}
                            {{--data: function (f) {--}}
                                {{--f.id = 'month';--}}
                                {{--f.value = month;--}}
                            {{--}--}}
                        {{--},--}}
                        {{--columns: [--}}
                            {{--{data: 'serialNumber', name: 'serialNumber'},--}}
                            {{--{data: 'tasks', name: 'tasks'},--}}
                            {{--{data: 'projects', name: 'projects'},--}}
                            {{--{data: 'date', name: 'date'},--}}
                            {{--{data: 'status', name: 'status'},--}}
                            {{--{data: 'priority', name: 'priority'},--}}
                            {{--{data: 'viewSubmittion', name: 'viewSubmittion'}--}}
                        {{--],--}}
                        {{--createdRow: function (row, data, index) {--}}
                            {{--let taskDetails = data.taskName.replace(/&amp;/g, '&');--}}
                            {{--let projName = data.projName.replace(/&amp;/g, '&');--}}
                            {{--$('td', row).eq(2).attr({--}}
                                {{--'data-tooltip': projName,--}}
                                {{--'style': 'word-break: break-all'--}}
                            {{--});--}}
                            {{--$('td', row).eq(1).attr({--}}
                                {{--'data-tooltip': taskDetails,--}}
                                {{--'style': 'word-break: break-all'--}}
                            {{--});--}}
                        {{--},--}}
                        {{--"order": [[0, 'desc']]--}}
                    {{--});--}}
                {{--}--}}
            {{--});--}}
        {{--});--}}

    {{--</script>--}}
    <script>
        let taskTableData = function (val) {
            $('#taskTable').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                destroy: true,
                ajax: {
                    // url: '/filteringOfTaskAjaxHandler',
                    url: '/taskAjaxHandler',
                    method:'post',
                    data: function (f) {
                        f.id = 'month';
                        f.value = val;
                    }
                },
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'tasks', name: 'tasks'},
                    {data: 'projects', name: 'projects'},
                    {data: 'date', name: 'date'},
                    {data: 'status', name: 'status'},
                    {data: 'priority', name: 'priority'},
                    {data: 'viewSubmittion', name: 'viewSubmittion'}
                ],
                createdRow: function (row, data, index) {
                    let taskDetails = data.taskName.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': taskDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });
        };

        let issueTableData = function (val) {
            $('#issueTable').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                destroy: true,
                ajax: {
                    url: '/issueListAjaxHandler',
                    method: 'post',
                    data: function (f) {
                        f.id = 'month';
                        f.value = val;
                    }
                },
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'issueList', name: 'issueList'},
                    {data: 'projects', name: 'projects'},
                    {data: 'dueDate', name: 'dueDate'},
                    {data: 'status', name: 'status'},
                    {data: 'severity', name: 'severity'},
                    {data: 'issueSubmittion', name: 'issueSubmittion'}
                ],
                createdRow: function (row, data, index) {
                    let taskDetails = data.issList.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': taskDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });
        };

        $('#selection1').monthpicker({
            pattern: 'mm yyyy',
            selectedYear: 2015,
            startYear: 1900,
            finalYear: 2212,
        });

        $('#selection').monthpicker({
            pattern: 'mm yyyy',
            selectedYear: 2015,
            startYear: 1900,
            finalYear: 2212,
        });

        $('#selection').monthpicker().bind('monthpicker-click-month', function (e, month) {
            var val = $("#selection").val();
            taskTableData(val)
        }).bind('monthpicker-change-year', function (e, year) {
            var val = $("#selection").val();
            // alert(year)
            // taskTableData(val)
        })

        $('#selection1').monthpicker().bind('monthpicker-click-month', function (e, month) {
            var val = $("#selection1").val();
            console.log(val);
            issueTableData(val)
        }).bind('monthpicker-change-year', function (e, year) {
            var val = $("#selection").val();
            // alert(year)
            // taskTableData(val)
        })

    </script>
    <script type="text/javascript">

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        taskGraphical();
        issueGraphical();
        milestoneGraphical();
        function taskGraphical() {
            $.ajax({
                url: "/staff/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Task'
                },
                success: function (response) {
                    if (response.length>0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart");
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"
                                    ]
                                }],
                                labels: [
                                    "Pending",
                                    "Finished"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    }else{
                        // console.log('No data');
                        let data='';
                        data='<h4 class="mb-3" >Tasks</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Task </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        // console.log(data);
                        $('.taskClass').html('').append(data);
                    }
                }
            });
        }
        function issueGraphical() {
            $.ajax({
                url: "/staff/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Issue'
                },
                success: function (response) {
                    if (response.length>0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart1");
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"

                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)"

                                    ]

                                }],
                                labels: [
                                    "Pending",
                                    "Finished"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    }else{
                        let data='';
                        data='<h4 class="mb-3" >Overview of Issues</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Issue </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        // console.log(data);
                        $('.issueClass').html('').append(data);
                    }
                }
            });
        }
        function milestoneGraphical() {
            $.ajax({
                url: "/staff/getAllCountInChart",
                type: "post",
                dataType: "json",
                data: {
                    chooseMethod: 'Milestone'
                },
                success: function (response) {
                    if (response.length>0) {
                        let data = response;
                        var ctx = document.getElementById("doughutChart2");
                        ctx.height = 150;
                        var myChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                datasets: [{
                                    data: data,
                                    backgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)",
                                        "rgba(50,205,50)"
                                    ],
                                    hoverBackgroundColor: [
                                        "rgba(253, 11, 21, 0.9)",
                                        "rgba(0, 123, 255,0.7)",
                                        "rgba(50,205,50)"
                                    ]
                                }],
                                labels: [
                                    "Pending",
                                    "Finished",
                                    "Overdue"

                                ]
                            },
                            options: {
                                responsive: true
                            }
                        });
                    }else{
                        let data='';
                        data='<h4 class="mb-3" >Milestones</h4>\n' +
                            '<p style="color: #4ca2ff;font-size:15px;">No Milestone </p>\n' +
                            '<img src="/images/No_data.png" style="margin-top: -5px;" width="120px">';
                        // console.log(data);
                        $('.milestoneClass').html('').append(data);
                    }
                }
            });
        }

        $(document).ready(function () {

            $('#taskTable').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                // destroy: true,
                processing: true,
                serverSide: true,
                ajax: '/taskAjaxHandler',
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'tasks', name: 'tasks'},
                    // {data: 'tasksId', name: 'tasksId'},
                    {data: 'projects', name: 'projects'},
                    {data: 'date', name: 'date'},
                    {data: 'status', name: 'status'},
                    {data: 'priority', name: 'priority'},
                    {data: 'viewSubmittion', name: 'viewSubmittion'}
                ],
                createdRow: function (row, data, index) {
                    let taskDetails = data.taskName.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': taskDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });


            $('#issueTable').DataTable({
                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                processing: true,
                serverSide: true,
                ajax: '/issueListAjaxHandler',
                columns: [
                    {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'issueList', name: 'issueList'},
                    {data: 'projects', name: 'projects'},
                    {data: 'dueDate', name: 'dueDate'},
                    {data: 'status', name: 'status'},
                    {data: 'severity', name: 'severity'},
                    {data: 'issueSubmittion', name: 'issueSubmittion'}
                ],
                createdRow: function (row, data, index) {
                    let taskDetails = data.issList.replace(/&amp;/g, '&');
                    let projName = data.projName.replace(/&amp;/g, '&');
                    $('td', row).eq(2).attr({
                        'data-tooltip': projName,
                        'style': 'word-break: break-all'
                    });
                    $('td', row).eq(1).attr({
                        'data-tooltip': taskDetails,
                        'style': 'word-break: break-all'
                    });
                },
                "order": [[0, 'desc']]
            });


            $('#milestoneTable').DataTable({

                lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                destroy: true,
                processing: true,
                serverSide: true,
                ajax: '/milestoneAjaxHandler',
                columns: [
                    // {data: 'serialNumber', name: 'serialNumber'},
                    {data: 'siNo', name: 'siNo'},
                    {data: 'projectName', name: 'projectName'},
                    {data: 'mileston', name: 'mileston'},
                    {data: 'start_date', name: 'start_date'},
                    {data: 'due_date', name: 'due_date'},
                    {data: 'milestoneStatus', name: 'milestoneStatus'}
                ],
                "order": [[0, 'desc']]
            });

//------------------------------------task filter------------------------------------------

            $(document.body).on('change', '.filterByProject', function () {
                let projId = $('.filterByProject').val();
                allFilter('projectId',projId)
            });
            $(document.body).on('change', '.filterByView', function () {
                let view = $('.filterByView').val();
                allFilter('view',view)
            });
            $(document.body).on('change', '.filterByTime', function () {
                let time = $('.filterByTime').val();
                allFilter('time',time)
            });
            function allFilter(id,value) {
                $('#taskTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: '/taskAjaxHandler',
                        method: 'post',
                        data: function (f) {
                            f.id = id;
                            f.value = value;
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'tasks', name: 'tasks'},
                        {data: 'projects', name: 'projects'},
                        {data: 'date', name: 'date'},
                        {data: 'status', name: 'status'},
                        {data: 'priority', name: 'priority'},
                        {data: 'viewSubmittion', name: 'viewSubmittion'}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.taskName.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            }

//---------------------------------------Issue filter-------------------------------------

            $(document.body).on('change', '.filterByProject1', function () {
                let projId = $('.filterByProject1').val();
                allIssueFilter('projectId',projId)
            });
            $(document.body).on('change', '.filterByView1', function () {
                let view = $('.filterByView1').val();
                allIssueFilter('view',view)
            });
            $(document.body).on('change', '.filterByTime1', function () {
                let time = $('.filterByTime1').val();
                allIssueFilter('time',time)
            });
            function allIssueFilter(id,value) {
                $('#issueTable').DataTable({
                    lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]],
                    processing: true,
                    serverSide: true,
                    destroy: true,
                    ajax: {
                        url: '/issueListAjaxHandler',
                        method: 'post',
                        data: function (f) {
                            f.id = id;
                            f.value = value;
                        }
                    },
                    columns: [
                        {data: 'serialNumber', name: 'serialNumber'},
                        {data: 'issueList', name: 'issueList'},
                        {data: 'projects', name: 'projects'},
                        {data: 'dueDate', name: 'dueDate'},
                        {data: 'status', name: 'status'},
                        {data: 'severity', name: 'severity'},
                        {data: 'issueSubmittion', name: 'issueSubmittion'}
                    ],
                    createdRow: function (row, data, index) {
                        let taskDetails = data.issList.replace(/&amp;/g, '&');
                        let projName = data.projName.replace(/&amp;/g, '&');
                        $('td', row).eq(2).attr({
                            'data-tooltip': projName,
                            'style': 'word-break: break-all'
                        });
                        $('td', row).eq(1).attr({
                            'data-tooltip': taskDetails,
                            'style': 'word-break: break-all'
                        });
                    },
                    "order": [[0, 'desc']]
                });
            }
        });

    </script>

@endsection
