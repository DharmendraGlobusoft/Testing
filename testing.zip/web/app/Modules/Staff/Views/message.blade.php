<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/19/2018
 * Time: 1:50 PM
 */
?>


@extends('Staff::layouts.master')

{{--@section('title','Project')--}}

@section('title')
    <title> Message || Cloud Office</title>
@endsection

@section('page-style')
    <link rel="stylesheet" href="/assets/css/toastr/toastr.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>

    <style>
        /*        chatt CSS  */
        .chat_window {
            /*  position: absolute;*/
            width: calc(100% - 20px);
            max-width: 800px;
            height: 430px;
            /*            border-radius: 10px;*/
            background-color: #ffffff;
            left: 50%;
            top: 50%;
            /*  transform: translateX(-50%) translateY(-50%);*/
            /*            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);*/
            /*            background-color: #ffffff;*/
            overflow: hidden;
        }

        .top_menu {
            background-color: #fff;
            width: 100%;
            padding: 20px 0 15px;
            box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1);
        }

        .top_menu .buttons {
            margin: 3px 0 0 20px;
            position: absolute;
        }

        .top_menu .buttons .button {
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 10px;
            position: relative;
        }

        .top_menu .buttons .button.close {
            background-color: #f5886e;
        }

        .top_menu .buttons .button.minimize {
            background-color: #fdbf68;
        }

        .top_menu .buttons .button.maximize {
            background-color: #a3d063;
        }

        .top_menu .title {
            text-align: center;
            color: #bcbdc0;
            font-size: 20px;
        }

        .messages {
            position: relative;
            list-style: none;
            padding: 20px 10px 0 10px;
            margin: 0;
            height: 347px;
            overflow: auto;
        }

        .messages .message {
            clear: both;
            overflow: hidden;
            margin-bottom: 20px;
            transition: all 0.5s linear;
            opacity: 0;
        }

        .messages .message.left .avatar {
            background-color: #f5886e;
            float: left;
        }

        .messages .message.left .text_wrapper {
            background-color: #ffe6cb;
            margin-left: 20px;
        }

        .messages .message.left .text_wrapper::after,
        .messages .message.left .text_wrapper::before {
            right: 100%;
            border-right-color: #ffe6cb;
        }

        .messages .message.left .text {
            color: #c48843;
        }

        .messages .message.right .avatar {
            background-color: #fdbf68;
            float: right;
        }

        .messages .message.right .text_wrapper {
            background-color: #c7eafc;
            margin-right: 20px;
            float: right;
        }

        .messages .message.right .text_wrapper::after,
        .messages .message.right .text_wrapper::before {
            left: 100%;
            border-left-color: #c7eafc;
        }

        .messages .message.right .text {
            color: #45829b;

        }

        .messages .message.appeared {
            opacity: 1;
        }

        .messages .message .avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: inline-block;
        }

        .messages .message .text_wrapper {
            display: inline-block;
            /*padding: 20px;*/
            border-radius: 6px;
            width: calc(50% - 85px);
            min-width: 100px;
            position: relative;
            word-wrap: break-word;
        }

        .messages .message .text_wrapper::after,
        .messages .message .text_wrapper:before {
            top: 18px;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
        }

        .messages .message .text_wrapper::after {
            border-width: 13px;
            margin-top: 0px;
        }

        .messages .message .text_wrapper::before {
            border-width: 15px;
            margin-top: -2px;
        }

        .messages .message .text_wrapper .text {
            font-size: 14px;
            font-weight: 500;
            padding: 20px;
        }

        .bottom_wrapper {
            position: relative;
            width: 100%;
            background-color: #fff;
            padding: 20px 20px;
            /*  position: absolute;*/
            bottom: 0;
        }

        .bottom_wrapper .message_input_wrapper {
            display: inline-block;
            height: 50px;
            border-radius: 25px;
            border: 1px solid #bcbdc0;
            width: calc(100% - 160px);
            position: relative;
            padding: 0 20px;
        }

        .bottom_wrapper .message_input_wrapper .message_input {
            border: none;
            height: 100%;
            box-sizing: border-box;
            width: calc(100% - 40px);
            position: absolute;
            outline-width: 0;
            color: gray;
        }

        .bottom_wrapper .send_message {
            width: 140px;
            height: 50px;
            display: inline-block;
            border-radius: 50px;
            background-color: #a3d063;
            border: 2px solid #a3d063;
            color: #fff;
            cursor: pointer;
            transition: all 0.2s linear;
            text-align: center;
            float: right;
        }

        .bottom_wrapper .send_message:hover {
            color: #a3d063;
            background-color: #fff;
        }

        .bottom_wrapper .send_message .text {
            font-size: 18px;
            font-weight: 300;
            display: inline-block;
            line-height: 48px;
        }

        .message_template {
            display: none;
        }

        .error {
            color: red;
        }

        .direct-chat-timestamp {
            font-size: 12px;
            padding: 5px;
            opacity: 0.6;
            color: #333;
        }
    </style>

@endsection

@section('page-content')

    <div id="loader11" >
        <div class=""
             style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); width: 100%; height: 100%; position: fixed; top: 0%; background: rgb(6, 6, 6) none repeat scroll 0% 0%;
opacity: 0.8; z-index: 1004; cursor: wait; right: 0px;"></div>
        <div class="blockUI blockMsg blockPage "
             style="padding: 0px; margin: 0px; top: 30%; color: rgb(0, 0, 0); font-weight: normal; font-size: 20px; left: 40%; text-align: center; z-index: 999999 ! important; position: fixed; width: 30%;">
            <img src="\images\cloud_loading.gif"
                 style="height:150px;display: block; margin-left: auto;margin-right: auto">
            <p style="text-align: center; font-size: 20px;color: #fff">Processing please wait...</p>
        </div>
    </div>


    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Messages List</h1>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <div class="page-header float-right">
                <div class="page-title">
                    <ol class="breadcrumb text-right">
                        <li><a href="/staff/dashboard">Dashboard</a></li>
                        <li class="active">Messages List</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Messages Details</strong>
                            <button onclick="getNewMsgdata()" class="btn btn-success pull-right" id="allStaff"
                                    data-toggle="modal"
                                    data-target="#addMessage">Add New Message
                            </button>
                        </div>
                        <div class="card-body">
                            <table id="messageTable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>SL NO</th>
                                    <th>Receiver</th>
                                    <th>Sender</th>
                                    <th>Start Date</th>
                                    <th>Conversation Details</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i = 1; if (isset($msg)){
                                foreach($msg as $key => $val){?>
                                <tr>
                                    <td>{{$i}}</td>
                                    <td>{{$val['sender']}}</td>
                                    <td>{{$val['receiver']}}</td>
                                    <td>{{$val['startDate']}}</td>
                                    <td><a class="custom_text_info"
                                           onclick="getMsg('{{$val['senderId']}}','{{$val['receiverId']}}');"
                                           data-toggle="modal" data-target="#messageModal">View Conversation</a>
                                    </td>
                                </tr>
                                <?php  $i++; }}?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .animated -->
    </div>

    <div class="modal fade" id="messageModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="border:3px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;">Message Conversations</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div id="load" class="loaderClass hide" style="text-align: center; overflow: hidden;position: absolute;left: 45%;top:25%;">
                        <img src="/images/cloud_loading.gif" style="width: 100px">
                    </div>

                    <div class="chat_window">
                        <ul class="messages">


                        </ul>
                        <form id="form1">
                            <div class="bottom_wrapper clearfix">
                                <div class="message_input_wrapper">
                                    <input class="message_input" name="message"
                                                                          id="message"
                                                                          placeholder="Type your message here..."/>
                                </div>
                                <input type="text" id="receiverId" name="receiverId" hidden>
                                <div class="send_message">
                                    <div class="icon"></div>
                                    <div class="text">Send</div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="message_template">
                        <li class="message">
                            <div id="li" class="avatar" tabindex="0" data-toggle="tooltip" title="Manager"><img
                                        src="{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}"
                                        alt=""
                                        style="border-radius: 50%;pointer-events: none;">
                            </div>
                            <div class="text_wrapper">


                                <!--
                                                                <div style="padding: 3px 14px;
                                border-radius: 30px;
                                border: 1px solid #333;
                                float: right;">Manager</div>
                                -->
                                <div class="text"></div>
                            </div>
                        </li>
                    </div>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" onclick="terminate()" data-dismiss="modal">Close
                    </button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="addMessage">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content" style="border:5px solid #3ca1eb;">

                <!-- Modal Header -->
                <div class="modal-header" style="background-color:#3ca1eb;padding: 0.5em;border-radius: 0;">
                    <h4 class="modal-title" style="text-align: center;color:#fff ;"><i class="fa fa-edit"></i>Create New
                        Message</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">

                    <form id="newMsg">
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="col col-md-3">
                                    <label class="control-label" for="name">Staff</label>
                                </div>
                                <input id="name" name="staffName" disabled="true" type="text" placeholder="Staff name"
                                       class="form-control col-md-9"
                                       value="{{ \Illuminate\Support\Facades\Session::get('staff_detail')['name']." ".\Illuminate\Support\Facades\Session::get('staff_detail')['last_name']}}">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="col col-md-3">
                                    <label class="control-label" for="name">Recipient</label>
                                </div>
                                <select name="receiver"
                                        class="form-control col-md-9 selectReceiverName js-states form-control"
                                        id="id_label_single">
                                    <option style="max-height:50px;overflow: auto;" value="1">Admin</option>
                                    {{--<span id="option1"></span>--}}
                                    <option style="max-height:50px;overflow: auto;" value="2">Manager</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="col-md-3">
                                    <label for="textarea-input" class=" form-control-label">Message</label>
                                </div>
                                <textarea name="message" id="message" rows="5"
                                          placeholder="Type Message here..."
                                          class="form-control col-md-9 senderMessage"></textarea>
                                <span id="messgData"></span>
                                <div class="col-lg-12" style="text-align: center;margin:4% 0;">

                                    <button class="btn btn-success addMessageBtn" onclick="checkMessage()" type="button"
                                            style="padding: 7.5px 10px;">Send
                                        Message
                                    </button>
                                    <button type="button" onclick="cancelBtn()" class="btn btn-danger"
                                            data-dismiss="modal">Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('page-scripts')
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="/staffAssets/js/toastr/toastr.min.js"></script>
    <script type="text/javascript">
        var $avtar = "{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}";
        (function () {
            var Message;
            Message = function (arg) {
                this.text = arg.text, this.message_side = arg.message_side;
                this.draw = function (_this) {
                    return function () {
                        var $message;
                        $message = $($('.message_template').clone().html());
                        $message.addClass(_this.message_side).find('.text').html(_this.text);
                        // $('.messages').append($message);
                        return setTimeout(function () {
                            return $message.addClass('appeared');
                        }, 0);
                    };
                }(this);
                return this;
            };
            $(function () {
                var getMessageText, message_side, sendMessage;
                message_side = 'right';
                getMessageText = function () {
                    var $message_input;
                    $message_input = $('.message_input');
                    return $message_input.val();
                };
                sendMessage = function (text) {
                    var $messages, message;
                    if (text.trim() === '') {
                        return;
                    }
                    $('.message_input').val('');
                    $messages = $('.messages');
                    // message_side = message_side === 'left' ? 'right' : 'left';
                    message_side = 'right';

                    message = new Message({
                        text: text,
                        message_side: message_side
                    });
                    message.draw();
                    return $messages.animate({
                        scrollTop: $messages.prop('scrollHeight')
                    }, 300);
                };
                $('.send_message').click(function (e) {
                    sendMsg();
                    return sendMessage(getMessageText());
                });
                $('.message_input').keyup(function (e) {
                    if (e.which === 13) {
                        e.preventDefault();
                        sendMsg();
                        return sendMessage(getMessageText());
                    }
                });
            });
        }.call(this));
        $('#messageTable').DataTable({
            lengthMenu: [[5, 10, 20, 50, -1], [5, 10, 20, 50, "All"]]
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function () {
            toastr.options.positionClass = "toast-top-center";
            toastr.options.progressBar = true;
            toastr.options.preventDuplicate = true;
        });

        function checkMessage() {
            var id=$('#id_label_single option:selected').attr("value");
            if(id == 0){
                toastr.error('Please select recipient..!!', {timeOut: 10000});
                return false;
            }
            var message = $('textarea#message').val().trim();
            alert(message);
            if (message.length < 1) {
                toastr.error('Message is required', {timeOut: 10000});
                return false;
            }
            $.ajax({
                url: "/staff/newMessage",
                method: "post",
                data: $('#newMsg').serializeArray(),
                // data: formdata,
                dataType: "json",
                success: function (response) {
                    if (response.msg == 200) {
                        $('#newMsg')[0].reset();
                        $('#addMessage').modal('hide');
                        toastr.success('Message Sent Successfully..!!', {timeOut: 10000});
                        location.reload();

                    } else {
                        toastr.error('Error Occured...!!', {timeOut: 10000});
                    }
                }
            });
        }

        var initial1 = 0;
        var myVar;
        var xhr;

        function getMsg(sender, receiver) {

            function getNewMessage() {
                if (initial1 == 1) {
                    myVar = setTimeout(function () {
                        getMsg(sender, receiver);
                    }, 15000);
                }
            }

            xhr = $.ajax({
                url: "/staff/getMsg",
                method: "post",
                data: {
                    senderId: sender,
                    receiverId: receiver,
                },
                dataType: "json",
                beforeSend: function () {
                    // $('.messages').html('');
                    // $('.loaderClass').addClass('show').removeClass('hide');
                    // $('.loaderClass').css('display', 'block');
                },
                success: function (response) {
                    if (response.code === 200) {
                        var msg = '';
                        var $this;
                        $.each(response.msg, function (i) {
                            $this = $(this)[0];
                            var date = getDateAndTime($this.posted_on);
                            if ($this.id == receiver) {
                                msg += '<li class="message right appeared"> ' +
                                    '<div class="avatar" tabindex="0" data-toggle="tooltip" title="Manager">' +
                                    '<a href="{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}" target="_blank"><img src="{{\Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}" alt="" style="border-radius: 50%;pointer-events: none;"></a>' +
                                    '</div> <div class="text_wrapper"> ' +
                                    '<div class="text">' + $this.message + '</div>' +
                                    '<span class="direct-chat-timestamp pull-right">' + date + '</span>' +
                                    '<span class="direct-chat-timestamp pull-left">{{\Illuminate\Support\Facades\Session::get('staff_detail')['name']." ".\Illuminate\Support\Facades\Session::get('staff_detail')['last_name']}}_ Staff</span>' +
                                    ' </div>' +
                                    ' </li>';
                            }else if ($this.id == 1){
                                msg += '<li class="message left appeared"> ' +
                                    '<div class="avatar" tabindex="0" data-toggle="tooltip" title="Admin">' +
                                    '<a href="{{\Illuminate\Support\Facades\Session::get('AdminImage')}}" target="_blank"><img src="{{\Illuminate\Support\Facades\Session::get('AdminImage')}}" alt="" style="border-radius: 50%;pointer-events: none;"></a></div>' +
                                    ' <div class="text_wrapper"> <div class="text">' + $this.message + '</div>' +
                                    '<span class="direct-chat-timestamp pull-right">' + date + '</span>' +
                                    '<span class="direct-chat-timestamp pull-left">Admin</span>' +
                                    ' </div>' +
                                    ' </li>';
                            }
                            else {
                                msg += '<li class="message left appeared"> ' +
                                    '<div class="avatar" tabindex="0" data-toggle="tooltip" title="Manager">' +
                                    '<a href="'+ response.profile +'" target="_blank"><img src="' + response.profile + '" alt="" style="border-radius: 50%;pointer-events: none;"></a></div>' +
                                    ' <div class="text_wrapper"> <div class="text">' + $this.message + '</div>' +
                                    '<span class="direct-chat-timestamp pull-right">' + date + '</span>' +
                                    '<span class="direct-chat-timestamp pull-left">' + response.name + '</span>' +
                                    ' </div>' +
                                    ' </li>';
                            }
                        });
                        $('#messageModal').find('.modal-body .messages').html(msg);
                        $('.messages').scrollTop(100000000000000000);
                        document.getElementById("receiverId").value = sender;
                        $('#load').hide();
                        initial1 = 1;

                    } else {
                        var n = $(".messages li").length;
                        if (n == 0) {
                            $('#load').show();
                            getMsg(sender, receiver);
                        }
                        else {
                            $('#load').hide();
                        }
                    }
                    getNewMessage();
                }
            });

        }

        $(document.body).on('hidden.bs.modal', '#messageModal', function () {
            $('#message').val('');
            $('.messages').html('');
            terminate();
        });

        $("#messageModal").on('shown.bs.modal', function () {
            var n = $(".messages li").length;
            if (n == 0) {
                $('#load').show();
            }
            else {
                $('#load').hide();
            }
        });

        function terminate() {
            {{\Illuminate\Support\Facades\Session::forget('number')}}
            $('.messages').html('');
            $('#load').hide();
            xhr.abort();
            clearTimeout(myVar);
        }

        function sendMsg() {
            $.ajax({
                url: "/staff/sendMsg",
                method: "post",
                data: $("#form1").serialize(),
                dataType: "json",
                success: function (response) {

                    if (response.msg == 200) {
                        var mess = message(response.mess, response.time);
                        $('.messages').append(mess).scrollTop(100000000000000000);
                        toastr.success('Message Sent Successfully', {timeOut: 10000});
                        // $(document).find('#li').find('img').attr('src', $avtar);
                    } else if (response.msg == 400) {
                        toastr.error('Please Enter Message...!!', {timeOut: 10000});
                    } else {
                        toastr.error('Error Occured...!!', {timeOut: 10000});
                    }
                }
            });
        }

        function cancelBtn() {
            $('#newMsg')[0].reset();
        }

        function message(mess, time) {
            var msg = '';
            var name = '{{\Illuminate\Support\Facades\Session::get('staff_detail')['name']." ".\Illuminate\Support\Facades\Session::get('staff_detail')['last_name']}}_Staff';
            var pict = '{{ \Illuminate\Support\Facades\Session::get('staff_detail')['profile_pic']}}';
            var date = getDateAndTime(time);
            msg = '<li class="message right appeared">' +
                '<div class="avatar" tabindex="0" data-toggle="tooltip" title="Manager">' +
                '<a href="'+ pict +'" target="_blank"><img src="' + pict + '" alt="" style="border-radius: 50%;pointer-events: none;"></a></div>' +
                '<div class="text_wrapper">' +
                '<div class="text">' + mess + '</div>' +
                '<span class="direct-chat-timestamp pull-right">' + date + '</span>' +
                '<span class="direct-chat-timestamp pull-left">' + name + '</span>' +
                '</div></li>';
            return msg;
        }

        function getNewMsgdata() {
            $('#subject-error').hide();
            $('#message-error').hide();
            $('#newMsg')[0].reset();
            $.ajax({
                url: "/staff/getNewMsgdata",
                method: "post",
                // data: $("#form1").serialize(),
                dataType: "json",
                success: function (response) {

                    if (response.msg === 200) {
                        let arr = '';

                        $.each(response.mdata, function (key, val) {
                            if(val.id==1){
                                arr = '<option style="max-height:50px;overflow: auto;" value="0">Select Recipient</option>';
                                arr += '<option style="max-height:50px;overflow: auto;" value="' + val.id + '">' + val.first_name + " " + val.last_name + '__[Admin]</option>';
                            }else{
                                arr += '<option style="max-height:50px;overflow: auto;" value="' + val.id + '">' + val.first_name + " " + val.last_name + '__[Manager]</option>';
                            }

                        });
                        $('.selectReceiverName').html('').append(arr);

                    } else {
                        arr = '<option style="max-height:50px;overflow: auto;" value="1">Admin</option>';
                        $('.selectReceiverName').html('').append(arr);
                        // alert('Data not Found');
                    }
                }
            });
        }

        function getDateFormat(date) {
            var date = date * 1000;
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

            if (month.length < 2)
                month = '0' + month;
            if (day.length < 2)
                day = '0' + day;
            var date = new Date();
            date.toLocaleDateString();

            return [day, month, year].join('/');
        }

        function getDateFormat1(date) {
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

            if (month.length < 2)
                month = '0' + month;
            if (day.length < 2)
                day = '0' + day;
            var date = new Date();
            date.toLocaleDateString();

            return [day, month, year].join('/');
        }

        let getDateAndTime = function (getDate) {
            let date = new Date(getDate * 1000);
            let month = date.getMonth() + 1;
            let day = date.getDate();
            let hour = date.getHours();
            let min = date.getMinutes();
            let sec = date.getSeconds();

            month = (month < 10 ? "0" : "") + month;
            day = (day < 10 ? "0" : "") + day;
            hour = (hour < 10 ? "0" : "") + hour;
            min = (min < 10 ? "0" : "") + min;
            sec = (sec < 10 ? "0" : "") + sec;

            let str = date.getFullYear() + "-" + month + "-" + day + " " + hour + ":" + min + ":" + sec;

            return str;
        }
    </script>
    <script>
        $(document).ready(function () {
            if ('{{\Illuminate\Support\Facades\Session::has('sid')}}') {
                $('#messageModal').modal('show');
                getMsg('{{\Illuminate\Support\Facades\Session::get('sid')}}', '{{\Illuminate\Support\Facades\Session::get('rid')}}');
                {{\Illuminate\Support\Facades\Session::forget('rid')}}
                {{\Illuminate\Support\Facades\Session::forget('sid')}}
            }
        });
        window.onload = function () {
            $('#loader11').hide();
        }
    </script>


@endsection
