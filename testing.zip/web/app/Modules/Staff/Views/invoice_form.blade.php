<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="/staffAssets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/staffAssets/css/bootstrap-popover-x.css">
    <link rel="stylesheet" href="/staffAssets/css/font-awesome.min.css">
    <link rel="stylesheet" href="/staffAssets/css/themify-icons.css">
    <link rel="stylesheet" href="/staffAssets/css/invoice.css">
    <link rel="stylesheet" href="/staffAssets/css/flag-icon.min.css">
    <link rel="stylesheet" href="/staffAssets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="/staffAssets/css/lib/datatable/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="/staffAssets/scss/style.css">
    <link rel="stylesheet" href="/staffAssets/css/invoice.css">
    <link rel="stylesheet" href="/staffAssets/css/toastr/toastr.min.css">
    <link rel="stylesheet" href="/staffAssets/css/lib/chosen/chosen.min.css">
    <link rel="stylesheet" href="/staffAssets/css/print.css" media="print">
    {{--<script src="/staffAssets/js/vendor/jquery-2.1.4.min.js"></script>--}}
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <style>

        .form-control {
            border-bottom: 1px solid #d3d0d0;
            border-right: none;
            border-top: none;
            border-left: none;
            padding: .050rem .15rem;
        }

        .fa-window-close{
            cursor: pointer;
            display: none;
            position: absolute;

        }
        .notes .form-control {
            border: none !important;
            display: inline-block;
            /*margin: 2px;*/
        }
        .pading_5 {
            padding: 5%;
        }

        .text_right {
            text-align: right;
        }

        .header_custom {
            background-color: #3ca1eb;
            padding: 0.5em;
            border-radius: 0;
        }

        .modal_title_custom {

            text-align: center;
            color: #fff;
        }

        .modal_dialog_custom {
            max-width: 800px;
        }

        .modal_content_custom {
            border: 2px solid #3ca1eb;
        }

        .border_color {
            border: 1px solid #fff !important;
        }

        .text_color {
            color: deepskyblue;
        }

        .color-invoice .row {
            padding: 3%;
        }

        .color-invoice {
            border: 1px solid #b0aaaa;
            margin-bottom: 15px;
        }
        #myiframe .form-control{

            color: #000;
        }

        thead th {
            border-bottom-width: 1px !important;
        }

        table { page-break-inside:auto }
        textarea {page-break-inside:avoid;}

        tr    { page-break-inside:avoid; page-break-after:auto }
        textarea {
            resize: none;
        }

        select.form-control:not([size]):not([multiple]) {

            height:auto;

        }

    </style>
</head>
<body>
{{--<p style="text-align: center" ><a href="javascript:;" id="btnprint" onclick="myFunction();" class="btn btn-info btn-sm">Save as--}}
{{--PDF</a></p>--}}

<div class="container">
    <div class="row">
        <div class="col-lg-10 offset-lg-1" style="text-align: center;margin-bottom: 2%;margin-top:2%;">
            <a href="/staff/invoice" class="btn btn-primary" id="btnback"
               style="padding: 6px 35px;color: #fff;">Back</a>
            <a href="javascript:;" id="btnprint" onclick="myFunction();" class="btn btn-success">Save as PDF</a>
            {{--<a href="javascript:;" id="btnprint" onclick="demoFromHTML();" class="btn btn-success">Save as PDF</a>--}}
        </div>

        <div class="col-lg-10 offset-lg-1 page-break">
            <div class="color-invoice" id="myiframe">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <br>
                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="Company Name"
                                      class="form-control col-md-8"></textarea>
                        </div>
                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="Your Name"
                                      class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="Your Name"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>
                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="Company Address"
                                      class="form-control col-md-8"></textarea>

                            {{--<input id="name" name="name" type="text" placeholder="Company Address"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>

                        <div class="form-group">
                              <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="State"
                                        class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="State" class="form-control col-md-8">--}}
                        </div>
                        <div class="form-group">
                             <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="City,State Zip"
                                       class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="City,State Zip"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="col-lg-12">
                            <img src="/images/bluelogo.png" class="img-responsive pull-right" width="200">
                        </div>
                        <div class="col-lg-12">
                            <h3 class="text_right">Invoice</h3>
                        </div>
                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-5 ">
                        <div class="form-group">
                            <label><b>Bill To :</b></label>
                              <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden"
                                        class="form-control col-md-8"></textarea>

                            {{--<input id="name" name="name" type="text" value="Bill To:"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>

                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="Your Client's Company"
                                      class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="Your Client's Company"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>
                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="Client's Address"
                                      class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="Client's Address"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>

                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="State"
                                      class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="State" class="form-control col-md-8">--}}
                        </div>
                        <div class="form-group">
                            <textarea onkeyup="textAreaAdjust(this)" style="overflow:hidden" placeholder="City,State Zip"
                                      class="form-control col-md-8"></textarea>
                            {{--<input id="name" name="name" type="text" placeholder="City,State Zip"--}}
                                   {{--class="form-control col-md-8">--}}
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7 col-sm-7">
                        <div class="col-md-12">
                            <div class="form-group col-lg-5 col-md-5 col-sm-5">
                                <label id="name" name="name" type="text"  class="">
                                    Invoice ID:
                                </label>
                            </div>
                            <div class="form-group col-lg-7 col-md-7 col-sm-7">
                                <input id="name" name="name" type="text" placeholder="Invoice no." class="form-control" value="{{'#CO-'.time()}}">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group col-lg-5 col-md-5 col-sm-5">
                                <label id="name" name="name" type="text"
                                       class="">
                                    Invoice Date:
                                </label>
                            </div>
                            <div class="form-group col-lg-7 col-md-7 col-sm-7">
                                <input id="name" name="name" type="date" value="App 17, 2018" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group col-lg-5 col-md-5 col-sm-5">
                                <label id="name" name="name" type="text"  class="">
                                    Due Date:
                                </label>
                            </div>
                            <div class="form-group col-lg-7 col-md-7 col-sm-7">
                                <input id="name" name="name" type="date" value="App 20, 2018" class="form-control">
                            </div>
                        </div>

                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <strong>ITEM DESCRIPTION & DETAILS :</strong>
                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="table-responsive">
                            <table class="table  table-bordered" id="tab_logic">
                                <thead>
                                <tr>

                                    <th>Item Description</th>
                                    <th>Quantity.</th>
                                    <th>Rate In
                                        <select class="form-control select-currency pull-right col-md-6" tabindex="27" id="currencySelect" name="currencySelect" onchange="jsFunction();" style="padding: 0px;display:inline-block;border:1px solid #c3bcbc !important;/*! border: 1px solid black; */">
                                            <option value="USD($)">USD($)</option>
                                            <option value="KSHS(K)">KSHS(K)</option>
                                        </select>

                                    </th>
                                    <th>Amount</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr id='addr1' class="item-row"></tr>
                                <tr class="addingrow text_right">
                                    <td><a id="add_row" class="btn btn-default pull-left"><i
                                                    class="fa fa-plus-circle text_color" aria-hidden="true"></i>
                                            Add New Item</a></td>
                                    <td colspan="2">Sub Total</td>
                                    <td id="subtotal">00.00</td>
                                </tr>
                                <tr class="text_right">
                                    <td colspan="3">Tax: <input class="form-control" id="blur" type="text" value="00.00" maxlength="5"
                                                                size="4"  style="width:10%;display: inline-block;">%
                                    </td>
                                    <td id="tax">00.00</td>
                                </tr>
                                <tr class="text_right">
                                    <td colspan="3" id="totalBill"> Bill amount in USD($)</td>
                                    <td class="due" id="total">00.00</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row notes">
                    <div class="col-lg-12 col-md-12 col-sm-12 pading_5">
                        <strong>Notes: </strong>
                        <ol>
                            <li>Please crosscheck your invoice before submission.</li>
                            <li>Our accounts department will process the payments within 1-48 Hours. In case of anything you will get prior communication through Cloud office support /email/Phone.</li>
                            <li>Please make sure the invoice is detailed and include the date and name  for each task in the item description.</li>
                        </ol>
                    </div>
                </div>
                {{--<hr />--}}
                {{--<div class="row">--}}
                {{--<div class="col-lg-12 col-md-12 col-sm-12" style="text-align: center;">--}}
                {{--<a href="#" class="btn btn-success btn-sm">Upload as PDF</a>    --}}
                {{--<a href="#" class="btn btn-info btn-sm">Save as PDF</a>--}}
                {{--</div>--}}
                {{--</div>--}}

                {{--<hr>--}}
            </div>
        </div>
    </div>
</div>

<div id="loader" style="display: none">
    <div class=""
         style="padding: 0px; margin: 0px; text-align: center; color: rgb(0, 0, 0); width: 100%; height: 100%; position: fixed; top: 0%; background: rgb(6, 6, 6) none repeat scroll 0% 0%;
opacity: 0.8; z-index: 1004; cursor: wait; right: 0px;"></div>
    <div class="blockUI blockMsg blockPage "
         style="padding: 0px; margin: 0px; top: 30%; color: rgb(0, 0, 0); font-weight: normal; font-size: 20px; left: 40%; text-align: center; z-index: 999999 ! important; position: fixed; width: 30%;">
        <img src="\images\cloud_loading.gif"
             style="height:150px;display: block; margin-left: auto;margin-right: auto">
        <p style="text-align: center; font-size: 20px;color: #fff">Processing please wait...</p>
    </div>
</div>

<script src="/assets/js/vendor/jquery-2.1.4.min.js"></script>
<script src="/assets/js/plugins.js"></script>
<script src="/assets/js/main.js"></script>
<script src="/assets/js/lib/data-table/datatables.min.js"></script>
<script src="/assets/js/lib/chosen/chosen.jquery.min.js"></script>
<script src="/assets/js/file_attach.js"></script>
<script src="/assets/js/popper.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.debug.js"
        integrity="sha384-CchuzHs077vGtfhGYl9Qtc7Vx64rXBXdIAZIPbItbNyWIRTdG0oYAqki3Ry13Yzu"
        crossorigin="anonymous"></script>
<script>

    $(document).ready(function () {
        var i = 1;
        $(document).on('click', '#add_row', function (e) {
            $('#addr' + i).html("<td><textarea onkeyup='textAreaAdjust(this)' style='overflow:hidden' name='Item Description" + i + "' type='text' placeholder='Item Description' class='form-control input-md'></textarea> </td>" +
            // $('#addr' + i).html("<td><input name='Item Description" + i + "' type='text' placeholder='Item Description' class='form-control input-md'  /> </td>" +
                "<td><input placeholder='Quantity' class='form-control input-md qty'></td>" +
                "<td><input class='form-control input-md cost' placeholder='Rate'></td>" +
                // "<td><span class='price'>$0</span></td>" +
                "<td><span class='price'>Amount</span></td>" +
                "<td name='closebtn" + i + "' style='border: 1px solid #fff;'><i class='fa fa-window-close'></i></td>");

            $('.addingrow').before('<tr id="addr' + (i + 1) + '" class="item-row"></tr>');
            i++;
            bind();
            $("tbody tr").hover(function () {
                $(".fa-window-close").css("display", "none");
                $(this).find(".fa-window-close").css("display", "block");
                $(this).find(".fa-window-close").click(function () {
                    $(this).parents("tr").remove();
                    update_total();

                });
            });
            bind();
        });

    });

    function myFunction() {

        if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
            var printButton = document.getElementById("btnprint");
            printButton.style.visibility = 'hidden';
            var backButton = document.getElementById("btnback");
            backButton.style.visibility = 'hidden';
            window.print();
            printButton.style.visibility = 'visible';
            backButton.style.visibility = 'visible';
        }
        else if (navigator.userAgent.indexOf("Chrome") != -1) {
            var printButton = document.getElementById("btnprint");
            // var printUpload = document.getElementById("btnUpload");
            printButton.style.visibility = 'hidden';
            $('.fa-window-close').hide();
            // printUpload.style.visibility = 'hidden';
            var backButton = document.getElementById("btnback");
            backButton.style.visibility = 'hidden';
            window.print();
            printButton.style.visibility = 'visible';
            backButton.style.visibility = 'visible';
            $('.fa-window-close').show();
        }
        else if (navigator.userAgent.indexOf("Safari") != -1) {
            var printButton = document.getElementById("btnprint");
            printButton.style.visibility = 'hidden';
            var backButton = document.getElementById("btnback");
            backButton.style.visibility = 'hidden';
            window.print();
            printButton.style.visibility = 'visible';
            backButton.style.visibility = 'visible';
        }
        else if (navigator.userAgent.indexOf("Firefox") != -1) {
            $('#loader').show();
            var printButton = document.getElementById("btnprint");
            printButton.style.visibility = 'hidden';
            var backButton = document.getElementById("btnback");
            backButton.style.visibility = 'hidden';
            $('.fa-window-close').hide();

            let doc = new jsPDF();

            var quotes = document.getElementById('myiframe');
            html2canvas(quotes, {
                onrendered: function (canvas) {


                    var pdf = new jsPDF('p', 'pt', 'letter',true);
                    // var pdf = new jsPDF('p', 'pt','a4',true);

                    for (var i = 0; i <= quotes.clientHeight / 980; i++) {
                        //! This is all just html2canvas stuff
                        var srcImg = canvas;
                        var sX = 0;
                        var sY = 980 * i; // start 980 pixels down for every new page
                        var sWidth = 950;
                        var sHeight = 980;
                        var dX = 0;
                        var dY = 0;
                        var dWidth = 950;
                        var dHeight = 980;

                        window.onePageCanvas = document.createElement("canvas");
                        onePageCanvas.setAttribute('width', 900);
                        onePageCanvas.setAttribute('height', 980);
                        var ctx = onePageCanvas.getContext('2d');
                        ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);

                        // document.body.appendChild(canvas);
                        var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

                        var width = onePageCanvas.width;
                        var height = onePageCanvas.clientHeight;

                        if (i > 0) {
                            pdf.addPage(612, 791); //8.5" x 11" in pts (in*72)
                        }
                        //! now we declare that we're working on that page
                        pdf.setPage(i + 1);
                        //! now we add content to that page!
                        pdf.addImage(canvasDataURL, 'PNG', 20, 40, (width * .62), (height * .62),undefined,'Medium');
                        // pdf.addImage(canvasDataURL, 'PNG', 20, 120, 485, 270,'','FAST');
                        // pdf.addImage(canvasDataURL, 'JPEG', 20, 40, (width * .62), (height * .62));

                    }
                    $('#loader').hide();
                    pdf.save('CO-Inv.pdf');
                }
            });
            printButton.style.visibility = 'visible';
            backButton.style.visibility = 'visible';
            $('.fa-window-close').show();
        }
        else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
        {
            var printButton = document.getElementById("btnprint");
            printButton.style.visibility = 'hidden';
            var backButton = document.getElementById("btnback");
            backButton.style.visibility = 'hidden';
            window.print();
            printButton.style.visibility = 'visible';
            backButton.style.visibility = 'visible';
        }
        else {
            alert('unknown browser Please try Google Chrome');
        }
    }

    function update_total() {
        var total = 0;
        $('.price').each(function (i) {
            price = $(this).html().replace("$", "");
            if (!isNaN(price)) total += Number(price);
        });

        total = roundNumber(total, 2);

        $('#subtotal').html("" + total);
        $('#total').html("" + total);
        bill();

        update_balance();
    }

    function update_balance() {
        var due = parseFloat($("#total").html().replace("$", "")) + parseFloat($("#tax").html().replace("$", ""));
        due = roundNumber(due, 2);
        $('#total').html("" + due);
        bill();
    }

    function bind() {
        $(".cost").blur(update_price);
        $(".qty").blur(update_price);
    }

    function update_price() {

        var row = $(this).parents('.item-row');

        // alert( row.find('.qty').val());
        // alert('quan  &&  Rate');
        // alert( row.find('.cost').val());

        var price = row.find('.cost').val().replace("$", "") * row.find('.qty').val();
        price = roundNumber(price, 2);
        isNaN(price) ? row.find('.price').html("N/A") : row.find('.price').html("" + price);

        update_total();
    }

    function roundNumber(number, decimals) {
        var newString;// The new rounded number
        decimals = Number(decimals);
        if (decimals < 1) {
            newString = (Math.round(number)).toString();
        } else {
            var numString = number.toString();
            if (numString.lastIndexOf(".") == -1) {// If there is no decimal point
                numString += ".";// give it one at the end
            }
            var cutoff = numString.lastIndexOf(".") + decimals;// The point at which to truncate the number
            var d1 = Number(numString.substring(cutoff, cutoff + 1));// The value of the last decimal place that we'll end up with
            var d2 = Number(numString.substring(cutoff + 1, cutoff + 2));// The next decimal, after the last one we want
            if (d2 >= 5) {// Do we need to round up at all? If not, the string will just be truncated
                if (d1 == 9 && cutoff > 0) {// If the last digit is 9, find a new cutoff point
                    while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
                        if (d1 != ".") {
                            cutoff -= 1;
                            d1 = Number(numString.substring(cutoff, cutoff + 1));
                        } else {
                            cutoff -= 1;
                        }
                    }
                }
                d1 += 1;
            }
            if (d1 == 10) {
                numString = numString.substring(0, numString.lastIndexOf("."));
                var roundedNum = Number(numString) + 1;
                newString = roundedNum.toString() + '.';
            } else {
                newString = numString.substring(0, cutoff) + d1.toString();
            }
        }
        if (newString.lastIndexOf(".") == -1) {// Do this again, to the new string
            newString += ".";
        }
        var decs = (newString.substring(newString.lastIndexOf(".") + 1)).length;
        for (var i = 0; i < decimals - decs; i++) newString += "0";
        //var newNumber = Number(newString);// make it a number if you like
        return newString; // Output the result to the form field (change for your purposes)
    }

    $(document).ready(function () {
        $("#blur").blur(function () {
            bill();
        });
    });

    function bill() {
        if ($("#blur").val() == 0) {
            $("#tax").html('00.00');
        } else {
            // var amount = ($("#subtotal").html().slice(1)) * ($("#blur").val()) * .01;
            var amount = ($("#subtotal").html()) * ($("#blur").val()) * .01;
            $("#tax").html('' + amount.toFixed(2));
            var total = parseFloat(parseFloat($("#subtotal").html())) + parseFloat(($("#tax").html()));
            $("#total").html('' + total.toFixed(2));
        }
    }

    function textAreaAdjust(o) {
        o.style.height = "1px";
        o.style.height = (o.scrollHeight)+"px";
    }


    function jsFunction() {
        var symbol=$('#currencySelect :selected').val();
        $('#totalBill').html("Bill amount in " + symbol);
    }






</script>
</body>
</html>
