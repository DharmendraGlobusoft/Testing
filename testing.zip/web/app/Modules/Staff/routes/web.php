<?php

Route::group(['module' => 'Staff', 'middleware' => ['web'], 'namespace' => 'App\Modules\Staff\Controllers'], function() {

    //    ****************************StaffController*******************

    Route::get('/staff/login', 'StaffController@login');

    Route::get('/', 'StaffController@login');
    Route::post('/sendContactForm', 'StaffController@sendContactForm');

    Route::get('/staff', 'StaffController@login');
    Route::post('/staff/login', 'StaffController@login');
    Route::get('/activateAccount/{confirmation_code}', 'StaffController@activateAccount');
    Route::get('/changePassword/{changePassword}', 'StaffController@changePassword');
    Route::post('/staff/changePassword/{changePassword}', 'StaffController@changePassword');
    Route::get('staff/sign-up/{confirmation_code}', 'StaffController@registerInvitationLink');

    Route::post('/staff/ajaxVerify', 'StaffController@ajaxVerify');
    Route::post('/staff/verifyEmail', 'StaffController@verifyEmail');
    Route::post('/staff/register', 'StaffController@register');
    Route::get('/staff/register', 'StaffController@register');
    Route::get('/staff/forgetPassword', 'StaffController@forgetPassword');
    Route::post('/staff/forgetPassword', 'StaffController@forgetPassword');


    Route::get('/staff/projectInvitation/{userId}/{projectId}', 'ProjectController@projectInvitation');
    Route::get('/staff/taskInvitation/{userId}/{projectId}/{taskId}', 'TaskSubmitionController@taskInvitation');
    Route::get('/staff/issueInvitation/{userId}/{projectId}/{issueId}', 'IssueController@issueInvitation');
    Route::get('/staff/invoicePaid/{userId}/{invoiceId}', 'InvoiceController@invoicePaid');


    //    ****************************middleware*******************

    Route::group(['middleware'=>['CheckSession:staff']],function (){

        //    ****************************DashboardController*******************

        Route::get('/staff/dashboard', 'DashboardController@dashboard');
        Route::get('/staff/myProfile', 'DashboardController@myProfile');
        Route::post('/staff/myProfile', 'DashboardController@myProfile');
        Route::post('/staff/updatePic', 'DashboardController@updatePic');
        Route::post('/staff/updateProfileAjaxHandler', 'DashboardController@updateProfileAjaxHandler');
        Route::post('/staff/getProfileData', 'DashboardController@getProfileData');
        Route::post('/staff/password', 'DashboardController@password');
        Route::post('/staff/updatePassword', 'DashboardController@updatePassword');
        Route::post('/staff/updateDetails', 'DashboardController@updateDetails');
        Route::get('generate-pdf', 'DashboardController@pdfview')->name('generate-pdf');
        Route::get('/staff/logout', 'DashboardController@logout');
        Route::get('/taskAjaxHandler', 'DashboardController@taskAjaxHandler');
        Route::post('/taskAjaxHandler', 'DashboardController@taskAjaxHandler');
        Route::get('/issueListAjaxHandler', 'DashboardController@issueListAjaxHandler');
        Route::post('/issueListAjaxHandler', 'DashboardController@issueListAjaxHandler');
        Route::get('/milestoneAjaxHandler', 'DashboardController@milestoneAjaxHandler');
        Route::post('/staff/getAllCountInChart', 'DashboardController@getAllCountInChart');


        //    ****************************MessageController*******************

        Route::get('/staff/redirectToMessage', 'MessageController@redirectToMessage');
        Route::post('/staff/redirectToMessage', 'MessageController@redirectToMessage');
        Route::get('/staff/message', 'MessageController@message');
        Route::post('/staff/getMsg', 'MessageController@getMsg');
        Route::post('/staff/newMessage', 'MessageController@newMessage');
        Route::post('/staff/getNewMsgdata', 'MessageController@getNewMsgdata');
        Route::post('/staff/sendMsg', 'MessageController@sendMsg');

        //    ****************************ProjectController*******************

        Route::get('/staff/projects', 'ProjectController@projects');
        Route::get('/staff/viewMore/{id}', 'ProjectController@viewMore');
        Route::post('/projectDataAjaxHandler', 'ProjectController@projectDataAjaxHandler');
        Route::get('/projectAjaxHandler', 'ProjectController@projectAjaxHandler');
        Route::post('/projectAjaxHandler', 'ProjectController@projectAjaxHandler');

        //    ****************************SupportController*******************

        Route::get('/staff/supportTicket', 'SupportController@supportlist');
        Route::get('/staff/supportTicket/{id}', 'SupportController@supportlist');
        Route::get('/staff/ticketsInfoAjaxHandler', 'SupportController@ticketsInfoAjaxHandler');
        Route::post('/staff/ticketsInfoAjaxHandler', 'SupportController@ticketsInfoAjaxHandler');
        Route::post('/staff/addNewTicket', 'SupportController@addNewTicket');
        Route::post('/staff/updateStatusOfTicket', 'SupportController@updateStatusOfTicket');
        Route::post('/staff/fetchTicketReply', 'SupportController@fetchTicketReply');
        Route::post('/staff/sendReplyForTicket', 'SupportController@sendReplyForTicket');
        Route::get('/staff/view-queries', 'SupportController@viewQueries');


        //    ****************************TaskSubmitionController*******************

        Route::get('/stff/taskSubmittion', 'TaskSubmitionController@taskSubmittion');
        Route::post('/stff/taskSubmittion', 'TaskSubmitionController@taskSubmittion');
        Route::get('/staff/viewSubmittion/{projectId}/{taskId}', 'TaskSubmitionController@viewSubmittion');
        Route::post('/viewTaskSubmittion', 'TaskSubmitionController@viewTaskSubmittion');
        Route::post('/viewTaskSubmittionAllFiles', 'TaskSubmitionController@viewTaskSubmittionAllFiles');
        Route::post('/staff/postComment', 'TaskSubmitionController@postComment');
        Route::post('/staff/getComment', 'TaskSubmitionController@getComment');
        Route::post('/staff/deleteComment', 'TaskSubmitionController@deleteComment');
        Route::post('/staff/editComment', 'TaskSubmitionController@editComment');
        Route::post('/staff/finalTaskSubmission', 'TaskSubmitionController@finalTaskSubmission');

        //    ****************************Copyscape Route*******************

        Route::get('/staff/copyScape', 'CopyScapeController@copyScape');

        //    ****************************Issue Controller*******************

        Route::get('/staff/issueSubmittion/{proj_Id}/{issue_Id}', 'IssueController@issueSubmittion');
        Route::post('/staff/issueFileSubmittion', 'IssueController@issueFileSubmittion');
        Route::post('/staff/issueFileSubmittionAllFiles', 'IssueController@issueFileSubmittionAllFiles');
        Route::post('/staff/postIssueComment', 'IssueController@postIssueComment');
        Route::post('/staff/getIssueComment', 'IssueController@getIssueComment');
        Route::post('/staff/deleteIssueComment', 'IssueController@deleteIssueComment');
        Route::post('/staff/editIssueComment', 'IssueController@editIssueComment');
        Route::post('/staff/finalIssueSubmission', 'IssueController@finalIssueSubmission');

        //    ****************************Notification Controller *******************

        Route::get('/staff/feeds', 'NotificationController@feeds');
        Route::post('/staff/feedsNoti', 'NotificationController@feedsNoti');
        Route::post('/staff/getNotification', 'NotificationController@getNotification');

        //    ****************************Invoice Controller *******************

        Route::get('/staff/invoiceDetails', 'InvoiceController@invoiceDetails');
        Route::get('/staff/invoiceDataAjaxHandler', 'InvoiceController@invoiceDataAjaxHandler');
        Route::post('/staff/invoiceDataAjaxHandler', 'InvoiceController@invoiceDataAjaxHandler');
        Route::post('/staff/fetchFile', 'InvoiceController@fetchFile');
        Route::post('/staff/insertInvoiceComment', 'InvoiceController@insertInvoiceComment');
        Route::post('/staff/fetchInvoiceData', 'InvoiceController@fetchInvoiceData');
        Route::post('/staff/deleteInvoiceData', 'InvoiceController@deleteInvoiceData');
        Route::post('/staff/updateInvoiceData', 'InvoiceController@updateInvoiceData');
        Route::post('/staff/updateInvoiceComment', 'InvoiceController@updateInvoiceComment');
        Route::post('/staff/sendTransationId', 'InvoiceController@sendTransationId');
        Route::get('/staff/invoice-comment/{id}', 'InvoiceController@invoiceComment');
        Route::post('/staff/invoice', 'InvoiceController@invoice');
        Route::get('/staff/invoice', 'InvoiceController@invoice');
        Route::post('/staff/getInvoiceComment', 'InvoiceController@getInvoiceComment');
        Route::get('/staff/invoice_form', function (){
            return view('Staff::invoice_form');
        });

        Route::get('/staff/resource-page', 'ResourceController@resourcePage');
        Route::get('/staff/add-resource-page', 'ResourceController@addResourcePage');
        Route::get('/staff/view-resource-page/{id}', 'ResourceController@showMoreResources');
        Route::post('/staff/insertResourceData', 'ResourceController@insertResourceData');
        Route::post('/staff/getContents', 'ResourceController@getContents');
        Route::post('/staff/getMoreContents', 'ResourceController@getMoreContents');


    });
});













