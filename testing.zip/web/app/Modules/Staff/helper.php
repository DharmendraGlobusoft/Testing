<?php

/**
 *	Staff Helper  
 */



if (! function_exists('checkCopyScape')) {
    function checkCopyScape()
    {
        return 'Hii';
    }
}

if (!function_exists('uploadImageToStoragePathStaff')) {
    /**
     * Upload image to storage path
     * @param $image
     * @param null $folderName Folder name (mainFolder_subFolder_subSubFolder)
     * @param null $fileName
     * @param int $imageWidth
     * @param int $imageHeight
     * @return bool|string
     * @author Bandana Sahu
     * @since 16th-Apr-2018
     */
    function uploadImageToStoragePathStaff($image, $folderName = null, $fileName = null, $imageWidth = 1024, $imageHeight = 1024)
    {
        ini_set('memory_limit', '-1');
        $destinationFolder = $folderName;
        if ($folderName != '') {
            $folderNames = explode('_', $folderName);
            $folderPath = implode('/', array_map(function ($value) {
                return $value;
            }, $folderNames));
            $destinationFolder = $folderPath . '/';
        }
        $destinationPath = public_path($destinationFolder);
        if (!File::exists($destinationPath)) File::makeDirectory($destinationPath, 0777, true, true);
        $filename = ($fileName != '') ? $fileName : $folderName . '_' . time() . '.txt';

        //for file upload
        if($image) $image->move($destinationPath,$filename);
        return $filename;
    }
}




?>





