<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 5/16/2018
 * Time: 10:54 AM
 */

namespace App\Modules\Staff\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mockery\Exception;


class StaffModel extends Model
{
    public static function getInstance()
    {
        if (!is_object(self::$_instance)) {
            self::$_instance = new StaffModel();
        }
        return self::$_instance;
    }
}