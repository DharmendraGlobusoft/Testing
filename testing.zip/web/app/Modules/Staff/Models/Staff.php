<?php

namespace App\Modules\Staff\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Mockery\Exception;

class Staff extends Model
{

//    ************************Eloquent Model*********************


    protected static $_instance = null;
    protected $tableName = 'users';


//************************Creating Instance********************

    public static function getInstance()
    {
        if (!is_object(self::$_instance)) {
            self::$_instance = new Staff();
        }
        return self::$_instance;
    }

//******************************getData**************************

    public function getData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->first();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

//*************************register************************


    public function register($data)
    {
        try {
            return DB::table($this->tableName)->insertGetId($data);
        } catch (Exception $e) {
            return 0;
        }
    }
//    invitationLink

//*************************Invitation Link verify************************


    public function invitationLink($data)
    {
        try {
            return DB::table('invite_links')
                ->where('token', $data)->get();
        } catch (Exception $e) {
            return 0;
        }
    }

//**********************Deactive Invitation Link******************************

    public function deactiveInvitationLink($data)
    {
            try {
                $result = DB::table('invite_links')
                    ->where('token',$data )
                    ->update(['token'=>'']);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
    }



    //********************************updateData************************************


    public function updateData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table($this->tableName)
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);
                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }


//***************************manageAccount*************************


    public function manageAccount($data)
    {
        try {
            return DB::table($this->tableName)
                ->where('id', $data)
                ->delete();
        } catch (Exception $e) {
            return 0;
        }
    }



//*******************************getUserdata*******************************


    public function getUserdata($where, $data = ['*'])
    {
        try {
            $result = DB::table($this->tableName)
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($data)
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

//    *****************************staffDetails*********************

    public function staffDetails($data)
    {
        $arr = array();
        try {
            foreach ($data as $key => $value) {
                $arr[$key] = DB::table($this->tableName)->where('id', $value)->value('name');
            }
        } catch (\Exception $exc) {
            return 0;
        }
        return $arr;
    }

// this is also one way to do the same thing
//    public function updateData()
//    {
//        if (func_num_args() > 0) {
//            $where = func_get_arg(0);
//            $data = func_get_arg(1);
////            dd($where,$data);
//            try {
//                $result = DB::table($this->tableName)
//                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
//                    ->update($data);
//
//                return $result ? $result : 0;
//            } catch (\Exception $exc) {
////                echo $exc->getMessage();
//                return 0;
//            }
//        } else {
//            echo 'Argument not passed!';
//        }
//    }



//    ************************projectData*********************************


    public function projectData()
    {
        try {
            return DB::table('projects')->get();
        } catch (\Exception $exc) {
            return 0;
        }
    }


    //    ************************************dataProject**********************

    public function dataProject($id)
    {
        try {
            return DB::table('projects')->where('project_id', $id)->get();
        } catch (\Exception $exc) {
            return 0;
        }
    }


    public function getProjectData($where, $data = ['*'])
    {
        try {
            $result = DB::table('projects')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($data)
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }


    public function getInvoiceComment($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('invoice_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }



//    **************************pendingIssues************************

    public function pendingIssues($where, $data = ['*'])
    {
        try {
            $result = DB::table('issues')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($data)
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

    public function getMilestoneDetails($where, $data = ['*'])
    {
        try {
            $result = DB::table('milestones')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($data)
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

    //    ***********************************issueData*************************

    public function issueData()
    {
        try {
            return DB::table('issues')->get();
        } catch (\Exception $exc) {
            return 0;
        }
    }

    public function updateIssueData($where, $data = ['*'])
    {
//        dd($where,$data);
        if (func_num_args() > 0) {
            try {
                $result = DB::table('issues')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }


//    ***********************************tasktData*************************

    public function tasktData()
    {
        try {
            return DB::table('tasks')->get();
        } catch (\Exception $exc) {
            return 0;
        }
    }

    public function getTaskData($where, $data = ['*'])
    {
        try {
            $result = DB::table('tasks')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->select($data)
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

    public function updateTaskData($where, $data = ['*'])
    {
//        dd($where,$data);
        if (func_num_args() > 0) {
            try {
                $result = DB::table('tasks')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }


    //    ***********************************invoice*************************

    public function invoice($data)
    {
        try {
            return DB::table('invoice_form')->insertGetId($data);
        } catch (Exception $e) {
//            echo $e->getMessage();
            return 0;
        }
    }

    //    ***********************************supportTicket*************************

    public function supportTicket($data)
    {
        try {
            return DB::table('support_tickets')->insertGetId($data);
        } catch (Exception $e) {
            return 0;
        }
    }


    //    *******************************supportTickets*************************

    public function supportTickets($where)
    {
        try {
            $result = DB::table('support_tickets')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

    //    ***********************************newMessage*************************

    public function newMessage($data)
    {
        try {
            return DB::table('messages')->insertGetId($data);
        } catch (Exception $e) {
            return 0;
        }
    }

//    ***********************************getMsgData*************************

    public function getMsgData($where, $data = ['*'])
    {
//        dd($where, $data);
        if (func_num_args() > 0) {
            try {
                $result = DB::table('messages')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    //    *******************************updateMsgData*************************

    public function updateMsgData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('messages')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }



    //    *******************************getSupportChat*************************


    public function getSupportChat($where)
    {
        try {
            $result = DB::table('ticket_replies')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->get();
            return $result ? $result : 0;
        } catch (\Exception $exc) {
            return 0;
        }
    }

    //    *******************************sendSupportChat*************************

    public function sendSupportChat($data)
    {
        try {
            return DB::table('ticket_replies')->insertGetId($data);
        } catch (Exception $e) {
            return 0;
        }
    }

    //**************************comment******************************

    public function comment($data)
    {
        try {
            return DB::table('task_comments')->insertGetId($data);
        } catch (Exception $e) {
//            echo $e->getMessage();
            return 0;
        }
    }

    public function getComment($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('task_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function getCommentDetail($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('task_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->first();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function deleteComment($data)
    {
        try {
            return DB::table('task_comments')
                ->where('task_comment_id', $data)
                ->delete();
        } catch (Exception $e) {
            return 0;
        }
    }

    public function updateComment()
    {
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            $data = func_get_arg(1);
//            dd($where,$data);
            try {
                $result = DB::table('task_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    //***************************IssueComments*****************************************
    public function issueComment($data)
    {
        try {
            return DB::table('issue_comments')->insertGetId($data);
        } catch (Exception $e) {
//            echo $e->getMessage();
            return 0;
        }
    }
    public function getIssueDetail($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('issue_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->first();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }
    public function getIssueComment($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('issue_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    public function deleteIssueComment($data)
    {
        try {
            return DB::table('issue_comments')
                ->where('issue_comment_id', $data)
                ->delete();
        } catch (Exception $e) {
            return 0;
        }
    }

    public function updateIssueComment()
    {
        if (func_num_args() > 0) {
            $where = func_get_arg(0);
            $data = func_get_arg(1);
//            dd($where,$data);
            try {
                $result = DB::table('issue_comments')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->update($data);

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }
    }

    //************************************Resource Data*************************************

    public function resourceData($where, $data = ['*'])
    {
        if (func_num_args() > 0) {
            try {
                $result = DB::table('resources')
                    ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                    ->get();

                return $result ? $result : 0;
            } catch (\Exception $exc) {
//                echo $exc->getMessage();
                return 0;
            }
        } else {
            echo 'Argument not passed!';
        }

    }

    //    *******************************sendSupportChat*************************

    public function resourceDetails($where)
    {
        try {
            $result = DB::table('resources')
                ->whereRaw($where['rawQuery'], isset($where['bindParams']) ? $where['bindParams'] : array())
                ->get();

            return $result ? $result : 0;
        } catch (Exception $e) {
            return 0;
        }
    }


    public function milestoneData()
    {
        try {
            $result = DB::table('milestones')
                ->get();

            return $result ? $result : 0;
        } catch (Exception $e) {
            return 0;
        }
    }

}
