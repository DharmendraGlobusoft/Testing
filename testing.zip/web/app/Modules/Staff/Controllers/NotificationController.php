<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/8/2018
 * Time: 7:30 PM
 */

namespace App\Modules\Staff\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Notification;
use App\Modules\Staff\Models\Staff;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;

class NotificationController extends Controller
{
    /**
     * Function name: getNotification
     * Desc : Function to return notification count and new notification
     * @param Request $request
     * @return 200 for success and data
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getNotification(Request $request)
    {
        $userId=Session::get('staff_detail')['id'];
        $result=DB::table('notifications')->where([
            ['receiver_id', '=', $userId],
            ['notification_status', '=', '0'],
        ])->get();
        $noti=json_decode(json_encode($result,true),true);
        $count=count($result);
        if(empty($noti)){
            return Response::json(['status' => 198, 'count'=>0]);
        } else {
            $total = DB::table('notifications')->where([
                ['receiver_id', '=', $userId]
            ])->get();
            $totalNotification = json_decode(json_encode($total, true), true);
            $difference = count($totalNotification) - 50;
            if ($difference > 0) {
                $i = 0;
                foreach ($totalNotification as $val) {
                    if ($val['notification_status'] == 1) {
                        DB::table('notifications')->where('notification_id', $val['notification_id'])->delete();
                        $i++;
                    }
                    if ($i == $difference) {
                        break;
                    }
                }
            }
        }
        return Response::json(['status' => 200, 'count'=>$count]);
    }

    /**
     * Function name: feeds
     * Desc : Function to return feeds data
     * @param Request $request
     * @return $allFeedData
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function feeds(\Illuminate\Http\Request $request)
    {
        ini_set('memory_limit', '-1');
        $dataToFetch=['t1.receiver_message','t1.created_at','t1.notify_type','t2.name','t2.role','t2.profile_pic'];
        $whereToFetch = ['rawQuery' => 'receiver_id = ?', 'bindParams' => [Session::get('staff_detail')['id']]];
        $allFeedData = json_decode(Notification::getInstance()->fetchFeedData($whereToFetch,$dataToFetch));
        foreach ($allFeedData as $val){
            if ($val->role == 'A'){
                $val->name=$val->name.'_[Admin]';
            }if ($val->role == 'M'){
                $val->name=$val->name.'_[Manager]';
            }
        }
        usort($allFeedData, function ($a, $b) {
            return $b->created_at - $a->created_at;
        });
        $dataToUpdate = ['notification_status' => '1'];
        $updateFeedStatus = Notification::getInstance()->updateNotificationDetails($whereToFetch, $dataToUpdate);
        return view('Staff::feeds', ['allFeed' => $allFeedData]);
    }

    public function feedsNoti(Request $request){
        dd('okk');
        return Response::json(['status' => 200, 'noti' => '']);
    }

}