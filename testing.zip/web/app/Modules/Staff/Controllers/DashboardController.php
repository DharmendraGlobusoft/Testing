<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/24/2018
 * Time: 11:06 AM
 */

namespace App\Modules\Staff\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class DashboardController extends Controller
{

    /**
     * Function name: dashboard
     * Desc : Function to return to Dashboard
     * @param Request $request
     * @return view to Dashboard
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function dashboard(Request $request)
    {
        if ($request->isMethod('get')) {
            $array=array();
            $taskDetails=array();

            $userId = Session::get('co_staff');
            $res = json_decode(json_encode(Staff::getInstance()->tasktData(), true), true);
            foreach ($res as $key => $value) {
                $staff = $res[$key]['task_assign_to'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if (in_array("$userId", $staff)) {
                    $taskDetails['project_id'] = $value['project_id'];
                    $projectId = $value['project_id'];
                    $projectName = json_decode(json_encode(Staff::getInstance()->dataProject($projectId), true), true);
                    $taskDetails['project_name'] = $projectName[0]['project_name'];
                    $array[]=$taskDetails;
                }
            }

            $res = json_decode(json_encode(Staff::getInstance()->issueData(), true), true);
            $issueData = array();
            if ($res) {
                foreach ($res as $key => $value) {
                    $staff = $res[$key]['issue_assign_to'];
                    $staff = substr($staff, 1, -1);
                    $staff = explode(',', $staff);
                    if (in_array($userId, $staff)) {
                        $issueDetails['project_id'] = $value['project_id'];
                        $projectId = $value['project_id'];
                        $projectName = json_decode(json_encode(Staff::getInstance()->dataProject($projectId), true), true);
                        $issueDetails['project_name'] = $projectName[0]['project_name'];
                        $issueData[] = $issueDetails;
                    }
                }
            }
            function unique_multidim_array($array, $key) {
                $temp_array = array();
                $i = 0;
                $key_array = array();

                foreach($array as $val) {
                    if (!in_array($val[$key], $key_array)) {
                        $key_array[$i] = $val[$key];
                        $temp_array[$i] = $val;
                    }
                    $i++;
                }
                return $temp_array;
            }
//            $projectData=functionToGetStaffProjectNames();
            $details = unique_multidim_array($array,'project_id');
            $issueDetails = unique_multidim_array($issueData,'project_id');
            return view('Staff::dashboard',['projectName'=>$details,'issueProjectName'=>$issueDetails]);
        }
    }

    /**
     * Function name: myProfile
     * Desc : Function to return to myProfile page with country codes
     * @param Request $request
     * @return view to myProfile
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function myProfile(Request $request)
    {
        if ($request->isMethod('get')) {
            $code = json_decode(json_encode(DB::table('countrycode')->get(), true), true);
            return view('Staff::myProfile', ['code' => $code]);
        }
    }

    /**
     * Function name: logout
     * Desc : Function to return to login page
     * @param Request $request
     * @return view to login page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function logout()
    {
        Session::forget('co_staff');
        Session::forget('staff_detail');
        if (Session::has('number')) {
            Session::forget('number');
        }
        if (Session::has('AdminImage')) {
            Session::forget('AdminImage');
        }
        return redirect('/staff/login');
    }

    /**
     * Function name: taskAjaxHandler
     * Desc : Function to return to task details to the Dashboard
     * @param Request $request
     * @return DataTables to Dashboard page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function taskAjaxHandler(Request $request)
    {
        $userId = Session::get('co_staff');
        $res = json_decode(json_encode(Staff::getInstance()->tasktData(), true), true);
        $taskDoc = [];
            $i = 0;
            foreach ($res as $key => $value) {
                $staff = $res[$key]['task_assign_to'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if (in_array("$userId", $staff)) {
                    $taskDetails['task_topic'] = $value['task_topic'];
                    $taskDetails['task_id'] = $value['task_id'];
                    $taskDetails['project_id'] = $value['project_id'];
                    $taskDetails['created_at'] = $value['created_at'];
                    $projectId = $value['project_id'];
                    $projectName = json_decode(json_encode(Staff::getInstance()->dataProject($projectId), true), true);
                    $taskDetails['project_name'] = $projectName[0]['project_name'];
                    $taskDetails['task_due_date'] = $value['task_due_date'] ? date('m-d-Y', $value['task_due_date']) : '--';

                    if ($value['task_status'] == 1) {
                        $taskDetails['task_status'] = '<a class="text-success" style="cursor: text">Completed</a>';
                    } else {
                        $taskDetails['task_status'] = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                    }

                    if ($value['priority'] == 1) {
                        $taskDetails['priority'] = 'Low';
                    } elseif ($value['priority'] == 2) {
                        $taskDetails['priority'] = 'Medium';
                    } elseif ($value['priority'] == 3) {
                        $taskDetails['priority'] = 'High';
                    } elseif ($value['priority'] == 0) {
                        $taskDetails['priority'] = 'None';
                    }
                    $taskDoc[$i] = $taskDetails;
                    $i++;
                }
            }
        $filterData=$taskDoc;
        $timeFilter=array();
        $monthFilter=array();
        $projectFilter=array();
        $viewFilter=array();

        if ($request->isMethod('post')){
            if ($request->all()['id'] == 'time'){
                if ($request->all()['value'] == 1){
                    foreach ($filterData as $key => $val){
                        if (date('d F Y',$val['created_at']) == date('d F Y',time())){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 2){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 3){
                    $a=time() - (86400*30);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }
                }
                if($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $timeFilter[]=$val;
                    }
                }
                $taskDoc=$timeFilter;
            }

            if ($request->all()['id'] == 'month'){
                foreach ($filterData as $key => $val){
                    if (date('m Y',$val['created_at']) == $request->all()['value']){
                        $monthFilter[]=$val;
                    }
                }
                $taskDoc=$monthFilter;
            }

            if ($request->all()['id'] == 'projectId'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $projectFilter[]=$val;
                    }
                    $taskDoc=$projectFilter;
                }else{
                    foreach ($filterData as $key => $val){
                        if ($val['project_id'] == $request->all()['value']){
                            $projectFilter[]=$val;
                        }
                    }
                    $taskDoc=$projectFilter;
                }
            }

            if ($request->all()['id'] == 'view'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $viewFilter[]=$val;
                    }
                    $taskDoc=$viewFilter;

                }elseif ($request->all()['value'] == 1){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $viewFilter[]=$val;
                        }
                    }
                    $taskDoc=$viewFilter;
                }
            }
        }

        $fullData = new Collection();
        $i = 1;
        foreach ($taskDoc as $key => $val) {
            $fullData->push([
                'serialNumber' => $i,
                'tasks' => '<p class="content_wrap">' . $val['task_topic'] . '</p>',
                'projects' => '<p class="content_wrap">' . $val['project_name'] . '</p>',
                'date' => $val['task_due_date'],
                'status' => $val['task_status'],
                'priority' => $val['priority'],
                'taskName' => $val['task_topic'],
                'projName' => $val['project_name'],
                'viewSubmittion' => '<td class="sorting_1"><a href="/staff/viewSubmittion/' . $val['project_id'] . '' . "/" . $val['task_id'] . '" class="custom_text_info">View</a> </td>',
            ]);

            $i++;
        }
        return DataTables::of($fullData)
            ->rawColumns(['viewSubmittion', 'status', 'tasks', 'projects'])
            ->make(true);
    }

    /**
     * Function name: issueListAjaxHandler
     * Desc : Function to return to issue details to the Dashboard
     * @param Request $request
     * @return DataTables to Dashboard page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function issueListAjaxHandler(Request $request)
    {
        $userId = Session::get('co_staff');
        $res = json_decode(json_encode(Staff::getInstance()->issueData(), true), true);
        $issueDoc = array();
        if ($res) {
            $i = 0;

            foreach ($res as $key => $value) {
                $staff = $res[$key]['issue_assign_to'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if (in_array($userId, $staff)) {
                    $issueDetails['project_id'] = $value['project_id'];
                    $issueDetails['issue_id'] = $value['issue_id'];
                    $issueDetails['issue_topic'] = $value['issue_topic'];
                    $issueDetails['issue_desc'] = $value['issue_desc'];
                    $issueDetails['created_at'] = $value['created_at'];
                    $issueDetails['issue_attachment_files'] = json_decode($value['issue_attachment_files'], true);
                    $projectId = $value['project_id'];
                    $projectName = json_decode(json_encode(Staff::getInstance()->dataProject($projectId), true), true);
                    $issueDetails['project_name'] = $projectName[0]['project_name'];
                    $issueDetails['due_date'] = $value['due_date'] ? date('m-d-Y', $value['due_date']) : '--';

                    if ($value['issue_status'] == 0) {
                        $issueDetails['issue_status'] = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                    } elseif ($value['issue_status'] == 1) {
                        $issueDetails['issue_status'] = '<a class="text-success" style="cursor: text">Completed</a>';
                    }


                    if ($value['severity'] == 1) {
                        $issueDetails['severity'] = 'Minor';
                    } elseif ($value['severity'] == 2) {
                        $issueDetails['severity'] = 'Major';
                    } else {
                        $issueDetails['severity'] = 'Critical';
                    }
                    $issueDoc[$i] = $issueDetails;
                    $i++;
                }
            }
        }

        $filterData=$issueDoc;
        $timeFilter=array();
        $monthFilter=array();
        $projectFilter=array();
        $viewFilter=array();

        if ($request->isMethod('post')){
            if ($request->all()['id'] == 'time'){
                if ($request->all()['value'] == 1){
                    foreach ($filterData as $key => $val){
                        if (date('d F Y',$val['created_at']) == date('d F Y',time())){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 2){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 3){
                    $a=time() - (86400*30);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }
                }
                if($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $timeFilter[]=$val;
                    }
                }
                $issueDoc=$timeFilter;
            }

            if ($request->all()['id'] == 'month'){
                foreach ($filterData as $key => $val){
                    if (date('m Y',$val['created_at']) == $request->all()['value']){
                        $monthFilter[]=$val;
                    }
                }
                $issueDoc=$monthFilter;
            }

            if ($request->all()['id'] == 'projectId'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $projectFilter[]=$val;
                    }
                    $issueDoc=$projectFilter;
                }else{
                    foreach ($filterData as $key => $val){
                        if ($val['project_id'] == $request->all()['value']){
                            $projectFilter[]=$val;
                        }
                    }
                    $issueDoc=$projectFilter;
                }
            }

            if ($request->all()['id'] == 'view'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $viewFilter[]=$val;
                    }
                    $issueDoc=$viewFilter;

                }elseif ($request->all()['value'] == 1){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $viewFilter[]=$val;
                        }
                    }
                    $issueDoc=$viewFilter;
                }
            }
        }

        $fullData = new Collection();
        $i = 1;
        foreach ($issueDoc as $key => $val) {
            $fullData->push([
                'serialNumber' => $i,
                'issueList' => '<p class="content_wrap">' . $val['issue_topic'] . '</p>',
                'projects' => '<p class="content_wrap">' . $val['project_name'] . '</p>',
                'dueDate' => $val['due_date'],
                'status' => $val['issue_status'],
                'severity' => $val['severity'],
                'issList' => $val['issue_topic'],
                'projName' => $val['project_name'],
                'issueSubmittion' => '<td class="sorting_1"><a href="/staff/issueSubmittion/' . $val['project_id'] . '/' . $val['issue_id'] . '" class="custom_text_info">View</a> </td>',
            ]);

            $i++;
        }
        return DataTables::of($fullData)
            ->rawColumns(['issueSubmittion', 'status', 'issueList', 'projects'])
            ->make(true);
    }

    /**
     * Function name: milestoneAjaxHandler
     * Desc : Function to return to milestone details to the Dashboard
     * @param Request $request
     * @return DataTables to Dashboard page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function milestoneAjaxHandler(Request $request)
    {
        $userId = Session::get('co_staff');
        $projectDetails = array();
        $projectInfo = array();
        $res = json_decode(json_encode(Staff::getInstance()->projectData(), true), true);
        if ($res) {
            foreach ($res as $key => $value) {
                $staff = $res[$key]['staff_id'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if (in_array("$userId", $staff)) {
                    $projectDetails['project_id'] = $value['project_id'];
                    $projectDetails['projectName'] = $value['project_name'];
                    $projectInfo[] = $projectDetails;
                }
            }
        }

        $miles = json_decode(json_encode(Staff::getInstance()->milestoneData(), true), true);
        $milesData = array();
        foreach ($projectInfo as $k => $val) {
            $temp = array();
            foreach ($miles as $m => $mVal) {
                if ($val['project_id'] == $mVal['project_id']) {
                    $temp['projectName'] = $val['projectName'];
                    if (isset($mVal['start_date'])) {
//                        $temp['start_date']=date('d/m/Y',strtotime($mVal['start_date']));
                        $temp['start_date'] = date('d-m-Y', $mVal['start_date']);
                    } else {
                        $temp['start_date'] = '--';
                    }
                    if (isset($mVal['due_date'])) {
//                        $temp['due_date']=date('d/m/Y',strtotime($mVal['due_date']));
                        $temp['due_date'] = date('d-m-Y', $mVal['due_date']);
                    } else {
                        $temp['due_date'] = '--';
                    }
                    $temp['milestone_status'] = $mVal['milestone_status'];
                    $temp['milestone'] = $mVal['milestone'];
                    unset($miles[$m]);
                    $milesData[] = $temp;
                }
            }
        }
        $fullData = new Collection();
        $i=1;
        foreach ($milesData as $key => $val) {
            if ($val['milestone_status'] === 0) {
                $milestoneStatus = 'In-Progress';
            } else if ($val['milestone_status'] === 1) {
                $milestoneStatus = 'Completed';
            } else if ($val['milestone_status'] === null) {
                $milestoneStatus = '--';
            } else {
                $milestoneStatus = 'Overdue';
            }
            $fullData->push([
                'siNo' => $i,
                'projectName' => $val['projectName'],
                'mileston' => $val['milestone'],
                'start_date' => $val['start_date'],
                'due_date' => $val['due_date'],
                'milestoneStatus' => '<a class="custom_text_info" style="cursor:text;">' . $milestoneStatus . '</a>',
            ]);
            $i++;
        }
        return DataTables::of($fullData)
            ->rawColumns(['milestoneStatus'])
            ->make(true);
    }

    /**
     * Function name: getProfileData
     * Desc : Function to return to Setting with whole  details of user
     * @param Request $request
     * @return $details
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getProfileData(Request $request)
    {
        $id = Session::get('co_staff');
        $option = 'id';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$id]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if ($details['staff_status'] == 0) {
            $details['staff_status'] = 'In-Active';
        } else {
            $details['staff_status'] = 'Active';
        }
        return Response::json(['data' => $details]);
    }

    /**
     * Function name: password
     * Desc : Function to check whether the entered password is valid or not
     * @param Request $request
     * @return 1 for valid and 0 for invalid
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function password(Request $request)
    {
        $currentPassword = $request->input('password');
        $id = Session::get('co_staff');
        $option = 'id';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$id]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if (Auth::attempt(['email' => $details['email'], 'password' => $currentPassword])) {
            return Response::json(['msg' => 1]);
        } else {
            return Response::json(['msg' => 0]);
        }
    }

    /**
     * Function name: updatePassword
     * Desc : Function to update password
     * @param Request $request
     * @return 1 for valid and 0 for invalid
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updatePassword(Request $request)
    {
        $id = Session::get('co_staff');
        $where = ['rawQuery' => 'id=?', 'bindParams' => [$id]];
        $dataToUpdate = ['password' => Hash::make($request->all()['new_password'])];
        $details = Staff::getInstance()->updateData($where, $dataToUpdate);
        if ($details) {
            $dataToGet = ['session_id'];
            $whereToGet = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_staff')]];
            $fetchQuery = json_decode(Staff::getInstance()->getUserdata($whereToGet, $dataToGet));
            $ids = json_decode($fetchQuery[0]->session_id);
            /* Destroy all browser session data..*/
            foreach ($ids as $k => $val) {
                File::delete(storage_path() . '/framework/sessions/' . $val);
            }

            $dataToUpdate = ['session_id' => ''];
            $updateQuery = Staff::getInstance()->updateData($where, $dataToUpdate);


            Session::forget('staff_detail');
            Session::forget('co_staff');
            return Response::json(['msg' => 1]);
        } else {
            return Response::json(['msg' => 0]);
        }

    }

    /**
     * Function name: updateDetails
     * Desc : Function to update user details and manage session data
     * @param Request $request
     * @return status 200 for valid and 198 for invalid
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updateDetails(Request $request)
    {
        $data = $request->all();
        $dataToUpdate['name'] = $data['firstName'];
        $dataToUpdate['first_name'] = $data['firstName'];
        $dataToUpdate['last_name'] = $data['lastName'];
        if (isset($data['countryName'])){
            $dataToUpdate['countryName'] = $data['countryName'];
        }
        $dataToUpdate['mobile_number'] = (int)$data['phoneNumber'];
        $dataToUpdate['countryCode'] = $data['code'];
        $dataToUpdate['country'] = $data['country'];
        if (isset($data['state'])) {
            $dataToUpdate['state'] = $data['state'];
        }
        if ($data['availabity'] == 'In-Active') {
            $dataToUpdate['staff_status'] = 0;
        } else {
            $dataToUpdate['staff_status'] = 1;
        }
        if ($data['paypalEmail'] == null) {
            //
        } else {
            $dataToUpdate['paypalEmail'] = $data['paypalEmail'];
        }
        if ($data['mPesaNumber'] == null) {
            //
        } else {
            $dataToUpdate['mPesaNumber'] = $data['mPesaNumber'];
        }

        $id = Session::get('co_staff');
        $where = ['rawQuery' => 'id=?', 'bindParams' => [$id]];
        $details = Staff::getInstance()->updateData($where, $dataToUpdate);
        if ($details) {

            // --------------------------update Session Data-----------------------------------

            $staff_detail = Session::get('staff_detail');
            $staff_detail['name'] = $data['firstName'];
            $staff_detail['first_name'] = $data['firstName'];
            $staff_detail['last_name'] = $data['lastName'];
            Session::put('staff_detail', $staff_detail);

//-------------------------------------------------------------------------------------
            return Response::json(['status' => 200]);
        } else {
            return Response::json(['status' => 198]);
        }
    }

//    public function updatePic(Request $request)
//    {
//        if ($request->isMethod('post')) {
//            if ($request->hasFile('imageFile')) {
//
//
//                $id = Session::get('co_staff');
//                $option = 'id';
//                $where = ['rawQuery' => $option . ' = ?',
//                    'bindParams' => [$id]
//                ];
//                $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
//                $defaultPath = '/uploads/profile_pic/dhiru.jpg';
//                $checkImage = $details['profile_pic'];
//                $ext = Input::File('imageFile')->getClientOriginalExtension();
//                $pic = time() . "." . $ext;
//                $img = "/uploads/profile_pic/" . $pic;
//                $path = public_path() . "/uploads/profile_pic";
//                if (Input::File('imageFile')->move($path, $pic)) {
//
//                    if ($checkImage == $defaultPath) {
//                        //
//                    } else {
//                        if (file_exists(public_path($checkImage))) {
//                            unlink(public_path($checkImage));
//                        }
////                        unlink(public_path($checkImage));
//                    }
//                    $dataToUpdate['profile_pic'] = $img;
//                    $id = Session::get('co_staff');
//                    $where = ['rawQuery' => 'id=?', 'bindParams' => [$id]];
//                    $details = Staff::getInstance()->updateData($where, $dataToUpdate);
//                    if ($details) {
//                        return Response::json(['msg' => 1, 'imgSrc' => $img]);
//                    } else {
//                        return Response::json(['msg' => 0]);
//                    }
//                } else {
//                    return Response::json(['msg' => 0]);
//                }
//            } else {
//                return Response::json(['msg' => 0]);
//            }
//        } else {
//            //
//        }
//    }

    /**
     * Function name: updateProfileAjaxHandler
     * Desc : Function to update user profile picture and manage session data
     * @param Request $request
     * @return status 200 for success and 400 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updateProfileAjaxHandler(Request $request)
    {
        if ($request->isMethod('post')) {
            $dataToUpdate = ['profile_pic' => $request->input('imageFile')];
            $updateData = $this->updateData($dataToUpdate);
            if ($updateData) {
                $staff_detail = Session::get('staff_detail');
                $staff_detail['profile_pic'] = $dataToUpdate['profile_pic'];
                Session::put('staff_detail', $staff_detail);
                return json_encode(['status' => 200, 'message' => 'Your Avatar Updated successfully.', 'profilepic' => $request->input('imageFile')]);
            } else {
                return json_encode(['status' => 400, 'message' => 'Sorry, there was an error uploading your file.']);
            }
        }
    }

    /**
     * Function name: updateData
     * Desc : Function to update user details
     * @param Request $request
     * @return $queryToUpdate
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updateData($userData)
    {
        $dataToUpdate = $userData;
        $whereToUpdate = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_staff')]];
        $queryToUpdate = Staff::getInstance()->updateData($whereToUpdate, $dataToUpdate);
        return $queryToUpdate;
    }

    /**
     * Function name: pdfview
     * Desc : Function to generate pdf using snappy.pdf
     * @param Request $request
     * @return 200
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function pdfview(Request $request)
    {
        if ($request->has('download')) {
            PDF::setOptions(['dpi' => 150, 'defaultFont' => 'sans-serif']);
            $pdf = PDF::loadView('Staff::invoice_form');
            return $pdf->download('Staff::invoice_form.pdf');
            $snappy = App::make('snappy.pdf');
            $html = '<h1>Bill</h1><p>You owe me money, dude.</p>';
            $snappy->generateFromHtml($html, '/tmp/bill-123.pdf');
            $snappy->generate('http://www.github.com', '/tmp/github.pdf');
            return new Response(
                $snappy->getOutputFromHtml($html),
                200,
                array(
                    'Content-Type' => 'application/pdf',
                    'Content-Disposition' => 'attachment; filename="file.pdf"'
                )
            );

        }
        return view('Staff::invoice_form');
    }

    /**
     * Function name: getAllCountInChart
     * Desc : Function to show the chart on the dashboard
     * @param Request $request
     * @return $allData
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getAllCountInChart(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            $staffId = Session::get('co_staff');
            switch ($chooseMethod) {
                case 'Task':
                    $whereToFind = ['rawQuery' => "task_status = 0 and find_in_set('" . $staffId . "',(substr(task_assign_to,2,length(task_assign_to)-2)))>0"];
                    $whereToFind1 = ['rawQuery' => "task_status = 1 and find_in_set('" . $staffId . "',(substr(task_assign_to,2,length(task_assign_to)-2)))>0"];
                    $dataToFInd = ['task_id', 'task_status'];
                    $pendingTasks = json_decode(Staff::getInstance()->getTaskData($whereToFind, $dataToFInd));
                    $completedTasks = json_decode(Staff::getInstance()->getTaskData($whereToFind1, $dataToFInd));
                    if (count($pendingTasks) > 0 || count($completedTasks) > 0)
                        $allData = [count($pendingTasks), count($completedTasks)];
                    else
                        $allData = [];
                    return $allData;
                    break;
                case 'Issue':
                    $whereToFind = ['rawQuery' => "issue_status = 0 and find_in_set('" . $staffId . "',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0"];
                    $whereToFind1 = ['rawQuery' => "issue_status = 1 and find_in_set('" . $staffId . "',(substr(issue_assign_to,2,length(issue_assign_to)-2)))>0"];
                    $dataToFInd = ['issue_id', 'issue_status'];
                    $pendingIssue = json_decode(Staff::getInstance()->pendingIssues($whereToFind, $dataToFInd));
                    $completedIssue = json_decode(Staff::getInstance()->pendingIssues($whereToFind1, $dataToFInd));
                    if (count($pendingIssue) > 0 || count($completedIssue) > 0)
                        $allData = [count($pendingIssue), count($completedIssue)];
                    else
                        $allData = [];
                    return $allData;
                case 'Milestone':

                    $whereToFind = ['rawQuery' => " find_in_set('" . $staffId . "',(substr(staff_id,2,length(staff_id)-2)))>0"];
                    $dataToFind = ['project_id'];
                    $getAllProjects = json_decode(Staff::getInstance()->getProjectData($whereToFind, $dataToFind));

                    $whereToFind = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [0]];
                    $whereToFind1 = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [1]];
                    $whereToFind2 = ['rawQuery' => 'milestone_status = ?', 'bindParams' => [2]];
                    $dataToFInd = ['milestone_id', 'milestone_status', 'project_id'];
                    $ongoingData = json_decode(Staff::getInstance()->getMilestoneDetails($whereToFind, $dataToFInd));
                    $finishedData = json_decode(Staff::getInstance()->getMilestoneDetails($whereToFind1, $dataToFInd));
                    $overdueData = json_decode(Staff::getInstance()->getMilestoneDetails($whereToFind2, $dataToFInd));
                    $arr = [];
                    $arr1 = [];
                    $arr2 = [];
                    $arr3 = [];
                    foreach ($ongoingData as $k => $v) {
                        $arr[] = $v->project_id;
                    }
                    foreach ($finishedData as $k => $v) {
                        $arr2[] = $v->project_id;
                    }
                    foreach ($overdueData as $k => $v) {
                        $arr3[] = $v->project_id;
                    }
                    foreach ($getAllProjects as $k => $v) {
                        $arr1[] = $v->project_id;
                    }
                    $ongoingData = array_intersect($arr, $arr1);
                    $finishedData = array_intersect($arr2, $arr1);
                    $overdueData = array_intersect($arr3, $arr1);
                    if (count($ongoingData) > 0 || count($finishedData) > 0 || count($overdueData) > 0)
                        $allData = [count($ongoingData), count($finishedData), count($overdueData)];
                    else
                        $allData = [];
                    return $allData;
            }
        }
    }

}