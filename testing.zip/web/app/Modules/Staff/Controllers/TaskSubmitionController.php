<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 5/14/2018
 * Time: 12:58 PM
 */

namespace App\Modules\Staff\Controllers;

namespace App\Modules\Staff\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use App\Modules\Staff\Models\StaffModel;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;


class TaskSubmitionController extends Controller
{
    protected $api_url;

    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * Function name: taskSubmittion
     * Desc : Function to get task submission details
     * @param Request $request
     * @return to resource.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function taskSubmittion(Request $request)
    {
        if ($request->isMethod('get')) {
            $a = "A";
            $m = "M";
            $dataToFind = ['id', 'first_name', 'last_name'];
            $where = ['rawQuery' => 'role=? or role=?', 'bindParams' => [$a, $m]];
            $details = json_decode(json_encode(Staff::getInstance()->getUserdata($where, $dataToFind), true), true);
            $res = json_decode(json_encode(Staff::getInstance()->projectData(), true), true);
            $project = array();
            $doc = [];
            if ($res) {
                $i = 0;
                foreach ($res as $key => $value) {
                    $staff = $value['staff_id'];
                    $staff = substr($staff, 1, -1);
                    $staff = explode(',', $staff);
                    if (in_array(Session::get('staff_detail')['id'], $staff)) {
                        $doc['project'] = $value['project_name'];
                        $doc['date'] = $value['end_date'];
                        $doc['id'] = $value['project_id'];
                        $i++;
                        $project[] = $doc;
                    }
                }
            } else {
                //
            }
            return view('Staff::resource', ['data1' => $details, 'data2' => $project]);
        } else {
//            dd($request->all());
        }
    }

    /**
     * Function name: viewSubmittion
     * Desc : Function to get particular taskId and projectId submission psge
     * @param $pro_id, $taskId, $request
     * @return to viewSubmittion.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function viewSubmittion(Request $request, $pro_id, $taskId)
    {
        if ($request->isMethod('get')) {
            $dataToFind = ['project_name'];
            $where = ['rawQuery' => 'project_id=? ', 'bindParams' => [$pro_id]];
            $details = json_decode(json_encode(Staff::getInstance()->getProjectData($where, $dataToFind), true), true);
            if ($details) {
                $projectName = $details[0]['project_name'];
                $dataToFind = ['task_due_date', 'task_topic','task_assign_to','priority', 'task_desc','task_due_hours', 'attachment_files','allFiles','task_submission_files'];
                $where = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$pro_id, $taskId]];
                $detail = json_decode(json_encode(Staff::getInstance()->getTaskData($where, $dataToFind), true), true);
                $allStaffName='';
                if ($detail) {
                    $staff = $detail[0]['task_assign_to'];
                    $staff = substr($staff, 1, -1);
                    $staff = explode(',', $staff);
                    if (in_array(Session::get('staff_detail')['id'], $staff)) {
                        $output = '';
                        foreach($staff as $val) {
                            $output .= $val .",";
                        }
                        $str=substr($output, 0, -1);
                        $where = ['rawQuery' => 'id in(' .$str.')'];
                        $StaffdataToFInd = ['first_name','last_name'];
                        $staffDetails = json_decode(json_encode(Staff::getInstance()->getUserdata($where, $StaffdataToFInd), true), true);
                        $allStaffName='';
                        foreach ($staffDetails as $val){
                            $allStaffName.= $val['first_name'].' '.$val['last_name'].', ';
                        }
                        $allStaffName=substr($allStaffName, 0, -1);

                    } else {
                        return view('Staff::error');
                    }
                    $arr = array();
                    if (isset($detail[0]['task_due_date'])) {
                        $arr['task_due_date'] = date('d/m/Y', $detail[0]['task_due_date']);
                    } else {
                        $arr['task_due_date'] = '--';
                    }
                    if (isset($detail[0]['task_due_hours'])) {
                        $arr['task_due_hours'] = $detail[0]['task_due_hours'];
                    } else {
                        $arr['task_due_hours'] = '--';
                    }
                    if (isset($detail[0]['priority'])){
                        if ($detail[0]['priority'] == 0){
                            $arr['priority'] = 'None';
                        }elseif ($detail[0]['priority'] == 1){
                            $arr['priority'] = 'Low';
                        }elseif ($detail[0]['priority'] == 2){
                            $arr['priority'] = 'Medium';
                        }elseif ($detail[0]['priority'] == 3){
                            $arr['priority'] = 'High';
                        }
                    }else{
                        $arr['priority'] = 'None';
                    }
                    $arr['project_name'] = $projectName;
                    $arr['project_id'] = $pro_id;
                    $arr['task_topic'] = $detail[0]['task_topic'];
                    $arr['task_id'] = $taskId;
                    $arr['task_desc'] = $detail[0]['task_desc'];
                    $arr['attachment_files'] = json_decode($detail[0]['attachment_files'], true);
                    $arr['allFiles'] = json_decode($detail[0]['allFiles'], true);
                    $arr['copyScapeFiles'] = json_decode($detail[0]['task_submission_files'], true);
                    return view('Staff::viewSubmition', ['data' => $arr,'fileData'=>json_encode($arr),'allStaffName'=>$allStaffName]);
                } else {
                    return view('Staff::error');
                }
            } else {
                return view('Staff::error');
            }
        } else {
            //
        }
    }

    /**
     * Function name: viewTaskSubmittion
     * Desc : Function to verify each file with copy scape
     * @param Request $request
     * @return 200 and $details for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function viewTaskSubmittion(Request $request)
    {
        $projectId = $request['projectId'];
        $fileId = $request['fileId'];
        $taskId = $request['taskId'];
        $array = $request->all();
        unset($array['projectId']);
        unset($array['fileId']);
        unset($array['taskId']);
        $verifyFile = array();
        if (empty($array)) {
            return Response::json(['msg' => 400]);
        } else {
            foreach ($array as $fileName => $val) {
                if ($fileName == $fileId) {
                    $verifyFile[$fileId] = $val;
                    break;
                }
            }
        }
        $file = array();
        $array = $verifyFile;
        $fileNoti='';
        foreach ($array as $val) {
            $path=json_decode($this->fileUpload($val));
            $file[] = $path->data1;
            $fileNoti = $path->data;
        }

// ----------------------------verifying file with copyScape--------------------------------
        $array1 = array();
        $copyscapeUrl = '';
            $fileArray = pathinfo($file[0]);
            $ext = $fileArray['extension'];
            if ($ext == 'doc' || $ext == 'docx' || $ext == 'pdf') {
                $detail = new CopyScapeController();
                $res = $detail->copyScape(new Request(['file' => $file[0]]));
                if (isset($res['error'])) {
//                    if (file_exists(public_path($file[0]))) {
//                        unlink(public_path($file[0]));
//                    }
                    return Response::json(['msg' => 500, 'data' => $res['error']]);
                }
                if(isset($res['allviewurl'])){
                    $copyscapeUrl = $res['allviewurl'];
                }else{
                    $copyscapeUrl = $res['result'][0]['url'];
                }
                $array1[] = ['filePath' => $fileNoti, 'copyScapeUrl' => $copyscapeUrl];
//                $array1[] = ['filePath' => $fileNoti, 'copyScapeUrl' => $res['allviewurl']];
//                $copyscapeUrl = $res['allviewurl'];
            } else {
                $array1[] = ['filePath' => $file[0], 'copyScapeUrl' => ''];
            }
        $file = $array1;
//--------------------------------------------------------------------------------------------------------

        $dataToFind = ['task_submission_files'];
        $whereToFind = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
        $queryToFindData = Staff::getInstance()->getTaskData($whereToFind, $dataToFind);
        $taskData = json_decode(json_encode($queryToFindData), true);
        $noti = array();
        if ($taskData[0]['task_submission_files']) {
            $data = $taskData[0]['task_submission_files'];
            $file = array_merge(json_decode($data), $file);
            $dataToUpdate = ['task_submission_files' => json_encode($file)];
            $where = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
            $details = Staff::getInstance()->updateTaskData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '16';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["copyscapeUrl"=>$copyscapeUrl,"fileUrl"=>$fileNoti,"taskId"=>$taskId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'copyscapeUrl' => $copyscapeUrl]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $dataToUpdate = ['task_submission_files' => json_encode($file)];
            $where = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
            $details = Staff::getInstance()->updateTaskData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '16';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["copyscapeUrl"=>$copyscapeUrl,"fileUrl"=>$fileNoti,"taskId"=>$taskId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'copyscapeUrl' => $copyscapeUrl]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }
    }

    /**
     * Function name: viewTaskSubmittionAllFiles
     * Desc : Function to upload genral files
     * @param Request $request
     * @return 200 and $details for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function viewTaskSubmittionAllFiles(Request $request)
    {
        $projectId = $request['projectId'];
        $taskId = $request['taskId'];
        $array = $request->all();
        unset($array['projectId']);
        unset($array['taskId']);
        $file = array();
        if (empty($array)) {
            return Response::json(['msg' => 400]);
        }
        foreach ($array as $val) {
            $file[] = json_decode($this->fileUpload($val))->data;
        }
        $notiFile=$file;
        $dataToFind = ['allFiles'];
        $whereToFind = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
        $queryToFindData = Staff::getInstance()->getTaskData($whereToFind, $dataToFind);
        $taskData = json_decode(json_encode($queryToFindData), true);
        $noti = array();
        if ($taskData[0]['allFiles']) {
            $data = $taskData[0]['allFiles'];
            $file = array_merge(json_decode($data), $file);
            $dataToUpdate = ['allFiles' => json_encode($file)];
            $where = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
            $details = Staff::getInstance()->updateTaskData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '15';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["filePath"=>$notiFile,"taskId"=>$taskId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $dataToUpdate = ['allFiles' => json_encode($file)];
            $where = ['rawQuery' => 'project_id=? and task_id=?', 'bindParams' => [$projectId, $taskId]];
            $details = Staff::getInstance()->updateTaskData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '15';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["filePath"=>$notiFile,"taskId"=>$taskId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }

    }

    /**
     * Function name: postComment
     * Desc : Function to post comment
     * @param Request $request
     * @return 200 and $details for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function postComment(Request $request)
    {

        $arr = $request->all();
        $taskId = $arr['taskId'];
        $comment = $arr['comment'];
        unset($arr['taskId']);
        unset($arr['comment']);
        $noti = array();
        if (empty($arr)) {
            $data = [];
            $data['task_id'] = $taskId;
            $data['comment_by'] = Session::get('staff_detail')['id'];
            $data['comments'] = $comment;
            $data['comment_posted_on'] = time();
            $data['created_at'] = time();
            $data['updated_at'] = time();
            $obj = Staff::getInstance();
            $result = $obj->comment($data);
            if ($result) {
                $where = ['rawQuery' => 'task_comment_id=?', 'bindParams' => [$result]];
                $details = json_decode(json_encode(Staff::getInstance()->getCommentDetail($where), true), true);
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '10';
                $noti['notification_status'] = '0';
                $mess = ["id" => $taskId];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'data' => $details]);
            } else {
                return Response::json(['msg' => 198]);
            }

        } else {

            $file = array();
            foreach ($arr as $val) {
                $file[] = json_decode($this->fileUpload($val))->data;
            }

            $data = [];
            $data['task_id'] = $taskId;
            $data['comment_by'] = Session::get('staff_detail')['id'];
            $data['comments'] = $comment;
            $data['attachment_files'] = $file ? json_encode($file) : '';
            $data['comment_posted_on'] = time();
            $data['created_at'] = time();
            $data['updated_at'] = time();
            $obj = Staff::getInstance();
            $result = $obj->comment($data);
            if ($result) {
                $where = ['rawQuery' => 'task_comment_id=?', 'bindParams' => [$result]];
                $details = json_decode(json_encode(Staff::getInstance()->getCommentDetail($where), true), true);
                $file_data = json_decode($details['attachment_files'], true);
                $details['attachment_files'] = $file_data;
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '10';
                $noti['notification_status'] = '0';
                $mess = ["id" => $taskId];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'data' => $details]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }
    }

    /**
     * Function name: fileUpload
     * Desc : Function to upload file
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'uploads/' . time() . $num;
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePathStaff($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url .'/'. $foldeName . '/' . $filePath,
                    'data1' =>  '/'. $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    /**
     * Function name: getComment
     * Desc : Function to get commented data
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getComment(Request $request)
    {
        $taskId = $request['taskId'];
        $where = ['rawQuery' => 'task_id=?', 'bindParams' => [$taskId]];
        $details = json_decode(json_encode(Staff::getInstance()->getComment($where), true), true);
        if ($details) {
            $arr2 = array();
            $arr3 = array();
            $where = ['rawQuery' => '1'];
            $usersData = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
            $users = [];
            foreach ($usersData as $user) {
                $users[$user['id']] = $user;
            }
            foreach ($details as $key => $val) {
                $userId = $val['comment_by'];
                if (isset($users[$userId])) {
                    $detail = $users[$userId];
                    $arr3['first_name'] = $detail['first_name'];
                    $arr3['last_name'] = $detail['last_name'];
                    $arr3['profile_pic'] = $detail['profile_pic'];
                    if ($detail['role'] == 'A') {
                        $arr3['role'] = 'Admin';
                    } elseif ($detail['role'] == 'M') {
                        $arr3['role'] = 'Manager';
                    } else {
                        $arr3['role'] = 'Staff';
                    }
                    $arr3['comments'] = $val['comments'];
                    $arr3['task_comment_id'] = $val['task_comment_id'];
                    $arr3['attachment_files'] = json_decode($val['attachment_files'], true);
                    $arr3['comment_posted_on'] = $val['comment_posted_on'];
//                    $arr3['comment_posted_on'] = date('d M Y H:i:s', $val['comment_posted_on']);
                    $arr3['commentOn'] = $val['comment_posted_on'];
                    $arr2[] = $arr3;
                }
            }
            $count = count($arr2);
            return Response::json(['msg' => 200, 'data' => $arr2, 'count' => $count]);
        } else {
            return Response::json(['msg' => 198, 'count' => 0]);
        }

    }

    /**
     * Function name: deleteComment
     * Desc : Function to delete comment
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function deleteComment(Request $request)
    {
        $data = $request->all();
        $where = ['rawQuery' => 'task_comment_id=?', 'bindParams' => [$data['rowId']]];
        $detail = json_decode(json_encode(Staff::getInstance()->getComment($where), true), true);
        if ($detail) {
                $obj = Staff::getInstance()->deleteComment($detail[0]['task_comment_id']);
                if ($obj) {
                    return Response::json(['status' => 200, 'msg' => 'Comment Successfully Deleted', 'data' => $detail[0]]);
                } else {
                    return Response::json(['status' => 198, 'msg' => 'Failed to Deleted']);
                }
        } else {
            return Response::json(['status' => 404, 'msg' => 'Error Occured Try After Some Time']);
        }
    }

    /**
     * Function name: editComment
     * Desc : Function to edit comment
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function editComment(Request $request)
    {
        $data = $request->all();
        $time = time();
        $where = ['rawQuery' => 'task_comment_id=? ', 'bindParams' => [$data['commentId']]];
        $dataToUpdate = ['comments' => $data['commentTxt'], 'comment_posted_on' => $time, 'updated_at' => $time];
        $obj = Staff::getInstance()->updateComment($where, $dataToUpdate);
        if ($obj) {
            return Response::json(['status' => 200, 'comment_posted_on' => $time]);
        } else {
            return Response::json(['status' => 198, 'msg' => 'Failed to Edit']);
        }
    }

    /**
     * Function name: finalTaskSubmission
     * Desc : Function to send task submission templet to admin through email
     * @param Request $request
     * @return 200 for success or 198 for failiur
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function finalTaskSubmission(Request $request)
    {
        $ajaxData = $request->all();
        $time = $ajaxData['timezone'];
        date_default_timezone_set($time);
        $today = date("D,M jS,h:i A");
        $ajaxData = $request->all();
        $adminEmail = '';
        $where = ['rawQuery' => '1'];
        $detail = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
        if (isset($detail[0]['email'])) {
            $adminEmail = $detail[0]['email'];
        } else {
            return Response::json(['code' => 198]);
        }
        $fromData=json_decode(json_encode(Session::get('staff_detail'),true),true)['email'];
        $image = $this->api_url . '/uploads/logo3.png';
        $link = $this->api_url . '/admin/task-submission/'.$ajaxData['taskId'].'?next=task-submission/'.$ajaxData['taskId'];
        $mail = $adminEmail;
//        $mail = 'sharmaglobussoft@gmail.com';
        $from = new \SendGrid\Email(null, $fromData);
        $subject = "Regarding Task Submission";
        $to = new \SendGrid\Email(null, $mail);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Task Submission</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$today</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    max-width:580px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td style=\"width: 180px;\"><h2>Task Submission</h2></td>
            </tr>

            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Task Name</b></td>
                <td style=\"padding-bottom: 10px;\">: {$ajaxData['taskName']}</td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Project Name</b></td>
                <td style=\"padding-bottom: 10px;\">: {$ajaxData['projectName']}</td>
            </tr>
            
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Due Date</b></td>
                <td style=\"padding-bottom: 10px;\">: {$ajaxData['dueDate']}</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Priority</b></td>
                <td style=\"padding-bottom: 10px;\">: {$ajaxData['priority']}</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Task Description</b> </td>
                <td style=\"padding-bottom: 10px;\">: {$ajaxData['taskDesc']} </td>
            </tr>
            <tr>
        <td style=\"padding-top:40px;\"><a style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" href='$link' >Check Details</a>
         
        </td>
      </tr>
        </table>
    </center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = env('sendgrid_api_key');
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
        if ($response->statusCode() == 202){
            $noti['sender_id'] = Session::get('staff_detail')['id'];
            $noti['receiver_id'] = 1;
            $noti['sender_message'] = '';
            $noti['notify_type'] = '32';
            $noti['notification_status'] = '0';
            $mess = ["taskId" => $ajaxData['taskId']];
            $noti['receiver_message'] = '[' . json_encode($mess) . ']';
            $noti['created_at'] = time();
            $noti['updated_at'] = time();
            DB::table('notifications')->insert($noti);
            return Response::json(['code' => 200]);
        }else{
            return Response::json(['code' => 198]);
        }

    }

    /**
     * Function name: taskInvitation
     * Desc : Function to return to login page
     * @param Request $request
     * @return '/staff/login'
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function taskInvitation(Request $request, $userId, $projectId,$taskId)
    {
        Session::put('u_id',$userId);
        Session::put('p_Tid',$projectId);
        Session::put('t_id',$taskId);
        return redirect('/staff/login');

    }


}