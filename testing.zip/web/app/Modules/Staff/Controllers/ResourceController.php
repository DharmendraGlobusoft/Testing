<?php
/**
 * Created by PhpStorm.
 * User: GLB-219
 * Date: 5/17/2018
 * Time: 12:03 PM
 * @author Bandana Sahu<bandanasahu@globussoft.in>
 */

namespace App\Modules\Staff\Controllers;

use App\Modules\Staff\Models\Resource;
use App\Modules\Admin\Models\User;
use App\Modules\Staff\Models\Staff;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;

class ResourceController extends Controller
{
    protected $api_url;

    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * Function name: resourcePage
     * Desc : Function to show full resource content
     * @param Request $request
     * @return to resource.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function resourcePage()
    {
        $resourceData = $this->allResourceDetails();
        return view('Staff::resource',['allResourceData' => $resourceData['allResourceData'], 'latestResource' => $resourceData['latestResource']]);
    }

    /**
     * Function name: allResourceDetails
     * Desc : Function to show full resource content
     * @param Request $request
     * @return $resourceDataArr, $latestResource
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function allResourceDetails()
    {
        $userId = Session::get('staff_detail')['id'];
        $where = ['rawQuery' => 'resource_privacy = ?', 'bindParams' => [0]];
        $public = json_decode(json_encode(Staff::getInstance()->resourceData($where), true), true);
        $where = ['rawQuery' => 'resource_privacy = ?', 'bindParams' => [1]];
        $private = json_decode(json_encode(Staff::getInstance()->resourceData($where), true), true);
        $pId = [];
        foreach ($private as $value) {
            $pid = $value['staff_ids'];
            $pid = substr($pid, 1, -1);
            $pid = explode(',', $pid);
            if (in_array($userId, $pid)) {
                $pId[] = $value;
            }
        }

        if(!empty($pId)){
            foreach ($pId as $val){
                array_push($public, $val);
            }
        }
        $public = array_reverse($public, true);
        $resourceDataArr = [];
        foreach ($public as $k => $data) {

            $path = $data['resource_content'];
            $resourceContent = Storage::get($path);

            $bgColor = $this->extractContent($resourceContent, 'src=', '>');
            $resourceDataArr[] = [
                'id' => $data['resource_id'],
                'title' => $data['resource_title'],
                'imagePath' => json_decode($data['resource_image']),
                'content' => $resourceContent,
                'shortImage' => $bgColor,
                'startDate' => date("F j, Y", $data['created_at'])
            ];
        }
        $latestResource = array_slice($resourceDataArr, 0, 4, true);
        return ['allResourceData' => $resourceDataArr, 'latestResource' => $latestResource];
    }

    /**
     * Function name: extractContent
     * Desc : Function to extract content of resource
     * @param Request $request
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function extractContent($str, $start, $end)
    {
        $lastPos = 0;
        $positions = array();
        $color = array();
        $final = array();
        while (($lastPos = strpos($str, $start, $lastPos)) !== false) {
            $positions[] = $lastPos;
            $lastPos = $lastPos + strlen($start);
        }
        $newStr = $str;
        if ($positions) {
            foreach ($positions as $value) {
                $newStr = substr($str, strpos($str, $start));
                array_push($color, substr($str, $value, strpos($newStr, $end)));
            }
            $color[0] = substr($color[0], strlen('"src='));
            $color[0] = substr($color[0], 0, strpos($color[0], '"'));
            return $color[0] ? $color[0] : '/images/default.png';
        } else {
            return '/images/blog2.png';
        }
    }

    /**
     * Function name: getContents
     * Desc : Function to show particular resource content
     * @param Request $request
     * @return $resourceDataArr
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getContents(Request $request)
    {
        $resId = $request->input('resourceId');
        $dataToFind = ['resource_id', 'resource_title', 'resource_content', 'resource_image', 'created_at'];
        $whereToFind = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resId]];
        $query = json_decode(Resource::getInstance()->getResourceDetails($whereToFind, $dataToFind));
        $path = $query[0]->resource_content;
        $resourceContent = Storage::get($path);
        $resourceDataArr[] = [
            'id' => $query[0]->resource_id,
            'title' => $query[0]->resource_title,
            'imagePath' => json_decode($query[0]->resource_image),
            'content' => $resourceContent,
            'date' => date('d-m-Y', $query[0]->created_at)
        ];
        return json_encode(['status' => 200, 'data' => $resourceDataArr]);
    }

    /**
     * Function name: showMoreResources
     * Desc : Function to show more resource content
     * @param Request $request
     * @return view showMoreResource.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function showMoreResources(Request $request, $id)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $resourceData = $this->allResourceDetails();
        return view('Staff::showMoreResource', ['latestResource' => $resourceData['latestResource'], 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }


}