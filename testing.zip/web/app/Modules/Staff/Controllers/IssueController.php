<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 6/4/2018
 * Time: 3:22 PM
 */

namespace App\Modules\Staff\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;

class IssueController extends Controller
{
    protected $api_url;

    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * Function name: issueSubmittion
     * Desc : Function to return issue details of the project
     * @param Request $request
     * @return to issue Submittion page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function issueSubmittion(Request $request, $proj_Id, $issue_Id)
    {
        $userId = Session::get('co_staff');
        $res = json_decode(json_encode(Staff::getInstance()->issueData(), true), true);
        $allStaffName='';
        $issueDoc = array();
        if ($res) {
            $i = 0;
            foreach ($res as $key => $value) {
                $staff = $res[$key]['issue_assign_to'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if (in_array($userId, $staff)) {
                    $issueDetails['project_id'] = $value['project_id'];
                    if ($value['project_id']==$proj_Id){
//                        dd('go forward');
                        $output = '';
                        foreach($staff as $val) {
                            $output .= $val .",";
                        }
                        $str=substr($output, 0, -1);
                        $where = ['rawQuery' => 'id in(' .$str.')'];
                        $StaffdataToFInd = ['first_name','last_name'];
                        $staffDetails = json_decode(json_encode(Staff::getInstance()->getUserdata($where, $StaffdataToFInd), true), true);
                        $allStaffName='';
                        foreach ($staffDetails as $val){
                            $allStaffName.= $val['first_name'].' '.$val['last_name'].', ';
                        }
                        $allStaffName=substr($allStaffName, 0, -1);
                    }else{
                        continue;
                    }

                    $issueDetails['issue_id'] = $value['issue_id'];
                    $issueDetails['issue_topic'] = $value['issue_topic'];
                    $issueDetails['issue_desc'] = $value['issue_desc'];
                    $issueDetails['issue_attachment_files'] = json_decode($value['issue_attachment_files'], true);
                    $issueDetails['copyScapeFiles'] = json_decode($value['issue_submission'], true);
                    $issueDetails['allFiles'] = json_decode($value['allFiles'], true);
                    $projectId = $value['project_id'];
                    $projectName = json_decode(json_encode(Staff::getInstance()->dataProject($projectId), true), true);
                    $issueDetails['project_name'] = $projectName[0]['project_name'];
                    $issueDetails['due_date'] = $value['due_date'] ? date('m-d-Y', $value['due_date']) : '--';
                    $issueDetails['due_hour'] = $value['issue_due_hours'] ? $value['issue_due_hours'] : '--';

                    if ($value['issue_status'] == 0) {
//                        $issueDetails['issue_status'] = '<a class="custom_text_danger" style="cursor: text">Pending</a>';
                        $issueDetails['issue_status'] = "<a class='custom_text_danger' style='cursor: text'>Pending</a>";
                    } elseif ($value['issue_status'] == 1) {
                        $issueDetails['issue_status'] = "<a class='text-success' style='cursor: text'>Completed</a>";
                    }


                    if ($value['severity'] == 1) {
                        $issueDetails['severity'] = 'Minor';
                    } elseif ($value['severity'] == 2) {
                        $issueDetails['severity'] = 'Major';
                    } else {
                        $issueDetails['severity'] = 'Critical';
                    }
                    $issueDoc[$i] = $issueDetails;
                    $i++;
                }
            }
        }
        foreach ($issueDoc as $key => $val) {
            if ($val['project_id'] == $proj_Id && $val['issue_id'] == $issue_Id) {
                $doc = $val;
                break;
            }
        }
        if (isset($doc)) {
            return view('Staff::issueSubmission', ['data' => $doc, 'fileData' => json_encode($doc),'allStaffName'=>$allStaffName]);
        } else {
            return view('Staff::error');
        }
    }

    /**
     * Function name: issueFileSubmittion
     * Desc : Function to verify file with copyscape
     * @param Request $request
     * @return 200 for success with copyscape url
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function issueFileSubmittion(Request $request)
    {
        $array = $request->all();
        $projectId = $array['projectId'];
        $fileId = $request['fileId'];
        $issueId = $array['issueId'];
        unset($array['projectId']);
        unset($array['issueId']);
        unset($array['fileId']);
        $file = array();
        $verifyFile = array();
        if (empty($array)) {
            return Response::json(['msg' => 400]);
        } else {
            foreach ($array as $fileName => $val) {
                if ($fileName == $fileId) {
                    $verifyFile[$fileId] = $val;
                    break;
                }
            }
        }
        $array = $verifyFile;
        $fileNoti = '';
        foreach ($array as $val) {
            $path = json_decode($this->fileUpload($val));
            $file[] = $path->data1;
            $fileNoti = $path->data;
        }

// ----------------------------verifying each file with copyScape--------------------------------

        $array1 = array();
        $copyscapeUrl = '';
        $fileArray = pathinfo($file[0]);
        $ext = $fileArray['extension'];
        if ($ext == 'doc' || $ext == 'docx' || $ext == 'pdf') {
            $detail = new CopyScapeController();
            $res = $detail->copyScape(new Request(['file' => $file[0]]));
            if (isset($res['error'])) {
//                    if (file_exists(public_path($file[0]))) {
//                        unlink(public_path($file[0]));
//                    }
                return Response::json(['msg' => 500, 'data' => $res['error']]);
            }
            if (isset($res['allviewurl'])) {
                $copyscapeUrl = $res['allviewurl'];
            } else {
                $copyscapeUrl = $res['result'][0]['url'];
            }
            $array1[] = ['filePath' => $fileNoti, 'copyScapeUrl' => $copyscapeUrl];
//                $array1[] = ['filePath' => $fileNoti, 'copyScapeUrl' => $res['allviewurl']];
//                $copyscapeUrl = $res['allviewurl'];
        } else {
            $array1[] = ['filePath' => $file[0], 'copyScapeUrl' => ''];
        }
        $file = $array1;
//--------------------------------------------------------------------------------------------------------
        $dataToFind = ['issue_submission'];
        $whereToFind = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
        $queryToFindData = Staff::getInstance()->pendingIssues($whereToFind, $dataToFind);
        $taskData = json_decode(json_encode($queryToFindData), true);
        $noti = array();
        if ($taskData[0]['issue_submission']) {
            $data = $taskData[0]['issue_submission'];
            $file = array_merge(json_decode($data), $file);
            $dataToUpdate = ['issue_submission' => json_encode($file)];
            $where = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
            $details = Staff::getInstance()->updateIssueData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '13';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["copyscapeUrl" => $copyscapeUrl, "fileUrl" => $fileNoti, 'issueId' => $issueId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'copyscapeUrl' => $copyscapeUrl]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $dataToUpdate = ['issue_submission' => json_encode($file)];
            $where = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
            $details = Staff::getInstance()->updateIssueData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '13';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["copyscapeUrl" => $copyscapeUrl, "fileUrl" => $fileNoti, 'issueId' => $issueId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'copyscapeUrl' => $copyscapeUrl]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }

    }

    /**
     * Function name: issueFileSubmittionAllFiles
     * Desc : Function to upload genral files
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function issueFileSubmittionAllFiles(Request $request)
    {
        $array = $request->all();
        $projectId = $array['projectId'];
        $issueId = $array['issueId'];
        unset($array['projectId']);
        unset($array['issueId']);
        $file = array();
        if (empty($array)) {
            return Response::json(['msg' => 400]);
        }
        foreach ($array as $val) {
            $file[] = json_decode($this->fileUpload($val))->data;
        }
        $notiFile = $file;
        $dataToFind = ['allFiles', 'issue_submission'];
        $whereToFind = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
        $queryToFindData = Staff::getInstance()->pendingIssues($whereToFind, $dataToFind);
        $taskData = json_decode(json_encode($queryToFindData), true);
        $noti = array();
        if ($taskData[0]['allFiles']) {
            $data = $taskData[0]['allFiles'];
            $file = array_merge(json_decode($data), $file);
            $dataToUpdate = ['allFiles' => json_encode($file)];
            $where = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
            $details = Staff::getInstance()->updateIssueData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '14';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["filePath" => $notiFile, "issueId" => $issueId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $dataToUpdate = ['allFiles' => json_encode($file)];
            $where = ['rawQuery' => 'project_id = ? and issue_id=?', 'bindParams' => [$projectId, $issueId]];
            $details = Staff::getInstance()->updateIssueData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '14';
                $noti['notification_status'] = '0';
                $noti['receiver_message'] = json_encode(["filePath" => $notiFile, "issueId" => $issueId]);
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }

    }

    /**
     * Function name: fileUpload
     * Desc : Function to upload files
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'uploads/' . time() . $num;
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePathStaff($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url . '/' . $foldeName . '/' . $filePath,
                    'data1' => '/' . $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    /**
     * Function name: postIssueComment
     * Desc : Function to post issue comments
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function postIssueComment(Request $request)
    {
        $array = $request->all();
        $arr = array();
        $comment = $array['comment'];
        $issueId = $array['issueId'];
        unset($array['comment']);
        unset($array['issueId']);
        $arr['issue_id'] = $issueId;
        $arr['comment_by'] = Session::get('staff_detail')['id'];
        $arr['comments'] = $comment;
        $file = array();
        $noti = array();

        if (!empty($array)) {

            foreach ($array as $val) {
                $file[] = json_decode($this->fileUpload($val))->data;
            }
            $arr['attachment_files'] = $file ? json_encode($file) : '';
        }
        $time = time();
        if (isset($arr['attachment_files'])) {
            //
        } else {
            $arr['attachment_files'] = '';
        }

        $arr['comment_posted_on'] = $time;
        $arr['created_at'] = $time;
        $arr['updated_at'] = $time;
        $obj = Staff::getInstance();
        $result = $obj->issueComment($arr);
        if ($result) {
            $where = ['rawQuery' => 'issue_comment_id=?', 'bindParams' => [$result]];
            $details = json_decode(json_encode(Staff::getInstance()->getIssueDetail($where), true), true);
            $file_data = json_decode($details['attachment_files'], true);
            $details['attachment_files'] = $file_data;
            $noti['sender_id'] = Session::get('staff_detail')['id'];
            $noti['receiver_id'] = 1;
            $noti['sender_message'] = '';
            $noti['notify_type'] = '11';
            $noti['notification_status'] = '0';
            $mess = ["id" => $issueId];
            $noti['receiver_message'] = '[' . json_encode($mess) . ']';
            $noti['created_at'] = time();
            $noti['updated_at'] = time();
            DB::table('notifications')->insert($noti);
            return Response::json(['msg' => 200, 'data' => $details]);
        } else {
            return Response::json(['msg' => 198]);
        }

    }

    /**
     * Function name: getIssueComment
     * Desc : Function to get issue comments
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getIssueComment(Request $request)
    {
        $array = $request->all();
        $where = ['rawQuery' => 'issue_id=?', 'bindParams' => [$array['issueId']]];
        $details = json_decode(json_encode(Staff::getInstance()->getIssueComment($where), true), true);
        if ($details) {
            $arr2 = array();
            $arr3 = array();

            $where = ['rawQuery' => '1'];
            $detail = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
            $users = [];
            foreach ($detail as $value) {
                $users[$value['id']] = $value;
            }
            foreach ($details as $key => $val) {
                $userId = $val['comment_by'];
                if (isset($users[$userId])) {
                    $detail = $users[$userId];
                    $arr3['first_name'] = $detail['first_name'];
                    $arr3['last_name'] = $detail['last_name'];
                    $arr3['profile_pic'] = $detail['profile_pic'];
                    if ($detail['role'] == 'A') {
                        $arr3['role'] = 'Admin';
                    } elseif ($detail['role'] == 'M') {
                        $arr3['role'] = 'Manager';
                    } else {
                        $arr3['role'] = 'Staff';
                    }
                    $arr3['comments'] = $val['comments'];
                    $arr3['issue_comment_id'] = $val['issue_comment_id'];
//                    $arr3['attachment_files'] = $val['attachment_files'];
                    $arr3['attachment_files'] = json_decode($val['attachment_files'], true);
                    $arr3['comment_posted_on'] = $val['comment_posted_on'];
                    $arr3['commentOn'] = $val['comment_posted_on'];
                    $arr2[] = $arr3;
                }
            }
            $count = count($arr2);
            return Response::json(['msg' => 200, 'data' => $arr2, 'count' => $count]);
        } else {
            return Response::json(['msg' => 198, 'count' => 0]);
        }
    }

    /**
     * Function name: deleteIssueComment
     * Desc : Function to delete issue comments
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function deleteIssueComment(Request $request)
    {
        $data = $request->all();
        $where = ['rawQuery' => 'issue_comment_id=?', 'bindParams' => [$data['rowId']]];
        $detail = json_decode(json_encode(Staff::getInstance()->getIssueComment($where), true), true);
        if ($detail) {
            $obj = Staff::getInstance()->deleteIssueComment($detail[0]['issue_comment_id']);
            if ($obj) {
                return Response::json(['status' => 200, 'msg' => 'Comment Successfully Deleted', 'data' => $detail[0]]);
            } else {
                return Response::json(['status' => 198, 'msg' => 'Failed to Deleted']);
            }
        } else {
            return Response::json(['status' => 404, 'msg' => 'Error Occured Try After Some Time']);
        }
    }

    /**
     * Function name: editIssueComment
     * Desc : Function to edit issue comments
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function editIssueComment(Request $request)
    {
        $data1 = $request->all();
        $time = time();
        $where = ['rawQuery' => 'issue_comment_id=? ', 'bindParams' => [$data1['commentId']]];
        $dataToUpdate = ['comments' => $data1['commentTxt'], 'comment_posted_on' => $time, 'updated_at' => $time];
        $obj = Staff::getInstance()->updateIssueComment($where, $dataToUpdate);
        if ($obj) {
            $data['comment_posted_on'] = $time;
            $data['commentId'] = $data1['commentId'];
            return Response::json(['status' => 200, 'data' => $data]);
        } else {
            return Response::json(['status' => 198, 'msg' => 'Failed to Edit']);
        }
    }

    /**
     * Function name: finalIssueSubmission
     * Desc : Function to send issue submission templet to admin through email
     * @param Request $request
     * @return 200 for success or 198 for failiur
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function finalIssueSubmission(Request $request)
    {
        $ajaxData = $request->all();
        $time = $ajaxData['timezone'];
        date_default_timezone_set($time);
        $today = date("D,M jS,h:i A");
        $ajaxData = $request->all();
        $adminEmail = '';
        $where = ['rawQuery' => '1'];
        $detail = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
        if (isset($detail[0]['email'])) {
            $adminEmail = $detail[0]['email'];
        } else {
            return Response::json(['code' => 198]);
        }
        $fromData=json_decode(json_encode(Session::get('staff_detail'),true),true)['email'];
        $image = $this->api_url . '/uploads/logo3.png';
        $link = $this->api_url . '/admin/issue-submission/'.$ajaxData['issueId'].'?next=issue-submission/'.$ajaxData['issueId'];
        $mail = $adminEmail;
        $from = new \SendGrid\Email(null, $fromData);
        $subject = "Regarding issue Submission";
        $to = new \SendGrid\Email(null, $mail);
        $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Issue Submission</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
<center>
    <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
        <tr>
            <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
            <td align=\"right\" style=\"font-size:13px;\">$today</td>
        </tr>
    </table>
    <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    max-width:580px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
        <tr>
            <td style=\"width: 200px;\"><h2>Issue Submission</h2></td>
        </tr>
        <tr style=\"padding-top:9px;padding-bottom:50px;\">
            <td style=\"padding-bottom: 10px;\"><b>Project Name</b></td>
            <td style=\"padding-bottom: 10px;\">: {$ajaxData['projectName']}</td>
        </tr>
        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Issues Name</b></td>
            <td style=\"padding-bottom: 10px;\">: {$ajaxData['issueList']}</td>
        </tr>


        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Due Date</b></td>
            <td style=\"padding-bottom: 10px;\">: {$ajaxData['dueDate']}</td>
        </tr>
        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Severity</b></td>
            <td style=\"padding-bottom: 10px;\">: {$ajaxData['severity']}</td>
        </tr>
        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Issue Description</b> </td>
            <td style=\"padding-bottom: 10px;\">:{$ajaxData['issueDesc']}</td>
        </tr>
        <tr>
            <td style=\"padding-top:40px;\"><a style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" href='$link' >Check Details</a>
            </td>
        </tr>
    </table>
</center>
</body>

</html>");
        $mail = new \SendGrid\Mail($from, $subject, $to, $content);
        $apiKey = env('sendgrid_api_key');
        $sg = new \SendGrid($apiKey);
        $response = $sg->client->mail()->send()->post($mail);
        if ($response->statusCode() == 202){
            $noti['sender_id'] = Session::get('staff_detail')['id'];
            $noti['receiver_id'] = 1;
            $noti['sender_message'] = '';
            $noti['notify_type'] = '31';
            $noti['notification_status'] = '0';
            $mess = ["issueId" => $ajaxData['issueId']];
            $noti['receiver_message'] = '[' . json_encode($mess) . ']';
            $noti['created_at'] = time();
            $noti['updated_at'] = time();
            DB::table('notifications')->insert($noti);
            return Response::json(['code' => 200]);
        }else{
            return Response::json(['code' => 198]);
        }

    }

    /**
     * Function name: issueInvitation
     * Desc : Function to return to projects page
     * @param Request $request
     * @return '/staff/login'
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function issueInvitation(Request $request, $userId, $projectId,$issueId)
    {
        Session::put('u_id',$userId);
        Session::put('p_Iid',$projectId);
        Session::put('i_id',$issueId);
        return redirect('/staff/login');

    }


}