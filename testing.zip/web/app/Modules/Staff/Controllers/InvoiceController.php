<?php
/**
 * Created by PhpStorm.
 * User: GLB-141
 * Date: 8/3/2018
 * Time: 3:46 PM
 */

namespace App\Modules\Staff\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\User;
use App\Modules\Staff\Models\Invoice;
use App\Modules\Staff\Models\InvoiceComment;
use App\Modules\Staff\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\Facades\DataTables;

class InvoiceController extends Controller
{
    protected $api_url;


    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * Function name: invoiceDetails
     * Desc : Function to return to invoice page
     * @param Request $request
     * @return view invoiceDetails blade page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function invoiceDetails(Request $request)
    {
        return view('Staff::invoiceDetails');
    }

    /**
     * Function name: invoiceDataAjaxHandler
     * Desc : Function to return invoice details
     * @param Request $request
     * @return DataTables
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function invoiceDataAjaxHandler(Request $request)
    {
        $staff_id = Session::get('staff_detail')['id'];
        if ($request->isMethod('post')){
            if ($request->all()['id'] == 'time'){
                if ($request->all()['value'] == 1){
                    $a=time() - (86400);
                    $whereToFetch = ['rawQuery' => 'sender = ? and created_at >= ' .$a, 'bindParams' => [$staff_id]];
                }
                if($request->all()['value'] == 2){
                    $a=time() - (86400*7);
                    $whereToFetch = ['rawQuery' => 'sender = ? and created_at >= ' .$a, 'bindParams' => [$staff_id]];
                }
                if($request->all()['value'] == 3){
                    $a=time() - (86400*30);
                    $whereToFetch = ['rawQuery' => 'sender = ? and created_at >= ' .$a, 'bindParams' => [$staff_id]];

                }
                if($request->all()['value'] == 0){
                    $whereToFetch = ['rawQuery' => 'sender = ?', 'bindParams' => [$staff_id]];
                }
            }

            if ($request->all()['id'] == 'month'){
                $whereToFetch = ['rawQuery' => 'sender = ?', 'bindParams' => [$staff_id]];
            }

            if ($request->all()['id'] == 'view'){
                if ($request->all()['value'] == 0){
                    $whereToFetch = ['rawQuery' => 'sender = ?', 'bindParams' => [$staff_id]];
                }elseif ($request->all()['value'] == 1){
                    $a=time() - (86400*7);
                    $whereToFetch = ['rawQuery' => 'sender = ? and created_at >= ' .$a, 'bindParams' => [$staff_id]];
                }
            }
        }else{
            $whereToFetch = ['rawQuery' => 'sender = ?', 'bindParams' => [$staff_id]];
        }
//        $whereToFetch = ['rawQuery' => 'sender = ?', 'bindParams' => [Session::get('co_staff')]];
        $dataToFetch = ['invoice_id', 'invoice_number', 'sender', 'receiver', 'payment_by', 'attachment', 'start_date','due_amount','invoice_status', 'created_at'];
        $fetchInvoiceTable = Invoice::getInstance()->getInvoiceDetails($whereToFetch, $dataToFetch);
        $invoiceDetails = new Collection();

        foreach (json_decode($fetchInvoiceTable) as $k => $data) {
            if ($request->isMethod('post') && $request->all()['id'] == 'month') {
                if (date('F Y', $data->created_at) == $request->all()['value']) {
//
                } else {
                    continue;
                }
            }
            $InvStatus='';
            if ($data->invoice_status == 0){
//                $InvStatus='Un-Paid';
                $InvStatus='<a class="custom_text_danger" style="cursor: text">Un-Paid</a>';
            }else{
                $InvStatus='<a class="text-success" style="cursor: text">Paid</a>';
            }

            $invoiceNumber = $data->invoice_number;
            $invoiceSenderId = $data->sender;
            $invoiceReceiverId = $data->receiver;
            $whereToFindS = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceSenderId]];
            $whereToFindR = ['rawQuery' => 'id = ?', 'bindParams' => [$invoiceReceiverId]];
            $dataToFInd = ['name', 'role'];
            $senderName = User::getInstance()->getUserDetails($whereToFindS, $dataToFInd);
            $receiverName = User::getInstance()->getUserDetails($whereToFindR, $dataToFInd);
            $role = json_decode($senderName) ? json_decode($senderName)[0]->role : '';
            if ($role == 'A')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgSenderName = json_decode($senderName)[0]->name . ' ' . '[Staff]';

            $role = json_decode($receiverName) ? json_decode($receiverName)[0]->role : '';

            if ($role == 'A')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Admin]';
            if ($role == 'M')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Manager]';
            if ($role == 'S')
                $msgReceiverName = json_decode($receiverName)[0]->name . ' ' . '[Staff]';

            $startDate = date('Y-m-d', $data->start_date);
            $payBy = $data->payment_by.'- '.$data->due_amount ;
            $dataId = $data->invoice_id;
            $invoiceFile = json_decode($data->attachment);
            $invoiceFile = array_map(function ($h) {
                return $this->api_url . $h;
            }, $invoiceFile);
            $invoiceFile = json_encode($invoiceFile);
            $invoiceDetails->push([
                'serialNumber' => $k + 1,
                'inviceNumber' => $invoiceNumber,
                'sender' => $msgSenderName,
                'receiver' => $msgReceiverName,
                'startDate' => $startDate,
                'paymentBy' => $payBy,
                'attachFile' => '<a class="custom_text_info attachmentBtn" data-id="' . $dataId . '"><span class="fa fa-download"></span>Paymentdetails.pdf</a>',
                'invoice_status'=>$InvStatus,
                'viewDetails' => '<a href="/staff/invoice-comment/' . $dataId . '" class="custom_text_danger viewInvoiceDetails" data-id="' . $dataId . '" >View Details</a>',
            ]);
        }
        return DataTables::of($invoiceDetails)->rawColumns(['attachFile', 'viewDetails','invoice_status'])->make(true);
    }

    /**
     * Function name: fetchFile
     * Desc : Function to return invoice details
     * @param Request $request
     * @return $invoiceFile
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fetchFile(Request $request)
    {
        if ($request->isMethod('post')) {
            $invoiceId = $request->input('invoiceId');
            $dataToFind = ['attachment'];
            $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
            $query = Invoice::getInstance()->getInvoiceDetails($whereToFind, $dataToFind);
            $invoiceFile = json_decode(json_decode($query)[0]->attachment);
            $invoiceFile = array_map(function ($h) {
                return $this->api_url . $h;
            }, $invoiceFile);
            return json_encode(['status' => 200, 'data' => $invoiceFile]);
        }
    }

    /**
     * Function name: insertInvoiceComment
     * Desc : Function to send invoice comment
     * @param Request $request
     * @return status 200 for success and 400 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function insertInvoiceComment(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'insertInvoiceComment':
                    $invoiceId = $request->input('invoiceId');
                    $whereToFindRecipient = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
                    $fetchQuery = json_decode(Invoice::getInstance()->getInvoiceDetails($whereToFindRecipient));

                    $commentData = $request->input('comment');
                    $commentedBy = Session::get('co_staff');

                    $fileDataArr = [];
                    foreach ($request->all() as $key => $value) {
                        if (strpos($key, 'commentFiles') === 0) {
                            $fileDataArr[] = $value;
                        }
                    }

                    $allUploadedFiles = array_map(function ($file) {
                        $response = $this->fileUpload($file);
                        return json_decode($response)->data;
                    }, $fileDataArr);

                    $dataToInsert = [
                        'invoice_id' => $invoiceId,
                        'comments' => $commentData,
                        'comment_by' => $commentedBy,
                        'attachment_files' => $allUploadedFiles ? json_encode($allUploadedFiles) : '',
                        'comment_posted_on' => time(),
                        'created_at' => time(),
                        'updated_at' => time()
                    ];

                    $queryToInsert = InvoiceComment::getInstance()->insertInvoiceCommentData($dataToInsert);
                    if ($queryToInsert) {

                        $noti['sender_id'] = Session::get('staff_detail')['id'];
                        $noti['receiver_id'] = 1;
                        $noti['sender_message'] = '';
                        $noti['notify_type'] = '7';
                        $noti['notification_status'] = '0';
//                        $mess = ["sid"=>$noti["sender_id"],"rid"=>$noti["receiver_id"]];
                        $mess = ["invoiceId" => $invoiceId];
                        $noti['receiver_message'] = json_encode($mess);
                        $noti['created_at'] = time();
                        $noti['updated_at'] = time();
                        DB::table('notifications')->insert($noti);

                        return json_encode(['status' => 200, 'message' => 'Commented Successfully', 'data' => time(), 'id' => $queryToInsert, 'file' => $allUploadedFiles]);
                    } else
                        return json_encode(['status' => 400, 'message' => 'Please Try Again']);
            }
        }
    }

    /**
     * Function name: fileUpload
     * Desc : Function to upload file
     * @param Request $request
     * @return status 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fileUpload($file)
    {
        if ($file) {
            $num = rand(1000, 9999);
            $foldeName = 'uploads/' . time() . $num;
            $fileName = $file->getClientOriginalName();
            $filePath = uploadImageToStoragePathStaff($file, $foldeName, $fileName);
            if ($filePath) {
                return json_encode([
                    'status' => 200,
                    'msg' => 'File has been uploaded!',
                    'data' => $this->api_url . '/' . $foldeName . '/' . $filePath
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'msg' => 'Sorry, there was an error uploading your file.'
                ]);
            }
        } else {
            return json_encode([
                'status' => 401,
                'msg' => 'Request doesnot contain any file.'
            ]);
        }
    }

    /**
     * Function name: fetchInvoiceData
     * Desc : Function to fetch invoice details
     * @param Request $request
     * @return status 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fetchInvoiceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'fetchInvoiceAndComments':
                    $invoiceId = $request->input('invoiceId');
                    $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
                    $fetchInvoiceData = Invoice::getInstance()->getInvoiceDetails($whereToFind);
                    $sortingOrder = ['col' => 'comment_posted_on', 'order' => 'ASC'];
                    $fetchCommentData = json_decode(InvoiceComment::getInstance()->getCommentDetails($whereToFind, $sortingOrder));
                    $commentArray = [];
                    if ($fetchCommentData) {
                        foreach ($fetchCommentData as $k => $val) {
                            $commentPostedOn = date('d F Y H:i:s', $val->comment_posted_on);
                            $commentBy = $val->comment_by;
                            $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$commentBy]];
                            $dataToFInd = ['name', 'role', 'profile_pic'];
                            $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
                            if ($getUserDetails[0]->role == 'A') {
                                $commentBy = 'Admin';
                            } else if ($getUserDetails[0]->role == 'S') {
                                $commentBy = 'Staff';
                            } else if ($getUserDetails[0]->role == 'M') {
                                $commentBy = $getUserDetails[0]->name . '_manager';
                            }
                            $commentArray[] = [
                                'invoice_comment_id' => $val->invoice_comment_id,
                                'comment' => $val->comments,
                                'commentBy' => $commentBy,
                                'commentPostedOn' => $commentPostedOn,
                                'attachment_files' => $val->attachment_files ? json_decode($val->attachment_files) : '',
                                'profilePic' => $getUserDetails[0]->profile_pic ? $getUserDetails[0]->profile_pic : '/images/default.png'
                            ];
                        }
                    }

                    $dueAmmount = json_decode($fetchInvoiceData)[0]->due_amount;
                    $date = date('Y-m-d', json_decode($fetchInvoiceData)[0]->start_date);
                    $getPaymentIds = $this->getUserdata(json_decode($fetchInvoiceData)[0]->sender, json_decode($fetchInvoiceData)[0]->payment_by);

                    $InvoiceDetailsArr[] = [
                        'dueAmount' => $dueAmmount,
                        'dueDate' => $date,
                        'paymentBy' => json_decode($fetchInvoiceData)[0]->payment_by,
                        'paymentId' => $getPaymentIds,
                        'invoiceStatus' => json_decode($fetchInvoiceData)[0]->invoice_status
                    ];

                    if ($fetchInvoiceData) {
                        return json_encode(['status' => 200, 'message' => 'Fetched Project Details', 'data' => $InvoiceDetailsArr, 'comments' => $commentArray ? $commentArray : []]);
                    } else {
                        return json_encode(['status' => 400, 'message' => 'Not Fetched Data.Please Try Again.', 'data' => null]);
                    }
            }
        }
    }

    /**
     * Function name: invoiceComment
     * Desc : Function to fetch invoice comment
     * @param Request $request
     * @return status 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function invoiceComment($invoiceId)
    {
        $whereToFind = ['rawQuery' => 'invoice_id = ?', 'bindParams' => [$invoiceId]];
        $fetchInvoiceData = Invoice::getInstance()->getInvoiceDetails($whereToFind);
        $invoiceData=json_decode(json_encode($fetchInvoiceData,true),true);
        $where = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_staff')]];
        $find = ['paypalEmail', 'mPesaNumber'];
        $getPaymentIds = json_decode(json_encode(Staff::getInstance()->getData($where,$find),true),true);
        $paymentId='---';
        if ($invoiceData[0]['payment_by'] == 'Paypal'){
            $paymentId=$getPaymentIds['paypalEmail'];
        }else{
            $paymentId=$getPaymentIds['mPesaNumber'];
        }
        return view('Staff::invoiceComment',['invoice'=>$invoiceData[0],'paymentId'=>$paymentId]);
    }

    public function getInvoiceComment(Request $request)
    {
        $invoiceId = $request->all()['invoiceId'];
        $where = ['rawQuery' => 'invoice_id=?', 'bindParams' => [$invoiceId]];
        $details = json_decode(json_encode(Staff::getInstance()->getInvoiceComment($where), true), true);
        $where = ['rawQuery' => '1'];
        $usersData = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
        $users = [];
        foreach ($usersData as $user) {
            $users[$user['id']] = $user;
        }
        $arr2 = array();
        $arr3 = array();

        foreach ($details as $key => $val) {
            $userId = $val['comment_by'];
            if (isset($users[$userId])) {
                $detail = $users[$userId];
                $arr3['first_name'] = $detail['first_name'];
                $arr3['last_name'] = $detail['last_name'];
                $arr3['name'] = $detail['name'];

                $arr3['profilePic'] = $detail['profile_pic'];
                if ($detail['role'] == 'A') {
                    $arr3['commentBy'] = 'Admin';
                } elseif ($detail['role'] == 'M') {
                    $arr3['commentBy'] = $arr3['name'].'_Manager';
                } else {
                    $arr3['commentBy'] = $arr3['name'].'_Staff';
                }
                $arr3['comment'] = $val['comments'];
                $arr3['invoice_comment_id'] = $val['invoice_comment_id'];
                $arr3['attachment_files'] = json_decode($val['attachment_files'], true);
                $arr3['commentPostedOn'] = date('d M Y', $val['comment_posted_on']);
                $arr2[] = $arr3;
            }
        }
        $count = count($arr2);
        return Response::json(['msg' => 200, 'data' => $arr2, 'count' => $count]);

    }

    /**
     * Function name: getUserdata
     * Desc : Function to get user details
     * @param Request $request
     * @return $getUserDetails
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getUserdata($id, $type)
    {
        $whereToFindStaff = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFInd = ['name', 'role', 'profile_pic', 'paypalEmail', 'mPesaNumber'];
        $getUserDetails = json_decode(User::getInstance()->getUserDetails($whereToFindStaff, $dataToFInd));
        if ($type == 'mPesa') {
            return $getUserDetails[0]->mPesaNumber;
        } else
            return $getUserDetails[0]->paypalEmail;
    }

    /**
     * Function name: deleteInvoiceData
     * Desc : Function to delete invoice comment
     * @param Request $request
     * @return status 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function deleteInvoiceData(Request $request)
    {
        if ($request->isMethod('post')) {
            $chooseMethod = $request->input('chooseMethod');
            switch ($chooseMethod) {
                case 'deleteInvoiceComment':
                    $commentId = $request->input('invoiceCommentId');
                    $whereData = [
                        'rawQuery' => 'invoice_comment_id = ?',
                        'bindParams' => [$commentId]
                    ];
                    $deleteInvoiceComment = InvoiceComment::getInstance()->deleteComment($whereData);
                    if ($deleteInvoiceComment == true) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comments Details Deleted Successfully.',
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Deleted. Please Try Again to delete the Record.',
                        ]);
                    }
            }
        }
    }

    /**
     * Function name: updateInvoiceComment
     * Desc : Function to edit invoice comment
     * @param Request $request
     * @return status 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updateInvoiceComment(Request $request)
    {
        if ($request->isMethod('post')) {
            if ($request->all()) {
                $data = [
                    'rawQuery' => 'invoice_comment_id = ?',
                    'bindParams' => [$request->input('invoiceCommentId')]
                ];
                $getCommentDetails = json_decode(InvoiceComment::getInstance()->getCommentData($data));

                if ($getCommentDetails[0]->comments == $request->input('comment')) {
                    return json_encode(['status' => 400, 'message' => 'No Data has to be Updated']);
                } else {
                    $dataToUpdate = [
                        'comments' => $request->input('comment') ? $request->input('comment') : $getCommentDetails->comments,
                        'comment_posted_on' => time(),
                        'updated_at' => time(),
                    ];

                    $updatedData = InvoiceComment::getInstance()->updateComment($data, $dataToUpdate);
                    if ($updatedData) {
                        return json_encode([
                            'status' => 200,
                            'message' => 'Comment Updated Successfully!.'
                        ]);
                    } else {
                        return json_encode([
                            'status' => 400,
                            'message' => 'Not Updated. Please Try again.',
                        ]);
                    }
                }
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'No Data Found.',
                ]);
            }
        }
    }

    /**
     * Function name: invoice
     * Desc : Function to send invoice
     * @param Request $request
     * @return msg as 1 for success and0 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function invoice(Request $request)
    {
        if ($request->isMethod('post')) {
            if (date("l")== 'Friday'){
                //
            }else{
                return Response::json(['code' => 400]);
            }
            $data = $request->all();
            $array = $data;

            unset($array['receiver']);
            unset($array['sender']);
            unset($array['subject']);
            unset($array['message']);
            unset($array['currencySelect']);
            unset($array['due_amount']);
            unset($array['option1']);
            unset($array['option2']);
            unset($array['timeZone']);
            $file = [];
            $i = 0;
            if (empty($array)) {
                return Response::json(['msg' => 198]);
            }
            foreach ($array as $val) {
                $ext = $val->getClientOriginalExtension();
                $extn = uniqid() . "." . $ext;
                $doc = '"/documents/' . $extn . '"';
                $path = public_path() . "/documents";
                if ($val->move($path, $extn)) {
                    $file[$i] = $doc;
                } else {
                    return Response::json(['msg' => 0]);
                }
                $i++;
            }
            $d = implode(",", $file);
            $arr = array();
            $arr['invoice_number'] = 'INV-' . time();
            $arr['sender'] = Session::get('staff_detail')['id'];
            if ($data['receiver'] == 'Admin') {
                $arr['receiver'] = 1;
            } else {
                $arr['receiver'] = 1;
            }
            $arr['subject'] = $data['subject'];
            $arr['message'] = $data['message'];
            $arr['attachment'] = "[" . $d . "]";
            $arr['due_amount'] = $data['due_amount'] .'  '. $data['currencySelect'];
            if ($data['option1'] == 'true') {
                $arr['payment_by'] = 'mPesa';
            } elseif ($data['option2'] == 'true') {
                $arr['payment_by'] = 'PayPal';
            }
            $arr['invoice_status'] = 0;
            $arr['start_date'] = time();
            $arr['end_date'] = time();
            $arr['created_at'] = time();
            $arr['updated_at'] = time();
            $obj = Staff::getInstance();
            $result = $obj->invoice($arr);

            $adminEmail = '';
            $time = $data['timeZone'];
            date_default_timezone_set($time);
            $today = date("D,M jS,h:i A");
            $where = ['rawQuery' => '1'];
            $detail = json_decode(json_encode(Staff::getInstance()->getUserdata($where), true), true);
            if (isset($detail[0]['email'])) {
                $adminEmail = $detail[0]['email'];
            } else {
                $adminEmail = 'admin@cloudoffice.ltd';
            }
            $fromData=json_decode(json_encode(Session::get('staff_detail'),true),true)['email'];
            $image = $this->api_url . '/uploads/logo3.png';
            $link = $this->api_url . '/admin/invoice-comment/'.$result.'?next=invoice-comment/'.$result;
            $mail = $adminEmail;
            $from = new \SendGrid\Email(null, $fromData);
            $subject = "Regarding Invoice Payment";
            $to = new \SendGrid\Email(null, $mail);
            $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>Invoice Payment</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
<center>
    <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
        <tr>
            <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
            <td align=\"right\" style=\"font-size:13px;\">$today</td>
        </tr>
    </table>
    <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    max-width:580px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
        <tr>
            <td style=\"width: 200px;\"><h2>Invoice Payment</h2></td>
        </tr>
        <tr style=\"padding-top:9px;padding-bottom:50px;\">
            <td style=\"padding-bottom: 10px;\"><b>Subject</b></td>
            <td style=\"padding-bottom: 10px;\">: {$arr['subject']}</td>
        </tr>
        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Message</b></td>
            <td style=\"padding-bottom: 10px;\">: {$arr['message']}</td>
        </tr>


        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Payment by</b></td>
            <td style=\"padding-bottom: 10px;\">: {$arr['payment_by']}</td>
        </tr>
        <tr style=\"padding-top:5px;padding-bottom:20px;\">
            <td style=\"padding-bottom: 10px;\"><b>Due Amount</b></td>
            <td style=\"padding-bottom: 10px;\">: {$arr['due_amount']}</td>
        </tr>
        
        <tr>
            <td style=\"padding-top:40px;\"><a style=\"background: #2294e6;
          padding: 15px 20px;
          border-radius: 4px;
          border: none;
          color:#fff;
            font-size:0.9rem;cursor: pointer;\" href='$link' >Check Details</a>
            </td>
        </tr>
    </table>
</center>
</body>

</html>");
            $mail = new \SendGrid\Mail($from, $subject, $to, $content);
            $apiKey = env('sendgrid_api_key');
            $sg = new \SendGrid($apiKey);
            $response = $sg->client->mail()->send()->post($mail);
            if ($response->statusCode() == 202){
//                return Response::json(['code' => 200]);
            }else{
                return Response::json(['code' => 201]);
            }

            $noti = array();
            if ($result) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = 1;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '12';
                $noti['notification_status'] = '0';
                $mess = ["invoiceId" => $result];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 1]);
            } else {
                return Response::json(['msg' => 0]);
            }
        }else{
            $str = 'M';
            $dataToFind = ['id', 'first_name', 'last_name'];
            $whereToFind = ['rawQuery' => 'role = ?', 'bindParams' => ['M']];
            $data = json_decode(json_encode(Staff::getInstance()->getUserdata($whereToFind, $dataToFind), true), true);
            $where = ['rawQuery' => 'id = ?', 'bindParams' => [Session::get('co_staff')]];
            $find = ['paypalEmail', 'mPesaNumber'];
            $getPaymentIds = json_decode(json_encode(Staff::getInstance()->getData($where,$find),true),true);
            $arr1 = array();
            $arr2 = array();
            $arr1['id'] = null;
            $arr1['first_name'] = null;
            $arr1['last_name'] = null;
            $arr2[] = $arr1;
            if (isset($data)) {
                return view('Staff::invoice', ['mdata' => $data,'today'=>date("l"), 'paypalEmail'=>$getPaymentIds['paypalEmail'],'mpesanum'=>$getPaymentIds['mPesaNumber']]);
            } else {
                return view('Staff::invoice', ['mdata' => $arr2,'today'=>date("l"), 'paypalEmail'=>$getPaymentIds['paypalEmail'],'mpesanum'=>$getPaymentIds['mPesaNumber']]);
            }
        }
    }

    /**
     * Function name: invoice
     * Desc : Function to show all manager
     * @param Request $request
     * @return to invoice.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

//    public function invoice(Request $request)
//    {
//        if ($request->isMethod('get')) {
//            $str = 'M';
//            $dataToFind = ['id', 'first_name', 'last_name'];
//            $whereToFind = ['rawQuery' => 'role = ?', 'bindParams' => ['M']];
//            $data = json_decode(json_encode(Staff::getInstance()->getUserdata($whereToFind, $dataToFind), true), true);
//            $arr1 = array();
//            $arr2 = array();
//            $arr1['id'] = null;
//            $arr1['first_name'] = null;
//            $arr1['last_name'] = null;
//            $arr2[] = $arr1;
//            if (isset($data)) {
//                return view('Staff::invoice', ['mdata' => $data]);
//            } else {
//                return view('Staff::invoice', ['mdata' => $arr2]);
//            }
//        }
//    }


    /**
     * Function name: invoicePaid
     * Desc : Function to return to login page
     * @param Request $request
     * @return '/staff/login'
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function invoicePaid(Request $request, $userId, $invoiceId)
    {
        Session::put('u_id',$userId);
        Session::put('inv_Id',$invoiceId);
        return redirect('/staff/login');

    }

}