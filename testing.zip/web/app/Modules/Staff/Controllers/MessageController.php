<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 5/7/2018
 * Time: 11:58 AM
 */

namespace App\Modules\Staff\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;


class MessageController extends Controller
{

    /**
     * Function name: message
     * Desc : Function to fetch all the conversation between staff and admin/manager from message table..
     * @param Request $request
     * @return $msg - total no of conversasation between staff and admin/manager
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function message(Request $request)
    {
        if ($request->isMethod('get')) {

            $id = Session::get('co_staff');
            $where = ['rawQuery' => 'message_sender_id=? or message_receiver_id=?', 'bindParams' => [$id, $id]];
            $dataToFInd = ['message_sender_id', 'message_receiver_id', 'message'];
            $details = json_decode(json_encode(Staff::getInstance()->getMsgData($where, $dataToFInd), true), true);

            $arr1 = $details;
            $arr2 = $details;
            foreach ($arr1 as $a => $b) {
                foreach ($arr2 as $c => $d) {
                    if (isset($arr1[$a]) && isset($arr2[$c])) {
                        if (($arr1[$a]['message_sender_id'] == $arr2[$c]['message_receiver_id']) && ($arr1[$a]['message_receiver_id'] == $arr2[$c]['message_sender_id'])) {
                            $a1 = json_decode($b['sender_message'], TRUE);
                            $a2 = json_decode($d['sender_message'], TRUE);
                            unset($arr1[$c]);
                            unset($arr2[$c]);
                        }
                    }
                }
            }
            foreach ($arr1 as $key => $val1) {
                $id = '';
                if ($val1['message_sender_id'] == Session::get('staff_detail')['id']) {
                    $value1['senderId'] = $val1['message_receiver_id'];
                    $value1['receiverId'] = Session::get('staff_detail')['id'];
                    $id = $val1['message_receiver_id'];
                    $option = 'id';
                    $where = ['rawQuery' => $option . ' = ?',
                        'bindParams' => [$id]
                    ];
                    $doc = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
                    if($doc){
                        if ($doc['role'] == 'A'){
                            $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name']."__[Admin]";
                        }else{
                            $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name']."__[Manager]";
                        }
                    }
                    $value1['receiver'] = Session::get('staff_detail')['first_name'] . " " . Session::get('staff_detail')['last_name']."__[Staff]";
                    $value1['startDate'] = date("d/m/Y", $val1['created_at']);
                } else {
                    $value1['senderId'] = $val1['message_sender_id'];
                    $value1['receiverId'] = Session::get('staff_detail')['id'];
                    $id = $val1['message_sender_id'];
                    $option = 'id';
                    $where = ['rawQuery' => $option . ' = ?',
                        'bindParams' => [$id]
                    ];
                    $doc = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
                    if($doc){
                        if ($doc['role'] == 'A'){
                            $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name']."__[Admin]";
                        }else{
                            $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name']."__[Manager]";
                        }
                    }
                    $value1['receiver'] = Session::get('staff_detail')['first_name'] . " " . Session::get('staff_detail')['last_name']."__[Staff]";
                    $value1['startDate'] = date("d/m/Y", $val1['created_at']);
                }
                $msg[] = $value1;
            }
        }else{
        }
        $arr4 = array();
        $arr5 = array();
        $arr4['senderId'] = null;
        $arr4['receiverId'] = null;
        $arr4['sender'] = null;
        $arr4['receiver'] = null;
        $arr4['startDate'] = null;
        $arr5[] = $arr4;
        if (isset($msg)) {
            $msg = array_reverse($msg, true);
            return view('Staff::message', ['msg' => $msg]);
        } else {
            return view('Staff::message', ['msg1' => $arr5]);
        }
    }

    /**
     * Function name: newMessage
     * Desc : Function to add new conversation with admin or manager if
     *        conversation already exists than it will update the data in message table
     * @param Request $request
     * @return success or error msg
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function newMessage(Request $request)
    {
        $data = $request->all();
        $receiver = $data['receiver'];
        $id = Session::get('staff_detail')['id'];
        $where = ['rawQuery' => 'message_sender_id in(' . $id . ','.$receiver.') and message_receiver_id in(' . $id . ','.$receiver.')'];
        $dataToFInd = ['sender_message'];
        $details = json_decode(json_encode(Staff::getInstance()->getMsgData($where, $dataToFInd), true), true);
        if ($details) {
            $mData = array();
            $ms1 = $data['message'];
            $mData[0] = substr($details[0]['sender_message'], 1, -1);
            $mData[1] = "{" . '"id":' . Session::get('staff_detail')['id'];
            $mData[2] = '"posted_on":' . time();
            $mData[3] = '"message":"' . $ms1 . '"';
            $d = implode(",", $mData);
            $text = "[" . $d . "}]";
            $id = Session::get('co_staff');
            $where = ['rawQuery' => 'message_sender_id in(' . $id . ','.$receiver.') and message_receiver_id in(' . $id . ','.$receiver.')'];
            $dataToUpdate = ['sender_message' => $text, 'updated_at' => time()];
            $details = Staff::getInstance()->updateMsgData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $receiver;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '4';
                $noti['notification_status'] = '0';
                $mess = ["sid" => $noti["sender_id"], "rid" => $noti["receiver_id"]];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $arr = array();
            $arr['message_sender_id'] = Session::get('staff_detail')['id'];
            $arr['message_receiver_id'] = $data['receiver'];
            $arr['receiver_message'] = '';
            $ms = $data['message'];
            $msg[0] = "{" . '"id":' . Session::get('staff_detail')['id'];
            $msg[1] = '"posted_on":' . time();
            $msg[2] = '"message":"' . $ms . '"';
            $msg[3] = '"messageId":"' . 1 . '"';
            $d = implode(",", $msg);
            $text = "[" . $d . "}]";
            $arr['sender_message'] = $text;
            $arr['created_at'] = time();
            $arr['updated_at'] = time();
            $obj = Staff::getInstance();
            $result = $obj->newMessage($arr);
            if ($result) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $receiver;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '4';
                $noti['notification_status'] = '0';
                $mess = ["sid" => $noti["sender_id"], "rid" => $noti["receiver_id"]];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }
    }

    /**
     * Function name: getMsg
     * Desc : Function to get all the conversation between a particular staff and admin/manager from message table
     * @param Request $request
     * @return code 200 along with data or error code
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getMsg(Request $request)
    {
        $ids = $request->all();
        $pic = '';
        $sender = $ids['senderId'];
        $id = Session::get('co_staff');
        $where = ['rawQuery' => 'message_sender_id=? and message_receiver_id=?', 'bindParams' => [$sender, $id]];
        $dataToFind = ['sender_message'];
        $details = json_decode(json_encode(Staff::getInstance()->getMsgData($where, $dataToFind), true), true);

        $where1 = ['rawQuery' => 'message_receiver_id=? and message_sender_id=?', 'bindParams' => [$sender, $id]];
        $dataToFInd1 = ['sender_message'];
        $details1 = json_decode(json_encode(Staff::getInstance()->getMsgData($where1, $dataToFInd1), true), true);
        $a1 = null;
        $a2 = null;
        if ($details) {
            $a1 = json_decode($details[0]['sender_message'], TRUE);
        }
        if ($details1) {
            $a2 = json_decode($details1[0]['sender_message'], TRUE);
        }
        if (isset($a1) && isset($a2)) {
            $data = array_merge($a1, $a2);
        } elseif ($a1 != null) {
            $data = $a1;
        } elseif ($a2 != null) {
            $data = $a2;
        }
        usort($data, function ($a, $b) {
            return $a['posted_on'] <=> $b['posted_on'];
        });

        $dataToFind = ['profile_pic', 'first_name', 'last_name', 'role'];
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$sender]];
        $data1 = json_decode(json_encode(Staff::getInstance()->getUserdata($whereToFind, $dataToFind), true), true);
        if ($data1) {
            if ($data1[0]['role'] === 'A') {
                $name = 'Admin';
            } else if ($data1[0]['role'] === 'M') {
                $name = $data1[0]['first_name'] . ' ' . $data1[0]['last_name'] . '_Manager';
            } else if ($data1[0]['role'] === 'S') {
                $name = $data1[0]['first_name'] . ' ' . $data1[0]['last_name'] . '_Staff';
            }
            $pic = $data1[0]['profile_pic'];
        }

        $count = count($data);
        if ($data) {
            if (Session::has('number') && Session::get('number') == $count) {
                Session::forget('number');
                return Response::json(['code' => 198]);
            }
            Session::put('number', $count);
            return Response::json(['code' => 200, 'count' => $count, 'msg' => $data, 'profile' => $pic, 'name' => isset($name) ? $name : '']);
        } else {
            return Response::json(['code' => 198]);
        }

    }

    /**
     * Function name: sendMsg
     * Desc : Function to send message  to admin or manager and update the same to message table
     * @param Request $request
     * @return message to particular view page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function sendMsg(Request $request)
    {
        $req = $request->all();
        if (isset($req['message'])) {
            //
        } else {
            return Response::json(['msg' => 400]);
        }
        $id = Session::get('co_staff');

        $array = [];
        $allIds = array_push($array, $id, $req['receiverId']);

        $allId = implode(',', array_unique(array_map(function ($h) {
            return $h;
        }, $array)));

        $where = ['rawQuery' => 'message_sender_id in(' . $allId . ') and message_receiver_id in(' . $allId . ')'];
        $dataToFInd = ['sender_message'];
        $details = json_decode(json_encode(Staff::getInstance()->getMsgData($where, $dataToFInd), true), true);
        if (count($details) > 0) {
            $x = count(json_decode($details[0]['sender_message']));
        }
        if ($details) {
            $mData = array();
            $ms1 = $req['message'];
            $mData[0] = substr($details[0]['sender_message'], 1, -1);
            $mData[1] = "{" . '"id":' . Session::get('staff_detail')['id'];
            $mData[2] = '"posted_on":' . time();
            $mData[3] = '"message":"' . $ms1 . '"';
            $mData[4] = '"messageId":"' . ++$x . '"';
            $d = implode(",", $mData);
            $text = "[" . $d . "}]";
            $id = Session::get('co_staff');
            $where = ['rawQuery' => 'message_sender_id in(' . $allId . ') and message_receiver_id in(' . $allId . ')'];
            $dataToUpdate = ['sender_message' => $text, 'updated_at' => time()];
            $details = Staff::getInstance()->updateMsgData($where, $dataToUpdate);
            if ($details) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $req['receiverId'];
                $noti['sender_message'] = '';
                $noti['notify_type'] = '4';
                $noti['notification_status'] = '0';
                $mess = ["sid" => $noti["sender_id"], "rid" => $noti["receiver_id"]];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'mess' => $req['message'], 'time' => time()]);
            } else {
                return Response::json(['msg' => 198]);
            }
        } else {
            $arr = array();
            $arr['message_sender_id'] = Session::get('staff_detail')['id'];
            $arr['message_receiver_id'] = $req['receiverId'];
            $arr['receiver_message'] = '';
            $ms = $req['message'];
            $msg[0] = "{" . '"id":' . Session::get('staff_detail')['id'];
            $msg[1] = '"posted_on":' . time();
            $msg[2] = '"message":"' . $ms . '"';
            $msg[3] = '"messageId":"' . $ms . '"';
            $d = implode(",", $msg);
            $text = "[" . $d . "}]";
            $arr['sender_message'] = $text;
            $arr['created_at'] = time();
            $arr['updated_at'] = time();
            $obj = Staff::getInstance();
            $result = $obj->newMessage($arr);
            if ($result) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $req['receiverId'];
                $noti['sender_message'] = '';
                $noti['notify_type'] = '4';
                $noti['notification_status'] = '0';
                $mess = ["sid" => $noti["sender_id"], "rid" => $noti["receiver_id"]];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return Response::json(['msg' => 200, 'mess' => $req['message']]);
            } else {
                return Response::json(['msg' => 198]);
            }
        }
    }

    /**
     * Function name: getMsg
     * Desc : Function to get all the manager of the project
     * @param Request $request
     * @return msg 200 along with data or error code
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function getNewMsgdata(Request $request)
    {
        $dataToFind = ['id', 'first_name', 'last_name'];
        $whereToFind = ['rawQuery' => 'role = ? or role = ?', 'bindParams' => ['M','A']];
        $data = json_decode(json_encode(Staff::getInstance()->getUserdata($whereToFind, $dataToFind), true), true);
//        dd($data,'okk');
        if ($data) {
            return Response::json(['msg' => 200, 'mdata' => $data]);
        } else {
            return Response::json(['msg' => 198]);
        }

    }

    /**
     * Function name: redirectToMessage
     * Desc : Function to redirect from notification message url to message chat model
     * @param Request $request
     * @return msg 200 along with data or error code
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function redirectToMessage(Request $request)
    {
        $sid='';
        $rid='';
        if (isset($request->all()['sid']) && isset($request->all()['sid'])){
            $sid=$request->all()['sid'];
            $rid=$request->all()['rid'];
        }else{
            return redirect('/staff/message');
        }
            $id = Session::get('co_staff');
            $where = ['rawQuery' => 'message_sender_id=? or message_receiver_id=?', 'bindParams' => [$id, $id]];
            $dataToFInd = ['message_sender_id', 'message_receiver_id', 'message'];
            $details = json_decode(json_encode(Staff::getInstance()->getMsgData($where, $dataToFInd), true), true);

            $arr1 = $details;
            $arr2 = $details;
            foreach ($arr1 as $a => $b) {
                foreach ($arr2 as $c => $d) {
                    if (isset($arr1[$a]) && isset($arr2[$c])) {
                        if (($arr1[$a]['message_sender_id'] == $arr2[$c]['message_receiver_id']) && ($arr1[$a]['message_receiver_id'] == $arr2[$c]['message_sender_id'])) {
                            $a1 = json_decode($b['sender_message'], TRUE);
                            $a2 = json_decode($d['sender_message'], TRUE);
                            unset($arr1[$c]);
                            unset($arr2[$c]);
                        }
                    }
                }
            }
            $msg = array();
            foreach ($arr1 as $key => $val1) {
                $id = '';
                if ($val1['message_sender_id'] == Session::get('staff_detail')['id']) {
                    $value1['senderId'] = $val1['message_receiver_id'];
                    $value1['receiverId'] = Session::get('staff_detail')['id'];
                    $id = $val1['message_receiver_id'];
                    $option = 'id';
                    $where = ['rawQuery' => $option . ' = ?',
                        'bindParams' => [$id]
                    ];
                    $doc = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
                    $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name'];
                    $value1['receiver'] = Session::get('staff_detail')['first_name'] . " " . Session::get('staff_detail')['last_name'];
                    $value1['startDate'] = date("d/m/Y", $val1['created_at']);
                } else {
                    $value1['senderId'] = $val1['message_sender_id'];
                    $value1['receiverId'] = Session::get('staff_detail')['id'];
                    $id = $val1['message_sender_id'];
                    $option = 'id';
                    $where = ['rawQuery' => $option . ' = ?',
                        'bindParams' => [$id]
                    ];
                    $doc = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
                    $value1['sender'] = $doc['first_name'] . ' ' . $doc['last_name'];
                    $value1['receiver'] = Session::get('staff_detail')['first_name'] . " " . Session::get('staff_detail')['last_name'];
                    $value1['startDate'] = date("d/m/Y", $val1['created_at']);
                }
                $msg[] = $value1;
            }

        $arr4 = array();
        $arr5 = array();
        $arr4['senderId'] = null;
        $arr4['receiverId'] = null;
        $arr4['sender'] = null;
        $arr4['receiver'] = null;
        $arr4['startDate'] = null;
        $arr5[] = $arr4;
        if (isset($msg)) {
            Session::put('sid', $sid);
            Session::put('rid', $rid);
            return view('Staff::message', ['msg' => $msg, 'sid' => $sid, 'rid' => $rid]);
        } else {
            return view('Staff::message', ['msg1' => $arr5]);
        }

    }
}