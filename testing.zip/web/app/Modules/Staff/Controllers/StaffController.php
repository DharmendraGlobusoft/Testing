<?php

namespace App\Modules\Staff\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use Illuminate\Http\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class StaffController extends Controller
{

    /**
     * @var mixed
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    protected $api_url;

    /**
     * __construct
     * AdminController constructor..
     * @author Bandana Sahu<bandanasahu@globussoft.in>
     * @since 23-Mar-2018
     */
    public function __construct()
    {
        $this->api_url = env('APP_URL');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view("Staff::index");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Function name: login
     * Desc : Function to authinticate user and return to dashboard if successfulelse show error message
     * @param Request $request
     * @return view dashboard.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function login(Request $request)
    {

        if (Session::get('co_staff')) {
            $path = $this->checkEmail();
            return redirect($path);
        }
        if ($request->isMethod('get')) {
            return view('Staff::login');
        } else {
            $data = $request->all();
            $email = $data['email'];
            $password = $data['password'];
            if (isset($data['remember'])) {
                $remember = $data['remember'];
            } else {
                $remember = 'off';
            }
            $option = 'username';
            if (strpos($email, '@') !== false) {
                $option = 'email';
            }
            $where = ['rawQuery' => $option . ' = ?',
                'bindParams' => [$email]
            ];
            $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
            if ($details) {
                //
            } else {
                return redirect()->back()->with('msg0', "Please enter valid credentials..!!");
            }


            if (Auth::attempt(['email' => $details['email'], 'password' => $password], $remember)) {
                if (Auth::user()->role == 'S') {
                    if (Auth::user()->account_status == 'verified') {
                        Session::put('co_staff', Auth::user()->id);
                        $staff_details = Auth::user();
                        Session::put('staff_detail', $staff_details);

                        /* To store all session Ids in DB */
                        if ($details['session_id'] == '') {
                            $sessionArray[] = $request->getSession()->getId();
                        } else {
                            $allSesssionData = json_decode($details['session_id']);
                            foreach ($allSesssionData as $k => $val) {
                                if (!(file_exists(storage_path() . '/framework/sessions/' . $val))) {
                                    unset($allSesssionData[$k]);
                                }
                            }
                            array_push($allSesssionData, $request->getSession()->getId());
                            foreach ($allSesssionData as $k => $data) {
                                $sessionArray[] = $data;
                            }
                        }
                        $dataToUpdate = ['session_id' => json_encode($sessionArray)];
                        $whereToUpdate = ['rawQuery' => 'id=?', 'bindParams' => [Session::get('co_staff')]];
                        $updateQuery = Staff::getInstance()->updateData($whereToUpdate, $dataToUpdate);
                        $dataToFind = ['profile_pic'];
                        $whereToFind = ['rawQuery' => 'role = ?', 'bindParams' => ['A']];
                        $data1 = json_decode(json_encode(Staff::getInstance()->getData($whereToFind, $dataToFind), true), true);
                        Session::put('AdminImage', $data1['profile_pic']);
                        $path = $this->checkEmail();
                        return redirect($path);
                    } else {
                        return redirect()->back()->with('msg', "Please verify EMAIL to proceed..");
                    }
                } else {
                    return redirect()->back()->with('msg0', "Please enter valid credentials..!!");
                }
            } else {
                return redirect()->back()->with('msg0', "Please enter valid credentials..!!");
            }
        }
    }

    public function checkEmail()
    {
        if (Session::get('u_id')) {
            $t_id = null;
            $i_id = null;
            $p_id = null;
            $p_Tid = null;
            $p_Iid = null;
            $inv_Id = null;
            $u_id = Session::get('u_id');
            if (Session::has('p_id')) {
                $p_id = Session::get('p_id');
            }
            if (Session::has('inv_Id')) {
                $inv_Id = Session::get('inv_Id');
            }
            if (Session::has('t_id') && Session::has('p_Tid')) {
                $t_id = Session::get('t_id');
                $p_Tid = Session::get('p_Tid');
            }
            if (Session::has('i_id') && Session::has('p_Iid')) {
                $i_id = Session::get('i_id');
                $p_Iid = Session::get('p_Iid');
            }
            if (Session::get('co_staff') == $u_id) {
                Session::forget('u_id');
                if (isset($p_Tid) && isset($t_id)) {
                    Session::forget('t_id');
                    Session::forget('p_Tid');
                    $path = '/staff/viewSubmittion/' . $p_Tid . '/' . $t_id;
                    return $path;
                } elseif (isset($p_Iid) && isset($i_id)) {
                    Session::forget('i_id');
                    Session::forget('p_Iid');
                    $path = '/staff/issueSubmittion/' . $p_Iid . '/' . $i_id;
                    return $path;
                } elseif (isset($p_id)) {
                    Session::forget('p_id');
                    $path = '/staff/projects';
                    return $path;
                } elseif (isset($inv_Id)) {
                    Session::forget('inv_Id');
                    $path = '/staff/invoice-comment/' . $inv_Id;;
                    return $path;
                }
            }
        }
        $path = '/staff/dashboard';
        return $path;
    }

    /**
     * Function name: ajaxVerify
     * Desc : Function to authinticate user name from users table to avoid duplicate entry of data
     * @param Request $request
     * @return 1 for success 0 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function ajaxVerify(Request $request)
    {
        $username = $request->all()['username'];
        $option = 'username';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$username]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if ($details) {
            return Response::json(['msg' => 1]);
        } else {
            return Response::json(['msg' => 0]);
        }
    }

    /**
     * Function name: registerInvitationLink
     * Desc : Function to register through activation link provided by admin
     * @param Request $request
     * @return to registration page
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function registerInvitationLink(Request $request, $invitationLink)
    {
        if ($request->isMethod('get')) {
            $obj = json_decode(json_encode(Staff::getInstance()->invitationLink($invitationLink), true), true);
            if (isset($obj[0]['token'])) {
                if ($obj[0]['token'] == $invitationLink) {
                    $mail = $obj[0]['email_id'];
                    return view('Staff::register', ['email' => $mail, 'code' => $invitationLink]);
                } else {
                    return view('Staff::invitationLink');
                }
            } else {
                return view('Staff::invitationLink');
            }
        }
    }

    /**
     * Function name: register
     * Desc : Function to register register and send email for verification
     * @param Request $request
     * @return to login page if successfully verified from email
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function register(Request $request)
    {
        if ($request->isMethod('get')) {
            return view('Staff::register');
        }
        $data1 = $request->all();
        $str = str_random(10);
        $validation = Validator::make($data1, [
            'first_name' => 'required',
            'last_name' => 'required',
            'username' => 'required',
            'email1' => 'required|email',
            'password' => 'required'
        ]);

        if ($validation->fails()) {
            return Redirect::back()->withErrors($validation)->withInput($request->input());
        } else {
            unset($data1['_token']);
            unset($data1['checkbox']);
            $data['name'] = $data1['first_name'];
            $data['first_name'] = $data1['first_name'];
            $data['last_name'] = $data1['last_name'];
            $data['username'] = $data1['username'];
            $data['email'] = $data1['email1'];
            $data['password'] = Hash::make($data1['password']);
            $data['account_status'] = $str;
            $data['profile_pic'] = '/uploads/profile_pic/dhiru.jpg';
            $data['role'] = 'S';
            $data['created_at'] = time();
        }

        $option = 'email';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$data1['email1']]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if ($details) {
            return redirect()->back()->with('msggg', 'This email already exists..!!');
        }
        $obj = Staff::getInstance();
        $result = $obj->register($data);
        if ($result) {

            $confirmation_code = $data['account_status'];
            $mail = $request->email1;
            $from = new \SendGrid\Email(null, "Admin@cloudoffice.ltd");
            $subject = "Sending For Email verification..";
            $to = new \SendGrid\Email(null, $mail);
            $content = new \SendGrid\Content("text/html", 'Please <a href="' . $this->api_url . '/activateAccount/' . $confirmation_code . $mail . '">click</a> here for activating your account');
            $mail = new \SendGrid\Mail($from, $subject, $to, $content);
            $sg = new \SendGrid('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');
            $response = $sg->client->mail()->send()->post($mail);

            if ($response) {
                // ----------------deactivate invitation link---------------------------
                $obj1 = json_decode(json_encode(Staff::getInstance()->deactiveInvitationLink($data1['code']), true), true);
                if ($obj1) {
                    return redirect('/staff/login')->with('msg2', 'Please verify email to activate account');
                } else {
                    return view('Staff::invitationLink');
                }
            } else {
                $obj = Staff::getInstance()->manageAccount($result);
                if ($obj) {
                    return redirect('/staff/register')->with('msg', 'Registration Failed Please Try Again..!!');
                }
            }
            return redirect('/staff/login');
        } else {
            return redirect()->back()->with('msg', 'Failed to Signup, please try Again..!!');
        }
    }

    /**
     * Function name: activateAccount
     * Desc : Function to activate account through email
     * @param Request $request
     * @return to login page if successfully verified from email
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function activateAccount(Request $request, $cnfrmId)
    {
        $email = substr($cnfrmId, 10);
        $code = substr($cnfrmId, 0, 10);
        $arr['email'] = $email;
        $arr['code'] = $code;
        $option = 'email';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$email]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if ($details) {
            if ($details['account_status'] == 'verified') {
                return \redirect('/staff')->with('msg1', 'Account Verified please LOGIN to continue..');
            } else {
                $whereToUpdate = ['rawQuery' => 'email=?', 'bindParams' => [$email]];
                $dataToUpdate = ['account_status' => 'verified'];
                $res = Staff::getInstance()->updateData($whereToUpdate, $dataToUpdate);
                if ($res) {
                    return \redirect('/staff')->with('msg1', 'Account Verified please LOGIN to continue..');
                } else {
                    return \redirect('/staff')->with('msg', 'Error Occured Try again..!!');
                }
            }
        } else {
            return \redirect('/staff')->with('msg', 'Error Occured Try again..!!');
        }
    }

    /**
     * Function name: verifyEmail
     * Desc : Function to check email for duplicate entry
     * @param Request $request
     * @return 1 for success 0 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function verifyEmail(Request $request)
    {
        $data = $request->all()['email'];
        $option = 'email';
        $where = ['rawQuery' => $option . ' = ?',
            'bindParams' => [$data]
        ];
        $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
        if ($details) {
            return Response::json(['msg' => 1]);
        } else {
            return Response::json(['msg' => 0]);
        }
    }

    /**
     * Function name: forgetPassword
     * Desc : Function to change password with the help of sending email to the user
     * @param Request $request
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function forgetPassword(Request $request)
    {
        if ($request->isMethod('get')) {
            return view('Staff::forgetPassword');
        } else {
            $data = $request->all()['email'];
            $option = 'email';
            $where = ['rawQuery' => $option . ' = ?',
                'bindParams' => [$data]
            ];
            $details = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
            if ($details) {
                if (($details['role']) == 'S') {
                    //
                } else {
                    return \redirect()->back()->with('msgg', 'Please enter REGISTERED email..');
                }
                $confirmation_code = time();
                $mail = $data;
                $from = new \SendGrid\Email(null, "Admin@cloudoffice.ltd");
                $subject = "Reset Your Password..";
                $to = new \SendGrid\Email(null, $mail);
                $content = new \SendGrid\Content("text/html", 'Please <a href="' . $this->api_url . '/changePassword/' . $confirmation_code . $mail . '">click</a> here for activating your account<br><br>Link will expire after 1 hour...');
                $mail = new \SendGrid\Mail($from, $subject, $to, $content);
                $sg = new \SendGrid('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');
                $response = $sg->client->mail()->send()->post($mail);
                if ($response) {
                    $where = ['rawQuery' => 'email=?', 'bindParams' => [$data]];
                    $dataToUpdate = ['password_token' => $confirmation_code];
                    $details = Staff::getInstance()->updateData($where, $dataToUpdate);
                    if ($details) {
                        return \redirect()->back()->with('msg1', 'Visit Email to RESET Password..!!');
                    } else {
                        return \redirect()->back()->with('msg', 'Error Occured..!! Try again..!!');
                    }
                } else {
                    return \redirect()->back()->with('msg', 'Error Occured..!! Try again..!!');
                }

            } else {
                return \redirect()->back()->with('msgg', 'Please enter REGISTERED email..');
            }
        }
    }

    /**
     * Function name: changePassword
     * Desc : Function to change passwoed
     * @param Request $request
     * @return to login if change password is successful
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function changePassword(Request $request, $code)
    {
        if ($request->isMethod('get')) {

            $email = substr($code, 10);
            $option = 'email';
            $where = ['rawQuery' => $option . ' = ?',
                'bindParams' => [$email]
            ];
            $res = json_decode(json_encode(Staff::getInstance()->getData($where), true), true);
            if ($res['password_token'] == null) {
                return \redirect('/staff/login')->with('msg', 'Session Failed Try Again..!!');
            }
            if ((time() - $res['password_token']) < 3600) {
                return view('Staff::resetPassword', ['code' => $code]);
            }

        } else {
            $email = substr($code, 10);
            $code = substr($code, 0, 10);
            $where = ['rawQuery' => 'email=?', 'bindParams' => [$email]];
            $arr['password'] = Hash::make($request->all()['confirm_password']);
            $arr['password_token'] = null;
            $res = Staff::getInstance()->updateData($where, $arr);
            if ($res) {

                return \redirect('/staff/login')->with('msg1', 'Password Updated Successfully..!!');
            } else {
                return \redirect('/staff/login')->with('msg', 'Error Occured..!!try Again..!!');
            }
        }
    }

    public function sendContactForm(Request $request)
    {
        if ($request->isMethod('post')) {
            $firstName = $request['name'];
            $lastName = $request['surname'];
            $email = $request['email'];
            $phone = $request['phone'];
            $message = $request['message'];
            $image = $this->api_url . '/images/logo3.png';
            $time = date('D,M jS,h:i A', time());

            $from = new \SendGrid\Email(null, env('sendgrid_emailid'));
            $subject = "New User Enquery";
            $to = new \SendGrid\Email(null, 'admin@cloudoffice.ltd');
//            $to = new \SendGrid\Email(null, 'bandana.globussoft@gmail.com');
            $content = new \SendGrid\Content("text/html", "<!DOCTYPE html>
<html>
<header>
    <title>User Query</title>
</header>

<body style=\"background-color: #E9ECF2;margin-top:5%;\">
    <center>
        <table style=\"color: #627085;
                  font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                  max-width:700px;\">
            <tr>
                <td style=\"width:80%;\" align=\"left\"><img src=$image width=\"150px;\"></td>
                <td align=\"right\" style=\"font-size:13px;\">$time</td>
            </tr>
        </table>
        <table style=\"background-color: #fff;
                    font-family: 'ProximaNova-Regular', Helvetica, Arial, sans-serif;
                    font-size: 0.9rem;
                    color: #627085;
                    min-width:600px;
                    border-radius:4px;
                    margin: 5px 20px 20px 20px;
                    padding: 40px;
                    box-shadow:0 1px 3px #B7C0CC, 0 1px 2px #B7C0CC;\">
            <tr>
            <td><h2>User Deatils</h2></td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>First Name</b></td>
                <td style=\"padding-bottom: 10px;\">: $firstName</td>
            </tr>
            <tr style=\"padding-top:9px;padding-bottom:50px;\">
                <td style=\"padding-bottom: 10px;\"><b>Last Date</b></td>
                <td style=\"padding-bottom: 10px;\">: $lastName</td>
            </tr>
            
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Email-ID </b></td>
                <td style=\"padding-bottom: 10px;\">: $email</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Phone Number</b></td>
                <td style=\"padding-bottom: 10px;\">: $phone</td>
            </tr>
            <tr style=\"padding-top:5px;padding-bottom:20px;\">
                <td style=\"padding-bottom: 10px;\"><b>Message</b> </td>
                <td style=\"padding-bottom: 10px;\">: $message</td>
            </tr>
          
        </table>
    </center>
</body>

</html>");
            $mail = new \SendGrid\Mail($from, $subject, $to, $content);
            $apiKey = env('sendgrid_api_key');
            $sg = new \SendGrid($apiKey);
            $response = $sg->client->mail()->send()->post($mail);
            if($response){
                return json_encode(['status'=>200,'message'=>'Send Successfully']);
            }
        }
    }


}
