<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 5/11/2018
 * Time: 3:29 PM
 */

namespace App\Modules\Staff\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use App\Modules\Staff\Models\SupportTickets;
use App\Modules\Staff\Models\TicketReply;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;


class SupportController extends Controller
{
    public function supportlist($id = null)
    {
        $allProjectName = functionToGetProjectData();
        $allStaffName = functionToGetStaffData();
        $allManagerName = functionToGetMangerData();
        $allAdminName = functionToGetAdminData();
        $allData = array_merge(json_decode($allAdminName), json_decode($allManagerName));
        return view('Staff::supportTicket', ['data' => $allData, 'id' => $id, 'userData' => json_decode($allStaffName), 'managerData' => json_decode($allManagerName), 'projectName' => json_decode($allProjectName)]);
    }

    /**
     * Function name: addNewTicket
     * Desc : Function to add new ticket
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function addNewTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketReciepient = $request->all()['ticketReciepient'];
            $subject = $request->input('subject');
            $ticketDesc = $request->input('ticketDesc');

            $dataToInsert = [
                'ticket_raised_by' => Session::get('staff_detail')['id'],
                'ticket_reciepient' => $ticketReciepient,
                'ticket_subject' => $subject,
                'ticket_description' => $ticketDesc,
                'ticket_status' => 1, // 1-open and 0-closed
                'ticket_queried_at' => time(),
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsert = SupportTickets::getInstance()->insertTicketData($dataToInsert);
            if ($queryToInsert) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $ticketReciepient;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '5';
                $noti['notification_status'] = '0';
                $mess = ["supportTicketId" => $queryToInsert];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return json_encode(['status' => 200, 'message' => 'Ticket Data Inserted Successfully!']);
            } else
                return json_encode(['status' => 400, 'message' => 'Failed..! Please Try Again']);
        }
    }

    /**
     * Function name: ticketsInfoAjaxHandler
     * Desc : Function to get all ticket details
     * @param Request $request
     * @return DataTables
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function ticketsInfoAjaxHandler(Request $request)
    {
        $staff_id = Session::get('staff_detail')['id'];
        if ($request->isMethod('post')){
            if ($request->all()['id'] == 'time'){
                if ($request->all()['value'] == 1){
                    $a=time() - (86400);
                    $whereToFetch = ['rawQuery' => '(ticket_raised_by = ? or ticket_reciepient = ?) and created_at >= ' .$a, 'bindParams' => [$staff_id, $staff_id]];
                }
                if($request->all()['value'] == 2){
                    $a=time() - (86400*7);
                    $whereToFetch = ['rawQuery' => '(ticket_raised_by = ? or ticket_reciepient = ?) and created_at >= ' .$a, 'bindParams' => [$staff_id, $staff_id]];
                }
                if($request->all()['value'] == 3){
                    $a=time() - (86400*30);
                    $whereToFetch = ['rawQuery' => '(ticket_raised_by = ? or ticket_reciepient = ?) and created_at >= ' .$a, 'bindParams' => [$staff_id, $staff_id]];

                }
                if($request->all()['value'] == 0){
                    $whereToFetch = ['rawQuery' => 'ticket_raised_by = ? or ticket_reciepient = ?', 'bindParams' => [$staff_id, $staff_id]];
                }
            }

            if ($request->all()['id'] == 'month'){
                $whereToFetch = ['rawQuery' => 'ticket_raised_by = ? or ticket_reciepient = ?', 'bindParams' => [$staff_id, $staff_id]];
            }

            if ($request->all()['id'] == 'view'){
                if ($request->all()['value'] == 0){
                  $whereToFetch = ['rawQuery' => 'ticket_raised_by = ? or ticket_reciepient = ?', 'bindParams' => [$staff_id, $staff_id]];
                }elseif ($request->all()['value'] == 1){
                    $a=time() - (86400*7);
                    $whereToFetch = ['rawQuery' => '(ticket_raised_by = ? or ticket_reciepient = ?) and created_at >= ' .$a, 'bindParams' => [$staff_id, $staff_id]];
                }
            }
        }else{
            $whereToFetch = ['rawQuery' => 'ticket_raised_by = ? or ticket_reciepient = ?', 'bindParams' => [$staff_id, $staff_id]];
        }
        $dataToFetch = ['ticket_id', 'ticket_raised_by', 'ticket_reciepient', 'ticket_subject', 'ticket_description', 'ticket_status', 'ticket_queried_at'];
        $fetchTicketTable = SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch);
        $ticketDetails = new Collection();

        foreach (json_decode($fetchTicketTable) as $k => $data) {

            $whereToFindReceipient = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_reciepient]];
            $whereToFindRaisedBy = ['rawQuery' => 'id = ?', 'bindParams' => [$data->ticket_raised_by]];
            $dataToFInd = ['name', 'role'];
            $receipientName = Staff::getInstance()->getUserdata($whereToFindReceipient, $dataToFInd);
            $raisedBy = Staff::getInstance()->getUserdata($whereToFindRaisedBy, $dataToFInd);

            if ($receipientName[0]->role == 'A') {
                $receiverName = 'Admin';
            } else if ($receipientName[0]->role == 'M') {
                $receiverName = $receipientName[0]->name . '_Manager';
            } else {
                $receiverName = $receipientName[0]->name . '_Staff';
            }

            if ($raisedBy[0]->role == 'A') {
                $raisedBy = 'Admin';
            } else if ($raisedBy[0]->role == 'M') {
                $raisedBy = $raisedBy[0]->name . '_Manager';
            } else {
                $raisedBy = $raisedBy[0]->name . '_Staff';
            }

            $queriedAt = date('Y-m-d', $data->ticket_queried_at);

            if ($request->isMethod('post') && $request->all()['id'] == 'month') {
                if (date('F Y', $data->ticket_queried_at) == $request->all()['value']) {
//
                } else {
                    continue;
                }
            }

            $status = '<option value="1" ' . ($data->ticket_status == 1 ? 'selected' : '') . '>Open</option><option value="0" ' . ($data->ticket_status == 0 ? 'selected' : '') . '>Closed</option>';


            $ticketDetails->push([
                'ticketId' => $data->ticket_id,
                'ticketRaisedBy' => $raisedBy,
                'supportPersonal' => $receiverName,
                'subject' => '<p class="content_wrap">' . $data->ticket_subject . '</p>',
                'queried_at' => $queriedAt,
                'status' => '<select class="statusSelect" data-id =' . $data->ticket_id . ' >' . $status . '</select>',
//                'description' => '<p class="content_wrap">' . $data->ticket_description . '</p>',
                'description' => '<a class="custom_text_info viewDescriptionBtn" data-toggle="modal" data-target="#viewDescription"  data-id="' . $data->ticket_description . '" >View</a>',
                'tcktDesc' => $data->ticket_description,
                'tckSubject' => $data->ticket_subject,
                'viewQuery' => '<a class="custom_text_info viewQueryBtn" data-toggle="modal" data-target="#editStaffDetails"  data-id="' . $data->ticket_id . '" >Reply</a>',
            ]);
        }
        return DataTables::of($ticketDetails)->rawColumns(['subject', 'description', 'status', 'viewQuery'])->make(true);
    }
    /**
     * Function name: updateStatusOfTicket
     * Desc : Function to update ticket status
     * @param Request $request
     * @return 200 for success
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function updateStatusOfTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $ticketStatus = $request->input('ticketStatus');
            $whereToUpdate = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$ticketId]];
            $dataToUpdate = ['ticket_status' => $ticketStatus];

            $queryToUpdateStatus = SupportTickets::getInstance()->updateTIcket($whereToUpdate, $dataToUpdate);
            if ($queryToUpdateStatus == true) {
                return json_encode([
                    'status' => 200,
                    'message' => 'Staff Status Updated Successfully!'
                ]);
            } else {
                return json_encode([
                    'status' => 400,
                    'message' => 'Status Not Updated, Please Try Again'
                ]);
            }
        }
    }

    /**
     * Function name: fetchTicketReply
     * Desc : Function to find reply on ticket
     * @param Request $request
     * @return $allTIcketData, $ticketReplyDetails
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function fetchTicketReply(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $whereToFetch = ['rawQuery' => 'ticket_id = ?', 'bindParams' => [$ticketId]];
            $dataToFetch = ['ticket_status', 'ticket_subject', 'ticket_description', 'ticket_raised_by', 'ticket_queried_at'];
            $queryToFetchData = json_decode(SupportTickets::getInstance()->getTicketDetails($whereToFetch, $dataToFetch));

            $ticketRaiseBy = $queryToFetchData[0]->ticket_raised_by;
            $queryToFindUserDeatils = $this->toFIndUser($ticketRaiseBy);
            $dataTOFetchReplies = ['replies', 'replied_by', 'reply_posted_on'];
            $getAllReplies = json_decode(TicketReply::getInstance()->getTicketReplyDetails($whereToFetch, $dataTOFetchReplies));
            usort($getAllReplies, function ($a, $b) {
                return $b->reply_posted_on - $a->reply_posted_on;
            });
            $ticketReplyDetails = array_map(function ($data) {
                $repliedBy = $data->replied_by;
                $userData = $this->toFIndUser($repliedBy);
                if ($data->replied_by == 1) {
                    $repledBy = 'Admin';
                } else if ($data->replied_by == Session::get('co_manager')['id']) {
                    $repledBy = $userData[0]->name . '_manager';
                } else {
                    $repledBy = $userData[0]->name . '_staff';
                }
                return [
                    'replies' => $data->replies,
                    'replied_by' => $repledBy,
                    'reply_posted_on' => $data->reply_posted_on,
                    'profilePic' => $userData[0]->profile_pic ? $userData[0]->profile_pic : '/images/default.png'
                ];
            }, $getAllReplies);
            if ($queryToFindUserDeatils[0]->role == 'A') {
                $name = 'Admin';
            } else if ($queryToFindUserDeatils[0]->role == 'M') {
                $name = $queryToFindUserDeatils[0]->name . '_Manager';
            } else {
                $name = $queryToFindUserDeatils[0]->name . '_Staff';
            }
            $allTIcketData[] = [
                'ticket_description' => $queryToFetchData[0]->ticket_description,
                'ticket_status' => $queryToFetchData[0]->ticket_status,
                'ticket_subject' => $queryToFetchData[0]->ticket_subject,
                'ticket_queried_at' => $queryToFetchData[0]->ticket_queried_at,
                'name' => $name,
                'profile_pic' => $queryToFindUserDeatils[0]->profile_pic ? $queryToFindUserDeatils[0]->profile_pic : 'http://dummyimage.com/60',
            ];
            return json_encode(['status' => 200, 'message' => 'all data', 'data' => $allTIcketData, 'allTicketReplies' => $ticketReplyDetails]);
        }
    }

    /**
     * Function name: toFIndUser
     * Desc : Function to find user details
     * @param $id
     * @return $queryToFindUserDeatils
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    function toFIndUser($id)
    {
        $whereToFind = ['rawQuery' => 'id = ?', 'bindParams' => [$id]];
        $dataToFind = ['name', 'profile_pic', 'role'];
        $queryToFindUserDeatils = json_decode(Staff::getInstance()->getUserdata($whereToFind, $dataToFind));
        return $queryToFindUserDeatils;
    }

    /**
     * Function name: sendReplyForTicket
     * Desc : Function to send reply for generated support ticket
     * @param Request $request
     * @return 200 for success 400 for error
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function sendReplyForTicket(Request $request)
    {
        if ($request->isMethod('post')) {
            $ticketId = $request->input('ticketId');
            $ticketReply = $request->input('ticketReply');
            $repliedBy = Session::get('staff_detail')['id'];
            $recieptant = DB::table('support_tickets')->where('ticket_id', $ticketId)->first();
            $receiver = json_decode(json_encode($recieptant, true), true);
            $recId = $receiver['ticket_reciepient'];

            if($recId == Session::get('staff_detail')['id']){
                $receiverId=$receiver['ticket_raised_by'];
            }else{
                $receiverId=$receiver['ticket_reciepient'];
            }

            $dataToInsert = [
                'ticket_id' => $ticketId,
                'replies' => $ticketReply,
                'replied_by' => $repliedBy,
                'reply_posted_on' => time(),
                'created_at' => time(),
                'updated_at' => time()
            ];
            $queryToInsert = TicketReply::getInstance()->insertTicketReplyData($dataToInsert);
            if ($queryToInsert) {
                $noti['sender_id'] = Session::get('staff_detail')['id'];
                $noti['receiver_id'] = $receiverId;
                $noti['sender_message'] = '';
                $noti['notify_type'] = '6';
                $noti['notification_status'] = '0';
                $mess = ["id" => $ticketId];
                $noti['receiver_message'] = '[' . json_encode($mess) . ']';
                $noti['created_at'] = time();
                $noti['updated_at'] = time();
                DB::table('notifications')->insert($noti);
                return json_encode(['status' => 200, 'message' => 'Support Ticket Replied Successfully', 'data' => time()]);
            } else
                return json_encode(['status' => 400, 'message' => 'Please Try Again']);
        }
    }

}