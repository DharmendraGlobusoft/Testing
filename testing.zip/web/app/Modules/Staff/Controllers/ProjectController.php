<?php
/**
 * Created by Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
 * Date: 4/19/2018
 * Time: 12:33 PM
 */

namespace App\Modules\Staff\Controllers;


use App\Http\Controllers\Controller;
use App\Modules\Staff\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;


class ProjectController extends Controller
{
    /**
     * Function name: projects
     * Desc : Function to return to projects page
     * @param Request $request
     * @return view projects.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function projects(Request $request)
    {
        if ($request->isMethod('get')) {

            $userId = Session::get('co_staff');
            $projectDetails = array();
            $projectDoc = array();
            $res = json_decode(json_encode(Staff::getInstance()->projectData(), true), true);
            foreach ($res as $key => $value) {
                $staff = $res[$key]['staff_id'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
                if ( in_array("$userId", $staff)) {
                    $projectDetails['project_id'] = $value['project_id'];
                    $projectDetails['project_name'] = $value['project_name'];
                    $projectDoc[] = $projectDetails;
                }
            }
            return view('Staff::projects',['projectName'=>$projectDoc]);
        }

    }

    /**
     * Function name: viewMore
     * Desc : Function to show full comments
     * @param Request $request
     * @return $resourceData
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function viewMore(Request $request, $id)
    {
        if ($request->isMethod('get')) {
            $resourceId = $id;
            $where = ['rawQuery' => 'resource_id = ?', 'bindParams' => [$resourceId]];
            $resourceData = json_decode(json_encode(Staff::getInstance()->resourceData($where), true), true);
            return view('Staff::viewMore', ['data' => $resourceData[0]]);
        }
    }

    /**
     * Function name: resource
     * Desc : Function to show full resource content
     * @param Request $request
     * @return to resource.blade.php
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function resource(Request $request)
    {
        if ($request->isMethod('get')) {
            $userId = Session::get('staff_detail')['id'];
            $where = ['rawQuery' => 'resource_privacy = ?', 'bindParams' => [0]];
            $public = json_decode(json_encode(Staff::getInstance()->resourceData($where), true), true);
            $where = ['rawQuery' => 'resource_privacy = ?', 'bindParams' => [1]];
            $private = json_decode(json_encode(Staff::getInstance()->resourceData($where), true), true);
            $allProject = json_decode(json_encode(Staff::getInstance()->projectData(), true), true);
            $projectId = [];

//------------------------user assigned in project-----------------------

            if ($allProject) {
                foreach ($allProject as $key => $value) {
                    $staff = $allProject[$key]['staff_id'];
                    $staff = substr($staff, 1, -1);
                    $staff = explode(',', $staff);
                    if (in_array("$userId", $staff)) {
                        $projectId[] = $value['project_id'];
                    }
                }
            }
            $pId = [];

//---------------user assigned in same project-----------------------

            foreach ($private as $value) {
                $pid = $value['project_ids'];
                $pid = substr($pid, 1, -1);
                $pid = explode(',', $pid);
                if (array_intersect($projectId, $pid)) {
                    $pId[] = $value['resource_id'];
                }
            }
//------------------user with private id---------------------------
            $p_Id = [];
            foreach ($private as $value) {
                $uid = $value['staff_ids'];
                $uid = substr($uid, 1, -1);
                $uid = explode(',', $uid);
                if (in_array("$userId", $uid)) {
                    $p_Id[] = $value['resource_id'];
                }
            }

//------------------user with public id---------------------------
            $up_Id = [];
            foreach ($public as $value) {
                $up_Id[] = $value['resource_id'];
            }

//------------------merge all array--------------------

            $merge = array_merge($pId, $p_Id, $up_Id);
            $resultant = array_unique($merge);
            $str = substr(json_encode($resultant), 1, -1);
            $where = ['rawQuery' => 'resource_id in(' . $str . ')'];
            if ($str == null) {
                return view('Staff::resource');
            }
            $data = Staff::getInstance()->resourceDetails($where);
            if ($data) {
                $jsonData = json_decode($data);
                foreach ($jsonData as $value) {
                    $fullPath = storage_path('app/' . $value->resource_content);
                    $text = file_get_contents($fullPath);

                    $content = implode(' ', array_slice(explode(' ', $text), 0, 35));
                    $a = strip_tags($content);
                    $value->resource_content = $a;
                }
                return view('Staff::resource', ['data' => $jsonData]);
            } else {
                return view('Staff::resource');
            }
        }
    }

    /**
     * Function name: projectDataAjaxHandler
     * Desc : Function to return project details
     * @param Request $request
     * @return $projectDetails
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function projectDataAjaxHandler(Request $request)
    {
        $id = $request->input('id');
        $userId = Session::get('co_staff');
        $projectDetails = array();
        $projectDoc = array();
        $allStaffName='';
        $arr = array();
        $value = json_decode(json_encode(Staff::getInstance()->dataProject($id), true), true);
        if ($value) {
            $staff = $value[0]['staff_id'];
            $staff = substr($staff, 1, -1);
            $staff = explode(',', $staff);
            $output = '';
            foreach($staff as $val) {
                $output .= $val .",";
            }
            $str=substr($output, 0, -1);
            $where = ['rawQuery' => 'id in(' .$str.')'];
            $StaffdataToFInd = ['first_name','last_name'];
            $staffDetails = json_decode(json_encode(Staff::getInstance()->getUserdata($where, $StaffdataToFInd), true), true);
            $allStaffName='';
            if ($staffDetails){
                foreach ($staffDetails as $val){
                    $allStaffName.= $val['first_name'].' '.$val['last_name'].', ';
                }
                $allStaffName=substr($allStaffName, 0, -1);
            }

//            dd($allStaffName);
            if (true) {
                $projectDetails['project_id'] = $value[0]['project_id'];
                $projectDetails['projectName'] = $value[0]['project_name'];
                if ($value[0]['project_status'] == 1) {
                    $projectDetails['projectStatus'] = 'Active';
                } else {
                    $projectDetails['projectStatus'] = 'In-Active';
                }

                $manager = $value[0]['manager_id'];
                $manager = substr($manager, 1, -1);
                $manager = explode(',', $manager);
                $res1 = json_decode(json_encode(Staff::getInstance()->staffDetails($manager), true), true);
                if ($res1[0]) {
                    $projectDetails['manager'] = $res1;
                } else {
                    $projectDetails['manager'] = 'No manager Assigned';
                }
                $projectDetails['staffName'] = $allStaffName;

                $projectDetails['startDate'] = isset($value[0]['start_date']) ? date('m-d-Y', $value[0]['start_date']) : '--';

                $projectDetails['end_date'] = isset($value[0]['end_date']) ? date('m-d-Y', $value[0]['end_date']) : '--';

                if ($value[0]['privacy_status'] == 1) {
                    $projectDetails['privacy'] = 'Public';
                } else {
                    $projectDetails['privacy'] = 'Private';
                }
                $dataToFind = ['issue_topic'];
                $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$value[0]['project_id']]];
                $queryToFindData = Staff::getInstance()->pendingIssues($whereToFind, $dataToFind);
                $isssuesData = json_decode(json_encode($queryToFindData), true);
                $issueDeatils = array_map(function ($d) {
                    return $d['issue_topic'];
                }, $isssuesData);
                if ($issueDeatils == null) {
                    $projectDetails['issues'] = ['No issues'];
                } else {
                    $projectDetails['issues'] = $issueDeatils;
                }
            }
//            return Response::json(['code' => 200, 'data' => $projectDetails,'allStaffName'=>$allStaffName]);
            return Response::json(['code' => 200, 'data' => $projectDetails]);

        } else {
            return Response::json(['code' => 198, 'msg' => "Data not found!!"]);
        }
    }

    /**
     * Function name: projectAjaxHandler
     * Desc : Function to return all project details in which user is assigned or the public project
     * @param Request $request
     * @return $fullData
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function projectAjaxHandler(Request $request)
    {
        $userId = Session::get('co_staff');
        $projectDetails = array();
        $projectDoc = array();
        $arr = array();
        $res = json_decode(json_encode(Staff::getInstance()->projectData(), true), true);
//        if ($res) {
            $i = 0;
            foreach ($res as $key => $value) {
                $staff = $res[$key]['staff_id'];
                $staff = substr($staff, 1, -1);
                $staff = explode(',', $staff);
//                if (in_array("$userId", $staff)) {
                if ($res[$key]['privacy_status'] == 1 || in_array("$userId", $staff)) {
                    $projectDetails['project_id'] = $value['project_id'];
                    $projectDetails['projectName'] = $value['project_name'];
                    $projectDetails['created_at'] = $value['created_at'];
                    if ($value['project_status'] == 1) {
                        $projectDetails['projectStatus'] = 'Active';
                    } else {
                        $projectDetails['projectStatus'] = 'In-Active';
                    }

                    $manager = $res[$key]['manager_id'];
                    $manager = substr($manager, 1, -1);
                    $manager = explode(',', $manager);
                    $res1 = json_decode(json_encode(Staff::getInstance()->staffDetails($manager), true), true);
                    if ($res1) {
                        $projectDetails['manager'] = $res1;
                    } else {
                        $projectDetails['manager'] = null;
                    }

                    $res2 = json_decode(json_encode(Staff::getInstance()->staffDetails($staff), true), true);
                    if ($res2) {
                        $arr['staffDetails'] = $res2;
                    } else {
                        $arr['staffDetails'] = null;
                    }
                    $projectDetails['staffName'] = $arr['staffDetails'];

                    if (isset($res[$key]['start_date'])) {
                        $projectDetails['startDate'] = date('m-d-Y', $res[$key]['start_date']);
                    } else {
                        $projectDetails['startDate'] = '--';
                    }
                    if (isset($res[$key]['end_date'])) {
                        $projectDetails['end_date'] = date('m-d-Y', $res[$key]['end_date']);
                    } else {
                        $projectDetails['end_date'] = '--';
                    }

//                    $projectDetails['startDate'] = date('m-d-Y', $res[$key]['start_date']);
//                    $projectDetails['endDate'] = date('m-d-Y', $res[$key]['end_date']);

                    if ($res[$key]['privacy_status'] == 1) {
                        $projectDetails['privacy'] = 'Public';
                    } else {
                        $projectDetails['privacy'] = 'Private';
                    }
                    $dataToFind = ['issue_topic'];
                    $whereToFind = ['rawQuery' => 'project_id = ?', 'bindParams' => [$value['project_id']]];
                    $queryToFindData = Staff::getInstance()->pendingIssues($whereToFind, $dataToFind);
                    $isssuesData = json_decode(json_encode($queryToFindData), true);
                    $issueDeatils = array_map(function ($d) {
                        return $d['issue_topic'];
                    }, $isssuesData);
                    if ($issueDeatils == null) {
                        $projectDetails['issues'] = '';
                    } else {
                        $projectDetails['issues'] = $issueDeatils;
                    }
                    $projectDoc[$i] = $projectDetails;
                    $i++;
                }
            }


        $filterData=$projectDoc;
        $timeFilter=array();
        $monthFilter=array();
        $projectFilter=array();
        $viewFilter=array();

        if ($request->isMethod('post')){
            if ($request->all()['id'] == 'time'){
                if ($request->all()['value'] == 1){
                    foreach ($filterData as $key => $val){
                        if (date('d F Y',$val['created_at']) == date('d F Y',time())){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 2){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }

                }
                if($request->all()['value'] == 3){
                    $a=time() - (86400*30);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $timeFilter[]=$val;
                        }
                    }
                }
                if($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $timeFilter[]=$val;
                    }
                }
                $projectDoc=$timeFilter;
            }

            if ($request->all()['id'] == 'month'){
                foreach ($filterData as $key => $val){
                    if (date('F Y',$val['created_at']) == $request->all()['value']){
                        $monthFilter[]=$val;
                    }
                }
                $projectDoc=$monthFilter;
            }

            if ($request->all()['id'] == 'projectId'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $projectFilter[]=$val;
                    }
                    $projectDoc=$projectFilter;
                }else{
                    foreach ($filterData as $key => $val){
                        if ($val['project_id'] == $request->all()['value']){
                            $projectFilter[]=$val;
                        }
                    }
                    $projectDoc=$projectFilter;
                }
            }

            if ($request->all()['id'] == 'view'){
                if ($request->all()['value'] == 0){
                    foreach ($filterData as $key => $val){
                        $viewFilter[]=$val;
                    }
                    $projectDoc=$viewFilter;

                }elseif ($request->all()['value'] == 1){
                    $a=time() - (86400*7);
                    foreach ($filterData as $key => $val){
                        if ($val['created_at'] >= $a){
                            $viewFilter[]=$val;
                        }
                    }
                    $projectDoc=$viewFilter;
                }
            }
        }

//        dd($projectDoc,'okk');

        $fullData = new Collection();
        $i = 1;
        foreach ($projectDoc as $key => $val) {

            $staff = '';
            $staff1 = '';

            foreach ($val['staffName'] as $name) {
                $staff .= "<p>$name</p>";
                $staff1 .= "$name ,";
            }

            $issue = '';
            $co = 1;
            if (!empty($val['issues'])) {
                foreach ($val['issues'] as $iss) {
                    $issue .= "<p>$co. $iss</p>";
                    $co++;
                }
            } else {
                $issue = "<p style='text-align: center'><b>No pending issues are there..!!</b></p>";
            }

            $fullData->push([
                'serialNumber' => $i,
                'projectName' => '<p class="content_wrap">' . $val['projectName'] . '</p>',
                'startDate' => $val['startDate'],
                'endDate' => $val['end_date'],
                'staffDetails' => ' <a class="btn btn-info name" style="color: #fff;">Staff List
                                            <div class="name_show">' . $staff . '</div>
                                    </a>',
                'pendingIssues' => '<a class="custom_text_info name issueList"  id="9" data-toggle="modal" data-target="#issue_list">Issue List
                                            <div class="name_show" id="listOfIsssue" hidden>' . $issue . '</div>
                                    </a>',
                'projectDetails' => '<a class="custom_text_info" data-toggle="modal" data-target="#editProjectmodal" onclick="data(' . $val['project_id'] . ')">View Details</a>',
                'projName' => $val['projectName'],
            ]);

            $i++;
        }
        return DataTables::of($fullData)
            ->rawColumns(['projectName','staffDetails', 'pendingIssues', 'projectDetails'])
            ->make(true);
//        } else {
//            echo 'data not found';
//        }
    }

    /**
     * Function name: projectInvitation
     * Desc : Function to return to projects page
     * @param Request $request
     * @return to login
     * @author Dharmendra Kumar Sharma <dharmendrasharma@globussoft.in>
     */

    public function projectInvitation(Request $request, $userId, $projectId)
    {
        Session::put('u_id',$userId);
        Session::put('p_id',$projectId);
        return redirect('/staff/login');

    }

}