<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class CheckSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next, $module)
    {
        if ($module == 'admin') {
            if (!Session::has('co_admin')) {
                if (isset($request['next']))
                    return redirect('/admin/login/?next=' . $request->all()['next']);
                else
                    return redirect('/admin/login');
            }
        } else if ($module == 'manager') {
            if (!Session::has('co_manager')) {
                if (isset($request['next']))
                    return redirect('/manager/sign-in/?next=' . $request->all()['next']);
                else
                    return redirect('/manager/sign-in');
            }
        } else if ($module == 'staff') {
            if (!Session::has('co_staff')) {
                return redirect('/staff/login');
            }
        }
        $response = $next($request);
        return $response;
    }
}