<?php
            return [
                'copyscape_username'=>'mikebeatz2010',
                'copyscape_api_key'=>'d2f4oowd7hd69vo3'
            ];