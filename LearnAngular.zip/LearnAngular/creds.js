module.exports = {
    app_url: 'http://localhost:8000',
    sendGridApiKey: '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',
    username: 'kumarglobussoft-facilitator_api1.gmail.com',
    password: '3FTQF5KBCFUTU4Z6',
    signature: 'AVxojh21GaEm-ayxn.nRWNuiTNRuAb0BCqrkJbWVlKGzl3pClkRES4jh',
    returnUrl: 'http://localhost:8000/returnUrl',
    cancelUrl: 'http://localhost:8000/cancelUrl',
    userEmail: 'sharmaglobussoft@gmail.com',
    pass: 'Sharma@123'
};