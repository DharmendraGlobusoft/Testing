'use strict';

var config = require('../../../../config');
var creds = require('../../../../creds');

module.exports.landingPage = function (req, res) {
    res.render('landing.ejs');
};
module.exports.logingPage = function (req, res) {

    // write your codes

    res.send({ code: 200, token: 'result from userController', message: "successfully signin" });


};
module.exports.contact = function (req, res) {

    // write your codes

    res.send({ code: 200, token: 'result from userController', message: "successfully got contact details" });


};