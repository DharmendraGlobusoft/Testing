(function(){

    console.log('jsFiles');

    var myApp=angular.module('myApp',[
        'ui.router',
        'ngRoute',
        'ngCookies',
        'oc.lazyLoad',
        'ui-notification',
        'ui.select',
        'ui.bootstrap',
        // 'ui.slimscroll'
    ]);

    myApp.filter('trusted', ['$sce', function ($sce) {
        return $sce.trustAsResourceUrl;
    }]);


    myApp.config(['$ocLazyLoadProvider', function ($ocLazyLoadProvider) {
        $ocLazyLoadProvider.config({
            cssFilesInsertBefore: 'ng_load_plugins_before'
            // load the above css files before a LINK element with this ID. Dynamic CSS files must be loaded between core and theme css files
        });
    }]);

    // myApp.controller('headController', function($scope) {
    //      console.log('=====================================here');
    //
    //      $scope.anyFunName=function() {
    //          $scope.name='Dharmendra';
    //      };
    //
    //
    // });



    myApp.config(['$stateProvider', '$locationProvider', '$urlRouterProvider', '$httpProvider',
        '$cookiesProvider',
        function ($stateProvider, $locationProvider, $urlRouterProvider, $httpProvider,
                  $cookiesProvider) {
            // $urlRouterProvider.otherwise('/signin');
            $urlRouterProvider.otherwise('/');
            $stateProvider
                .state("/", {
                    url: "/",
                    // .state("/signin", {
                    // url: "/signin",
                    // templateUrl: '/app/module/user/views/login.html',
                    templateUrl: '/app/module/user/views/first.html',
                    controller: 'signcntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/login", {
                    url: "/login",
                    templateUrl: '/app/module/user/views/login.html',
                    controller: 'logincntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/register", {
                    url: "/register",
                    templateUrl: '/app/module/user/views/register.html',
                    controller: 'logincntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/contact", {
                    url: "/contact",
                    templateUrl: '/app/module/user/views/contact.html',
                    controller: 'contactcntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/first", {
                    url: "/home",
                    templateUrl: '/app/module/user/views/first.html',
                    controller: 'homecntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/single", {
                    url: "/single",
                    templateUrl: '/app/module/user/views/single.html',
                    controller: 'homecntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/products", {
                    url: "/products",
                    templateUrl: '/app/module/user/views/products.html',
                    controller: 'homecntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("/checkout", {
                    url: "/checkout",
                    templateUrl: '/app/module/user/views/checkout.html',
                    controller: 'homecntrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/app/module/user/views/angularcontroller/controller.js',
                                ]
                            });
                        }]
                    }
                })
                .state("signout", {
                    url: "/signout",
                    templateUrl: '',
                    controller: 'signoutctrl',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/admin-client/controllers/signoutcontroller.js',
                                    '/assets/angularjs/css/angular-ui-notification.css'
                                ]
                            });
                        }]
                    }
                })
                .state("dashboard", {
                    url: "/dashboard",
                    templateUrl: '/admin-client/views/dashboard.html',
                    controller: 'DashboardController',
                    resolve: {
                        deps: ['$ocLazyLoad', function ($ocLazyLoad) {
                            return $ocLazyLoad.load({
                                name: 'myApp',
                                files: [
                                    '/admin-client/controllers/dashboardcontroller.js',
                                    '/assets/angularjs/css/angular-ui-notification.css',

                                    '/assets/admin/pages/css/dashboard.css',

                                    '/assets/admin/pages/css/tasks.css',
                                    '/assets/admin/pages/scripts/index3.js',
                                    '/assets/admin/pages/scripts/tasks.js',
                                ]
                            });
                        }]
                    }
                });
            $locationProvider.html5Mode({ enabled: true });
        }]);


    myApp.run(['$rootScope', '$state', '$http', '$location', '$rootElement', '$timeout',
        '$cookies',
        function ($rootScope, $state, $http, $location, $rootElement, $timeout, $cookies) {
                console.log("i m runing",$location.$$path);
            // $location.path($location.$$path);


        }])


})();





