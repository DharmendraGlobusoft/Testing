'use strict';
var myApp = angular.module('myApp');

myApp.controller('signcntrl', ['$scope', '$rootScope', '$state', '$http', '$location', '$cookies',
    '$stateParams', 'Notification', '$sce', function ($scope, $rootScope, $state, $http, $location, $cookies, $stateParams, Notification, $sce) {

        console.log('testing');
        $scope.signin = function (formdata) {

            // console.log("working")
            // console.log("email->",$scope.email)
            // console.log("password->",$scope.password)

        }


    }]);

myApp.controller('logincntrl', ['$scope', '$rootScope', '$state', '$http', '$location', '$cookies',
    '$stateParams', 'Notification', '$sce', function ($scope, $rootScope, $state, $http, $location, $cookies, $stateParams, Notification, $sce) {

        console.log('logincntrl');
        $scope.login = function (formdata) {
            console.log("working");
            console.log(formdata);

            $http.post('/login', formdata).success(function (response) {
                if (response.code == 200) {

                    console.log('========================');
                    console.log(response);


                    // sessionStorage.setItem("token", response.token);
                    // $state.go('dashboard', {});
                    // $rootScope.message = response.message; ///please sign in
                    // Notification.success({message: $rootScope.message, title: 'successful'});
                } else {
                    $rootScope.message = response.message;
                    Notification.error({message: $rootScope.message, title: 'successful'});
                }
            });
        }
    }]);

myApp.controller('contactcntrl', ['$scope', '$rootScope', '$state', '$http', '$location', '$cookies',
    '$stateParams', 'Notification', '$sce', function ($scope, $rootScope, $state, $http, $location, $cookies, $stateParams, Notification, $sce) {

        console.log('contactcntrl');

        $scope.getPageData=function () {

            $http.post('/contact').success(function (response) {
                if (response.code == 200) {

                    console.log('===========contact=============');
                    console.log('===========if=============');
                    console.log(response);


                    // sessionStorage.setItem("token", response.token);
                    // $state.go('dashboard', {});
                    // $rootScope.message = response.message; ///please sign in
                    // Notification.success({message: $rootScope.message, title: 'successful'});
                } else {
                    console.log('===========else=============');
                    $rootScope.message = response.message;
                    Notification.error({message: $rootScope.message, title: 'successful'});
                }
            });
            console.log("get data here");
            $scope.contacts="Dharmendra"
            // $scope.contacts={username:"saisanath"}

        };

        //init
        $scope.getPageData()


    }]);

myApp.controller('homecntrl', ['$scope', '$rootScope', '$state', '$http', '$location', '$cookies',
    '$stateParams', 'Notification', '$sce', function ($scope, $rootScope, $state, $http, $location, $cookies, $stateParams, Notification, $sce) {

        console.log('homecntrl');
        $scope.signin = function (formdata) {
            // console.log("working")
            // console.log("email->",$scope.email)
            // console.log("password->",$scope.password)

        }


    }]);


