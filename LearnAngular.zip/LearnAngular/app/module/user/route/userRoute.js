

var userController = require('../controller/userController.js');

const multer = require('multer');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/images/profilePic')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
var upload = multer({
    storage: storage
});


var myLogger = function (req, res, next) {
    // console.log('Check Session',req.session.success);
    if (req.session.success) {
        next();
    } else {
        res.redirect('/user');
    }
};

var express=require('express');
var router=express.Router();

router.get('/', function (req, res) {

    userController.landingPage(req, res);
});
// or; router.get('/test',userController.landingPage(req, res);

router.post('/login', function (req, res) {
    userController.logingPage(req, res);
});
router.post('/contact', function (req, res) {
    userController.contact(req, res);
});

router.get('*', function (req, res) {
    res.render('landing.ejs');
});




module.exports = router;