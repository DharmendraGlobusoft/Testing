var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');
var path=require('path');

var app = express();

app.use(session({
    secret: 'Sharma', // session secret
    resave: true,
    saveUninitialized: true
}));

// app.set('views', __dirname + '/app/module/User/view');   // this is used when only one module is there say only user
//
// app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/public'));
app.use('/app',express.static(__dirname + '/app'));

app.set('views', [__dirname + '/app/module/user/views', __dirname + '/app/module/admin/views']);

app.engine('ejs', require('ejs').__express);

app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


// var adminRoutes = require('./app/module/admin/route/adminRoutes.js');

var userRoutes = require('./app/module/user/route/userRoute.js');


app.use('/', userRoutes);
// app.use('/user', userRoutes);
// app.use('/admin', adminRoutes);

app.listen('8000', function (req, res) {
    console.log('Server started at', 'localhost:8000');
});

module.exports = app;